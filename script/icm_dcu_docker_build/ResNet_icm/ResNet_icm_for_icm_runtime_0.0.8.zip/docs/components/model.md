# 模型(Model)与模块（Module）

在训练深度学习任务时，我们通常需要定义一个模型来实现算法的主体。由于AlgICM的底座是基于不同深度学习框架实现的，所以在此进行一定约束。

*注：所有的模块与模型定义与实现，需基于框架自身提供的方法*
## 模块（module）

所有的神经网络模块应继承于 `BaseModule`, 并且覆写forward模型前馈的方法，与pytorch类似。

```python
import algicm.models.backend.nn as nn
import algicm.models.backend.functional as F
from algicm.models.backend.core import BaseModule

class ToyModule(BaseModule)
    def __init__(self):
        self.linear = nn.Linear(768, 10)

    def forward(self, x):
        return F.relu(self.linear(x))

```

## 模型（model）

所有的模型应继承于 `BaseModel`, 并且覆写forward、train_step、val_step、test_step与verify.

- forward: 该方法用于定义模型的前馈的方法，在forward方法中只实现模型前馈的方法。与tensor无关的操作不建议放在forward中进行，例如计算损失[`loss`]等相关的过程。虽然该约束非必须，但仍推荐按照此约束定义模型。
- train_step: 在模型训练中调用，输入参数为data_batch与[optim_wrapper](./optimizer.md),请在定义模型前阅读优化器相关文档。其中data_batch必须包含模型输入数据与标签，是 [data_preprocesser](##数据处理器)的输出。在train_step中计算损失，并以字典的方式进行返回。
- val_step: 在模型验证阶段调用，输入参数为data_batch,必须包含模型输入数据与标签。返回结果为模型推理的结果，结果以字典方式保存。
- test_step: 在模型测试与推理时调用：输入参数为data_batch,必须包含模型输入数据，可包含标签数据。在模型测试时调用该方法，返回模型预测结果与标签计算，用于指标计算。在模型推理时调用该方法，仅返回模型预测结果，结果与字典方式保存。
- verify（可选）: 在模型构建时调用，用于检测数据与模型的正确性。

``` python
import algicm.models.backend.nn as nn
import algicm.models.backend.functional as F
from algicm.models.backend.core import BaseModel

class ToyNet(BaseModel):
    def __init__(self):
        self.toy_module = ToyModule()


    def forward(self, x):
        return self.toy_module(x)

    def train_step(self, data_batch, optim_wrapper):

        with optim_wrapper.optim_context(self):
            # collect to batch and convert to tensor.
            data_batch = self.data_preprocessor(data_batch, True)
            data, labels = data_batch["data"], data_batch["labels"]
            # Run forward function
            predictions = self(**data) 
            # Function or module to compute loss
            loss = fn(predictions, labels) 

        # Compute loss and get str obj to print
        # parsed_losses: dict of tensor used to update weights.
        # log_vars: dict of float used to show in the console.
        parsed_losses, log_vars = self.parse_losses(dict(loss=loss)) 
        # Two steps:  gradients computation and weights updattion.
        optim_wrapper.update_params(parsed_losses) 
        return log_vars

    def val_step(self, data_batch):
        # process data
        data_batch = self.data_preprocessor(data_batch, False)
        data, labels = data_batch["data"], data_batch["labels"]
        # Run forward function
        predictions = self(**data) 
        # wrap output and labels to numpy obj
        output = dict(
            preds=F.convert_to_numpy(predictions), labels=F.convert_to_numpy(labels)
        )
        return output

    def test_step(self, data_batch):
        # process data
        data_batch = self.data_preprocessor(data_batch, False)
        # labels is None, if not pass into dataset.
        data, labels = data_batch["data"], data_batch.get("labels",None)
        # Run forward function
        predictions = self(**data) 
        # wrap output and labels to numpy obj
        output = dict(
            preds=F.convert_to_numpy(predictions)
        )
        if labels is not None:
            output.update(dict(labels=F.convert_to_numpy(labels)))
        return output

    def verify(self, data_batch):
        # process data
        data_batch = self.data_preprocessor(data_batch, False)
        data, labels = data_batch["data"], data_batch["labels"]
        # Run forward function
        predictions = self(**data) 
```

## 数据处理器

数据处理器通常将一个Batch的数据进行聚合，并将数据移动到指定的硬件设备上（比如：GPU）。数据处理器实现了 `BaseDataPreprocessor`, 可以通过继承的方式覆写相关处理操作，也可以直接使用。同样的，`BaseDataPreprocessor`继承于 `BaseModule`，以便于将数据移动到与模型相同的设备上。

`BaseDataPreprocessor`初始化时需要指定进行的数据处理操作，通常该步骤进行`Stack`操作，即将多个进程中收集的数据聚合成一个批次的输入,即在初始化时，将`Stack`数据处理方法传入。

[数据处理](./transform.md)方法请参考相关文件。

- forward: 输入为list[dict,...], 输出为dict。执行两步操作：（1）进行数据处理操作，通常使用`Stack`方法将一个batch的数据进行聚合。（2）使用`cast_data`将数据转为tensor,再移动到指定设备。
- cast_data: 通过遍历字典，将所有的numpy.ndarray数据转换为tensor，并移动到指定设备上。

可以自定义不同的处理方法,以适应不同的场景。

``` python
class NormalizeDataPreprocessor(BaseDataPreprocessor):
    def forward(self, data, training=False):
        data = super().forward(data, training=False)
        data["img"] = (data["img"] - 127.5) / 127.5
        return data
```



