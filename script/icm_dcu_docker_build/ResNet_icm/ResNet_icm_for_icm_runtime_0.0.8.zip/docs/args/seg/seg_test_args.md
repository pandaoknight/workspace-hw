# 目标分割_Unet算子评估全参数配置详细介绍

  
``` json

{
    "backend": "torch", 
    //backend：后端训练框架,可更改类型，目前支持torch,tensorflow
    "test_dataloader": {
    //测试数据集加载器配置
        "batch_size": 1, 
        //batch_size: 每批次训练的图像数量，评估时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1, 
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler", 
            // type: 指定数据采样策略的类型。这里使用 DefaultSampler（默认采样器）
            "shuffle": false 
            // shuffle: 决定是否在加载前对数据进行随机筛选。设置为 false，表示不随机。一般在验证和评估时选择不随机
        },
        "dataset": {
        //数据集参数配置
            "type": "SegDataset", 
            // 数据集类型为SegDataset（语义分割数据集），默认固定
            "data_root": "ball_seg_val", 
            // 数据集的根目录
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage" 
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData", 
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                        "img": "Image", 
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_seg": "Polygon", 
                        //gt_seg：Polygon，将gt_seg标签封装进Polygon类中，默认固定
                        "gt_seg_labels": "ClassLabel" 
                        //gt_seg_labels：ClassLabel，将gt_seg_labels标签封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "PolygonsToMask" 
                    // 将多边形分割标签转换为掩码
                },
                {
                    "type": "ConvertDataType", 
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32" 
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [640,640] 
                    //size: 图片调整后的尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [123.675, 116.28, 103.53], 
                    //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                    "std": [58.395, 57.12, 57.375] 
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                },
                {
                    "type": "TransposeImage", 
                    //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                    "axes": [2, 0, 1] 
                    //axes: shape序列号，默认固定
                }
            ]
        }
    },
    "test_cfg": {
    //测试参数配置
        "type": "TestLoop", 
        // 使用TestLoop进行测试，默认固定
        "evaluator": {
        //评估器参数配置
            "type": "Evaluator", 
            // 使用Evaluator进行评估，默认固定
            "metrics": [
            //评估参数配置
                {
                    "type": "SegMetric" 
                    // 使用SegMetric进行语义分割评估，默认固定
                }
            ]
        }
    },
    "default_hooks": {
    //默认钩子设置
        "logger": {
            "type": "LoggerHook", 
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 2 
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义。
        },
        "saver": {
        //保存参数配置
            "type": "OutputSaveHook", 
            // 使用OutputSaveHook保存输出结果，默认固定
            "formatter": {
            //格式化器配置
                "type": "ImageSegOutputFormatter" 
                // 使用ImageSegOutputFormatter格式化输出结果，默认固定
            }
        }
    },
    "load_from": "work_dir/test_unet/best_mean_IoU_epoch_13.pth", 
    // 加载模型的权重路径
    "pre_formatter": [
    //预处理格式化器参数配置
        {
            "type": "HttpImageReader" 
            // 使用HttpImageReader作为预处理格式化器，默认为固定
        }
    ],
    "post_formatter": [
    //发送格式化器参数配置
        {
            "type": "HttpImageSegFormatter" 
            // 使用HttpImageSegFormatter作为后处理格式化器，默认固定
        }
    ]
}