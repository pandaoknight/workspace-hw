# 目标分割_Unet算子训练全参数配置详细介绍
## 说明：1、因算法模型与预训练模型存在强关联，故算法模型本身参数可调整范围有限。2、在训练时建议加载预训练模型，可大大提升模型训练效果，节约训练时间
``` json
{
    "backend": "torch",
    //backend：后端训练框架,可更改类型，目前支持torch,tensorflow
    "model": {
    //model:定义算法模型
        "type": "EncoderDecoder",
        //type：算法模型名称,不可更改类型，默认固定
        "data_preprocessor": {
        //data_preprocessor：数据进入模型前的预处理
            "type": "BaseDataProcessor",
            //type：预处理方式，不可更改类型，默认固定
            "batch_preprocess": [
            //batch_preprocess：数据拼接操作
                {
                    "type": "Stack",
                    //type：拼接方式Stack，默认固定
                    "meta_keys": [
                    //meta_keys：需要拼接的对象，默认固定
                        "img",
                        //img：图片
                        "gt_seg"
                        //gt_seg：分割标注
                    ]
                 
                }
            ]
        },
        "backbone": {
        //backbone：模型主干网络定义
            "type": "UNet",
            //type：模型主干网络名称，默认固定，暂时不支持其他的backbone
            "in_channels": 3,
            //in_channels: 输入图像的通道数，一般为的RGB三通道图像，即为3
            "base_channels": 64,
            //base_channels: 模型的基础通道数量，跟预训练绑定，默认固定  
            "num_stages": 5,
            //num_stages: 将模型分成多个阶段的数量，跟预训练绑定，默认固定  
            "strides": [
                1,
                1,
                1,
                1,
                1
            ],
            //strides: 模型中卷积层卷积核滑动的步长 跟预训练绑定，默认固定         
            "enc_num_convs": [
                2,
                2,
                2,
                2,
                2
            ],
            //enc_num_convs: 模型中编码器部分的卷积层数量  跟预训练绑定，默认固定           
            "dec_num_convs": [
                2,
                2,
                2,
                2
            ],
            //dec_num_convs: 模型中解码器部分的卷积层数量  跟预训练绑定，默认固定  
            "downsamples": [
                true,
                true,
                true,
                true
            ],
            //downsamples: 模型中每一个编码器是否进行下采样操作 跟预训练绑定，默认固定  
            "enc_dilations": [
                1,
                1,
                1,
                1,
                1
            ],
            //enc_dilations: 模型中每一个编码器的扩张率，扩张率代表卷积核在输入上跳过的像素数量 跟预训练绑定，默认固定  
            "dec_dilations": [
                1,
                1,
                1,
                1
            ],
            //dec_dilations: 模型中每一个解码器的扩张率，扩张率代表卷积核在输入上跳过的像素数量 跟预训练绑定，默认固定  
            "norm_cfg": {
            //norm_cfg: 模型中归一化层的参数
                "type": "BN2d",
                //type：批量归一化类型，暂时只支持BN2d
                "momentum": 0.03,
                //momentum 动量系数 决定运行平均和样本平均的权重。
                //建议取值范围0.1~0.9
                "eps": 0.001
                //epsilon eps常数 以防止除以0发生。
                //建议取值范围1e-5~0.1
            },
            
            "act_cfg": {
            //激活函数配置
                "type": "ReLU"
                //type：激活函数类型，可选择参数，
                //常用的激活函数有ReLU，ELU，ReLU6，LeakyReLU，Swish等
            },
            "upsample_cfg": {
                "type": "InterpConv"
            },
            //upsample_cfg: 上采样配置，采用了卷积插值 ，默认固定
            "norm_eval": false
            //norm_eval: 在验证阶段是否使用不同的统计信息 默认False
        },
        "decode_head": {
        //decode_head: 解码头参数配置
            "type": "FCNHead",
            //type: 解码头类型
            "in_channels": 64,
            //in_channels: 解码头输入通道数量，默认固定
            "in_index": 4,
            //in_index: 解码头输入特征图索引 默认固定
            "channels": 64,
            //channels: 解码头通道数 默认固定
            "num_convs": 1,
            //num_convs: 解码头卷积层数量 默认固定
            "concat_input": false,
            //concat_input: 是否需要对输入进行拼接 默认固定
            "dropout_ratio": 0.1,
            //dropout_ratio: 解码头丢弃率，可调整参数范围0~0.99
            "norm_cfg": {
            //norm_cfg: 解码头中归一化层的参数
                "type": "BN2d",
                //type：批量归一化类型，暂时只支持BN2d
                "momentum": 0.03,
                //momentum 动量系数 决定运行平均和样本平均的权重。
                //建议取值范围0.1~0.9
                "eps": 0.001
                //epsilon eps常数 以防止除以0发生。
                //建议取值范围1e-5~0.1
            },
            
            "align_corners": false,
            //align_corners: 解码头中是否对角进行对齐，默认false
            "loss_decode": {
            //loss_decode: 模型中解码头使用的损失函数和其参数
                "type": "CrossEntropyLoss",
                //type: 损失函数类型
                "use_sigmoid": false,
                //use_sigmoid：是否使用sigmoid进行归一化，如果训练集类别只有单类别
                //可设置为True，大于1类设置为False
                "loss_weight": 1.0
                //损失函数权重占比，默认为1，建议范围0~4
            }
        },
        "auxiliary_head": {
        //auxiliary_head: 辅助头参数配置
            "type": "FCNHead",
            //type: 辅助头类型，默认固定
            "in_channels": 128,
            //type: 辅助头输入通道数，默认固定
            "in_index": 3, 
            //辅助头输入特征索引，默认固定
            "channels": 64, 
            //辅助头通道数，默认固定
            "num_convs": 1, 
            //辅助头卷积层数量，默认固定
            "concat_input": false, 
            //是否需要对输入进行拼接，默认固定
            "dropout_ratio": 0.1, 
            //辅助头丢弃率，可调整参数范围0~0.99
            "norm_cfg": { 
            //norm_cfg: 解码头中归一化层的参数
                "type": "BN2d",
                //type：批量归一化类型，暂时只支持BN2d
                "momentum": 0.03,
                //momentum 动量系数 决定运行平均和样本平均的权重。
                //建议取值范围0.1~0.9
                "eps": 0.001
                //epsilon eps常数 以防止除以0发生。
                //建议取值范围1e-5~0.1
            },
            "align_corners": false, 
            //辅助头中是否对角进行对齐，默认为false
            "loss_decode": { 
                //模型中辅助头使用的损失函数和其参数
                "type": "CrossEntropyLoss",
                //type: 损失函数类型 默认固定
                "use_sigmoid": false,
                //use_sigmoid：是否使用sigmoid进行归一化，如果训练集类别只有单类别
                //可设置为True，大于1类设置为False
                "loss_weight": 0.4
                //损失函数权重占比，默认为0.4，建议范围0~4
            }
        },
        "train_cfg": {}, 
        //训练相关参数配置
        "test_cfg": { 
            //测试相关参数配置
            "mode": "whole"
            //支持whole整图推理和slice切片推理
        }
    },
    "work_dir": "work_dir/test_unet", 
    //工作目录路径
    "train_dataloader": { 
        //训练集数据加载器参数配置
        "batch_size": 2, 
        //batch_size: 每批次训练的数量，建议填写为偶数，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1, 
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": { 
        //数据采样器
            "type": "DefaultSampler",
            //使用默认数据采样器
            "shuffle": true 
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "SegDataset", 
            // 数据集类型为SegDataset，用于语义分割任务
            "data_root": "ball_seg", 
            // 数据集的根目录
            "pipelines": [ 
                //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage" 
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData", 
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                        "img": "Image", 
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_seg": "Polygon", 
                        //gt_seg：Polygon，将gt_seg标签封装进Polygon类中，默认固定
                        "gt_seg_labels": "ClassLabel" 
                        //gt_seg_labels：ClassLabel，将gt_seg_labels标签封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "PolygonsToMask" 
                    // 将多边形分割标签转换成掩膜形式
                },
                {
                    "type": "ConvertDataType", 
                    // 转换数据类型
                    "mapping": {
                        "img": "float32" 
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] 
                    //size: 图片调整后的尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "RandomFlip", 
                    //type: 数据集处理方法类型, RandomFlip为随机翻转，默认固定
                    "p": 0.5, 
                    //p: 执行随机翻转操作的概率，可选填参数，0~1之间
                    "direction": "horizontal" 
                    //direction：随机翻转的方向，可选填参数vertical垂直翻转，diagonal对角翻转，horizontal水平翻转
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        123.675,
                        116.28,
                        103.53
                    ], //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按上面的参数填写
                    "std": [
                        58.395,
                        57.12,
                        57.375
                    ] //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按上面的参数填写
                },
                {
                    "type": "TransposeImage", 
                    //type: 数据集处理方法类型，TransposeImage为shape顺序调整处理，默认固定
                    "axes": [
                        2,
                        0,
                        1
                    ] //axes: shape序列号，默认固定
                }
            ]
        }
    },
    "val_dataloader": {
    //验证集数据加载器配置
        "batch_size": 1, 
        //batch_size: 每批次训练的图像数量，验证时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1, 
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler", 
            // type: 指定数据采样策略的类型。这里使用 DefaultSampler（默认采样器）。
            "shuffle": false 
            // shuffle: 决定是否在加载前对数据进行随机筛选。设置为 false，表示不随机。一般在验证和评估时选择不随机
        },
        "dataset": {
            "type": "SegDataset", 
            // 数据集类型为SegDataset，用于语义分割任务
            "data_root": "ball_seg_val", 
            // 数据集的根目录
            "pipelines": [ 
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage" 
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData", 
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                    //封装数据
                        "img": "Image", 
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_seg": "Polygon", 
                        //gt_seg：Polygon，将gt_seg标签封装进Polygon类中，默认固定
                        "gt_seg_labels": "ClassLabel" 
                        //gt_seg_labels：ClassLabel，将gt_seg_labels标签封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "PolygonsToMask" 
                    // 将多边形分割标签转换成掩膜形式
                },
                {
                    "type": "ConvertDataType", 
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32" 
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] //size: 图片重采样结果尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        123.675,
                        116.28,
                        103.53
                    ], //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                    "std": [
                        58.395,
                        57.12,
                        57.375
                    ] //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                },
                {
                    "type": "TransposeImage", //type: 数据集处理方法类型，TransposeImage为图像通道顺序调整处理，默认固定
                    "axes": [
                        2,
                        0,
                        1
                    ] //axes: 通道序列号，默认固定
                }
            ]
        }
    },
    "test_dataloader": {
    //测试数据集加载器参数配置
        "batch_size": 1, 
        //batch_size: 每批次训练的图像数量，验证时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1, 
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler", 
            //sampler: 对数据集进行样本采样
            "shuffle": false 
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "SegDataset", 
            // 数据集类型为SegDataset，用于语义分割任务
            "data_root": "ball_seg_val", 
            // 数据集的根目录
            "pipelines": [ 
             //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage" 
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData", 
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                        "img": "Image", 
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_seg": "Polygon", 
                        //gt_seg：ClassLabel，将gt_seg标签封装进Polygon类中，默认固定
                        "gt_seg_labels": "ClassLabel" 
                        //gt_seg_labels：ClassLabel，将gt_seg_labels标签封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "PolygonsToMask" 
                    // 将多边形分割标签转换成掩膜形式
                },
                {
                    "type": "ConvertDataType", 
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32" 
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] //size: 图片重采样结果尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        123.675,
                        116.28,
                        103.53
                    ], //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                    "std": [
                        58.395,
                        57.12,
                        57.375
                    ] //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                },
                {
                    "type": "TransposeImage", 
                    //type: 数据集处理方法类型，TransposeImage为shape顺序调整处理，默认固定
                    "axes": [
                        2,
                        0,
                        1
                    ] //axes: shape序列号，默认固定
                }
            ]
        }
    },
    "test_cfg": {
    //测试时参数配置
        "type": "TestLoop", 
        // 测试循环类型为TestLoop，默认固定
        "evaluator": {
            "type": "Evaluator", 
            // 评估器类型为Evaluator，默认固定
            "metrics": [
            //评估使用的参数
                {
                    "type": "SegMetric" 
                    // 使用SegMetric进行评估（语义分割任务），默认固定
                }
            ]
        }
    },
    "train_cfg": {
    //训练时参数配置
        "type": "EpochBasedTrainLoop", 
        // type: 训练循环的类型，这里是按照 epoch 进行训练的，默认固定 
        "max_epochs": 30, 
        // max_epochs: 最大训练周期数，可设置范围从1到任意值，根据模型收敛情况决定，建议30到50轮左右填写
        "val_begin": 1, 
        // val_begin: 开始进行验证的训练周期数，根据实际情况决定，可设置范围从1到模型最大训练周期数，
        //建议从1开始填写
        "val_interval": 1 
        // val_interval: 进行验证的周期间隔，每隔一个周期进行一次验证，视实际情况决定，建议每个轮次都验证一次设置为1。
    },
    "val_cfg": {
    //验证时参数配置
        "type": "ValLoop", 
        // type: 验证模式循环类型， "ValLoop"，默认固定参数
        "evaluator": {
            "type": "Evaluator", 
            // 评估器类型为Evaluator
            "metrics": [
            //评估器使用的参数
                {
                    "type": "SegMetric" 
                    // 使用SegMetric进行评估（语义分割任务）
                }
            ]
        }
    },
    "optimizer": {
    //优化器参数配置
        "type": "SGD", 
        // type: 优化器的类型，这里是随机梯度下降（SGD）优化器。图片分割建议用SGD
        "lr": 0.01, 
        // lr: 学习率，可设置范围建议0.01~0.00001之间。
        "momentum": 0.9, 
        // momentum: 动量参数，建议设置为 0.9。
        "weight_decay": 0.0001 
        // weight_decay: 权重衰减参数，建议设置为 0.0001，用于控制模型参数的正则化。
    },
    "experiment_name": "test_voc", 
    // experiment_name: 实验名称，根据具体实验进行设置。
    "default_hooks": {
    //钩子参数配置
        "checkpoint": {
            "type": "CheckpointHook", 
            // type: CheckpointHook，模型权重保存钩子函数，默认固定
            "save_best": "mean_IoU", 
            // save_best: 检查点回调函数保存最佳模型，以 "mean_IoU" 为标准。默认固定
            "by_epoch": true 
            // by_epoch: 标志，表示以 epoch 为单位进行检查点保存，建议填写为true，默认固定。
        },
        "logger": {
        //日志参数配置
            "type": "LoggerHook", 
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 2 
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义。
        }
    },
    "randomness": {
    //随机化配置
        "seed": 123 
        // seed: 随机数生成器的种子，设置为 123，可设置范围很大，这里默认为123 可不做修改。
    }
}