# 目标检测_Yolov5算子评估全参数配置详细介绍

  
``` json
{
    "backend": "torch",
    //backend：后端框架,可更改类型，目前支持torch,tensorflow
    "work_dir": "work_dir/test_yolov5",
    //工作目录路径
    "test_dataloader": {
    //评估数据集加载器参数配置
        "batch_size": 1,
        //batch_size: 每批次训练的图像数量，评估时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler",
            //sampler: 对数据集进行样本采样
            "shuffle": false
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "DetDataset",
            // 数据集类型为DetDataset，用于目标检测任务
            "data_root": "obj_ball_val",
            // 数据集的根目录
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_bboxes": "BoxArray",
                        //gt_bboxes：BoxArray，将gt_bboxes封装进BoxArray类中，默认固定
                        "gt_bboxes_labels": "ClassLabel"
                        //gt_bboxes_labels：ClassLabel，将gt_bboxes_labels图片封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] //size: 图片重采样结果尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        0.0,
                        0.0,
                        0.0
                    ],//mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                    "std": [
                        255.0,
                        255.0,
                        255.0
                    ]//std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                },
                {
                    "type": "TransposeImage",
                    //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                    "axes": [
                        2,
                        0,
                        1
                    ]
                    //axes: shape序列号，默认固定
                }
            ]
        }
    },
    "test_cfg": {
    //测试时参数配置
        "type": "TestLoop",
        // 测试循环类型为TestLoop，默认固定
        "evaluator": {
            "type": "Evaluator",
            // 评估器类型为Evaluator，默认固定
            "metrics": [
            //评估使用的参数
                {
                    "type": "COCOMetric"
                    // 使用COCOMetric进行评估（图像检测任务），默认固定
                }
            ]
        }
    },
    "experiment_name": "test_voc",
    // experiment_name: 实验名称，根据具体实验进行设置。
    "default_hooks": {
    //钩子参数配置
        "logger": {
        //日志参数配置
            "type": "LoggerHook",
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 2
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义
        },
        "saver": {
            "type": "OutputSaveHook",
            //输出钩子函数，默认固定
            "formatter": {
                "type": "ImageDetOutputFormatter"
                //图片输出格式调整，默认固定
            }
        },
        "kafka": {
            "interval": 1,
            // interval: Kafka 回调函数的触发间隔，每 1 个周期触发一次，根据实际情况填写。
            "type": "TransferStationHook",
            // type: Kafka 回调函数的类型，默认固定。
            "name": "kafka",
            // name: Kafka 回调函数的名称，默认固定。
            "kafka_address": "kafka.icaplat-sit.svc.cluster.local:19092",
            // kafka_address: Kafka 服务器的地址，根据实际情况填写。
            "task_id": "35",
            // task_id: 任务 ID，根据实际情况填写。
            "topic": "alg_train_visual-automodel",
            // topic: Kafka 主题，用于发布训练可视化信息，根据实际情况填写。
            "work_dir": "output/models"
            // work_dir: 工作目录，根据实际情况填写。
        }
    },
    "load_from": "work_dir/test_yolov5/epoch_8.pth",
    //加载模型权重进行评估
    "randomness": {
    //随机化配置
        "seed": 123
        // seed: 随机数生成器的种子，设置为 123，可设置范围很大，这里默认为123 可不做修改。
    }
}