# 目标检测_Yolov5算子推理全参数配置详细介绍

  
``` json
{
    "service": {
        "ip": "0.0.0.0",
        //ip: 算法接口的ip地址，默认0.0.0.0
        "port": 18081,
        //port: 算法接口的端口号，按需求填写
        "urls": "/infer"
        //urls：算法接口后缀的地址，按需求填写
    },
    "datasets": {
    //数据集参数配置
        "type": "DetDataset",
        //type：数据集的类型，分类任务默认为DetDataset
        "pipelines": [
        //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
            {
                "type": "LoadImage"
                //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
            },
            {
                "type": "WrapData",
                //type: 数据集处理方法类型，默认固定
                "mapping": {
                    "img": "Image"
                    //img：Image，将img图片封装进Image类中，默认固定
                }
            },
            {
                "type": "ConvertDataType",
                //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                "mapping": {
                    "img": "float32"
                    //img: 图片类型转换类别，float32为32位浮点型，建议采用float32
                }
            },
            {
                "type": "Resize",
                // 调整图像尺寸
                "size": [
                    640,
                    640
                ]
                //size: 图片调整后的结果尺寸，默认为640*640
                //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                //在推理时，建议和训练时采用的resize尺寸相同
            },
            {
                "type": "Normalize",
                //type: 数据集处理方法类型, Normalize为图像标准化处理
                "mean": [
                //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                //建议按下面的参数填写
                    0.0,
                    0.0,
                    0.0
                ],
                "std": [
                //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                //建议按下面的参数填写
                    255.0,
                    255.0,
                    255.0
                ]
            },
            {
                "type": "TransposeImage",
                //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                "axes": [
                //axes: 通道序列号，默认固定
                    2,
                    0,
                    1
                ]
            }
        ]
    },
    "load_from": "work_dir/test_yolov5/best_mAP_epoch_20.pth",
    // load_from: 模型加载的文件路径，加载训练好的模型文件。
    "pre_formatter": [
        {
            "type": "HttpImageReader"
            // 使用HttpImageReader作为预处理格式化器,默认固定
        }
    ],
    "post_formatter": [
        {
            "type": "HttpImageDetFormatter"
            // 使用HttpImageDetFormatter作为后处理格式化器,默认固定
        }
    ]
}