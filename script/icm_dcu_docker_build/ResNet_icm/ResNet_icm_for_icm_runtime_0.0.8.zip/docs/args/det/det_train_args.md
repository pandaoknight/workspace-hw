# 目标检测_Yolov5算子训练全参数配置详细介绍
## 说明：1、因算法模型与预训练模型存在强关联，故算法模型本身参数可调整范围有限。2、在训练时建议加载预训练模型，可大大提升模型训练效果，节约训练时间
``` json
{
    "backend": "torch", 
    //backend：后端框架,可更改类型，目前支持torch,tensorflow
    "model": {
    //model:定义算法模型
        "type": "YOLODetector",
        //type：算法模型名称,不可更改类型，默认固定
        "data_preprocessor": {
        //data_preprocessor：数据进入模型前的预处理
            "type": "BaseDataProcessor",
            //type：预处理方式，不可更改类型，默认固定
            "batch_preprocess": [
            //batch_preprocess：数据拼接操作
                {
                    "type": "Stack"
                    //type：拼接方式Stack，默认固定
                }
            ]
        },
        "backbone": {
        //backbone：模型主干网络定义
            "type": "YOLOv5CSPDarknet",
            //type：模型主干网络名称，默认固定，暂时不支持其他的backbone
            "deepen_factor": 0.33,
            //deepen_factor：控制模型大小的深度参数，在不加载预训练的时候可改
            //在加载预训练时需按照预训练指定参数填写
            //范围0.33~1.33
            "widen_factor": 0.5,
            //widen_factor：控制模型大小的宽度参数，在不加载预训练的时候可改
            //在加载预训练时需按照预训练指定参数填写
            //范围0.5~1
            "norm_cfg": {
            //norm_cfg：归一化参数配置
                "type": "BN2d",
                //type：批量归一化类型，暂时只支持BN2d
                "momentum": 0.03,
                //momentum 动量系数 决定运行平均和样本平均的权重。
                //建议取值范围0.1~0.9
                "eps": 0.001
                //epsilon eps常数 以防止除以0发生。
                //建议取值范围1e-5~0.1
            },
            "act_cfg": {
            //激活函数配置
                "type": "SiLU"
                //type：激活函数类型，可选择参数，
                //常用的激活函数有ReLU，ELU，ReLU6，LeakyReLU，Swish等
                //建议在yolov5中选择SiLU作为激活函数
            },
            "frozen_stages": 4
            //frozen_stages：冻结主干网络参数
            //在训练小样本任务并且加载了预训练权重时建议冻结
            //建议范围1~4
        },
        "neck": {
        //颈部网络参数配置
            "type": "YOLOv5PAFPN",
            //type：模型主干网络名称，默认固定，暂时不支持其他的颈部网络
            "deepen_factor": 0.33,
            //deepen_factor：控制模型大小的深度参数，在不加载预训练的时候可改
            //在加载预训练时需按照预训练指定参数填写
            //范围0.33~1.33
            "widen_factor": 0.5,
            //widen_factor：控制模型大小的宽度参数，在不加载预训练的时候可改
            //在加载预训练时需按照预训练指定参数填写
            //范围0.5~1
            "in_channels": [
                256,
                512,
                1024
            ],
            //in_channels：控制输入颈部网络的通道大小，建议默认
            "out_channels": [
                256,
                512,
                1024
            ],
            //in_channels：控制输出颈部网络的通道大小，建议默认
            "num_csp_blocks": 3,
            //num_csp_blocks：CSP网络模块循环数量，在加载预训练参数时默认为3
            "norm_cfg": {
            //norm_cfg：归一化参数配置
                "type": "BN2d",
                //type：批量归一化类型，暂时只支持BN2d
                "momentum": 0.03,
                //momentum 动量系数 决定运行平均和样本平均的权重。
                //建议取值范围0.1~0.9
                "eps": 0.001
                //epsilon eps常数 以防止除以0发生。
                //建议取值范围1e-5~0.1
            },
            "act_cfg": {
            //激活函数配置
                "type": "SiLU"
                //type：激活函数类型，可选择参数，
                //常用的激活函数有ReLU，ELU，ReLU6，LeakyReLU，Swish等
                //建议在yolov5中选择SiLU作为激活函数
            },
        },
        "head": {
        //head：检测头参数配置
            "type": "YOLOv5Head",
            //type：YOLOV5检测头类型，默认参数，暂时不支持别的检测头建议固定
            "head_module": {
            //head_module：检测头模块配置
                "type": "YOLOv5HeadModule",
                //type：YOLOV5检测头模块配置
                "in_channels": [
                    256,
                    512,
                    1024
                ],
                //in_channels：控制输入头部网络的通道大小，建议默认
                "widen_factor": 0.5,
                //宽度因子：0.5 与预训练挂钩 建议默认
                "featmap_strides": [
                    8,
                    16,
                    32
                ],
                //featmap_strides：下采样倍率，建议默认
                "num_base_priors": 3
                //num_base_priors：每个Cell生成先验框的数量，默认为3，建议默认为3 
            },
            "prior_generator": {
                "type": "YOLOAnchorGenerator",
                "base_sizes": [
                    [
                        [
                            10,
                            13
                        ],
                        [
                            16,
                            30
                        ],
                        [
                            33,
                            23
                        ]
                    ],
                    [
                        [
                            30,
                            61
                        ],
                        [
                            62,
                            45
                        ],
                        [
                            59,
                            119
                        ]
                    ],
                    [
                        [
                            116,
                            90
                        ],
                        [
                            156,
                            198
                        ],
                        [
                            373,
                            326
                        ]
                    ]
                ],
                //针对3种不同的下采样尺度，会生成3类先验框，每类先验框有3种不同的宽高，这里建议默认，如需更改可适当根据目标数据集进行调整，调大或者调小。
                "strides": [
                    8,
                    16,
                    32
                ]
                //下采样倍率，建议默认
            },
            "loss_cls": {
                "type": "CrossEntropyLoss",
                //type: 损失函数类型，默认固定
                "use_sigmoid": false,
                //use_sigmoid：是否使用sigmoid进行归一化，如果训练集类别只有单类别
                //可设置为True，大于1类设置为False
                "reduction": "mean",
                //损失函数汇总方式，默认为mean按平均数汇总，可选sum按加法汇总
                "loss_weight": 0.5
                //损失函数权重占比，默认为1，建议范围0~4
            },
            "loss_bbox": {
                "type": "IoULoss",
                //type: 损失函数类型，默认固定
                "iou_mode": "ciou",
                //iou损失函数类型可选填ciou,giou和siou
                "bbox_format": "xywh",
                //输入box的格式 默认xywh，可选xyxy
                "eps": 1e-07,
                //偏置参数，默认1e-07
                "reduction": "mean",
                //损失函数汇总方式，默认为mean按平均数汇总，可选sum按加法汇总
                "loss_weight": 0.05,
                //损失函数权重占比，默认为0.05，建议范围0~4
                "return_iou": true
            },
            "loss_obj": {
                "type": "CrossEntropyLoss",
                //type: 损失函数类型，默认固定
                "use_sigmoid": true,
                //use_sigmoid：是否使用sigmoid进行归一化，如果训练集类别只有单类别
                //可设置为True，大于1类设置为False
                "reduction": "mean",
                //损失函数汇总方式，默认为mean按平均数汇总，可选sum按加法汇总
                "loss_weight": 1.0
                //损失函数权重占比，默认为1，建议范围0~4
            },
            "prior_match_thr": 4.0,
            //最大anchor长宽比例，默认固定参数，建议不更改
            "obj_level_weights": [
                4.0,
                1.0,
                0.4
            ]
            //loss值系数，建议默认
        },
        "test_cfg": {
            "multi_label": true,
            //是否为单分类，如果是则为false，如果不是则为true
            "nms_pre": 2000,
            //在做nms操作前按topk筛选，加速nms，2000为默认值，建议范围500~2000      
            "score_thr": 0.3,
            //根据输出的confidence保留nms结果，大于0.3才保留，可选范围0~1
            "nms": {
                "type": "nms",
                //nms：非极大值抑制，默认固定
                "iou_threshold": 0.3
                //iou阈值，值越接近1则保留的框越多（iou大于阈值的滤除）反之成立
            },
            "max_per_img": 300
            //nms结束后最多保留的框的数量，可选范围100~500 建议固定

        }
    },
    "work_dir": "work_dir/test_yolov5",
    //工作目录路径
    "train_dataloader": {
    //训练集数据加载器参数配置
        "batch_size": 2,
        //batch_size: 每批次训练的数量，建议填写为偶数，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
        //数据采样器
            "type": "DefaultSampler",
            //使用默认数据采样器
            "shuffle": true
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "DetDataset",
            // 数据集类型为DetDataset，用于图像检测任务
            "data_root": "obj_ball",
            // 数据集的根目录
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_bboxes": "BoxArray",
                        //gt_bboxes：BoxArray，将gt_bboxes标签封装进BoxArray类中，默认固定
                        "gt_bboxes_labels": "ClassLabel"
                        //gt_bboxes_labels：ClassLabel，将gt_bboxes_labels标签封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    // 转换数据类型，默认固定
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Mosaic",
                    //马赛克数据增强，将多张图拼接成一张图训练
                    "pre_transform": [
                        {
                            "type": "LoadImage"
                            //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                        },
                        {
                            "type": "WrapData",
                            //type: 数据集处理方法类型，默认固定
                            "mapping": {
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_bboxes": "BoxArray",
                        //gt_bboxes：BoxArray，将gt_bboxes标签封装进BoxArray类中，默认固定
                        "gt_bboxes_labels": "ClassLabel"
                        //gt_bboxes_labels：ClassLabel，将gt_bboxes_labels标签封装进ClassLabel类中，默认固定
                    }
                        },
                        {
                            "type": "ConvertDataType",
                    // 转换数据类型，默认固定
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                        }
                    ]
                },
                
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] 
                    //size: 图片调整后的尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "RandomFlip", 
                    //type: 数据集处理方法类型, RandomFlip为随机翻转，默认固定
                    "p": 0.5, 
                    //p: 执行随机翻转操作的概率，可选填参数，0~1之间
                    "direction": "horizontal" 
                    //direction：随机翻转的方向，可选填参数vertical垂直翻转，diagonal对角翻转，horizontal水平翻转
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        0.0,
                        0.0,
                        0.0
                    ],//mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按上面的参数填写
                    "std": [
                        255.0,
                        255.0,
                        255.0
                    ]
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按上面的参数填写
                },
                {
                    "type": "TransposeImage", 
                    //type: 数据集处理方法类型，TransposeImage为shape顺序调整处理，默认固定
                    "axes": [
                        2,
                        0,
                        1
                    ] //axes: shape序列号，默认固定
                }
            ]
        }
    },
    "val_dataloader": {
    //验证集数据加载器配置
        "batch_size": 1,
        //batch_size: 每批次训练的图像数量，验证时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler",
            // type: 指定数据采样策略的类型。这里使用 DefaultSampler（默认采样器）
            "shuffle": false
            // shuffle: 决定是否在加载前对数据进行随机筛选。设置为 false，表示不随机。一般在验证和评估时选择不随机
        },
        "dataset": {
            "type": "DetDataset",
            // 数据集类型为DetDataset，用于目标检测任务
            "data_root": "obj_ball_val",
            // 数据集的根目录
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                    //封装数据
                        "img": "Image", 
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_bboxes": "BoxArray",
                        //gt_bboxes：BoxArray，将gt_bboxes封装进BoxArray类中，默认固定
                        "gt_bboxes_labels": "ClassLabel"
                        //gt_bboxes_labels：ClassLabel，将gt_bboxes_labels封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] //size: 图片重采样结果尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "Normalize",
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        0.0,
                        0.0,
                        0.0
                    ],
                    //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                    "std": [
                        255.0,
                        255.0,
                        255.0
                    ]
                },
                {
                    "type": "TransposeImage",
                    "axes": [
                        2,
                        0,
                        1
                    ]
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                }
            ]
        }
    },
    "test_dataloader": {
    //测试数据集加载器参数配置
        "batch_size": 1,
        //batch_size: 每批次训练的图像数量，验证时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler",
            //sampler: 对数据集进行样本采样
            "shuffle": false
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "DetDataset",
            // 数据集类型为DetDataset，用于目标检测任务
            "data_root": "obj_ball_val",
            // 数据集的根目录
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "gt_bboxes": "BoxArray",
                        //gt_bboxes：BoxArray，将gt_bboxes封装进BoxArray类中，默认固定
                        "gt_bboxes_labels": "ClassLabel"
                        //gt_bboxes_labels：ClassLabel，将gt_bboxes_labels图片封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize", 
                    // 调整图像尺寸
                    "size": [
                        640,
                        640
                    ] //size: 图片重采样结果尺寸，默认为640*640
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                },
                {
                    "type": "Normalize", 
                    //type: 数据集处理方法类型, Normalize为图像归一化化处理
                    "mean": [
                        0.0,
                        0.0,
                        0.0
                    ],//mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                    "std": [
                        255.0,
                        255.0,
                        255.0
                    ]//std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                },
                {
                    "type": "TransposeImage",
                    //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                    "axes": [
                        2,
                        0,
                        1
                    ]
                    //axes: shape序列号，默认固定
                }
            ]
        }
    },
    "test_cfg": {
    //测试时参数配置
        "type": "TestLoop",
        // 测试循环类型为TestLoop，默认固定
        "evaluator": {
            "type": "Evaluator",
            // 评估器类型为Evaluator，默认固定
            "metrics": [
            //评估使用的参数
                {
                    "type": "COCOMetric"
                    // 使用COCOMetric进行评估（图像检测任务），默认固定
                }
            ]
        }
    },
    "train_cfg": {
    //训练时参数配置
        "type": "EpochBasedTrainLoop",
        // type: 训练循环的类型，这里是按照 epoch 进行训练的 ，默认固定
        "max_epochs": 300,
        // max_epochs: 最大训练周期数，可设置范围从1到任意值，根据模型收敛情况决定，建议30到50轮左右填写
        "val_begin": 1,
        // val_begin: 开始进行验证的训练周期数，根据实际情况决定，可设置范围从1到模型最大训练周期数，
        //建议从1开始填写
        "val_interval": 1
        // val_interval: 进行验证的周期间隔，每隔一个周期进行一次验证，视实际情况决定，建议每个轮次都验证一次设置为1。
    },
    "val_cfg": {
    //验证时参数配置
        "type": "ValLoop",
        // type: 验证模式循环类型， "ValLoop"，默认固定参数
        "evaluator": {
            "type": "Evaluator",
            // 评估器类型为Evaluator
            "metrics": [
            //评估器使用的参数
                {
                    "type": "COCOMetric"
                    // 使用COCOMetric进行评估（目标检测任务）
                }
            ]
        }
    },
    "optimizer": {
    //优化器参数配置
        "type": "SGD",
        // type: 优化器的类型，这里是随机梯度下降（SGD）优化器。图像检测建议用SGD
        "lr": 0.01,
        // lr: 学习率，可设置范围建议0.01~0.00001之间。
        "momentum": 0.9, 
        // momentum: 动量参数，建议设置为 0.9。
        "weight_decay": 0.0001 
        // weight_decay: 权重衰减参数，建议设置为 0.0001，用于控制模型参数的正则化。
    },
    "experiment_name": "test_voc",
    // experiment_name: 实验名称，根据具体实验进行设置。
    "default_hooks": {
    //钩子参数配置
        "checkpoint": {
            "type": "CheckpointHook",
            // type: CheckpointHook，模型权重保存钩子函数，默认固定
            "save_best": "mAP",
            // save_best: 检查点回调函数保存最佳模型，以 "mAP" 为标准。默认固定
            "by_epoch": true
            // by_epoch: 标志，表示以 epoch 为单位进行检查点保存，建议填写为true，默认固定。
        },
        "logger": {
        //日志参数配置
            "type": "LoggerHook",
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 2
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义
        }
    },
    "randomness": {
    //随机化配置
        "seed": 123
        // seed: 随机数生成器的种子，设置为 123，可设置范围很大，这里默认为123 可不做修改。
    }
}