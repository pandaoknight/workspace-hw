# 图像分类_resnet算子训练全参数配置详细介绍
## 说明：1、因算法模型与预训练模型存在强关联，故算法模型本身参数可调整范围有限。2、在训练时建议加载预训练模型，可大大提升模型训练效果，节约训练时间
``` json

{
    "backend": "torch",
    //backend：后端框架,可更改类型，目前支持torch,tensorflow
    "model": {
    //model:定义算法模型
        "type": "ImageClassifier",
        //type：算法模型名称,不可更改类型，默认固定
        "data_preprocessor": {
        //data_preprocessor：数据进入模型前的预处理
            "type": "BaseDataProcessor",
            //type：预处理方式，不可更改类型，默认固定
            "batch_preprocess": [
            //batch_preprocess：数据拼接操作
                {
                    "type": "Stack",
                    //type：拼接方式Stack，默认固定
                    "meta_keys": [
                    //meta_keys：需要拼接的对象，默认固定
                        "img",
                        //img：图片
                        "label"
                        //label：标注
                    ]
                }
            ]
        },
        "backbone": {
        //backbone：模型主干网络定义
            "type": "ResNet",
            //type：模型主干网络名称，默认固定，暂时不支持其他的backbone
            "depth": 18
            //depth：模型主干网络的深度,在不加载预训练时可改，在加载预训练时需要对应各自不同的预训练模型进行加载
            //可改值  18,34,50,101,152
        },
        "neck": {
        //颈部网络参数配置
            "type": "GlobalAveragePooling"
            //type：模型主干网络名称，默认固定，暂时不支持其他的颈部网络
        },
        "head": {
        //head：检测头参数配置
            "type": "LinearClsHead",
            //type：检测头类型，默认参数，暂时不支持别的检测头建议固定
            "in_channels": 512,
            //in_channels：输入全连接层的通道数，默认512固定
            "loss": {
                "type": "CrossEntropyLoss",
                //type: 损失函数类型 默认固定
                "use_sigmoid": false,
                //use_sigmoid：是否使用sigmoid进行归一化，如果训练集类别只有单类别
                //可设置为True，大于1类设置为False
                "reduction": "mean"
                //reduction：每类损失整合方式，可选参数，
                //可选填mean(平均),sum(相加)，建议默认mean进行平均
               
            }
        }
    },
    "work_dir": "work_dir/test_cifar",
    //work_dir: 算法工作目录，输出的模型文件以及log地址
    "train_dataloader": {
    //train_dataloader：训练数据集的加载器
        "batch_size": 2,
        //batch_size: 每批次训练的图像数量，建议填写为偶数，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量，经验设置值是服务器的CPU核心数
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1
        "sampler": {
        //sampler: 对数据集进行样本采样
            "type": "DefaultSampler",
            //type：样本采样方法类型
            "shuffle": false
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "ClsDataset",
            //type：数据集的类型，分类任务默认为ClsDataset
            "data_root": "V2",
            //data_root：图像分类数据集根目录地址
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                    //封装数据
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "label": "ClassLabel"
                        //label：ClassLabel，将标注封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize",
                    //type: 数据集处理方法类型, 
                    "size": [
                    //size: 图片尺寸调整，默认为128*128
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                        128,
                        128
                    ]
                },
                {
                    "type": "RandomFlip",
                    //type: 数据集处理方法类型, RandomFlip为随机翻转，默认固定
                    "p": 0.5,
                    //p: 执行随机翻转操作的概率，可选填参数，0~1之间
                    "direction": "horizontal"
                    //direction：随机翻转的方向，可选填参数vertical垂直翻转，diagonal对角翻转，horizontal水平翻转
                },
                {
                    "type": "Normalize",
                    //type: 数据集处理方法类型, Normalize为图像标准化处理
                    "mean": [
                    //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                        123.675,
                        116.28,
                        103.53
                    ],
                    "std": [
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                        58.395,
                        57.12,
                        57.375
                    ]
                },
                {
                    "type": "TransposeImage",
                    //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                    "axes": [
                    //axes: shape序列号，默认固定
                        2,
                        0,
                        1
                    ]
                }
            ]
        }
    },
    "test_cfg": {
    //test_cfg：评估参数配置
        "type": "TestLoop",
        //type: 测试类型，TestLoop循环测试，默认固定
        "evaluator": {
        //evaluator：指标计算
            "type": "Evaluator",
            //type: Evaluator，指标计算类，默认固定
            "metrics": [
            //Metrics：指标参数
                {
                    "type": "MulticlassAccuracy"
                    //MulticlassAccuracy，指标计算类，默认固定
                }
            ]
        }
    },
    "val_dataloader": {
        "batch_size": 1,
        //batch_size: 每批次训练的图像数量，验证时建议填写为1，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量，经验设置值是服务器的CPU核心数
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1
        "sampler": {
            "type": "DefaultSampler",
            // type: 指定数据采样策略的类型。这里使用 DefaultSampler（默认采样器）。
            "shuffle": false
            // shuffle: 决定是否在加载前对数据进行随机筛选。设置为 false，表示不随机。一般在val和test时选择不随机
        },
        "dataset": {
            "type": "ClsDataset",
            // type: ClsDataset 使用该类进行数据封装，默认固定
            "data_root": "V2",
            // data_root: 数据集所在的根目录。
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                    //封装数据
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "label": "ClassLabel"
                        //label：ClassLabel，将标注封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize",
                    //type: 数据集处理方法类型,
                    "size": [
                    //size: 图片尺寸调整，默认为128*128
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                        128,
                        128
                    ]
                },
                {
                    "type": "RandomFlip",
                    //type: 数据集处理方法类型, RandomFlip为随机翻转，默认固定
                    "p": 0.5,
                    //p: 执行随机翻转操作的概率，可选填参数，0~1之间
                    "direction": "horizontal"
                    //direction：随机翻转的方向，可选填参数vertical垂直翻转，diagonal对角翻转，horizontal水平翻转
                },
                {
                    "type": "Normalize",
                    //type: 数据集处理方法类型, Normalize为图像标准化处理
                    "mean": [
                    //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                        123.675,
                        116.28,
                        103.53
                    ],
                    "std": [
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                        58.395,
                        57.12,
                        57.375
                    ]
                },
                {
                    "type": "TransposeImage",
                    //type: 数据集处理方法类型，TransposeImage为图像通道顺序调整处理，默认固定
                    "axes": [
                    //axes: 通道序列号，默认固定
                        2,
                        0,
                        1
                    ]
                }
            ]
        }
    }    
    "test_dataloader": {
        "batch_size": 2,
        //batch_size: 每批次训练的图像数量，建议填写为偶数，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量，经验设置值是服务器的CPU核心数
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1
        "sampler": {
        //sampler: 对数据集进行样本采样
            "type": "DefaultSampler",
            //type：样本采样方法类型
            "shuffle": false
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        
        "dataset": {
            "type": "ClsDataset",
            // type: 指示使用的数据集类型。在这种情况下，是一个分类数据集（ClsDataset）。
            
            "data_root": "V2",
            // data_root: 数据集所在的根目录。
            
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                    //封装数据
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "label": "ClassLabel"
                        //label：ClassLabel，将标注封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32进行训练
                    }
                },
                {
                    "type": "Resize",
                    //type: 数据集处理方法类型, Resize为图片尺寸调整
                    "size": [
                    //size: 图片尺寸调整，默认为128*128
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                        128,
                        128
                    ]
                },
                {
                    "type": "RandomFlip",
                    //type: 数据集处理方法类型, RandomFlip为随机翻转，默认固定
                    "p": 0.5,
                    //p: 执行随机翻转操作的概率，可选填参数，0~1之间
                    "direction": "horizontal"
                    //direction：随机翻转的方向，可选填参数vertical垂直翻转，diagonal对角翻转，horizontal水平翻转
                },
                {
                    "type": "Normalize",
                    //type: 数据集处理方法类型, Normalize为图像标准化处理
                    "mean": [
                    //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                        123.675,
                        116.28,
                        103.53
                    ],
                    "std": [
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                        58.395,
                        57.12,
                        57.375
                    ]
                },
                {
                    "type": "TransposeImage",
                    //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                    "axes": [
                    //axes: shape序列号，默认固定
                        2,
                        0,
                        1
                    ]
                }
            ]
        }
    },    
    "train_cfg": {
        "type": "EpochBasedTrainLoop",
        // type: 训练循环的类型，这里是按照 epoch 进行训练的 "EpochBasedTrainLoop"。
        "max_epochs": 30,
        // max_epochs: 最大训练周期数，可设置范围从1到任意值，根据模型收敛情况决定，建议30到50轮左右填写
        "val_begin": 1,
        // val_begin: 开始进行验证的训练周期数，根据实际情况决定，可设置范围从1到模型最大训练周期数，
        //建议从1开始填写
        "val_interval": 1
        // val_interval: 进行验证的周期间隔，每隔一个周期进行一次验证，视实际情况决定，建议每个轮次都验证一次设置为1。
    },
    "optimizer": {
        "type": "SGD",
        // type: 优化器的类型，这里是随机梯度下降（SGD）优化器。图片分类建议用SGD
        "lr": 0.01,
        // lr: 学习率，可设置范围建议0.01~0.00001之间。
        "momentum": 0.9,
        // momentum: 动量参数，建议设置为 0.9。
        "weight_decay": 0.0001
        // weight_decay: 权重衰减参数，建议设置为 0.0001，用于控制模型参数的正则化。
    },
    
    "val_cfg": {
        "type": "ValLoop",
        // type: 验证模式循环类型， "ValLoop"，默认固定参数
        "evaluator": {
            "type": "Evaluator",
            // type: 评估器的类型 "Evaluator"，默认固定参数
            "metrics": [
                {
                    "type": "MulticlassAccuracy"
                    // type: 评估指标的类型，，默认固定参数。
                }
            ]
        }
    },
    "experiment_name": "test_voc",
    // experiment_name: 实验名称，根据具体实验进行设置
    "default_hooks": {
    //默认钩子函数
        "checkpoint": {
            "type": "CheckpointHook",
            // type: CheckpointHook，模型权重保存钩子函数，默认固定
            "save_best": "MeanF1Score",
            // save_best: 检查点回调函数保存最佳模型，以 "MeanF1Score" 为标准。默认固定
            "by_epoch": true
            // by_epoch: 标志，表示以 epoch 为单位进行检查点保存，建议填写为true，默认固定。
        },
        "logger": {
            "type": "LoggerHook",
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 2
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义。
        },
        "saver": {
            "type": "OutputSaveHook",
            // type: 回调函数的类型，这里是保存输出的回调函数。
            "formatter": {
                "type": "ImageClsOutputFormatter"
                // type: 输出保存回调函数的格式化方式，这里是图像分类模型的输出格式化，默认固定。
            }
        },
        "kafka": {
            "interval": 1,
            // interval: Kafka 回调函数的触发间隔，每 1 个周期触发一次，根据实际情况填写。
            "type": "TransferStationHook",
            // type: Kafka 回调函数的类型，默认固定。
            "name": "kafka",
            // name: Kafka 回调函数的名称，默认固定。
            "kafka_address": "kafka.icaplat-sit.svc.cluster.local:19092",
            // kafka_address: Kafka 服务器的地址，根据实际情况填写。
            "task_id": "35",
            // task_id: 任务 ID，根据实际情况填写。
            "topic": "alg_train_visual-automodel",
            // topic: Kafka 主题，用于发布训练可视化信息，根据实际情况填写。
            "work_dir": "output/models"
            // work_dir: 工作目录，根据实际情况填写。
        }
    },
    "randomness": {
        "seed": 123
        // seed: 随机数生成器的种子，设置为 123，可设置范围很大，这里默认为123 可不做修改。
    },
    "load_from": "xx.pth"
    //加载预训练权重进行训练，强烈建议加载
    
}