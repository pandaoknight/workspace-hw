# 图像分类_resnet算子评估全参数配置详细介绍

``` json
{
    "backend": "torch",
    //backend：后端框架,可更改类型，目前支持torch,tensorflow
    "work_dir": "work_dir/test_cifar",
    //work_dir: 算法工作目录
    "test_dataloader": {
    //test_dataloader：测试数据集的加载器
        "batch_size": 1,
        //batch_size: 每批次训练的图像数量，建议填写为偶数，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量，经验设置值是服务器的CPU核心数
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1
        "sampler": {
        //sampler: 对数据集进行样本采样
            "type": "DefaultSampler",
            //type：样本采样方法类型
            "shuffle": false
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "ClsDataset",
            //type：数据集的类型，分类任务默认为ClsDataset
            "data_root": "/data/sdv1/zhoutianqi/icm_tlx/icm/V1",
            //data_root：数据集根目录的文件地址
            "pipelines": [
            //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
                {
                    "type": "LoadImage"
                    //type: 数据集处理方法类型，LoadImage为数据读取方式，默认固定
                },
                {
                    "type": "WrapData",
                    //type: 数据集处理方法类型，默认固定
                    "mapping": {
                    //封装数据
                        "img": "Image",
                        //img：Image，将img图片封装进Image类中，默认固定
                        "label": "ClassLabel"
                        //label：ClassLabel，将标注封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "ConvertDataType",
                    //type: 数据集处理方法类型, ConvertDataType为图片类型转换处理
                    "mapping": {
                        "img": "float32"
                        //img: 图片类型转换类别，float32为32位浮点型，建议采用float32
                    }
                },
                {
                    "type": "Resize",
                    //type: 数据集处理方法类型, 
                    "size": [
                    //size: 图片重采样结果尺寸，默认为128*128
                    //可选填为256*256,512*512等，根据剩余显存进行更改，设置为32的整数倍
                    //如果设置过高，会跟batch_size设置过高产生同样的OOM问题
                    //在评估时，建议和训练时采用的resize尺寸相同
                        128,
                        128
                    ]
                },
                {
                    "type": "Normalize",
                    //type: 数据集处理方法类型, Normalize为图像标准化处理
                    "mean": [
                    //mean: 标准化处理后图像三个通道的均值，可取值范围0~255
                    //建议按下面的参数填写
                        123.675,
                        116.28,
                        103.53
                    ],
                    "std": [
                    //std: 标准化处理后图像三个通道的标准差，可取值范围0~255
                    //建议按下面的参数填写
                        58.395,
                        57.12,
                        57.375
                    ]
                },
                {
                    "type": "TransposeImage",
                    //type: 数据集处理方法类型，TransposeImage为图像shape顺序调整处理，默认固定
                    "axes": [
                    //axes: shape序列号，默认固定
                        2,
                        0,
                        1
                    ]
                }
            ]
        }
    },
    "test_cfg": {
    //test_cfg：评估参数配置
        "type": "TestLoop",
        // type: 测试循环的类型，这里是 "TestLoop"。
    
        "evaluator": {
            "type": "Evaluator",
            //type: Evaluator，指标计算类，默认固定
    
            "metrics": [
                {
                    "type": "MulticlassAccuracy"
                    //MulticlassAccuracy，指标计算类，默认固定。
                }
            ]
        }
    },
    
    "experiment_name": "test_voc",
    // experiment_name: 实验名称，根据具体实验进行设置，仅仅是一个名字。
    "default_hooks": {
        "logger": {
            "type": "LoggerHook",
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 2
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义。
        },
        "saver": {
            "type": "OutputSaveHook",
            // type: 回调函数的类型，这里是保存输出的回调函数。
            "formatter": {
                "type": "ImageClsOutputFormatter"
                // type: 输出保存回调函数的格式化方式，这里是图像分类模型的输出格式化，默认固定。
            }
        }
    },
    "load_from": "work_dir/test_cifar/epoch_1.pth",
    // load_from: 模型加载的文件路径，加载训练好的模型文件（在 "work_dir/test_cifar/epoch_1.pth"）。
    "randomness": {
        "seed": 123
        // seed: 随机数生成器的种子，设置为 123，可设置范围很大，这里默认为123 可不做修改。
    },
    "kafka_station": {
        "name": "kafka",
        // name: Kafka 回调函数的名称，默认固定。
        "kafka_address": "kafka.icaplat-sit.svc.cluster.local:19092",
        // kafka_address: Kafka 服务器的地址，根据实际情况填写。
        "task_id": "35",
        // task_id: 任务 ID，根据实际情况填写。
        "topic": "alg_train_visual-automodel",
        // topic: Kafka 主题，用于发布训练可视化信息，根据实际情况填写。
        "work_dir": "output/models"
        // work_dir: 工作目录，根据实际情况填写。
    }
}