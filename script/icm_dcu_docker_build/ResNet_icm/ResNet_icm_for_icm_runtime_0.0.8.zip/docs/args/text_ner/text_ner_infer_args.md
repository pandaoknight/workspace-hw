# 实体识别算子推理全参数配置详细介绍

  
``` json
{
    "service": {
        "ip": "0.0.0.0",
        //ip: 算法接口的ip地址，默认0.0.0.0
        "port": 18081,
        //port: 算法接口的端口号，按需求填写
        "urls": "/infer"
        //urls：算法接口后缀的地址，按需求填写
    },
    "datasets": {
        "type": "NERDataset",
        //type：数据集的类型，实体识别任务默认为NERDataset
        "pipelines": [
        //pipelines：数据增强和处理的管道方式，按顺序对读取的数据进行处理
            {
                "type": "WrapData",
                //type: 数据集处理方法类型，默认固定
                "mapping": {
                    "text": "Text",
                    //text：Text，将文本数据封装进Text类中，默认固定
                    "token_label": "ClassLabel",
                    //token_label：ClassLabel，将token_label封装进ClassLabel类中，默认固定
                }
            },
            {
                "type": "BertTokenizer",
                //type：分词器类型，暂时不可改
                "vocab_file": "tmp/demo/nlp/vocab.txt",
                //vocab_file：词汇表文件地址，跟预训练模型与模型名称绑定，该地址是对应的 bert-base-chinese 21128
                "max_length": 512,
                //max_length：最大文本长度，取值范围1~512，bert可接受长度最长为512的文本
            }
        ]
    },
    "load_from": "work_dir/ner/epoch_16.pth",
    //load_from：模型加载地址
    "pre_formatter": [
        {
            "type": "HttpTextReader"
            //处理Post请求转为推理格式，默认固定
        }
    ],
    "post_formatter": [
        {
            "type": "HttpTextNerFormatter"
            //处理Post请求的输出格式，默认固定
        }
    ]
}