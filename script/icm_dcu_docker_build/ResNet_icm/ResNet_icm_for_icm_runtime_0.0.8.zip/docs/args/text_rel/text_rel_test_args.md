# 关系抽取算子评估全参数配置详细介绍

  
``` json
{
    "backend": "torch",
    //backend：后端训练框架,可更改类型，目前支持torch,tensorflow
    "work_dir": "work_dir/relation",
    //工作目录路径
    "test_dataloader": {
        "batch_size": 1,
        //batch_size: 每批次训练的图像数量，建议填写为偶数，取值根据剩余显存决定
        //batch_size设置过高会导致显存OOM报错
        "num_workers": 1,
        //num_workers：一次性创建的工作进程的数量
        //num_workers设置过高会导致内存占用过高，io占用过高等问题，默认为1，代表单进程读取数据，经验设置最大值是服务器的CPU核心数
        "sampler": {
            "type": "DefaultSampler",
            //type：采样器类型，暂时不可改
            "shuffle": false,
            //shuffle：样本采样是否为随机采样，false为正序采样，true为随机采样，一般在训练时采用随机采样
        },
        "dataset": {
            "type": "RelationDataset",
            //type：数据集类型，暂时不可改
            "data_root": "/data/sdv1/zhoutianqi/icm_tlx/icm/bert_data/",
            //data_root：数据集地址
            "ann_file": "txt_relation.json",
            //ann_file：数据文件名称
            "pipelines": [
                {
                    "type": "WrapData",
                    "mapping": {
                        "text": "Text",
                        //text：Text，将文本数据封装进Text类中，默认固定
                        "sub_obj": "ClassLabel",
                        //sub_obj：ClassLabel，将sub_obj封装进ClassLabel类中，默认固定
                        "rel_label": "ClassLabel",
                        //rel_label：ClassLabel，将rel_label封装进ClassLabel类中，默认固定
                    }
                },
                {
                    "type": "BertTokenizer",
                    //type：分词器类型，暂时不可改
                    "vocab_file": "tmp/demo/nlp/vocab.txt",
                    //vocab_file：词汇表文件地址，跟预训练模型与模型名称绑定，该地址是对应的 bert-base-chinese 21128
                    "max_length": 512,
                    //max_length：最大文本长度，取值范围(1,512)，bert可接受长度最长为512的文本
                    "task": "rel",
                    //task：任务类型，暂时不可改
            ]
        }
    },
    "test_cfg":, {
        "type": "TestLoop",
        //type：测试设置类型，暂时不可改
        "evaluator": {
            "type": "Evaluator",
            //type：验证器类型，暂时不可改
            "metrics": [
                {
                    "type": "RelationMetric",
                    //type：评估指标类型，暂时不可改
                }
            ]
        }
    },
    "optimizer":, {
        "type": "AdamW",
        //type：优化器类型，文本任务默认AdamW
        "lr": 1e-05,
        // lr: 学习率，可设置范围建议0.01~0.00001之间。
    },
    "experiment_name": "test_bert",
    // experiment_name: 实验名称，根据具体实验进行设置。
    "default_hooks": {
        "logger": {
        //日志参数配置
            "type": "LoggerHook",
            // type: 回调函数的类型，这里是记录日志的回调函数，默认固定
            "interval": 1
            // interval: 记录日志的周期间隔，每 2 个周期记录一次，可选填范围自定义。
        },
        "saver": {
            "type": "OutputSaveHook",
            //输出钩子函数，默认固定
            "formatter": {
                "type": "TextRelOutputFormatter"
                //关系抽取输出格式调整，默认固定
            }
        }
    },
    "randomness":, {
        "seed": 123,
        // seed: 随机数生成器的种子，设置为 123，可设置范围很大，这里默认为123 可不做修改。
    },
    "load_from": "work_dir/relation/best_F1Score_epoch_1.pth",
    //load_from：模型加载地址
    "kafka_station":, {
        "name": "kafka",
        "kafka_address": "kafka.icaplat-sit.svc.cluster.local:19092",
        //kafka_address：kafka系统地址，暂时不可改
        "task_id": "35",
        //task_id：任务id，暂时不可改
        "topic": "alg_train_visual-automodel",
        //topic：任务主题，暂时不可改
        "work_dir": "output/models",
        //work_dir：运行地址
    },
}