# AlgICM设计文档
本文档介绍将AlgICM运行中数据流转关系与模块功能设计。

## 一、数据流转

AlgICM期望基于配置文件的方式进行数据解析、模型构建、训练、评估与提供服务。

![algicm-main-arch](../pics/icm总流程.png)

[配置文件](../components/configs.md)：在启动训练、测试、服务等过程中，可以通过修改参数调整过程状态，以适应不同的需求场景。配置文件的颗粒度很高，支持用户进行不同模型的组装，不同输入输出的定义等功能。其参数与训练、测试、服务引擎中的参数一致。
[训练引擎](../components/runner.md):负责在训练任务中构建数据集、模型构建、训练流程构建等，其输出结果保存了模型结构、模型权重、相关配置等，便于用户在后续任务中使用。
[测试引擎](../components/runner.md):负责在测试任务中构建数据集，根据保存文件解析模型，计算相关指标，并将相关结果进行输出。
[服务引擎](../components/runner.md):负责解析已有的模型文件，并将模型启动为简单的http server, 便于直接访问输出。

## 二、核心组件与模型

[引擎](../components/runner.md): 是对训练、测试、服务流程的高度抽象方法，所有流程中相关的信息均可在引擎中被找到，如：数据集、模型、指标等。其中涉及到不同组件与分工：
- [数据集（Dataset）](../components/basedataset.md)：负责在训练、测试、推理任务中构建数据集，并将数据送给模型。实际使用过程中会被数据加载器（DataLoader）封装一层，数据加载器会启动多个子进程来加载数据。*其中Dataloader与其他深度学习场景所自带的Dataloader不同，是基于python对象实现的，而非与框架绑定。*
- [模型（Model）](../components/model.md)：在训练过程中接受数据并输出 loss；在测试、推理任务中接受数据，并进行预测。分布式场景待补充。。。
- [数据处理（Transform）](../components/transform.md)
- [优化器（Optimizer）](../components/optimizer.md)

