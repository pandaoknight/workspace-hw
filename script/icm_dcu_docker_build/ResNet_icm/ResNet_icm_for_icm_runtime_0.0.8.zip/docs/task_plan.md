<div align="center">
<b><font size="5">Algicm任务清单</font></b>
</div>

## 1 简介

Algicm需要实现模型建模，训练，测试，服务和数据处理等功能，详情见表格。

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="120"> 模块名称 </th>
        <th align="mid" width="360"> 任务说明</th>
    </tr>
    <tr>
        <th align="mid" width="120"> core </th>
        <th align="left" width="360">
        1.指标的计算功能。 <br>
        2.前处理和后处理功能。  <br>
        3.数据可视化功能。  <br>
        4.模型解析功能。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="120"> engine </th>
        <th align="left" width="360"> 
        支持不同深度学习框架的模型单机训练与分布式训。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="120"> models </th>
        <th align="left" width="360"> 
        1.提供通用的预置模型组件。 <br>
        2.支撑不同框架下自定义组件。 <br>
        3.支持拖拉拽建模的相关功能。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="120"> datasets </th>
        <th align="left" width="360">
        提供常见的数据集解析方法。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="120"> service </th>
        <th align="left" width="360"> 
        1.提供模型服务相关功能。 <br>
        2.兼容不同部署框架（tritonserver, flask等)。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="120"> compression </th>
        <th align="left" width="360"> 
        1.不同框架模型的解析功能。 <br>
        2.支持模型剪枝、量化、蒸馏功能。
        </th>
    </tr>
    <tr>
        <th align="mid" width="120"> utils </th>
        <th align="left" width="360"> 
        相关工具。 <br>
        </th>
    </tr>

  </tbody>
</table>

## 2.core模块

### 2.1 前后处理功能

#### 2.1.1 前后处理功能需求

前处理功能目前只考虑图像相关的数据处理操作，但需要考虑**二维、三维和多通道**图像的处理。 除此之外还应包含对标签的处理。


<details>
<summary>(1) 数据处理 </summary>

计划实施的功能：

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 中文名称 </th>
        <th align="mid" width="90"> 英文名称</th>
        <th align="mid" width="180"> 详细说明</th>
    </tr>
    <tr>
        <th align="mid" width="90"> 缩放 </th>
        <th align="mid" width="90"> Resize </th>
        <th align="left" width="240">
        需要实现固定大小、区间范围、固定边长的图像缩放.
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 填充 </th>
        <th align="mid" width="90"> Pad </th>
        <th align="left" width="240">
        需要实现图像的填充，包括固定数值和固定位置填充
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 随机裁剪 </th>
        <th align="mid" width="90"> CenterCrop </th>
        <th align="left" width="240">
        基于图像中心区域进行裁剪
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 中心裁剪 </th>
        <th align="mid" width="90"> RandomCrop </th>
        <th align="left" width="240">
        随机位置图像的剪裁
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 随机翻转 </th>
        <th align="mid" width="90"> RandomFlip </th>
        <th align="left" width="240">
        图像的翻转包括垂直，水平和镜像翻转,可选择一个或多个策略。
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 旋转 </th>
        <th align="mid" width="90"> Rotate </th>
        <th align="left" width="240">
        根据不同的角度进行图像旋转。
        </th>
    </tr>
  </tbody>
</table>

</details>   


<details>
<summary>(2) 边框和多边形处理 </summary>

需明确： 边框应考虑**有角度的边框**(x,y,w,h,a)；多边形点数应大于3个。

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 中文名称 </th>
        <th align="mid" width="90"> 英文名称</th>
        <th align="mid" width="180"> 详细说明</th>
    </tr>
    <tr>
        <th align="mid" width="90"> 缩放 </th>
        <th align="mid" width="90"> Resize </th>
        <th align="left" width="240">
        根据缩放比例，调整坐标.
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 填充 </th>
        <th align="mid" width="90"> Pad </th>
        <th align="left" width="240">
        根据填充的方式，调整坐标。
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 裁剪 </th>
        <th align="mid" width="90"> Crop </th>
        <th align="left" width="240">
        根据裁剪区域，调整坐标
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 翻转 </th>
        <th align="mid" width="90"> Flip </th>
        <th align="left" width="240">
        根据翻转的策略对边框进行翻转。
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 旋转 </th>
        <th align="mid" width="90"> Rotate </th>
        <th align="left" width="240">
        根据角度对边框进行旋转。
        </th>
    </tr>
  </tbody>
</table>
</details>   

#### 2.1.2 后处理功能

<details>
<summary>后处理操作 </summary>


<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 中文名称 </th>
        <th align="mid" width="90"> 英文名称</th>
        <th align="mid" width="180"> 详细说明</th>
    </tr>
    <tr>
        <th align="mid" width="90"> 排序 </th>
        <th align="mid" width="90"> TopK </th>
        <th align="left" width="240">
        选择前K类标签
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 非极大值抑制 </th>
        <th align="mid" width="90"> NMS </th>
        <th align="left" width="240">
        根据iou过滤边框
        </th>
    </tr>
  </tbody>
</table>
</details>   

### 2.2 指标计算

<details>
<summary>指标计算</summary>

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 任务</th>
        <th align="mid" width="240"> 名称</th>
    </tr>
    <tr>
        <th align="mid" width="90"> 分类 </th>
        <th align="left" width="240">
        precision, recall, f1_score, cls_confusion_matrix
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 检测 </th>
        <th align="left" width="240">
        mean_recall, mean_ap, det_confusion_matrix
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 分割 </th>
        <th align="left" width="240">
        mean_iou, mean_dice, mean_fsocre
        </th>
    </tr>
  </tbody>
</table>
</details>   

### 2.3 可视化

<details>
<summary>可视化</summary>

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 功能名称</th>
        <th align="mid" width="240"> 详细说明</th>
    </tr>
    <tr>
        <th align="mid" width="90"> show_box </th>
        <th align="left" width="240">
        1.传入图像和边框，展示边框信息。  <br>
        2.可传入边框或边框加置信度。  <br>
        3.可传入类别。  <br>
        4.可自定义类别颜色。  <br>
        5.可选择叠加到图像。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> show_seg </th>
        <th align="left" width="240">
         1.传入图像和分割结果，展示分割结果。  <br>
         2.可传入类别。  <br>
         3.可自定义类别颜色。 <br>
         4.可选择叠加到图像上。 <br>
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> show_cls </th>
        <th align="left" width="240">
         1.传入图像和分类信息，展示结果。
        </th>
    </tr>
  </tbody>
</table>
</details>   

### 2.4 模型解析功能
待定 

## 3.engine模块
### 3.1 训练流程控制
训练流程控制支持不同框架的模型训练，具体应包含

<details>
<summary>(1) runner模块</summary>

对于模型的训练流程控制

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 功能名称</th>
        <th align="mid" width="240"> 详细说明</th>
    </tr>
    <tr>
        <th align="mid" width="90"> 迭代器 </th>
        <th align="left" width="240">
        迭代器控制整个训练流程，应包含基于epoch和基于iteration的迭代器
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 钩子函数 </th>
        <th align="left" width="240">
         对于训练过程中的模型、过程数据等变量的增删改查。 其中前5条需要基于不同框架实现<br>
         1.模型保存与加载功能。 <br>
         2.优化器的创建功能。 <br>
         3.不同学习率变化策略。<br>
         4.不同动量变化策略。<br>
         5.模型验证流程功能。（不实现具体的模型验证过程）。<br>
         6.时间计算功能。<br>
         7.日志记录功能。<br>
         8.kafka消息传输功能。 <br>
         9.支持自定义钩子函数。<br>
        </th>
    </tr>
  </tbody>
</table>
</details>   


<details>
<summary>(2) parallel模块</summary>

用于不同框架的分布式相关功能。

<table class="docutils">
  <tbody>
    <tr>
        <th align="mid" width="90"> 功能名称</th>
        <th align="mid" width="240"> 详细说明</th>
    </tr>
    <tr>
        <th align="mid" width="90"> 初始化 </th>
        <th align="left" width="240">
        不同框架的环境初始化
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 状态管理查询 </th>
        <th align="left" width="240">
        不同框架当前状态的管理与查询，是否分布式，分布式的rank和world size的查询。
        </th>
    </tr>
    <tr>
        <th align="mid" width="90"> 分布式运算操作 </th>
        <th align="left" width="240">
        包括但不限于all_reduce, all_gather等
        </th>
    </tr>
  </tbody>
</table>
</details>   


## 4.models模块
待定

## 5.datasets模块
支持常见数据集的读取与解析工作，计划支持:

cifar10, cifar100, imagenet, coco, pascal voc, cityspace


## 6.service模块
待定


## 7.compression模块
待定
