ICM算法剩余工作:
1.实现参数调度方法, 即学习率调整等策略。验证tensorflow下如何根据param_group设置参数。(已实现待验证)
2.实现模型EMA方法。
3.验证pytorch与tensorflow在k8s的分布式训练;
4.单机多卡和多机多卡分布式训练的验证（非k8s平台）。
5.tensorflow模型权重名称变换，尽量与torch保存名称相近，方便后期转换
6.推理引擎需要兼容不同的推理框架如triton、flask，是否需要兼容多种通信协议（？）。
7.tensorflow某些层在CPU上不支持channel_first, 需要做兼容。
8.如何进行多模型的联合训练（如GAN），想法验证。optimizer
9.用户自定义模块的添加。
10.相关文档需尽快丰富起来。

# 2023年9月计划
1.重新排列各层级结构。
（a）将与深度学习相关的模块合并到backend, 比如runner， optimizer等
（b）太深的模块重新排列， 比如evaluator 提到最外层

2.reformat模块合并预和改造。
(a) http_reformat与icm_reformat其实可以合并
(b) http_reformat支持一个mini-batch的预测

3.增加分布式相关功能。
（a）在backend中增加dist相关方法，如 broadcast, reduce等
（b）验证单机多卡分布式。

4.val_step与test_step均需要改造为无gt输入，将datasets中test mode设置为true，
即gt不参与transformation.

5.单元测试
添加layer的单元测试

6.文档
补充核心模块、方法的文档

7.注释
补充已做单元测试模块的注释





