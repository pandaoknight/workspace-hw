#!/bin/bash

# 定义参数
json_path=$2

key='work_dir'
# 开始分离json文件
echo "-----------开始分离json文件-----------"  
python algicm/utils/split_json.py  --config $json_path

# root_path=$(dirname $json_path)
# rel_json_string=$(cat ./rel.json) 
# ner_json_string=$(cat ./ner.json) 


# rel_work_dir=$(echo "$rel_json_string" | awk -F"[,:}]" '{for(i=1;i<=NF;i++){if($i~/\042'$key'\042/){print $(i+1)}}}' | tr -d '"' | tr -d ' ')
# ner_work_dir=$(echo "$ner_json_string" | awk -F"[,:}]" '{for(i=1;i<=NF;i++){if($i~/\042'$key'\042/){print $(i+1)}}}' | tr -d '"' | tr -d ' ')

# 开始实体识别训练
echo "-----------开始实体识别训练-----------"  
python train.py --config ./ner.json

# 开始关系抽取训练
echo "-----------开始关系抽取训练-----------"
python train.py --config ./rel.json

echo "-----------合并checkpoint文件-----------"
# python algicm/utils/merge_checkpoints.py --ner_work_dir $ner_work_dir --rel_work_dir $rel_work_dir
python algicm/utils/merge_checkpoints.py
echo "-----------执行完成-----------"

