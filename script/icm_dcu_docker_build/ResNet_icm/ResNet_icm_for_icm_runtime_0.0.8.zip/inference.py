#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   inference.py
@Time    :   2023/08/07 14:55:15
@Author  :   htx 
"""
import json
import os
import argparse


def parse_args():
    parser = argparse.ArgumentParser(
        description="ICM algorithms server script.")
    parser.add_argument(
        "--config",
        default="tmp/icm_test_json/rel_end2end/end2end_rel_infer.json",
        help="Hyper parameter config path.",
    )
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = parse_args()
    with open(args.config, "r") as f:
        cfg = json.load(f)
    # os.environ["CUDA_VISIBLE_DEVICES"] = "1"
    backend = cfg.get("load_from", None)

    if cfg.get("ner", None) is not None:
        ner_config = cfg.get("ner", None)
        rel_config = cfg.get("rel", None)
        load_from = cfg.get("load_from", None)
        cfg["ner"]["load_from"] = load_from
        cfg["rel"]["load_from"] = load_from

    if backend.endswith(".pth"):
        os.environ["ALGICM_BACKEND"] = "torch"
    else:
        os.environ["ALGICM_BACKEND"] = "tensorflow"
        import tensorflow as tf

        gpus = tf.config.experimental.list_physical_devices("GPU")
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)

    from algicm.service.server import run_server

    run_server(cfg)
