import numpy as np
import algicm.models.backend.functional as F
from algicm.models.layers import activation


def test_ReLU():
    inputs = F.random_uniform([2, 10], -10, 10)
    gt = F.identity(inputs)
    gt[gt < 0] = 0
    layer = activation.ReLU()
    pred = layer(inputs)
    np.allclose(pred, gt, atol=1e-8)


def test_ReLU6():
    # ReLU6(x)=min(max(0,x),6)
    inputs = F.random_uniform([2, 10], -10, -10)
    gt = F.identity(inputs)
    gt = F.minimum(F.maximum(F.convert_to_tensor(0), gt), F.convert_to_tensor(6))
    layer = activation.ReLU6()
    pred = layer(inputs)
    np.allclose(pred, gt, atol=1e-8)


def test_LeakyReLU():
    # \text{LeakyReLU}(x) = \max(0, x) + negative\_slope * \min(0, x)
    neg_slop = 0.2
    inputs = F.random_uniform([2, 10], -10, 10)
    gt = F.identity(inputs)
    gt = F.maximum(F.convert_to_tensor(0), gt) + neg_slop * F.minimum(gt, F.convert_to_tensor(0))
    layer = activation.LeakyReLU(neg_slop)
    pred = layer(inputs)
    np.allclose(pred, gt, atol=1e-8)
