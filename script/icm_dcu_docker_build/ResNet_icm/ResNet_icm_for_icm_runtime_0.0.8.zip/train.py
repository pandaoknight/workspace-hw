#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   train.py
@Time    :   2023/08/07 10:41:34
@Author  :   htx 
"""
import os
import json
import argparse


def parse_args():
    parser = argparse.ArgumentParser(
        description="ICM algorithms training script.")
    parser.add_argument(
        "--config",
        default="tmp/icm_test_json/det/image_yolov5_det_train.json",
        help="Hyper parameter config path.",
    )
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = parse_args()
    with open(args.config, "r") as f:
        cfg = json.load(f)

    # os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    os.environ["ALGICM_BACKEND"] = cfg["backend"]
    ALGICM_BACKEND = os.environ.get("ALGICM_BACKEND", "torch").lower()
    if ALGICM_BACKEND == "torch":
        from algicm.engine.pytorch.runner import Runner
    else:
        from algicm.engine.tensorflow.runner import Runner

    runner = Runner.from_cfg(cfg)
    runner.train()
