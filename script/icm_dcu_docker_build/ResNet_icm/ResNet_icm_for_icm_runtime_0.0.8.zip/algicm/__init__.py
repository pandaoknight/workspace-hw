# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/9/5

import os
# Set backend based on ALGICM_BACKEND.
BACKEND = os.environ.get("ALGICM_BACKEND", "torch")
