#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   icm_formatter.py
@Time    :   2023/08/04 13:58:40
@Author  :   htx 
"""

import os
import cv2
import numpy as np
import algicm.models.backend.functional as F
from algicm.transform.transform.base import BaseTransform
from algicm.registry.common import TRANSFORMS


@TRANSFORMS.register_module()
class ImageClsOutputFormatter(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self, work_dir) -> None:
        super().__init__()
        self._global_count = 0
        self.work_dir = work_dir

    def transform(self, results, datasets=None, **kwargs):
        # model outputs
        outputs = results.get("outputs")
        # collected data from dataset pipelines
        data_batch = results.get("data_batch")
        preds = outputs.get("preds")
        if outputs is None:
            raise RuntimeError(
                "In ImageClsFormatter, 'preds' should contrains in outputs")
        assert len(preds) == len(
            data_batch), "The length of preds and data_batch does not match"
        preds = F.convert_to_numpy(preds)

        out_list = []
        for pred, data in zip(preds, data_batch):
            out_dict = dict()
            file_path = data.get("img_path")
            if file_path is None:
                file_path = self._global_count
            out_dict["fileName"] = str(file_path)
            out_dict["annotations"] = dict(imgCategory=[pred.argmax()])
            out_list.append(out_dict)
        return out_list

    def collect(self, result_list, datasets):
        """Reformat all results.
        for a single image result:
        {"fileName":"1.jpg", annotations:{"imgCategory":[0]}}
        """
        ## Add categories here.
        categories = []
        cat2id = datasets.metainfo.get("cat2id")
        for k, v in cat2id.items():
            categories.append(dict(id=v, name=k))
        return dict(images=result_list, categories=categories)


@TRANSFORMS.register_module()
class ImageDetOutputFormatter(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self, work_dir) -> None:
        super().__init__()
        self._global_count = 0
        self.work_dir = work_dir

    def transform(self, results, datasets=None, **kwargs):
        # model outputs
        outputs = results.get("outputs")
        # collected data from dataset pipelines
        data_batch = results.get("data_batch")
        preds = outputs.get("pred_instances")
        if outputs is None:
            raise RuntimeError(
                "In ImageClsFormatter, 'preds' should contrains in outputs")
        assert len(preds) == len(
            data_batch), "The length of preds and data_batch does not match"

        out_list = []
        out_dict = dict()
        for pred, data in zip(preds, data_batch):
            file_path = data.get("img_path")
            if file_path is None:
                file_path = self._global_count

            if len(pred["bboxes"]) == 0:
                bboxes = []
                scores = []
            else:
                if pred.get("rescale_bboxes") is not None:

                    for index, arr in enumerate(pred["rescale_bboxes"]):
                        pred["rescale_bboxes"][index][2] = arr[2] - arr[0]
                        pred["rescale_bboxes"][index][3] = arr[3] - arr[1]

                    bboxes = np.concatenate([
                        pred["rescale_bboxes"], pred["labels"].reshape(-1, 1)
                    ],
                                            axis=-1).tolist()
                else:
                    bboxes = np.concatenate(
                        [pred["bboxes"], pred["labels"].reshape(-1, 1)],
                        axis=-1).tolist()
                scores = pred["scores"].tolist()

            out_dict["fileName"] = str(file_path)
            out_dict["annotations"] = dict(bboxes=bboxes, scores=scores)
            out_list.append(out_dict)
        return [out_dict]

    def collect(self, result_list, datasets):
        """Reformat all results.
        for a single image result:
        {"fileName":"1.jpg", annotations:{"imgCategory":[0]}}
        """
        ## Add categories here.
        categories = []
        # rescale(result_list,runner)
        cat2id = datasets.metainfo.get("cat2id")
        for k, v in cat2id.items():
            categories.append(dict(id=v, name=k))
        return dict(images=result_list, categories=categories)


@TRANSFORMS.register_module()
class ImageSegOutputFormatter(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self, work_dir) -> None:
        super().__init__()
        self._global_count = 0
        self.work_dir = work_dir

    def transform(self, results, datasets=None, **kwargs):
        # model outputs
        outputs = results.get("outputs")
        # collected data from dataset pipelines
        data_batch = results.get("data_batch")
        preds = outputs.get("preds")
        if outputs is None:
            raise RuntimeError(
                "In ImageClsFormatter, 'preds' should contrains in outputs")
        assert len(preds) == len(
            data_batch), "The length of preds and data_batch does not match"

        out_list = []
        out_dict = dict()
        for pred, data in zip(preds, data_batch):
            file_path = data.get("img_path")
            if file_path is None:
                file_path = str(self._global_count) + ".png"

            seg_path = os.path.join(
                self.work_dir,
                ".".join(os.path.basename(file_path).split(".")[:-1]) + ".png")
            pred = pred.argmax(axis=-1)
            cv2.imwrite(seg_path, pred.astype(np.uint8))
            out_dict["fileName"] = str(file_path)
            out_dict["annotations"] = dict(segmentations=seg_path)
        out_list.append(out_dict)
        return out_list

    def collect(self, result_list, datasets):
        """Reformat all results.
        for a single image result:
        {"fileName":"1.jpg", annotations:{"imgCategory":[0]}}
        """
        ## Add categories here.
        categories = []
        cat2id = datasets.metainfo.get("cat2id")
        for k, v in cat2id.items():
            categories.append(dict(id=v, name=k))
        return dict(images=result_list, categories=categories)


@TRANSFORMS.register_module()
class TextClsOutputFormatter(BaseTransform):
    """Transform Text classification results to desired format"""

    def __init__(self, work_dir) -> None:
        super().__init__()
        self._global_count = 0
        self.work_dir = work_dir

    def transform(self, results, datasets=None, **kwargs):
        # model outputs
        outputs = results.get("outputs")
        # collected data from dataset pipelines
        data_batch = results.get("data_batch")
        preds = outputs.get("preds")

        if outputs is None:
            raise RuntimeError(
                "In TextClsOutputFormatter, 'preds' should contrains in outputs"
            )
        assert len(preds) == len(
            data_batch), "The length of preds and data_batch does not match"
        preds = F.convert_to_numpy(preds)

        # list
        out_list = []
        out_dict = dict()
        for pred, data in zip(preds, data_batch):
            text = data.get("data")
            id = data.get("id")
            cat_id = pred.argmax()
            out_list.append(
                dict(text=text,
                     id=id,
                     label=datasets.metainfo.get("id2cat")[cat_id]))
        return out_list

    def collect(self, result_list, datasets=None):
        return dict(annotations=result_list)


@TRANSFORMS.register_module()
class TextNerOutputFormatter(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self, work_dir) -> None:
        super().__init__()
        self._global_count = 0
        self.work_dir = work_dir

    def transform(self, results, datasets=None, **kwargs):
        # model outputs
        outputs = results.get("outputs")
        # collected data from dataset pipelines
        data_batch = results.get("data_batch")
        preds = outputs.get("preds")

        if outputs is None:
            raise RuntimeError(
                "In ImageClsFormatter, 'preds' should contrains in outputs")
        assert len(preds) == len(
            data_batch), "The length of preds and data_batch does not match"
        # preds = F.convert_to_numpy(preds)

        output_list = []
        for index, data in enumerate(data_batch):
            pred = datasets.decode(preds[index])
            out_dict = dict(id=data["id"], text=data["data"], entities=[])
            for entity in pred:
                out_dict["entities"].append(
                    dict(labelName=entity[0],
                         mention=[entity[1], entity[2]],
                         span=data["data"][entity[1]:entity[2]]))
            output_list.append(out_dict)
        return output_list

    def collect(self, result_list, datasets=None):
        return dict(annotations=result_list)


@TRANSFORMS.register_module()
class TextRelOutputFormatter(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self, work_dir) -> None:
        super().__init__()
        self._global_count = 0
        self.work_dir = work_dir

    def transform(self, results, datasets=None, **kwargs):
        # model outputs
        outputs = results.get("outputs")
        # collected data from dataset pipelines
        data_batch = results.get("data_batch")
        preds = outputs.get("preds")

        if outputs is None:
            raise RuntimeError(
                "In ImageClsFormatter, 'preds' should contrains in outputs")
        assert len(preds) == len(
            data_batch), "The length of preds and data_batch does not match"

        output_list = []

        for index, data in enumerate(data_batch):
            preds_cat = preds[index]
            text = data["data"]
            pair_entity = data["rel_infos"]
            pred_name = datasets.metainfo.get("id2rel")[preds_cat]
            out_dict = dict(text=text,
                            id=data["id"],
                            index=data["index"],
                            entity=data["entity"])
            # for no relation entity pair, not to return relation results.
            if preds_cat != 0:
                sub_start, sub_end = pair_entity[
                    "sub_start"], pair_entity["sub_end"] + 1
                obj_start, obj_end = pair_entity[
                    "obj_start"], pair_entity["obj_end"] + 1
                subject_span = text[sub_start:sub_end]
                object_span = text[obj_start:obj_end]
                relations_dict = dict(
                    relationName=pred_name,
                    subjectSpan=subject_span,
                    objectSpan=object_span,
                    subjectMention=[sub_start, sub_end],
                    objectMention=[obj_start, obj_end],
                )
                out_dict["relations"] = relations_dict
            output_list.append(out_dict)
        return output_list
