#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   http_formatter.py
@Time    :   2023/08/07 11:33:46
@Author  :   htx 
"""
import os
import requests
import base64
import cv2
import numpy as np
import copy

from flask import request
import algicm.models.backend.functional as F

from algicm.service.utils import wrap_jsonify
from algicm.transform.transform.base import BaseTransform
from algicm.registry.common import TRANSFORMS
from algicm.utils.logger import Logger


@TRANSFORMS.register_module()
class HttpOutputFormat(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results, datasets=None, **kwargs):
        return wrap_jsonify(code="200", msg="success", content=results)


@TRANSFORMS.register_module()
class HttpImageReader(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results=None, datasets=None):
        file = request.files.get("file")
        ## file stream
        if file:
            file = file.read()
        ## address
        else:
            file_path = request.form.get("url")

            ##base64 images
            if file_path is None:
                base64_str = request.json.get("image")

                file = base64.b64decode(base64_str)

            ## local address
            elif os.path.exists(file_path):
                with open(f"{file_path}", "rb") as f:
                    file = f.read()

            ## remote address
            else:
                file = requests.get(url=file_path).content

        # Convert the decoded bytes to a NumPy array
        image_array = np.frombuffer(file, dtype=np.uint8)

        # Decode the NumPy array to an OpenCV image
        image = cv2.imdecode(image_array, 1)
        self.logger.log_msg(f"Image shape is {image.shape}")
        return dict(img=image, img_shape=image.shape, data_meta=[])


@TRANSFORMS.register_module()
class HttpTextReader(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results=None, datasets=None):
        text = request.json.get("text")
        return dict(text=text, data_meta=[], data=copy.deepcopy(text))


@TRANSFORMS.register_module()
class HttpTextRelationReader(BaseTransform):
    """Transform Image classification results to desired format"""

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results=None, datasets=None):
        text = request.json.get("text")
        entities = request.json.get("entities")
        text_o, text, sub_obj_list, entity_list, _ = datasets.parse_anns(
            dict(text=text, entities=entities))
        for rel_infos, entity in zip(sub_obj_list, entity_list):
            yield dict(id=0,
                       data=text_o,
                       entity=entity,
                       rel_infos=rel_infos,
                       text=text,
                       sub_obj=rel_infos,
                       data_meta=[])


@TRANSFORMS.register_module()
class HttpImageClsFormatter(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results, datasets=None, **kwargs):
        data = kwargs["data"]
        preds = results["preds"]
        preds = F.convert_to_numpy(preds)
        label_id = preds.argmax()
        out_list = []
        out_dict = dict()
        file_path = data.get("img_path")
        if file_path is None:
            file_path = str(0)
        out_dict["fileName"] = str(file_path)
        out_dict["annotations"] = dict(imgCategory=[label_id])
        out_list.append(out_dict)
        return out_list

    def collect(self, result_list, datasets):
        """Reformat all results.
        for a single image result:
        {"fileName":"1.jpg", annotations:{"imgCategory":[0]}}
        """
        ## Add categories here.
        categories = []
        cat2id = datasets.metainfo.get("cat2id")
        for k, v in cat2id.items():
            categories.append(dict(id=v, name=k))
        return dict(images=result_list, categories=categories)


@TRANSFORMS.register_module()
class HttpImageDetFormatter(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results, datasets=None, **kwargs):
        data = kwargs["data"]
        if results["pred_instances"][0].get("rescale_bboxes") is not None:
            bboxes_ = results["pred_instances"][0]["rescale_bboxes"]
        else:
            bboxes_ = results["pred_instances"][0]["bboxes"]
        scores_ = results["pred_instances"][0]["scores"]
        labels_ = results["pred_instances"][0]["labels"]
        out_dict = dict()
        if len(bboxes_) == 0:
            bboxes = []
            scores = []
        else:
            bboxes = np.concatenate([bboxes_, labels_.reshape(-1, 1)],
                                    axis=-1).tolist()
            scores = scores_.tolist()

        file_path = data.get("img_path")
        if file_path is None:
            file_path = str(0)

        out_dict["fileName"] = str(file_path)
        out_dict["annotations"] = dict(bboxes=bboxes, scores=scores)
        # self.logger.log_msg(f"Image category is {img_cls}")
        return [out_dict]

    def collect(self, result_list, datasets):
        """Reformat all results.
        for a single image result:
        {"fileName":"1.jpg", annotations:{"imgCategory":[0]}}
        """
        ## Add categories here.
        categories = []
        cat2id = datasets.metainfo.get("cat2id")
        for k, v in cat2id.items():
            categories.append(dict(id=v, name=k))
        return dict(images=result_list, categories=categories)


@TRANSFORMS.register_module()
class HttpImageSegFormatter(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()
        self._global_count = 0

    def transform(self, results, datasets=None, **kwargs):
        data = kwargs["data"]
        classes = kwargs.get("classes")
        classes = np.array(classes)
        pred = results.get("preds")[0]
        pred = pred.argmax(axis=-1)
        _, encoded_img = cv2.imencode(".png", pred)
        file_path = data.get("img_path")
        out_list = []
        out_dict = dict()
        if file_path is None:
            file_path = str(self._global_count) + ".png"

        # seg_path = os.path.join(self.work_dir, ".".join(os.path.basename(file_path).split(".")[:-1]) + ".png")

        encoded_img = base64.b64encode(encoded_img.tobytes()).decode("utf-8")
        out_dict["fileName"] = str(file_path)
        out_dict["annotations"] = dict(segmentations=encoded_img)
        out_list.append(out_dict)
        return out_list

    def collect(self, result_list, datasets):
        """Reformat all results.
        for a single image result:
        {"fileName":"1.jpg", annotations:{"imgCategory":[0]}}
        """
        ## Add categories here.
        categories = []
        cat2id = datasets.metainfo.get("cat2id")
        for k, v in cat2id.items():
            categories.append(dict(id=v, name=k))
        return dict(images=result_list, categories=categories)


@TRANSFORMS.register_module()
class HttpTextClsFormatter(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results, datasets=None, **kwargs):
        classes = datasets.metainfo.get("classes")
        data = kwargs.get("data")
        preds = results["preds"]
        preds = F.convert_to_numpy(preds)

        # list
        out_list = []
        out_dict = dict()
        for pred in preds:
            cat = pred.argmax()
            text = data.get("data")
            out_list.append(
                dict(text=text, label=datasets.metainfo.get("id2cat")[cat]))
        return out_list

    def collect(self, result_list, datasets=None):
        return dict(annotations=result_list)


@TRANSFORMS.register_module()
class HttpTextNerFormatter(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results, datasets=None, **kwargs):
        preds = results["preds"]
        # original text
        text = kwargs["data"]["data"]

        output_list = []

        pred = datasets.decode(preds[0])
        out_dict = dict(text=text, entities=[])
        for entity in pred:
            out_dict["entities"].append(
                dict(labelName=entity[0],
                     mention=[entity[1], entity[2]],
                     span=text[entity[1]:entity[2]]))
        output_list = [out_dict]

        return output_list

    def collect(self, result_list, datasets=None):
        return dict(annotations=result_list)


@TRANSFORMS.register_module()
class HttpTextRelFormatter(BaseTransform):

    def __init__(self) -> None:
        self.logger = Logger.get_current_instance()

    def transform(self, results, datasets=None, **kwargs):
        preds = results["preds"]
        # original text
        data = kwargs["data"]

        output_list = []
        preds_cat = preds[0]
        text = data["data"]
        pair_entity = data["rel_infos"]
        pred_name = datasets.metainfo.get("id2rel")[preds_cat]
        out_dict = dict(text=text, index=data["id"], entity=data["entity"])
        # for no relation entity pair, not to return relation results.
        if preds_cat != 0:
            sub_start, sub_end = pair_entity[
                "sub_start"], pair_entity["sub_end"] + 1
            obj_start, obj_end = pair_entity[
                "obj_start"], pair_entity["obj_end"] + 1
            subject_span = text[sub_start:sub_end]
            object_span = text[obj_start:obj_end]
            relations_dict = dict(
                relationName=pred_name,
                subjectSpan=subject_span,
                objectSpan=object_span,
                subjectMention=[sub_start, sub_end],
                objectMention=[obj_start, obj_end],
            )
            out_dict["relations"] = relations_dict
        output_list.append(out_dict)

        return output_list
