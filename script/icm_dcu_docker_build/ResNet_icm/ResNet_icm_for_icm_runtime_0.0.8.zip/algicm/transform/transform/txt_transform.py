import re
import jieba
from .base import BaseTransform
from algicm.registry.common import TRANSFORMS


@TRANSFORMS.register_module()
class RegularMatchFilter(BaseTransform):
    def __init__(self, re_match=None, meta_keys=["text"]) -> None:
        super().__init__(meta_keys)
        if re_match is None:
            # using default
            re_match = "[’!\"#$%&'()*+,-./:：;<=>?@[\\]^_`{|}~]+"

        self.re_match = repr(re_match)

    def transform(self, results, dataset=None):
        text = results["text"].data
        text = re.sub(self.re_match, "", text)
        results["text"].data = text
        return results


@TRANSFORMS.register_module()
class LowerChars(BaseTransform):
    def __init__(self, meta_keys=["text"]) -> None:
        super().__init__(meta_keys)

    def transform(self, results, datasets=None):
        results["text"].data = results["text"].data.lower()
        return results


@TRANSFORMS.register_module()
class Truncate(BaseTransform):
    def __init__(self, max_seq_len=512, meta_keys=["text"]) -> None:
        super().__init__(meta_keys)
        assert isinstance(max_seq_len, int) and max_seq_len > 0
        self.max_seq_len = max_seq_len

    def transform(self, results, datasets=None):
        results["text"].data = results["text"].data[: self.max_seq_len]
        return results


@TRANSFORMS.register_module()
class JiebaCut(BaseTransform):
    def __init__(self, meta_keys=["text"]) -> None:
        super().__init__(meta_keys)
        jieba.initialize()

    def transform(self, results, datasets=None):
        text = results["text"].data
        text = jieba.cut(text)
        results["text"].data = list(text)
        return results


@TRANSFORMS.register_module()
class FilterChar(BaseTransform):
    def __init__(self, stop_words=None, stop_files=None, meta_keys=["text"]) -> None:
        super().__init__(meta_keys)
        if all([stop_words is None, stop_files is None]):
            raise ValueError("Both 'stop_worlds' and 'stop_files' could not be None ")
        if all([stop_words is not None, stop_files is not None]):
            raise ValueError("Both 'stop_worlds' and 'stop_files' could not set value ")

        if stop_words:
            self.stop_words = stop_words
            assert isinstance(
                stop_words, (list, tuple)
            ), "stop_words should be a list or tuple of str"
        if stop_files:
            with open(stop_files, "r") as f:
                words = f.read()
            self.stop_words = words.split("\n")

    def transform(self, results, datasets=None):
        text = results["text"].data
        for token in text:
            if token in self.stop_words:
                text.remove(token)
        results["text"].data = text
        return results


@TRANSFORMS.register_module()
class TokenToId(BaseTransform):
    def __init__(
        self,
        meta_keys=["text"],
    ) -> None:
        super().__init__(meta_keys)

    def transform(self, results, datasets=None):
        if datasets is None:
            raise RuntimeError("TokenToId need to pass datasets")
        text = results["text"].data
        seq = datasets.vocab[text]
        results["text"].data = seq
        return results


@TRANSFORMS.register_module()
class PadText(BaseTransform):
    def __init__(self, seq_len=512, meta_keys=["text"]) -> None:
        super().__init__(meta_keys)
        self.seq_len = seq_len

    def transform(self, results, datasets):
        pad_value = datasets.vocab.get_pad_token_id()
        if len(results["text"].data) < self.seq_len:
            text = results["text"].data
            results["text"].data = text + int(self.seq_len - len(results["text"].data)) * [
                pad_value
            ]
        return results
