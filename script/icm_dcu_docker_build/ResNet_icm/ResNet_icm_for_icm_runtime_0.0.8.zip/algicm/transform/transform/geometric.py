from typing import Any
import numpy as np
from .base import BaseTransform
from algicm.registry.common import TRANSFORMS
from algicm.transform.annotation import Mask, Polygon


@TRANSFORMS.register_module()
class Resize(BaseTransform):
    def __init__(self, size, keep_ratio=False) -> None:
        """
        Args:
            size(tuple[int,int]|int): for (h,w)
        """
        if isinstance(size, int):
            self.scale = [size, size]
        assert len(size) == 2 and isinstance(size[0], int)
        self.size = size
        self.keep_ratio = keep_ratio

    def _compute_scale_factor(self, img_shape):
        h, w = img_shape
        if self.keep_ratio:
            max_long_edge = max(self.size)
            max_short_edge = min(self.size)
            scale_factor = min(max_long_edge / max(h, w), max_short_edge / min(h, w))
        else:
            scale_factor = (self.size[0] / h, self.size[1] / w)
        return scale_factor

    def transform(self, results, datasets=None, **kwargs):
        original_size = results["img"].shape[:2]

        scale_factor = self._compute_scale_factor(original_size)
        results["img"].resize(scale_factor)
        if "gt_bboxes" in results:
            results["gt_bboxes"].resize(scale_factor)
        if "gt_seg" in results:
            results["gt_seg"].resize(scale_factor)
        results["data_meta"].append(self._get_config(scale_factor))
        return results

    def _get_config(self, scale_factor=None):
        cfg = dict(
            type="Resize",
            size=self.size,
            keep_ratio=self.keep_ratio,
        )

        if scale_factor:
            cfg.update(dict(records=dict(scale_factor=scale_factor)))
        return cfg

    def __repr__(self) -> str:
        return f"Resize[size={self.size}, keep_ratio={self.keep_ratio}]"


@TRANSFORMS.register_module()
class TransposeImage(BaseTransform):
    def __init__(self, axes) -> None:
        self.axes = axes

    def transform(self, results, datasets=None):
        results["img"].data = np.ascontiguousarray(np.transpose(results["img"].data, self.axes))
        results["data_meta"].append(self._get_config())
        return results

    def _get_config(self):
        return dict(
            type="Transpose",
            axes=self.axes,
        )

    def __repr__(self) -> str:
        return f"Transpose[size={self.axes}]"


@TRANSFORMS.register_module()
class PolygonsToMask(BaseTransform):
    def transform(self, results, datasets=None, **kwargs):
        if "gt_seg" in results and "gt_seg_labels" in results:
            if not isinstance(results["gt_seg"], (Polygon, Mask)):
                raise RuntimeError(f"Expected type of Polygon or Mask, but got type {type(results['gt_seg'])}")
            if isinstance(results["gt_seg"], Mask):
                return results
            labels = results.pop("gt_seg_labels")
            mask = results["gt_seg"].to_mask(results["img"].shape, labels)
            results["gt_seg"] = mask
        return results
