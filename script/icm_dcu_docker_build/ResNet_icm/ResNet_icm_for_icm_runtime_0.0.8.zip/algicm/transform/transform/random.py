import numpy as np

from .base import BaseTransform
from algicm.utils.misc import is_list_of
from collections import Sequence
from algicm.registry.common import TRANSFORMS


@TRANSFORMS.register_module()
class RandomFlip(BaseTransform):

    def __init__(self, p, direction="horizontal") -> None:
        if isinstance(p, list):
            assert is_list_of(p, float)
            assert 0 <= sum(p) <= 1
        elif isinstance(p, float):
            assert 0 <= p <= 1
        else:
            raise ValueError(f"probs must be float or list of float, but \
                              got `{type(p)}`.")
        self.p = p
        valid_directions = ["horizontal", "vertical", "diagonal"]
        if isinstance(direction, str):
            assert direction in valid_directions
        elif isinstance(direction, list):
            assert is_list_of(direction, str)
            assert set(direction).issubset(set(valid_directions))
        else:
            raise ValueError(f"direction must be either str or list of str, \
                               but got `{type(direction)}`.")
        self.direction = direction

        if isinstance(p, list):
            assert len(p) == len(self.direction)

    def _choose_direction(self) -> str:
        """Choose the flip direction according to `prob` and `direction`"""
        if isinstance(self.direction,
                      Sequence) and not isinstance(self.direction, str):
            # None means non-flip
            direction_list: list = list(self.direction) + [None]
        elif isinstance(self.direction, str):
            # None means non-flip
            direction_list = [self.direction, None]

        if isinstance(self.p, list):
            non_prob = 1 - sum(self.p)
            prob_list = self.p + [non_prob]
        elif isinstance(self.p, float):
            non_prob = 1.0 - self.p
            # exclude non-flip
            single_ratio = self.p / (len(direction_list) - 1)
            prob_list = [single_ratio] * (len(direction_list) - 1) + [non_prob]

        flip_direction = np.random.choice(direction_list, p=prob_list)

        return flip_direction

    def transform(self, results, datasets=None):
        flip_direction = self._choose_direction()

        if flip_direction is not None:
            results["img"].flip(flip_direction)
            if "gt_bboxes" in results:
                results["gt_bboxes"].flip(results["img"].shape, flip_direction)
            if "gt_seg" in results:
                results["gt_seg"].flip(results["img"].shape, flip_direction)
        results["data_meta"].append(self._get_config(flip_direction))
        return results

    def _get_config(self, flip=None):
        return dict(
            type="RandomFlip",
            p=self.p,
            direction=self.direction,
            records=dict(flip=flip),
        )


@TRANSFORMS.register_module()
class RandomCrop(BaseTransform):
    """Random crop the image & seg.

    Args:
        crop_size (tuple): Expected size after cropping, (h, w).
        cat_max_ratio (float): The maximum ratio that single category could
            occupy.
    """

    def __init__(self, crop_size, cat_max_ratio=1., ignore_index=255):
        assert crop_size[0] > 0 and crop_size[1] > 0
        self.crop_size = crop_size
        self.cat_max_ratio = cat_max_ratio
        self.ignore_index = ignore_index

    def get_crop_bbox(self, img):
        """Randomly get a crop bounding box."""
        margin_h = max(img.shape[0] - self.crop_size[0], 0)
        margin_w = max(img.shape[1] - self.crop_size[1], 0)
        offset_h = np.random.randint(0, margin_h + 1)
        offset_w = np.random.randint(0, margin_w + 1)
        crop_y1, crop_y2 = offset_h, offset_h + self.crop_size[0]
        crop_x1, crop_x2 = offset_w, offset_w + self.crop_size[1]

        return crop_y1, crop_y2, crop_x1, crop_x2

    def crop(self, img, crop_bbox):
        """Crop from ``img``"""
        crop_y1, crop_y2, crop_x1, crop_x2 = crop_bbox
        img = img[crop_y1:crop_y2, crop_x1:crop_x2, ...]
        return img

    def __call__(self, results):
        """Call function to randomly crop images, semantic segmentation maps.

        Args:
            results (dict): Result dict from loading pipeline.

        Returns:
            dict: Randomly cropped results, 'img_shape' key in result dict is
                updated according to crop size.
        """

        img = results['img']
        crop_bbox = self.get_crop_bbox(img)
        if self.cat_max_ratio < 1.:
            # Repeat 10 times
            for _ in range(10):
                seg_temp = self.crop(results['gt_semantic_seg'], crop_bbox)
                labels, cnt = np.unique(seg_temp, return_counts=True)
                cnt = cnt[labels != self.ignore_index]
                if len(cnt) > 1 and np.max(cnt) / np.sum(
                        cnt) < self.cat_max_ratio:
                    break
                crop_bbox = self.get_crop_bbox(img)

        # crop the image
        img = self.crop(img, crop_bbox)
        img_shape = img.shape
        results['img'] = img
        results['img_shape'] = img_shape

        # crop semantic seg
        for key in results.get('seg_fields', []):
            results[key] = self.crop(results[key], crop_bbox)

        return results

    def __repr__(self):
        return self.__class__.__name__ + f'(crop_size={self.crop_size})'