import random
import numpy as np
import copy
from .batch import BaseTransform, Compose
from algicm.registry.common import TRANSFORMS
from ..annotation.base import BaseImageAnns
from ..annotation import Image


@TRANSFORMS.register_module()
class Mosaic(BaseTransform):

    def __init__(
        self,
        img_scale=[640, 640],
        center_ratio_range=[0.5, 1.5],
        bbox_clip_border=True,
        pad_val: float = 114.0,
        pre_transform=None,
        prob: float = 1.0,
        max_refetch: int = 15,
    ) -> None:
        assert isinstance(img_scale, (list, tuple))
        assert 0 <= prob <= 1.0, "The probability should be in range [0,1]. " f"got {prob}."
        self.max_refetch = max_refetch
        self.prob = prob

        if pre_transform is None:
            self.pre_transform = None
        else:
            self.pre_transform = Compose(pre_transform)

        self.img_scale = img_scale
        self.center_ratio_range = center_ratio_range
        self.bbox_clip_border = bbox_clip_border
        self.pad_val = pad_val

    def get_indexes(self, ds):
        indexes = [random.randint(0, (len(ds) - 1)) for _ in range(3)]
        return indexes

    def mosaic_transform(self, results, mix_results):
        # first geneter mosaic image
        if len(results["img"].shape) == 3:
            mosaic_img_shape = (
                int(self.img_scale[0] * 2),
                int(self.img_scale[1] * 2),
                3,
            )
        else:
            mosaic_img_shape = (int(self.img_scale[0] * 2),
                                int(self.img_scale[1] * 2))
        mosaic_img = np.full(
            mosaic_img_shape,
            fill_value=self.pad_val,
            dtype=results["img"].dtype,
        )
        # random a mosaic center
        mosaic_cx = int(
            random.uniform(*self.center_ratio_range) * self.img_scale[1])
        mosaic_cy = int(
            random.uniform(*self.center_ratio_range) * self.img_scale[0])
        mosaic_ctr = (mosaic_cx, mosaic_cy)
        # img_scale for (h,w)
        img_scale_wh = (self.img_scale[1], self.img_scale[0])

        # sequence 4: top_left, top_right, bottom_left, bottom_right
        for i in range(4):
            if i == 0:
                results_patch = results
            else:
                results_patch = mix_results[i - 1]

            data_i = results_patch["img"]

            # resize img patch
            data_h_i, data_w_i = data_i.shape[:2]
            scale_ratio_i = min(self.img_scale[0] / data_h_i,
                                self.img_scale[1] / data_w_i)
            # in-place resize
            data_i.resize([scale_ratio_i, scale_ratio_i])
            patch_shape_wh = data_i.shape[:2][::-1]
            # compute copy-paste coordinates
            paste_coord, copy_coord = self._compute_mosaic_coordinates(
                i, mosaic_ctr, patch_shape_wh, img_scale_wh)
            x1_p, y1_p, x2_p, y2_p = paste_coord
            x1_c, y1_c, x2_c, y2_c = copy_coord
            mosaic_img[y1_p:y2_p,
                       x1_p:x2_p] = data_i.crop_(data_i.data, [copy_coord])[0]
            # adjust coordinate
            padw = x1_p - x1_c
            padh = y1_p - y1_c
            valid_index = None
            # for bboxes
            if "gt_bboxes" in results_patch:
                results_patch["gt_bboxes"].resize(
                    [scale_ratio_i, scale_ratio_i])
                results_patch["gt_bboxes"].translate([padw, padh])
                results_patch["gt_bboxes"].clip(
                    [int(self.img_scale[0] * 2),
                     int(self.img_scale[1] * 2)])
                valid_index = results_patch["gt_bboxes"].is_inside(
                    [int(self.img_scale[0] * 2),
                     int(self.img_scale[1] * 2)])
                if valid_index is not None:
                    results_patch["gt_bboxes"] = results_patch["gt_bboxes"][
                        valid_index]
                    results_patch["gt_bboxes_labels"] = results_patch[
                        "gt_bboxes_labels"][valid_index]

        if "gt_bboxes" in results:
            for i in range(3):
                results["gt_bboxes"].cat(mix_results[i]["gt_bboxes"].data)
                results["gt_bboxes_labels"].cat(
                    mix_results[i]["gt_bboxes_labels"].data)

        results["img"] = Image(mosaic_img)
        return results

    def _compute_mosaic_coordinates(self, index, center_position_xy,
                                    patch_shape_wh, img_scale_wh):
        assert index in (0, 1, 2, 3)
        if index == 0:
            # index0 to top left part of image
            x1, y1, x2, y2 = (
                max(center_position_xy[0] - patch_shape_wh[0], 0),
                max(center_position_xy[1] - patch_shape_wh[1], 0),
                center_position_xy[0],
                center_position_xy[1],
            )
            crop_coord = (
                patch_shape_wh[0] - (x2 - x1),
                patch_shape_wh[1] - (y2 - y1),
                patch_shape_wh[0],
                patch_shape_wh[1],
            )

        elif index == 1:
            # index1 to top right part of image
            x1, y1, x2, y2 = (
                center_position_xy[0],
                max(center_position_xy[1] - patch_shape_wh[1], 0),
                min(center_position_xy[0] + patch_shape_wh[0],
                    img_scale_wh[0] * 2),
                center_position_xy[1],
            )
            crop_coord = (
                0,
                patch_shape_wh[1] - (y2 - y1),
                min(patch_shape_wh[0], x2 - x1),
                patch_shape_wh[1],
            )

        elif index == 2:
            # index2 to bottom left part of image
            x1, y1, x2, y2 = (
                max(center_position_xy[0] - patch_shape_wh[0], 0),
                center_position_xy[1],
                center_position_xy[0],
                min(img_scale_wh[1] * 2,
                    center_position_xy[1] + patch_shape_wh[1]),
            )
            crop_coord = (
                patch_shape_wh[0] - (x2 - x1),
                0,
                patch_shape_wh[0],
                min(y2 - y1, patch_shape_wh[1]),
            )

        else:
            # index3 to bottom right part of image
            x1, y1, x2, y2 = (
                center_position_xy[0],
                center_position_xy[1],
                min(center_position_xy[0] + patch_shape_wh[0],
                    img_scale_wh[0] * 2),
                min(img_scale_wh[1] * 2,
                    center_position_xy[1] + patch_shape_wh[1]),
            )
            crop_coord = (
                0,
                0,
                min(patch_shape_wh[0], x2 - x1),
                min(y2 - y1, patch_shape_wh[1]),
            )

        paste_coord = x1, y1, x2, y2
        return paste_coord, crop_coord

    def transform(self, results, datasets=None):
        if datasets is None:
            raise RuntimeError("Mosiac only used in training process")

        if random.uniform(0, 1) > self.prob:
            return results

        for _ in range(self.max_refetch):
            # get index of one or three other images
            indexes = self.get_indexes(datasets)
            # get images information will be used for Mosaic or MixUp
            # if hasattr(datasets, "get_ann_info"):
            #     mix_results1 = [copy.deepcopy(datasets.get_data_info(index)) for index in indexes]
            #     mix_results2 = [copy.deepcopy(datasets.get_ann_info(index)) for index in indexes]
            #     mix_results = [dict(**dict1, **dict2) for dict1, dict2 in zip(mix_results1, mix_results2)]
            # else:
            mix_results = [
                copy.deepcopy(datasets.get_data_info(index))
                for index in indexes
            ]

            if self.pre_transform is not None:
                for i, data in enumerate(mix_results):
                    # before Mosaic or MixUp need to go through
                    # the necessary pre_transform
                    data["data_meta"] = []
                    _results = self.pre_transform(data)
                    mix_results[i] = _results

            if None not in mix_results:
                break
        else:
            raise RuntimeError(
                "The loading pipeline of the original dataset"
                " always return None. Please check the correctness "
                "of the dataset and its pipeline.")
        # Mosaic
        results = self.mosaic_transform(results, mix_results)
        return results
