import numpy as np

from .base import BaseTransform
from ..annotation.base import BaseDataStructure
from algicm.registry.common import TRANSFORMS, ALL_METHODS
from abc import abstractmethod, ABC
from typing import Callable, Dict, Optional, Sequence


@TRANSFORMS.register_module()
class Stack(BaseTransform):
    def __init__(self, meta_keys=["img"]) -> None:
        self.meta_keys = meta_keys

    def transform(self, results_list, datasets=None):
        """
        results_list (list[dict])
        """
        results = dict()
        assert isinstance(results_list[0], dict)
        all_keys = results_list[0].keys()
        for k in all_keys:
            data_list = []
            for result in results_list:
                if isinstance(result[k], BaseDataStructure):
                    data_list.append(result[k].to_numpy())
                else:
                    data_list.append(result[k])
            if k in self.meta_keys:
                data_list = np.stack(data_list)
            results[k] = data_list
        return results

    def __repr__(self):
        return f"Stack[meta_keys={self.meta_keys}]"


@ALL_METHODS.register_module()
class Compose:
    """Compose multiple transforms sequentially.

    Args:
        transforms (list[dict | callable]): Sequence of transform object or
            config dict to be composed.
    """

    def __init__(self, transforms):
        if not isinstance(transforms, Sequence):
            transforms = [transforms]
        self.transforms = []
        for transform in transforms:
            if isinstance(transform, dict):
                transform = TRANSFORMS.build(transform)
                self.transforms.append(transform)
            elif callable(transform):
                self.transforms.append(transform)
            else:
                raise TypeError("transform must be callable or a dict, but got" f" {type(transform)}")

    def __iter__(self):
        """Allow easy iteration over the transform sequence."""
        return iter(self.transforms)

    def __call__(self, results: Dict, datasets=None, **kwargs) -> Optional[Dict]:
        """Call function to apply transforms sequentially."""
        for t in self.transforms:
            results = t(results, datasets, **kwargs)  # type: ignore
            if results is None:
                return None
        return results

    def __repr__(self):
        """Compute the string representation."""
        format_string = "Compose("
        for t in self.transforms:
            format_string += f"{t} \n"
        format_string += "\n)"
        return format_string
