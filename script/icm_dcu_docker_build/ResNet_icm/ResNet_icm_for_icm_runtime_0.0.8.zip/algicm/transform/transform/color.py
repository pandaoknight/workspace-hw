import numpy as np
from .base import BaseTransform
from algicm.registry.common import TRANSFORMS
from algicm.utils.logger import Logger


@TRANSFORMS.register_module()
class Normalize(BaseTransform):
    def __init__(self, mean, std, eps=1e-10):
        self.mean = np.array(mean, dtype=np.float32)
        self.std = np.array(std, dtype=np.float32)
        self.eps = eps

    def transform(self, results, datasets=None):
        results["img"].data = ((results["img"].data - self.mean) / (self.std + self.eps)).astype(
            results["img"].data.dtype
        )
        results["data_meta"].append(self._get_config())
        return results

    def _get_config(self):
        return dict(
            type="Normalize",
            mean=self.mean.tolist(),
            std=self.std.tolist(),
            eps=self.eps,
        )

    def __repr__(self) -> str:
        return f"Normalize[mean={self.mean.tolist()},std={self.std.tolist()},eps={self.eps}]"


@TRANSFORMS.register_module()
class ConvertDataType(BaseTransform):
    _mapping = {
        "float32": np.float32,
        "int64": np.int64,
        "int32": np.int32,
        "float16": np.float16,
        "uint8": np.uint8,
    }

    def __init__(self, mapping=dict(img="float32")) -> None:
        self.mapping_dict = mapping
        for k, v in mapping.items():
            if v not in self._mapping:
                raise ValueError(f"Not support type {v} for {k}")

    def transform(self, results, datasets=None, **kwargs):
        for k, v in self.mapping_dict.items():
            if k not in results:
                Logger.log_msg(
                    f"{k} is not in results for Transform[ConvertDataType], ignore this message in inference.",
                    level="DEBUG",
                )
                continue
            results[k].data = results[k].data.astype(self._mapping[v])
        return results

    def _get_config(self):
        return dict(type="ConvertDataType", dtype=self.dtype, meta_keys=self.meta_keys)

    def __repr__(self) -> str:
        return f"ConvertDataType[dtype={self.dtype},meta_keys={self.meta_keys}]"
