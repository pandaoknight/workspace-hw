import numpy as np
import cv2
from .base import BaseTransform
from algicm.registry.common import TRANSFORMS, DATA_STRUCTURE
from algicm.utils.logger import Logger


@TRANSFORMS.register_module()
class LoadImage(BaseTransform):
    """Load an image from file or ndarray"""

    def __init__(self, channels=3) -> None:
        self.channels = channels

    def transform(self, results: dict, datasets=None):
        """Functions to load image.

        Args:
            results (dict): Result dict from
                :class:`mmengine.dataset.BaseDataset`.

        Returns:
            dict: The dict contains loaded image and meta information.
        """
        if results.get("img") is not None:
            img = results["img"]
        else:
            filename = results["img_path"]
            img = cv2.imread(filename)
            if img is None:
                return
        if img.ndim == 3:
            if img.shape[-1] == 1:
                img = np.squeeze(np.stack([img, img, img], axis=-2), axis=-1)
            else:
                img = img[..., :3]
        if img.ndim == 2:
            img = np.stack([img, img, img], axis=-1)
        results["img"] = img
        return results

    def _get_config(self):
        return dict(type="LoadImage", channels=self.channels)

    def __repr__(self) -> str:
        return f"LoadImage[channels={self.channels}]"


@TRANSFORMS.register_module()
class WrapData(BaseTransform):

    def __init__(self, mapping=dict(img="Image")) -> None:
        assert isinstance(mapping, dict)
        self.mapping = mapping

    def transform(self, results, datasets=None, **kwargs):
        for k, v in self.mapping.items():
            data_structure = DATA_STRUCTURE.get(v)
            if data_structure is None:
                raise ValueError(
                    f"Data structure {v} is not in registry, supported: {DATA_STRUCTURE._module_dict.keys()}"
                )
            if k not in results:
                Logger.log_msg(
                    f"Could not find {k} in results,ignore this message in inference.",
                    level="DEBUG")
                continue
            results[k] = data_structure(results[k])

        return results

    def _get_config(self):
        return dict(type="WrapData", mapping=self.mapping)
