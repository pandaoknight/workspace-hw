from abc import abstractmethod, ABC
from typing import Any, Callable, Dict, Optional, Sequence
from algicm.utils.misc import is_seq_of
from algicm.registry.common import TRANSFORMS


class BaseTransform(ABC):
    """
    This abstract class defines a transform class. All transform should inheriate from BaseTransform.

    """

    def _get_config(self):
        raise NotImplementedError("Not implement")

    @abstractmethod
    def transform(self, results, datasets=None, **kwargs):
        pass

    def __call__(self, results, datasets=None, **kwargs):
        if isinstance(results, dict) and ("data_meta" not in results):
            results["data_meta"] = []
        return self.transform(results, datasets, **kwargs)
