import numpy as np
from algicm.models.backend.utils import Tensor
import algicm.models.backend.functional as F


def bbox2roi(bbox_list):
    """Convert a list of bboxes to roi format.

    Args:
        bbox_list (list[Tensor]): a list of bboxes corresponding to a batch
            of images.

    Returns:
        Tensor: shape (n, 5), [batch_ind, x1, y1, x2, y2]
    """
    rois_list = []
    for img_id, bboxes in enumerate(bbox_list):
        if bboxes.shape[0] > 0:
            img_inds = F.conver_dtype(
                F.new_full(bboxes, (bboxes.shape[0], 1), img_id), bboxes.dtype)
            rois = F.concat([img_inds, bboxes[:, :4]], axis=-1)
        else:

            rois = F.zeros((0, 5))
        rois_list.append(rois)
    rois = F.concat(rois_list, 0)
    return rois


def bbox2result(bboxes, labels, num_classes):
    """Convert detection results to a list of numpy arrays.

    Args:
        bboxes (torch.Tensor | np.ndarray): shape (n, 5)
        labels (torch.Tensor | np.ndarray): shape (n, )
        num_classes (int): class number, including background class

    Returns:
        list(ndarray): bbox results of each class
    """
    if bboxes.shape[0] == 0:
        return [np.zeros((0, 5), dtype=np.float32) for i in range(num_classes)]
    else:
        if isinstance(bboxes, Tensor):

            bboxes = F.convert_to_numpy(bboxes)
            labels = F.convert_to_numpy(labels)
        return [bboxes[labels == i, :] for i in range(num_classes)]