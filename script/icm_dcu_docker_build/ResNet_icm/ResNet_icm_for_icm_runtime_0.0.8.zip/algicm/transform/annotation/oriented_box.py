import cv2
import numpy as np
import warnings
from .base import BaseImageAnns
from .utils import compute_2d_pad_shape
from algicm.registry.common import DATA_STRUCTURE

@DATA_STRUCTURE.register_module()
class OrientedBoxArray(BaseImageAnns):
    def __init__(self, data, in_type="xywha") -> None:
        """
        Args:
        """

        assert in_type in ["xywha", "xyxyxyxy"]
        assert isinstance(data, list) or isinstance(data, np.ndarray)
        box_data = np.array(data, dtype=np.float32)
        if box_data.ndim != 2 and box_data.shape[-1] != 4:
            raise ValueError("box data should have shape with (N,4)")
        if in_type == "xyxyxyxy":
            box_data = OrientedBoxArray.xyxyxyxy_to_xywha(box_data)
        super().__init__(box_data)

    @staticmethod
    def norm_angle(angle, angle_range):
        assert angle_range in ["360", "180", "90"]
        if angle_range == "360":
            return angle // (np.pi * 2)
        elif angle_range == "180":
            return angle // np.pi
        else:
            return (angle + np.pi / 2) % np.pi - np.pi / 2

    @staticmethod
    def xywha_to_xyxyxyxy(boxes):

        ctr, w, h, theta = boxes[:, :2], boxes[:, 2], boxes[:, 3], boxes[:, 4]

        cos_value, sin_value = np.cos(theta), np.sin(theta)
        vec1 = np.concatenate([w / 2 * cos_value, w / 2 * sin_value], axis=-1)
        vec2 = np.concatenate([-h / 2 * sin_value, h / 2 * cos_value], axis=-1)
        pt1 = ctr + vec1 + vec2
        pt2 = ctr + vec1 - vec2
        pt3 = ctr - vec1 - vec2
        pt4 = ctr - vec1 + vec2
        return np.concatenate([pt1, pt2, pt3, pt4], dim=-1)

    @staticmethod
    def xyxyxyxy_to_xywha(boxes):
        original_shape = boxes.shape[:-1]
        points = boxes.reshape(-1, 4, 2)
        rboxes = []
        for pts in points:
            (x, y), (w, h), angle = cv2.minAreaRect(pts)
            rboxes.append([x, y, w, h, angle / 180 * np.pi])
        rboxes = np.array(rboxes)
        return rboxes.reshape(*original_shape, 5)

    # properties

    @property
    def areas(self):
        w = self.data[..., 2]
        h = self.data[..., 3]
        return w * h

    def __repr__(self):
        s = f"OrientedBoxArray[num_box = {len(self.data)}]"
        return s

    # transforms
    @staticmethod
    def clip_(rboxes, img_shape=None):
        warnings.warn("The `clip` function does nothing in `RotatedBoxes`.")
        return rboxes

    def clip(self, img_shape=None):
        # warnings.warn("The `clip` function does nothing in `RotatedBoxes`.")
        self.data = OrientedBoxArray.clip_(self.data, img_shape)

    @staticmethod
    def pad_(rboxes, pad_shape):
        np_pad_shape = compute_2d_pad_shape(pad_shape, ndim=2)
        pad_top, pad_left = np_pad_shape[0][0], np_pad_shape[1][0]
        rboxes[..., 0] += pad_left
        rboxes[..., 1] += pad_top
        return rboxes

    def pad(self, pad_shape):
        self.data = OrientedBoxArray.pad_(self.data, pad_shape)

    @staticmethod
    def crop_(rboxes, area):
        xmin, ymin, _, _ = list(map(int, area))
        rboxes[..., 0] -= xmin
        rboxes[..., 1] -= ymin
        return rboxes

    def crop(self, area):
        xmin, ymin, xmax, ymax = list(map(int, area))
        self.data = OrientedBoxArray.crop_(self.data, [xmin, ymin, xmax, ymax])

    @staticmethod
    def flip_(rboxes, img_shape, direction="horizontal"):
        assert direction in ["horizontal", "vertical", "diagonal"]
        flipped = rboxes
        if direction == "horizontal":
            flipped[..., 0] = img_shape[1] - flipped[..., 0]
            flipped[..., 4] = -flipped[..., 4]
        elif direction == "vertical":
            flipped[..., 1] = img_shape[0] - flipped[..., 1]
            flipped[..., 4] = -flipped[..., 4]
        else:
            flipped[..., 0] = img_shape[1] - flipped[..., 0]
            flipped[..., 1] = img_shape[0] - flipped[..., 1]
        return flipped

    def flip(self, img_shape, direction="horizontal"):
        self.data = OrientedBoxArray.flip_(self.data, img_shape, direction=direction)

    @staticmethod
    def rotate_(rboxes, angle, *, center=None, img_shape=None, auto_bound=True):
        """
        Rotate the box with the image by some degree.
        """
        boxes = rboxes
        rotation_matrix = OrientedBoxArray.get_rotation_matrix(
            angle, center=center, img_shape=img_shape, auto_bound=auto_bound
        )
        centers, wh, a = boxes[..., :2], boxes[..., 2:4], boxes[..., 4]
        a = a + angle / 180 * np.pi
        centers = np.concatenate([centers, np.zeros(-1, 2, 1)], axis=-1)
        ceneter_T = np.transpose(centers, (0, 2, 1))
        ceneter_T = np.multiply(rotation_matrix, ceneter_T)
        centers = np.transpose(ceneter_T, (0, 2, 1))
        centers = np.concatenate([centers, wh, a], dim=-1)

        return centers

    def rotate(self, angle, *, center=None, img_shape=None, auto_bound=True):

        self.data = OrientedBoxArray.rotate_(
            self.data, angle, center=center, img_shape=img_shape, auto_bound=auto_bound
        )

    @staticmethod
    def resize_(rboxes, scale_factor):
        boxes = rboxes
        assert len(scale_factor) == 2
        scale_x, scale_y = scale_factor[::-1]
        ctrs, w, h, t = boxes[..., :2], boxes[..., 2], boxes[..., 3], boxes[..., 4]
        cos_value, sin_value = np.cos(t), np.sin(t)

        ctrs = ctrs * np.array([scale_x, scale_y])
        # rescale width and height
        w = w * np.sqrt((scale_x * cos_value) ** 2 + (scale_y * sin_value) ** 2)
        h = h * np.sqrt((scale_x * sin_value) ** 2 + (scale_y * cos_value) ** 2)
        # recalculate theta
        t = np.atan2(scale_x * sin_value, scale_y * cos_value)
        boxes = np.concatenate([ctrs, w, h, t], axis=-1)
        return boxes

    def resize(self, scale_factor):
        self.data = OrientedBoxArray.resize_(self.data, scale_factor=scale_factor)

    # relations
    def is_inside_(
        rbboxes, img_shape, all_inside: bool = False, allowed_border: int = 0
    ):
        img_h, img_w = img_shape
        return (
            (rbboxes[..., 0] <= img_w + allowed_border)
            & (rbboxes[..., 1] <= img_h + allowed_border)
            & (rbboxes[..., 0] >= -allowed_border)
            & (rbboxes[..., 1] >= -allowed_border)
        )

    def is_inside(
        self, img_shape, all_inside: bool = False, allowed_border: int = 0
    ):
        """Find boxes inside the image.

        Args:
            img_shape (Tuple[int, int]): A tuple of image height and width.
            all_inside (bool): Whether the boxes are all inside the image or
                part inside the image. Defaults to False.
            allowed_border (int): Boxes that extend beyond the image shape
                boundary by more than ``allowed_border`` are considered
                "outside" Defaults to 0.

        Returns:
            BoolTensor: A BoolTensor indicating whether the box is inside
            the image. Assuming the original boxes have shape (m, n, 5),
            the output has shape (m, n).
        """
        return OrientedBoxArray.is_inside_(
            self.data, img_shape, all_inside, allowed_border
        )
