from .base import BaseImageAnns

import numpy as np

from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class ClassLabel(BaseImageAnns):
    def __init__(self, data, dtype="int32"):
        super().__init__(data)

    @staticmethod
    def filter_(label, indices):
        return label[indices]

    def filter(self, indices):
        self.data = self.data[indices]

    @staticmethod
    def cat_(labels1, labels2):
        labels = np.concatenate([labels1, labels2], 0)
        return labels

    def cat(self, labels):
        self.data = ClassLabel.cat_(self.data, labels)

    def __setitem__(self, index, values):
        self.data[index] = values

    def __repr__(self) -> str:
        return f"ClassLabel[num_label={len(self.data)}]"

    def __len__(self):
        if isinstance(self.data, np.ndarray):
            if self.data.ndim == 0 and self.data.size==1:
                return 1
            else:
                return len(self.data)
             
                