import cv2
import numpy as np

from .base import BaseImageData
from .utils import compute_2d_pad_shape
from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class Image(BaseImageData):
    """
    Numpy based (H, W, C) shape image data
    """

    def __init__(self, data: np.ndarray) -> None:
        """
        Args:
            data (np.ndarray): image data, should be a 3-dim (H, W, C) or 2-dim (H, W) ndarray
            .Note that the number of the color channel
            restricts some color-involved image transformations.
        """
        assert isinstance(data, np.ndarray)
        if not (data.ndim == 2 or data.ndim == 3):
            raise ValueError("data dim should be 2 or 3")
        super().__init__(data=data)

    @classmethod
    def from_pil(cls, image):
        return cls(np.array(image))

    def to_pil(self):
        import PIL.Image

        data = self.data if self.channels > 1 else self.data[..., 0]
        return PIL.Image.fromarray(data)

    # properties
    @property
    def width(self) -> int:
        return self.data.shape[1]

    @property
    def height(self) -> int:
        return self.data.shape[0]

    @property
    def shape(self):
        return self.data.shape

    @property
    def channels(self) -> int:
        if self.data.ndim == 3:
            return self.data.shape[2]
        else:
            return 0

    def __repr__(self):
        return f"ImageAnnotaion[img_w={self.width}, img_h={self.height}, channels={self.channels}, dtype={self.dtype}]"

    # transformations
    @staticmethod
    def resize_(img, scale_factor, interpolation=cv2.INTER_LINEAR):
        h, w = img.shape[:2]
        hs, ws = scale_factor
        # new_h, new_w = int(h * hs), int(w * ws)
        new_h, new_w = round(h * hs), round(w * ws)
        return cv2.resize(img, (new_w, new_h), interpolation=interpolation)

    def resize(self, scale_factor):
        self.data = Image.resize_(self.data, scale_factor)

    @staticmethod
    def pad_(img, pad_shape, fill_value=0):
        np_pad_shape = compute_2d_pad_shape(pad_shape)

        return np.pad(img, np_pad_shape, constant_values=fill_value)
        # self.data = np.pad(self.data, np_pad_shape, constant_values=fill_value)

    def pad(self, shape, fill_value=0):
        self.data = Image.pad_(self.data, shape, fill_value=fill_value)

    @staticmethod
    def crop_(img, boxes):
        boxes = np.array(boxes)
        if boxes.ndim != 2 or boxes.shape[-1] != 4:
            raise RuntimeError("Boxes in crop should be (N,4) format")
        img_h, img_w = img.shape[:2]
        patches = []
        boxes[..., 0] = np.maximum(boxes[..., 0], 0)
        boxes[..., 1] = np.maximum(boxes[..., 1], 0)
        boxes[..., 2] = np.minimum(boxes[..., 2], img_w)
        boxes[..., 3] = np.minimum(boxes[..., 3], img_h)
        areas = ((boxes[..., 2] - boxes[..., 0]) > 0) & (
            (boxes[..., 3] - boxes[..., 1]) > 0)
        valid_bboxes = boxes[areas > 0]
        valid_bboxes = valid_bboxes.astype(np.int32)
        for box in valid_bboxes:
            xmin, ymin, xmax, ymax = box
            patches.append(img[ymin:ymax, xmin:xmax, ...])

        return patches

    def crop(self, boxes):
        if not len(boxes) == 1:
            raise ValueError("Crop function only support crop one area.")
        self.data = Image.crop_(self.data, boxes)[0]

    @staticmethod
    def flip_(img, direction="horizontal"):
        assert direction in ["horizontal", "vertical", "diagonal"]
        if direction == "horizontal":
            return np.flip(img, 1)
        elif direction == "vertical":
            return np.flip(img, 0)
        else:
            return np.flip(img, axis=(0, 1))

    def flip(self, direction="horizontal"):
        self.data = Image.flip_(self.data, direction=direction)

    @staticmethod
    def rotate_(
        img,
        angle,
        center=None,
        auto_bound=True,
        border_value: int = 0,
        interpolation: str = "bilinear",
        border_mode: str = "constant",
    ):
        if center is not None and auto_bound:
            raise ValueError("`auto_bound` conflicts with `center`")
        h, w = img.shape[:2]
        if center is None:
            center = ((w - 1) * 0.5, (h - 1) * 0.5)
        assert isinstance(center, tuple)

        matrix = cv2.getRotationMatrix2D(center, -angle, 1.0)
        if auto_bound:
            cos = np.abs(matrix[0, 0])
            sin = np.abs(matrix[0, 1])
            new_w = h * sin + w * cos
            new_h = h * cos + w * sin
            matrix[0, 2] += (new_w - w) * 0.5
            matrix[1, 2] += (new_h - h) * 0.5
            w = int(np.round(new_w))
            h = int(np.round(new_h))
        rotated = cv2.warpAffine(
            img,
            matrix,
            (w, h),
            flags=Image.CV2_INTERP_CODES[interpolation],
            borderMode=Image.CV2_INTERP_CODES[border_mode],
            borderValue=border_value,
        )

        return rotated

    def rotate(
        self,
        angle,
        center=None,
        auto_bound=True,
        border_value: int = 0,
        interpolation: str = "bilinear",
        border_mode: str = "constant",
    ):
        self.data = Image.rotate_(
            self.data,
            angle=angle,
            center=center,
            auto_bound=auto_bound,
            border_value=border_value,
            interpolation=interpolation,
            border_mode=border_mode,
        )

    @staticmethod
    def paste_on_(img, area, data):
        x1, y1, x2, y2 = list(map(int, area))
        assert data.shape[0] == (y2 - y1) and data.shape[1] == (x2 - x1)
        img[y1:y2, x1:x2] = data.copy()
        return img

    def paste_on(self, area, data):
        self.data = Image.paste_on_(area, data)

    def __eq__(self, img):
        if not isinstance(img, Image):
            raise TypeError()
        return self.dtype == img.dtype and np.all(self.data == img.data)
