import numpy as np
from typing import Iterable, List
from .base import BaseImageAnns
from .utils import compute_2d_pad_shape
from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class BoxArray(BaseImageAnns):
    def __init__(self, data, in_type="xyxy", dtype="float32") -> None:
        """
        Args:
            data (array|list): box array contains: xyxy format
        """
        assert in_type in ["xyxy", "cxcywh"]
        assert isinstance(data, list) or isinstance(data, np.ndarray)
        if isinstance(dtype, str):
            dtype_ = self._dtype[dtype]
        else:
            dtype_ = dtype

        if len(data) == 0:
            box_data = np.zeros([0, 4], dtype=dtype_)
        else:

            box_data = np.array(data, dtype=dtype_)

        if box_data.ndim != 2 and box_data.shape[-1] != 4:
            raise ValueError("box data should have shape with (N,4)")
        if in_type == "cxcywh":
            box_data = BoxArray.cxcywh_to_xyxy(box_data)
        super().__init__(box_data)

    @staticmethod
    def cxcywh_to_xyxy(boxes):
        """Convert box coordinates from (cx, cy, w, h) to (x1, y1, x2, y2).

        Args:
            boxes (Tensor): cxcywh boxes tensor with shape of (..., 4).

        Returns:
            Tensor: xyxy boxes tensor with shape of (..., 4).
        """
        ctr, wh = boxes[..., :2], boxes[..., 2:]
        return np.concatenate([(ctr - wh / 2), (ctr + wh / 2)], axis=-1)

    @staticmethod
    def xyxy_to_cxcywh(boxes):
        """Convert box coordinates from (x1, y1, x2, y2) to (cx, cy, w, h).

        Args:
            boxes (Tensor): xyxy boxes tensor with shape of (..., 4).

        Returns:
            Tensor: cxcywh boxes tensor with shape of (..., 4).
        """
        xy1, xy2 = boxes[..., :2], boxes[..., 2:]
        return np.concatenate([(xy2 + xy1) / 2, (xy2 - xy1)], axis=-1)

    @property
    def areas(self):
        return (self.data[..., 2] - self.data[..., 0]) * (
            self.data[..., 3] - self.data[..., 1]
        )

    def __setitem__(self, index, values):
        if isinstance(values, np.ndarray):
            assert values.shape[-1] == 4
            v = values
        elif isinstance(values, BoxArray):
            v = values.data
        else:
            raise TypeError(f"Not support type {type(values)} in BoxArray __setitem__")
        self.data[index] = v

    def __repr__(self):
        s = f"BoxArray[num_box = {len(self.data)}]"
        return s

    @staticmethod
    def filter_(bboxes, indices):
        return bboxes[indices]

    def filter(self, indices):
        self.data = BoxArray.filter_(self.data, indices=indices)

    @staticmethod
    def clip_(bboxes, img_shape):
        bboxes[..., 0::2] = np.clip(bboxes[..., 0::2], 0, img_shape[1])
        bboxes[..., 1::2] = np.clip(bboxes[..., 1::2], 0, img_shape[0])
        return bboxes

    def clip(self, img_shape):
        self.data = BoxArray.clip_(self.data, img_shape)

    @staticmethod
    def pad_(bboxes, pad_shape):
        np_pad_shape = compute_2d_pad_shape(pad_shape, ndim=2)
        pad_top, pad_left = np_pad_shape[0][0], np_pad_shape[1][0]

        bboxes[..., 0::2] += pad_left
        bboxes[..., 1::2] += pad_top
        # update img_shape
        return bboxes

    def pad(self, pad_shape):
        np_pad_shape = compute_2d_pad_shape(pad_shape, ndim=2)
        # pad for bboxes
        self.data = BoxArray.pad_(self.data, np_pad_shape)

    @staticmethod
    def crop_(bboxes, area):
        xmin, ymin, xmax, ymax = area
        h, w = ymax - ymin, xmax - xmin
        bboxes[..., 0::2] -= xmin
        bboxes[..., 1::2] -= ymin
        bboxes = BoxArray.clip_(bboxes, (h, w))
        return bboxes

    def crop(self, area):
        xmin, ymin, xmax, ymax = list(map(int, area))
        self.data = BoxArray.crop_(self.data, [xmin, ymin, xmax, ymax])

    @staticmethod
    def flip_(bboxes, img_shape, direction="horizontal"):
        assert direction in ["horizontal", "vertical", "diagonal"]
        flipped = bboxes.copy()
        if direction == "horizontal":
            bboxes[..., 0] = img_shape[1] - flipped[..., 2]
            bboxes[..., 2] = img_shape[1] - flipped[..., 0]
        elif direction == "vertical":
            bboxes[..., 1] = img_shape[0] - flipped[..., 3]
            bboxes[..., 3] = img_shape[0] - flipped[..., 1]
        else:
            bboxes[..., 0] = img_shape[1] - flipped[..., 2]
            bboxes[..., 1] = img_shape[0] - flipped[..., 3]
            bboxes[..., 2] = img_shape[1] - flipped[..., 0]
            bboxes[..., 3] = img_shape[0] - flipped[..., 1]
        return bboxes

    def flip(self, img_shape, direction="horizontal"):
        self.data = BoxArray.flip_(self.data, img_shape, direction=direction)

    @staticmethod
    def rotate_(bboxes, angle, *, center=None, img_shape=None, auto_bound=True):
        """
        Rotate the box with the image by some degree.
        """
        rotation_matrix = BoxArray.get_rotation_matrix(
            angle, center=center, img_shape=img_shape, auto_bound=auto_bound
        )
        x1, y1, x2, y2 = bboxes[..., 0], bboxes[..., 1], bboxes[..., 2], bboxes[..., 3]
        corners = np.concatenate([x1, y1, x2, y1, x1, y2, x2, y2], axis=-1)
        corners = corners.reshape(-1, 4, 2)
        num = corners.shape[0]
        corners = np.concatenate([corners, np.zeros(num, 4, 1)], axis=-1)
        corners_T = np.transpose(corners, (0, 2, 1))
        corners_T = np.matmul(rotation_matrix, corners_T)
        corners = np.transpose(corners_T, (0, 2, 1))
        min_xy = corners.min(dim=-2)
        max_xy = corners.max(dim=-2)
        rotated_box = np.concatenate([min_xy, max_xy], axis=-1)
        return rotated_box

    def rotate(self, angle, *, center=None, img_shape=None, auto_bound=True):

        assert center is not None or img_shape is not None

        self.data = BoxArray.rotate_(
            self.data, angle, center=center, img_shape=img_shape, auto_bound=auto_bound
        )

    @staticmethod
    def resize_(box, scale_factor):
        assert len(scale_factor) == 2
        scale_factor_ = scale_factor[::-1]  # scale factor (h,w) tranpsoe to (w,h)
        scale_factor_ = np.array(scale_factor_, dtype=np.float32)
        scale_factor_ = np.tile(scale_factor_, 2)  # xyxy
        box = box * scale_factor_
        return box

    def resize(self, scale_factor):
        self.data = BoxArray.resize_(self.data, scale_factor=scale_factor)

    @staticmethod
    def translate_(bboxes, translate_coord):
        bboxes[:, 0] += translate_coord[0]
        bboxes[:, 1] += translate_coord[1]
        bboxes[:, 2] += translate_coord[0]
        bboxes[:, 3] += translate_coord[1]
        return bboxes

    def translate(self, translate_coord):
        self.data = BoxArray.translate_(self.data, translate_coord)

    @staticmethod
    def cat_(bboxes1, bboxes2):
        bboxes = np.vstack([bboxes1, bboxes2]).astype(bboxes1.dtype)
        return bboxes

    def cat(self, bboxes):
        self.data = BoxArray.cat_(self.data, bboxes)

    # relations
    @staticmethod
    def is_inside_(bboxes, img_shape, all_inside=False, allowed_border=0):
        """Find boxes inside the image.

        Args:
            img_shape (Tuple[int, int]): A tuple of image height and width.
            all_inside (bool): Whether the boxes are all inside the image or
                part inside the image. Defaults to False.
            allowed_border (int): Boxes that extend beyond the image shape
                boundary by more than ``allowed_border`` are considered
                "outside" Defaults to 0.
        Returns:
            BoolArray: A BoolArray indicating whether the box is inside
            the image. Assuming the original boxes have shape (m, n, 4),
            the output has shape (m, n).

        """
        img_h, img_w = img_shape
        boxes = bboxes
        if all_inside:
            return (
                (boxes[:, 0] >= -allowed_border)
                & (boxes[:, 1] >= -allowed_border)
                & (boxes[:, 2] < img_w + allowed_border)
                & (boxes[:, 3] < img_h + allowed_border)
            )
        else:
            return (
                (boxes[..., 0] < img_w + allowed_border)
                & (boxes[..., 1] < img_h + allowed_border)
                & (boxes[..., 2] > -allowed_border)
                & (boxes[..., 3] > -allowed_border)
            )

    def is_inside(self, img_shape, all_inside=False, allowed_border=0):
        return BoxArray.is_inside_(self.data, img_shape, all_inside, allowed_border)
