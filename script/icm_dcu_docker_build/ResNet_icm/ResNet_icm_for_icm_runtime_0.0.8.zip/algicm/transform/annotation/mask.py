from typing import Iterable, Hashable

import cv2
import numpy as np

from .base import BaseImageAnns
from .image import Image
from .utils import compute_2d_pad_shape

from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class Mask(BaseImageAnns):
    def __init__(self, data, dtype="uint8") -> None:
        """
        Args:
            mask (np.ndarray): label mask. Label 0 is the background.
                dtype is one of uint8, uint16, int16.
            class_label List[Hashable]: class label of each value(>=1) in the mask.
            copy (bool, optional): copy the argument mask. Defaults to False.
        """
        img_shape = data.shape
        if len(data) == 0:
            data = np.empty((0, img_shape[0], img_shape[1]), dtype=dtype)
        else:
            assert isinstance(data, (list, np.ndarray))
            if isinstance(data, list):
                assert isinstance(data[0], np.ndarray)
                assert data[0].ndim == 2  # (H, W)
            else:
                assert data.ndim == 2  # (N, H, W)

            # masks = np.stack(data).reshape(-1, img_shape[0], img_shape[1])
            # assert masks.shape[1] == img_shape[0]
            # assert masks.shape[2] == img_shape[1]

        super().__init__(data)

    def __repr__(self):
        return f"Mask[num_mask={len(self.data)}]"

    # transformations
    @staticmethod
    def clip_(masks, img_shape=None):
        return masks

    def clip(self, img_shape=None):
        self.data = Mask.clip_(self.data, img_shape)

    @staticmethod
    def pad_(img, pad_shape, fill_value=0):
        np_pad_shape = compute_2d_pad_shape(pad_shape)
        return np.pad(img, np_pad_shape, constant_values=fill_value)

    def pad(self, pad_shape, fill_value=0):
        self.data = Mask.pad_(self.data, pad_shape, fill_value=fill_value)

    @staticmethod
    def crop_(img, boxes):
        boxes = np.array(boxes)
        if boxes.ndim != 2 or boxes.shape[-1] != 4:
            raise RuntimeError("Boxes in crop should be (N,4) format")
        img_h, img_w = img.shape[:2]
        patches = []
        boxes[..., 0] = np.maximum(boxes[..., 0], 0)
        boxes[..., 1] = np.maximum(boxes[..., 1], 0)
        boxes[..., 2] = np.maximum(boxes[..., 2], img_w)
        boxes[..., 3] = np.maximum(boxes[..., 3], img_h)
        areas = ((boxes[..., 2] - boxes[..., 0]) > 0) & ((boxes[..., 3] - boxes[..., 1]) > 0)
        valid_bboxes = boxes[areas > 0]
        valid_bboxes = valid_bboxes.astype(np.int32)
        for box in valid_bboxes:
            xmin, ymin, xmax, ymax = box
            patches.append(img[..., ymin:ymax, xmin:xmax])

        return patches

    def crop(self, boxes):
        if not len(boxes) == 1:
            raise ValueError("Crop function only support crop one area.")
        xmin, ymin, xmax, ymax = list(map(int, boxes))
        self.data = Mask.crop_(self.data, [xmin, ymin, xmax, ymax])[0]

    @staticmethod
    def flip_(img, direction):
        assert direction in ["horizontal", "vertical", "diagonal"]
        if direction == "direction":
            return np.flip(img, 0)
        elif direction == "vertical":
            return np.flip(img, 1)
        else:
            return np.flip(img, axis=(0, 1))

    def flip(self, shape, direction="horizontal"):
        self.data = Mask.flip_(self.data, direction)

    @staticmethod
    def rotate_(
        masks,
        angle,
        center=None,
        auto_bound=True,
        border_value: int = 0,
        interpolation: str = "bilinear",
        border_mode: str = "constant",
    ):
        rotated_masks = [
            Image.rotate_(
                mask,
                angle,
                center,
                auto_bound,
                border_value,
                interpolation,
                border_mode,
            )
            for mask in masks
        ]
        rotated_masks = np.stack(rotated_masks)
        return rotated_masks

    def rotate(
        self,
        angle,
        center=None,
        auto_bound=True,
        border_value: int = 0,
        interpolation: str = "bilinear",
        border_mode: str = "constant",
    ):
        self.data = Mask.rotate_(
            self.data,
            angle,
            center,
            auto_bound,
            border_value,
            interpolation,
            border_mode,
        )

    @staticmethod
    def resize_(masks, scale_factor):
        # resized_masks = [Image.resize_(mask, scale_factor) for mask in masks]
        resized_masks = Image.resize_(masks, scale_factor, cv2.INTER_NEAREST)
        # resized_masks = np.stack(resized_masks)
        return resized_masks

    def resize(self, scale_factor):
        self.data = Mask.resize_(self.data, scale_factor)
