import warnings
import numpy as np
import numbers
from .base import BaseDataStructure
from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class Text(BaseDataStructure):
    def __init__(self, data=None):
        super().__init__(data)

    @property
    def dtype(self):
        if isinstance(self.data, list):
            return type(self.data[0])
        elif isinstance(self.data, np.ndarray):
            return self.data.dtype
        else:
            raise RuntimeError("Data dtype is unknown")

    def to_numpy(self):
        """
        return the point coordinates as a (len(self), 2) ndarray. Inverse of from_numpy.
        """
        if isinstance(self.data, np.ndarray):
            return self.data
        elif isinstance(self.data, list) and isinstance(self.data[0], numbers.Number):
            return np.array(self.data)
        else:
            raise RuntimeError("To_numpy: data type is unknown")

    def convert_to(self, dtype="float32"):
        if isinstance(dtype, str):
            dtype = self._dtype[dtype]
        if isinstance(self.data, np.ndarray):
            self.data = self.data.astype(dtype)
        elif isinstance(self.data, list) and isinstance(self.data[0], numbers.Number):
            self.data = np.array(self.data).astype(dtype).tolist()
        else:
            warnings.warn("Unknown type of text, do noting in convert type.")

    def __len__(self):
        return len(self.data)

    def __repr__(self) -> str:
        return f"Text[seq_len={len(self)}]"
