from algicm.utils.misc import is_seq_of
from collections.abc import Sequence


def compute_2d_pad_shape(pad_shape, ndim: int = 3):
    """According to pad_shape, compute padding shape for data.
    Args:
        pad_shape:(int, List[int], List[List[int, int],List[int, int]]): pad shape for image.
                Four dimensions will be considered: top, left, buttom, right.
                if pad_shape is an int, all four dimensions will be pad_shape.
                if pad_shape is list[int,int], first number represent top/buttom.
                if pad_shape is List[List[int, int],List[int, int]]), numbers represent four dimension.
        ndim (int): number of dimension for image, 2 or 3.
    Return:
        numpy format pad shape.
    """
    assert ndim in [2, 3]
    if len(pad_shape) == 1:
        np_pad_shape = [[pad_shape, pad_shape], [pad_shape, pad_shape]]
    elif len(pad_shape) > 2:
        raise ValueError("Image pad_shape length should not greater than 2.")
    assert len(pad_shape) == 2

    if is_seq_of(pad_shape, Sequence):
        if not is_seq_of(pad_shape[0], int):
            raise TypeError("Pad shape value should be int")
        if len(pad_shape[0]) != 2:
            raise ValueError("Sequence of pad_shape should be 2.")
        np_pad_shape = pad_shape
        if ndim == 3:
            np_pad_shape = np_pad_shape + [0, 0]
    elif is_seq_of(pad_shape, int):
        np_pad_shape = [
            [pad_shape[0], pad_shape[0]],
            [pad_shape[1], pad_shape[1]],
        ]
        if ndim == 3:
            np_pad_shape += [0, 0]

    else:
        raise TypeError("Pad shape should be a sequence of list or int.")
    return np_pad_shape
