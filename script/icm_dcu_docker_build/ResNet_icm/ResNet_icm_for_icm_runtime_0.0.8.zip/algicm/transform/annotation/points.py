import cv2
import numpy as np
from .base import BaseImageAnns

from typing import Iterable, List, Union
from .utils import compute_2d_pad_shape
from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class PointArray(BaseImageAnns):
    def __init__(self, data):
        """
        Args:
            data(ndarray): with shape (N,2), N for number of points.

        """
        assert isinstance(data, np.ndarray)
        assert data.shape[-1] == 2

        super().__init__(data)

    def __repr__(self):
        return f"PointArray[num_points={len(self.data)}]"

    # transformations
    @staticmethod
    def clip_(points, img_shape):
        points[..., 0] = np.maximum(points[..., 0], 0)
        points[..., 1] = np.maximum(points[..., 1], 0)
        points[..., 0] = np.minimum(points[..., 2], img_shape[1])
        points[..., 1] = np.minimum(points[..., 3], img_shape[0])
        return points

    def clip(self, img_shape=None):
        if img_shape is None:
            raise ValueError("BoxArray flip func should pass image shape")
        self.data = PointArray.clip_(self.data, img_shape)

    @staticmethod
    def pad_(points, pad_shape):
        np_pad_shape = compute_2d_pad_shape(pad_shape, ndim=2)
        pad_top, pad_left = np_pad_shape[0][0], np_pad_shape[1][0]

        points[..., 0] += pad_left
        points[..., 1] += pad_top
        return points

    def pad(self, pad_shape):
        self.data = PointArray.pad_(self.data, pad_shape)

    @staticmethod
    def crop_(points, area):
        xmin, ymin, xmax, ymax = area
        h, w = ymax - ymin, xmax - xmin
        points[..., 0] -= xmin
        points[..., 1] -= ymin
        points = PointArray.clip_(points, (h, w))
        return points

    def crop(self, area):
        xmin, ymin, xmax, ymax = list(map(int, area))
        h, w = ymax - ymin, xmax - xmin
        self.data = PointArray.crop_(self.data, [xmin, ymin, xmax, ymax])

    @staticmethod
    def flip_(box, img_shape, direction="horizontal"):
        assert direction in ["horizontal", "vertical", "diagonal"]
        if direction == "horizontal":
            box[..., 0] = img_shape[1] - box[..., 2]
        elif direction == "vertical":
            box[..., 1] = img_shape[0] - box[..., 3]
        else:
            box[..., 0] = img_shape[1] - box[..., 2]
            box[..., 1] = img_shape[0] - box[..., 3]

    def flip(self, img_shape=None, direction="horizontal"):
        if img_shape is None:
            raise ValueError("BoxArray flip func should pass image shape")
        self.data = PointArray.flip_(self.data, img_shape, direction=direction)

    @staticmethod
    def rotate_(points, angle, *, center=None, img_shape=None, auto_bound=True):
        """
        Rotate the box with the image by some degree.
        """
        rotation_matrix = PointArray.get_rotation_matrix(
            angle, center=center, img_shape=img_shape, auto_bound=auto_bound
        )
        corners = points.reshape(-1, 2)
        num = corners.shape[0]
        corners = np.concatenate([corners, np.zeros(num, 1)], axis=-1)
        corners_T = np.transpose(corners, (1, 0))
        corners_T = np.matmul(rotation_matrix, corners_T)
        corners = np.transpose(corners_T, (1, 0))
        return corners

    def rotate(self, angle, *, center=None, img_shape=None, auto_bound=True):

        self.data = PointArray.rotate_(
            self.data, angle, center=center, img_shape=img_shape, auto_bound=auto_bound
        )

    @staticmethod
    def resize_(points, scale_factor):
        assert len(scale_factor) == 2
        scale_factor_ = scale_factor[::-1]  # scale factor (h,w) tranpsoe to (w,h)
        scale_factor_ = np.array(scale_factor_, dtype=np.float32)
        points = points * scale_factor_
        return points

    def resize(self, scale_factor):
        self.data = PointArray.resize_(self.data, scale_factor=scale_factor)
