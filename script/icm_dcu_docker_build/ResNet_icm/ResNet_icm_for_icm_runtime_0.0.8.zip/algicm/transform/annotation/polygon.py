import cv2
import warnings
import numpy as np

from .base import BaseImageAnns
from .utils import compute_2d_pad_shape
from .mask import Mask
from typing import List, Union, Tuple
from algicm.utils.misc import is_seq_of
from shapely import geometry
from algicm.registry.common import DATA_STRUCTURE


@DATA_STRUCTURE.register_module()
class Polygon(BaseImageAnns):

    def __init__(self, data) -> None:
        """
        Args:
            data (list[ndarray]): each array is a polygon.

        """
        assert isinstance(data, list)
        if len(data) > 0:
            # assert isinstance(data, list)
            assert isinstance(data[0], np.ndarray)

        super().__init__(data)

    @property
    def dtype(self):
        return self.data[0].dtype

    # conversions
    def to_numpy(self, img_shape, labels):
        """
        Convert the Polygon object to a Mask object

        Args:
            dtype (optional): one of an integer data type or bool. Defaults to bool.
        """
        assert len(self.data) == len(labels.data)
        h, w = img_shape[:2]
        if len(self.data) == 0:
            return np.empty((0, h, w), dtype=self.dtype)
        masks = []
        mask = np.zeros([h, w], dtype=self.dtype)
        for (
                poly,
                label,
        ) in zip(self.data, labels.data):
            masks.append(
                cv2.fillPoly(
                    mask,
                    pts=[poly.astype(np.int32).reshape(-1, 2)],
                    color=int(label),
                    lineType=cv2.LINE_AA,
                ))
        return np.stack(masks)

    def to_mask(self, img_shape, labels):
        h, w = img_shape[:2]
        gt_mask = np.zeros([h, w], dtype=np.uint8)
        for polygon, label in zip(self.data, labels.data):
            # background value is 0 for seg, category id start with 0 before
            color = int(label)
            cv2.drawContours(
                gt_mask, [np.array(polygon, dtype=np.int32).reshape(-1, 2)], 0,
                (color, color, color), -1)
        return Mask(gt_mask)

    def convert_to(self, dtype="uint8"):
        """
        Convert the Polygon object to a Mask object

        Args:
            dtype (optional): one of an integer data type or bool. Defaults to bool.
        """
        if len(self.data) == 0:
            return self.data.astype(self._dtype[dtype])

        for i in range(len(self.data)):
            self.data[i].astype(self._dtype[dtype])

    # properties

    @property
    def area(self):
        area = []
        for polygons_per_obj in self.data:
            area_per_obj = 0
            for p in polygons_per_obj:
                area_per_obj += self._polygon_area(p[0::2], p[1::2])
            area.append(area_per_obj)
        return np.asarray(area)

    def _polygon_area(self, x, y):
        """Compute the area of a component of a polygon.

        Using the shoelace formula:
        https://stackoverflow.com/questions/24467972/calculate-area-of-polygon-given-x-y-coordinates

        Args:
            x (ndarray): x coordinates of the component
            y (ndarray): y coordinates of the component

        Return:
            float: the are of the component
        """  # noqa: 501
        return 0.5 * np.abs(
            np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))

    def __repr__(self):
        return f"Polygon[num_poly={len(self.data)}]"

    # transformations
    @staticmethod
    def clip_(polygons, img_shape=None):
        warnings.warn("The `clip` function does nothing in `RotatedBoxes`.")
        return polygons

    def clip(self, img_shape=None):
        self.data = Polygon.clip_(self.data, img_shape)

    @staticmethod
    def pad_(polygons, pad_shape):
        np_pad_shape = compute_2d_pad_shape(pad_shape)
        pad_top, pad_left = np_pad_shape[0][0], np_pad_shape[1][0]
        for i in range(len(polygons)):
            polygons[i][0::2] += pad_left
            polygons[i][1::2] += pad_top
        return polygons

    def pad(self, pad_shape):
        np_pad_shape = compute_2d_pad_shape(pad_shape, ndim=2)
        self.data = Polygon.pad_(self.data, pad_shape)

    @staticmethod
    def crop_(polygons, area):
        # clip the boundary
        x1, y1, x2, y2 = area
        w = np.maximum(x2 - x1, 1)
        h = np.maximum(y2 - y1, 1)

        if len(polygons) == 0:
            return []
        else:
            # reference: https://github.com/facebookresearch/fvcore/blob/main/fvcore/transforms/transform.py  # noqa
            crop_box = geometry.box(x1, y1, x2, y2).buffer(0.0)
            cropped_masks = []
            # suppress shapely warnings util it incorporates GEOS>=3.11.2
            # reference: https://github.com/shapely/shapely/issues/1345
            initial_settings = np.seterr()
            np.seterr(invalid="ignore")
            for poly_per_obj in polygons:
                cropped_poly_per_obj = []
                for p in poly_per_obj:
                    p = p.copy()
                    p = geometry.Polygon(p.reshape(-1, 2)).buffer(0.0)
                    # polygon must be valid to perform intersection.
                    if not p.is_valid:
                        continue
                    cropped = p.intersection(crop_box)
                    if cropped.is_empty:
                        continue
                    if isinstance(cropped,
                                  geometry.collection.BaseMultipartGeometry):
                        cropped = cropped.geoms
                    else:
                        cropped = [cropped]
                    # one polygon may be cropped to multiple ones
                    for poly in cropped:
                        # ignore lines or points
                        if not isinstance(
                                poly, geometry.Polygon) or not poly.is_valid:
                            continue
                        coords = np.asarray(poly.exterior.coords)
                        # remove an extra identical vertex at the end
                        coords = coords[:-1]
                        coords[:, 0] -= x1
                        coords[:, 1] -= y1
                        cropped_poly_per_obj.append(coords.reshape(-1))
                # a dummy polygon to avoid misalignment between masks and boxes
                if len(cropped_poly_per_obj) == 0:
                    cropped_poly_per_obj = [np.array([0, 0, 0, 0, 0, 0])]
                cropped_masks.append(cropped_poly_per_obj)
            np.seterr(**initial_settings)
            cropped_masks = polygons(cropped_masks, img_shape=(h, w))
        return cropped_masks

    def crop(self, area):
        xmin, ymin, xmax, ymax = list(map(int, area))
        self.data = Polygon.crop_(self.data, [xmin, ymin, xmax, ymax])

    @staticmethod
    def flip_(polygons, img_shape, flip_direction="horizontal"):
        """see :func:`BaseInstanceMasks.flip`"""
        assert flip_direction in ("horizontal", "vertical", "diagonal")
        h, w = img_shape[:2]
        if len(polygons) == 0:
            return []
        else:
            flipped_masks = []
            for poly_per_obj in polygons:
                flipped_poly_per_obj = []
                for p in poly_per_obj:
                    p = p.copy()
                    if flip_direction == "horizontal":
                        p[0::2] = w - p[0::2]
                    elif flip_direction == "vertical":
                        p[1::2] = h - p[1::2]
                    else:
                        p[0::2] = w - p[0::2]
                        p[1::2] = h - p[1::2]
                    flipped_poly_per_obj.append(p)
                flipped_masks.append(flipped_poly_per_obj)
            flipped_masks = Polygon(flipped_masks, img_shape=(h, w))
        return flipped_masks

    def flip(self, img_shape=None, direction="horizontal"):
        if img_shape is None:
            raise ValueError("Polygon flip func should pass image shape")
        self.data = Polygon.flip_(self.data, img_shape, direction=direction)

    @staticmethod
    def rotate_(polygons,
                angle,
                *,
                center=None,
                img_shape=None,
                auto_bound=True):
        if len(polygons) == 0:
            return []
        else:
            rotated_polygons = []
            rotate_matrix = Polygon.get_rotation_matrix(center, -angle, 1.0)
            for poly_per_obj in polygons:
                rotated_poly = []
                for p in poly_per_obj:
                    p = p.copy()
                    coords = np.stack([p[0::2], p[1::2]], axis=1)  # [n, 2]
                    # pad 1 to convert from format [x, y] to homogeneous
                    # coordinates format [x, y, 1]
                    coords = np.concatenate(
                        (coords, np.ones((coords.shape[0], 1), coords.dtype)),
                        axis=1)  # [n, 3]
                    rotated_coords = np.matmul(
                        rotate_matrix[None, :, :],
                        coords[:, :, None])[..., 0]  # [n, 2, 1] -> [n, 2]
                    rotated_poly.append(rotated_coords.reshape(-1))
                rotated_polygons.append(rotated_poly)
        return rotated_polygons

    def rotate(self, angle, *, center=None, img_shape=None, auto_bound=True):
        self.data = Polygon.rotate_(self.data,
                                    angle,
                                    center=center,
                                    img_shape=img_shape,
                                    auto_bound=auto_bound)

    @staticmethod
    def resize_(polygons, scale_factor):
        assert len(scale_factor) == 2
        if len(polygons) == 0:
            return []
        else:
            resized_polygons = []
            for poly_per_obj in polygons:
                resized_poly = []
                for p in poly_per_obj:
                    p = p.copy()
                    p[0::2] = p[0::2] * scale_factor[1]
                    p[1::2] = p[1::2] * scale_factor[0]
                    resized_poly.append(p)
                resized_polygons.append(resized_poly)
        return resized_polygons

    def resize(self, scale_factor):
        self.data = Polygon.resize_(self.data, scale_factor=scale_factor)
