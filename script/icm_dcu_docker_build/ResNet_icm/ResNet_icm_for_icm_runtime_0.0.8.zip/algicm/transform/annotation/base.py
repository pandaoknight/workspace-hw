import cv2
import numpy as np
from abc import abstractmethod, ABC
from copy import deepcopy


class BaseDataStructure(ABC):
    _dtype = {
        "DType": np.dtype,
        "float16": np.float16,
        "float32": np.float32,
        "float64": np.float64,
        "int8": np.int8,
        "int16": np.int16,
        "int32": np.int32,
        "int64": np.int64,
        "uint8": np.uint8,
        "uint16": np.uint16,
        "uint32": np.uint32,
        "uint64": np.uint64,
        "bool": np.bool_,
        "complex64": np.complex64,
        "complex128": np.complex128,
    }

    def __init__(self, data=None):
        self.data = data

    @property
    def dtype(self):
        return self.data.dtype

    def to_numpy(self):
        """
        return the point coordinates as a (len(self), 2) ndarray. Inverse of from_numpy.
        """
        return self.data

    def convert_to(self, dtype="float32"):
        return self.data.astype(self._dtype[dtype])

    def copy(self):
        """
        Deep copy of all attributes. Return the same type of object.

        In subclass, ignore it if deepcopy(self) is a proper way.
        """
        return deepcopy(self)


class BaseImageData(BaseDataStructure):

    CV2_INTERP_CODES = {
        "nearest": cv2.INTER_NEAREST,
        "bilinear": cv2.INTER_LINEAR,
        "bicubic": cv2.INTER_CUBIC,
        "area": cv2.INTER_AREA,
        "lanczos": cv2.INTER_LANCZOS4,
    }

    CV2_BORDER_MODES = {
        "constant": cv2.BORDER_CONSTANT,
        "replicate": cv2.BORDER_REPLICATE,
        "reflect": cv2.BORDER_REFLECT,
        "wrap": cv2.BORDER_WRAP,
        "reflect_101": cv2.BORDER_REFLECT_101,
        "transparent": cv2.BORDER_TRANSPARENT,
        "isolated": cv2.BORDER_ISOLATED,
    }


class BaseImageAnns(BaseDataStructure):
    def __init__(self, data):
        super().__init__(data)

    def _update_image_shape(self, img_shape):
        self._img_shape = list(img_shape)

    def __getitem__(self, index):
        return type(self)(
            self.data[index].copy(),
            dtype=self.dtype,
        )

    def __iter__(self):
        return iter(self.data)

    def __len__(self):
        """Number of Annotations."""
        return len(self.data)

    @classmethod
    def get_rotation_matrix(
        cls, angle, *, center=None, img_shape=None, auto_bound=True
    ):
        assert center is not None or img_shape is not None
        if center is None:
            center = (img_shape[1] * 0.5, img_shape[0] * 0.5)
        if img_shape is None:
            img_shape = [center[0] * 2, center[1] * 2]

        matrix = cv2.getRotationMatrix2D(center, -angle, 1.0)
        if auto_bound and img_shape is not None:
            cos = np.abs(matrix[0, 0])
            sin = np.abs(matrix[0, 1])
            new_w = h * sin + w * cos
            new_h = h * cos + w * sin
            matrix[0, 2] += (new_w - w) * 0.5
            matrix[1, 2] += (new_h - h) * 0.5
            w = int(np.round(new_w))
            h = int(np.round(new_h))
            return matrix, (h, w)
        return matrix
