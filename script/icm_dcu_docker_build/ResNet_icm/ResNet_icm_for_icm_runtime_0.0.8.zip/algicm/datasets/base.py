# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/29

import copy
import numpy as np
import warnings
import functools
import os.path as osp
from abc import abstractmethod

from .backend import Dataset
from algicm.transform.transform import Compose
from algicm.utils.logger import Logger


def force_full_init(old_func):
    """Those methods decorated by ``force_full_init`` will be forced to call
    ``full_init`` if the instance has not been fully initiated.

    Args:
        old_func (Callable): Decorated function, make sure the first arg is an
            instance with ``full_init`` method.

    Returns:
        Any: Depends on old_func.
    """

    @functools.wraps(old_func)
    def wrapper(obj: object, *args, **kwargs):
        # The instance must have `full_init` method.
        if not hasattr(obj, "full_init"):
            raise AttributeError(f"{type(obj)} does not have full_init "
                                 "method.")
        # If instance does not have `_fully_initialized` attribute or
        # `_fully_initialized` is False, call `full_init` and set
        # `_fully_initialized` to True
        if not getattr(obj, "_fully_initialized", False):
            warnings.warn("Attribute `_fully_initialized` is not defined in "
                          f"{type(obj)} or `type(obj)._fully_initialized is "
                          "False, `full_init` will be called and "
                          f"{type(obj)}._fully_initialized will be set to "
                          "True")
            obj.full_init()  # type: ignore
            obj._fully_initialized = True  # type: ignore

        return old_func(obj, *args, **kwargs)

    return wrapper


class BaseDataset(Dataset):
    _metainfo = {}
    _fully_initialized = False
    """ BaseDataset
    
    
    Args:
        ann_file (str): Annotation file path. Defaults to ''.
        metainfo (dict, optional): Meta information for dataset, such as class
            information. Defaults to None.
        data_root (str): The root directory for ``data_prefix`` and
            ``ann_file``. Defaults to ''.
        data_prefix (dict): Prefix for training data. Defaults to
            dict(img_path='').
        pre_pipeline (list, optional): Pre-Processing pipeline. Defaults to [].
        post_pipeline (list, optional): Post-Processing pipeline. Defaults to [].
        post_first (bool): if True do post-processing first, then do reverting back process 
        test_mode (bool): 
            if False, return transformed data and labels
            if True, return transformed data and non-transformed labels, which need to convert results to original shape
            Defaults to False.
        lazy_init (bool, optional): Whether to load annotation during
            instantiation. In some cases, such as visualization, only the meta
            information of the dataset is needed, which is not necessary to
            load annotation file. ``Basedataset`` can skip load annotations to
            save time by set ``lazy_init=False``. Defaults to False.
        max_refetch (int, optional): If ``Basedataset.prepare_data`` get a
            None img. The maximum extra number of cycles to get a valid
            image. Defaults to 500.
    
    
    """

    def __init__(
        self,
        data_root="",
        ann_file="",
        data_prefix=dict(img_path=""),  # dict
        pipelines=[],
        test_mode=False,
        meta_info=None,
        max_refetch=500,
        lazy_init=True,
    ):
        self.data_root = data_root
        self.ann_file = ann_file
        self.data_prefix = copy.deepcopy(data_prefix)
        self.test_mode = test_mode
        self.max_refetch = max_refetch

        # join path
        self._join_prefix()
        # update metainfo
        if meta_info is not None:
            self._update_metainfo(meta_info)
        # build pipelines
        self.pipelines = Compose(pipelines)

        if not lazy_init:
            self.full_init()
        # Logger.log_msg(f"Success to load {len(self.data_list)} data.")

    @classmethod
    def build_from_cfg(cls, cfg):
        """
        Args:
            cfg (dict): using config to build datasets
        Returns:
        """
        if "init_cfg" in cfg:
            init_cfg = copy.deepcopy(cfg["init_cfg"])
        else:
            init_cfg = copy.deepcopy(cfg)
        ds = cls(
            data_root=init_cfg.get("data_root", ""),
            ann_file=init_cfg.get("ann_file", ""),
            data_prefix=init_cfg.get("data_prefix", dict(img_path="")),
            pre_pipelines=init_cfg.get("pre_pipelines", []),
            post_pipelines=init_cfg.get("post_pipelines", []),
            test_mode=init_cfg.get("test_mode", False),
            max_refetch=init_cfg.get("max_refetch", 500),
        )
        return ds

    def __getitem__(self, idx):
        if not self._fully_initialized:
            warnings.warn(
                "Please call `full_init()` method manually to accelerate "
                "the speed.")
            self.full_init()

        if self.test_mode:
            data = self.prepare_test_data(idx)
            if data is None:
                raise Exception("Test time pipline should not get `None` "
                                "data_sample")
            return data

        for _ in range(self.max_refetch + 1):
            data = self.prepare_train_data(idx)
            # Broken images or random augmentations may cause the returned data
            # to be None
            if data is None:
                idx = self._rand_another()
                continue
            return data  # {'img', 'pipelines'}

        raise Exception(f"Cannot find valid image after {self.max_refetch}! "
                        "Please check your image path and pipeline")

    @force_full_init
    def __len__(self):
        return len(self.data_list)

    @abstractmethod
    def load_data_info(self):
        """Load files that contains all file messages
        Returns:
        """
        pass

    @abstractmethod
    def get_data_info(self, index):
        """Get annotation and data by index
        Returns:
        """
        pass

    @abstractmethod
    def filter_data(self, data):
        pass

    def full_init(self):
        """Load annotation file and set ``BaseDataset._fully_initialized`` to
        True.

        If ``lazy_init=False``, ``full_init`` will be called during the
        instantiation and ``self._fully_initialized`` will be set to True. If
        ``obj._fully_initialized=False``, the class method decorated by
        ``force_full_init`` will call ``full_init`` automatically.

        Several steps to initialize annotation:

            - load_data_list: Load annotations from annotation file.
            - filter data information: Filter annotations according to
              filter_cfg.
            - slice_data: Slice dataset according to ``self._indices``
            - serialize_data: Serialize ``self.data_list`` if
            ``self.serialize_data`` is True.
        """
        if self._fully_initialized:
            return
        # load data information
        self.data_list = self.load_data_info()
        # filter illegal data, such as data that has no annotations.
        self.data_list = self.filter_data(self.data_list)
        self._fully_initialized = True

    def prepare_train_data(self, idx):
        data = self.get_data_info(idx)
        data = copy.deepcopy(data)
        data = self.pipelines(data, self)
        return data

    def prepare_test_data(self, idx):
        data = self.get_data_info(idx)
        data = copy.deepcopy(data)
        data = self.pipelines(data, self)
        return data

    def prepare_val_data(self, idx):
        data = self.get_data_info(idx)
        data = self.pipelines(data, self)
        return data

    @property
    def metainfo(self):
        return copy.deepcopy(self._metainfo)

    def _collect_metainfo(self):
        dataset_metainfos = dict(init_cfg=dict(
            type="BaseDatasets",
            data_root=self.data_root,
            ann_file=self.ann_file,
            data_prefix=self.data_prefix,
            pipelines=[],
            test_mode=self.test_mode,
            max_refetch=self.max_refetch,
        ))

        if isinstance(self.pipelines, list):
            pipelines = self.pipelines
        else:
            raise TypeError(
                f"pipelines expect type list, but got type {self.pipelines}")

        for pipeline in pipelines:
            dataset_metainfos["init_cfg"]["pipelines"].append(pipeline)
        self._update_metainfo(dataset_metainfos)

    def _update_metainfo(self, info):
        """
        Args:
            info (dict): some infomation need to store
        Returns: None

        """
        if info is None:
            return
        elif not isinstance(info, dict):
            raise TypeError(
                f"metainfo expected type dict, but got type {type(info)})")
        self._metainfo.update(info)

    def _join_prefix(self):
        """Join ``self.data_root`` with ``self.data_prefix`` and
        ``self.ann_file``.

        """
        # Automatically join annotation file path with `self.root` if
        # `self.ann_file` is not an absolute path.
        if not osp.isabs(self.ann_file) and self.ann_file:
            self.ann_file = osp.join(self.data_root, self.ann_file)
        # Automatically join data directory with `self.root` if path value in
        # `self.data_prefix` is not an absolute path.
        for data_key, prefix in self.data_prefix.items():
            if isinstance(prefix, str):
                if not osp.isabs(prefix):
                    self.data_prefix[data_key] = osp.join(
                        self.data_root, prefix)
                else:
                    self.data_prefix[data_key] = prefix
            else:
                raise TypeError("prefix should be a string, but got "
                                f"{type(prefix)}")

    def _rand_another(self) -> int:
        """Get random index.

        Returns:
            int: Random index from 0 to ``len(self)-1``
        """
        return np.random.randint(0, len(self))
