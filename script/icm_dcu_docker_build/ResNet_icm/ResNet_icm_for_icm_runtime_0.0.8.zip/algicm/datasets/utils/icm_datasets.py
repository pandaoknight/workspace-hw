# -*- coding: utf-8 -*-
# @Time    : 2022/7/18 16:38
# @Author  : htx

import json
import os
from collections import defaultdict


class ICMdataset:

    def __init__(self, annotation_file, meta_info):
        assert os.path.exists(
            annotation_file
        ), f"Check annotation file exists in {annotation_file}"
        with open(annotation_file, "r") as f:
            dataset = json.load(f)
        assert type(
            dataset) == dict, "annotation file format {} not supported".format(
                type(dataset))
        self.meta_info = meta_info
        self.dataset = dataset
        self.createIndex()

    def createIndex(self):
        # create index
        anns, cats, imgs = {}, {}, {}
        imgToAnns = defaultdict(list)
        imgIdToAnnIds = defaultdict(list)

        ann_id = 0
        if "images" in self.dataset:
            for img_id, img in enumerate(self.dataset["images"]):
                imgs[str(img_id)] = {
                    "filename": img["fileName"],
                    "ori_height": img["height"],
                    "ori_width": img["width"],
                }
                imgToAnns[str(img_id)].append(img["annotations"])
                if img["annotations"]["polyPoints"]:
                    for ann in img["annotations"]["polyPoints"]:
                        if len(ann) < 7:
                            raise ValueError(
                                "polyPoints must has number of points greater than 3, but got {} in file {}"
                                .format((len(ann) / 2 - 1), img["fileName"]))
                        anns[str(ann_id)] = ann
                        imgIdToAnnIds[str(img_id)].append(ann_id)
                        ann_id += 1

        if self.meta_info is None:
            for cat in self.dataset["categories"]:
                cats[cat["id"]] = cat
        

        # create class members
        self.anns = anns
        self.imgToAnns = imgToAnns
        self.imgIdToAnnIds = imgIdToAnnIds
        self.imgs = imgs
        self.cats = cats
