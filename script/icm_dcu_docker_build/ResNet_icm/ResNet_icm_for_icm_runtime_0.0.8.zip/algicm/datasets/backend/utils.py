# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/28

MP_STATUS_CHECK_INTERVAL = 5.0

PYTHON_EXIT_STATUS = False
