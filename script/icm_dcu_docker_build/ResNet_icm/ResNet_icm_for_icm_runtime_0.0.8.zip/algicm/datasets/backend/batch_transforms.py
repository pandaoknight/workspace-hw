# # !/usr/bin/env python
# # -*- coding: utf-8 -*-
# # @Author: htx
# # @Date  : 2022/12/26

# import numpy as np

# import torch
# import tensorflow as tf
# from algicm.registry.settings import (
#     is_env_initialized,
#     get_framework_backend,
#     _SUPPORTED_BACKEND,
# )
# from algicm.registry.common import TRANSFORMS

# default_collate_err_msg_format = (
#     "torch_collate: batch must contain tensorflow or torch tensor, numpy arrays, numbers; "
#     "found {}"
# )


# def torch_collate(batch):
#     elem = batch[0]
#     elem_type = type(elem)
#     if isinstance(elem, (list, dict, tuple)):
#         raise TypeError("Could not convert list,dict,tuple to tensor")
#     elif isinstance(elem, float):
#         return torch.tensor(batch)
#     elif isinstance(elem, int):
#         return torch.tensor(batch)
#     elif (
#         elem_type.__module__ == "numpy"
#         and elem_type.__name__ != "str_"
#         and elem_type.__name__ != "string_"
#     ):
#         batch_numpy = np.vstack(batch)
#         return torch.from_numpy(batch_numpy)
#     elif isinstance(elem, torch.Tensor):
#         return torch.stack(batch).squeeze(1)
#     else:
#         raise TypeError(default_collate_err_msg_format.format(elem_type))


# def tf_collate(batch):
#     # Notified, dataload will start multiple subprocess,
#     # tensorflow will automatically move tensor to gpu when gpu is available
#     # But in subprocess, GPU can not be used.
#     # GPU is available only in main process
#     with tf.device("cpu"):
#         elem = batch[0]
#         elem_type = type(elem)
#         if isinstance(elem, (list, dict, tuple)):
#             raise TypeError("Could not convert list,dict,tuple to tensor")
#         elif isinstance(elem, (float, int)):
#             return tf.convert_to_tensor(batch)
#         elif (
#             elem_type.__module__ == "numpy"
#             and elem_type.__name__ != "str_"
#             and elem_type.__name__ != "string_"
#         ):
#             batch_numpy = np.vstack(batch)
#             return tf.convert_to_tensor(batch_numpy)
#         elif isinstance(elem, torch.Tensor):
#             return tf.squeeze(tf.stack(batch), 1)
#         else:
#             raise TypeError(default_collate_err_msg_format.format(elem_type))


# @TRANSFORMS.register_module()
# class ToTensor:
#     def __init__(self, convert_keys):
#         self.convert_keys = convert_keys
#         if not is_env_initialized:
#             raise RuntimeError("Please initialize env first")
#         backend = get_framework_backend()
#         if backend == "pytorch":
#             assert torch is not None, "Cannot import torch, please install pytorch"
#             collate_fn = torch_collate
#         elif backend == "tensorflow":
#             assert tf is not None, "Cannot import tensorflow, please install tensorflow"
#             collate_fn = tf_collate
#         else:
#             raise RuntimeError(
#                 f"Support framework are {_SUPPORTED_BACKEND}, but got {backend}"
#             )
#         self.collate_fn = collate_fn

#     def _transform(self, batch):
#         results = {}
#         assert isinstance(batch, list)
#         assert isinstance(batch[0], dict)
#         num_sample = len(batch)
#         for k, v in batch[0].items():
#             results[k] = []
#             for idx in range(num_sample):
#                 results[k].append(batch[idx][k])

#         for k in results.keys():
#             if k in self.convert_keys:
#                 results[k] = self.collate_fn(results[k])
#         return results

#     def __call__(self, results):
#         return self._transform(results)
