# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/28

import os
import sys
import signal
import threading
from collections import OrderedDict
from algicm.utils.misc import is_seq_of

worker_pids = OrderedDict()
_SIGCHLD_handler_set = False
r"""Whether SIGCHLD handler is set for DataLoader worker failures. Only one
handler needs to be set for all DataLoaders in a process."""


def _set_worker_pids(unique_id, pids):
    # check type
    if not isinstance(unique_id, int):
        raise ValueError(f'unique_id should be int but got type {type(unique_id)}')
    if not is_seq_of(pids, int):
        raise ValueError(f'worker pids should be a sequence of int but got type {pids}')

    worker_pids[unique_id] = pids


def _remove_worker_pids(unique_id):
    if unique_id not in worker_pids:
        raise ValueError(f'Cannot find worker information for _BaseDataLoaderIter with id {unique_id}')

    worker_pids.pop(unique_id)


def _error_if_any_worker_fails():
    for unique_id, pid_set in worker_pids.items():
        for pid_it in pid_set:
            worker_pid = pid_it
            # monitor process, when exit or error will return status
            status = os.waitid(os.P_PID, worker_pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            if status is None:
                continue

            # if status.si_code == os.CLD_EXITED and status.si_code != os.EX_OK:
            #
            #     # remove all process
            #     ## TODO: seems not correct here
            #     worker_pids[unique_id] = tuple()
            #
            #     raise RuntimeError(f'"DataLoader worker pid "{worker_pid}") exited,'
            #                        f'unexpectedly with exit code " {status.si_status},'
            #                        f'Details are lost due to multiprocessing. Rerunning with '
            #                        'num_workers=0 may give better error trace.')
            if status.si_code==os.CLD_EXITED:
                worker_pids[unique_id] = tuple()

            elif status.si_code == os.CLD_EXITED or status.si_code == os.CLD_DUMPED:
                msg = f'DataLoader worker (pid "f{worker_pid}") is killed by signal: {status.si_status}'
                if status.si_status == signal.SIGBUS:
                    msg += f"It is possible that dataloader's workers are out of shared memory. " \
                           f"Please try to raise your shared memory limit."

                worker_pids[unique_id] = tuple()
                raise RuntimeError(msg)


def _set_SIGCHLD_handler():
    # Windows doesn't support SIGCHLD handler
    if sys.platform == 'win32':
        return
    # can't set signal in child threads
    if not isinstance(threading.current_thread(), threading._MainThread):  # type: ignore
        return
    global _SIGCHLD_handler_set
    if _SIGCHLD_handler_set:
        return
    previous_handler = signal.getsignal(signal.SIGCHLD)
    if not callable(previous_handler):
        # This doesn't catch default handler, but SIGCHLD default handler is a
        # no-op.
        previous_handler = None

    def handler(signum, frame):
        # This following call uses `waitid` with WNOHANG from C side. Therefore,
        # Python can still get and update the process status successfully.
        _error_if_any_worker_fails()
        if previous_handler is not None:
            assert callable(previous_handler)
            previous_handler(signum, frame)

    signal.signal(signal.SIGCHLD, handler)
    _SIGCHLD_handler_set = True


def set_handler(sig, msg):

    previous_handler = signal.getsignal(sig)

    if not callable(previous_handler):
        # This doesn't catch default handler, but SIGCHLD default handler is a
        # no-op.
        previous_handler = None

    def handler(signum, frame):
        # This following call uses `waitid` with WNOHANG from C side. Therefore,
        # Python can still get and update the process status successfully.

        if previous_handler is not None:
            assert callable(previous_handler)
            previous_handler(signum, frame)
            print(msg)

    signal.signal(sig, handler)


def _set_worker_signal_handlers():
    sigbus_error = f'ERROR: Unexpected bus error encountered in worker. ' \
                   f'This might be caused by insufficient shared memory \n'
    set_handler(signal.SIGBUS, sigbus_error)

    sigsegv_error = f'"ERROR: Unexpected segmentation fault encountered in worker.\n"'
    set_handler(signal.SIGSEGV, sigsegv_error)

    sigfpe_error = f'ERROR: Unexpected floating-point exception encountered in worker.\n'
    set_handler(signal.SIGFPE, sigfpe_error)

    sigterm_error = f'ERROR: Unknown error occurs.\n'
    set_handler(signal.SIGTERM, sigterm_error)
