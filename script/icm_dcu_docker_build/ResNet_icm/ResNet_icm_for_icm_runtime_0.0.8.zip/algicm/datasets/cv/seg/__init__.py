#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# File    :   __init__.py
# Time    :   2023/05/09 16:36:31
# Author  :   Tianqi
from .icm_seg_dataset import SegDataset
