import os
from ..base import BaseDataset


class BaseCVDataset(BaseDataset):
    _IMAGE_FORMAT = ["jpg", "jpeg", "png", "bmp", "tif"]

    def get_data_info(self, index):
        return self.data_list[index]

    def filter_data(self, data):
        return data

    # def get_ann_info(self, idx):
    #     """Get annotation by index.

    #     Args:
    #         idx (int): Index of data.

    #     Returns:
    #         dict: Annotation info of specified index.
    #     """
    #     img_info = self.data_list[idx]
    #     ann_info = self.data_anns.imgToAnns[img_info["img_id"]]

    #     return self._parse_ann_info(img_info, ann_info[0])

    @classmethod
    def filter_image_file(cls, filenames):
        out_filenames = []
        for name in filenames:
            postfix = name.split(".")[-1]
            if postfix.lower() in cls._IMAGE_FORMAT:
                out_filenames.append(name)
        return out_filenames
