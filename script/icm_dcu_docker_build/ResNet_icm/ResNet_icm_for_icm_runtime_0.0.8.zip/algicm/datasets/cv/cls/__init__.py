# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/27

from .cifar import CIFAR10
from .mnist import MNIST
from .icm_cls_dataset import ClsDataset