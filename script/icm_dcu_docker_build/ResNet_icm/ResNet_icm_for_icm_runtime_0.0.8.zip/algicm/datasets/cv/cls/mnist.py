# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/27

import os
import numpy as np
import struct
from ..base import BaseCVDataset
from algicm.fileio.backend.io import get
from algicm.registry.common import DATASETS


@DATASETS.register_module()
class MNIST(BaseCVDataset):
    train_list = ["train-images-idx3-ubyte", "train-labels-idx1-ubyte"]
    test_list = ["t10k-images-idx3-ubyte", "t10k-labels-idx1-ubyte"]
    _metainfo = {"classes": ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]}

    def __init__(
        self, data_root: str = "", data_type="train", meta_info=None, **kwargs
    ):
        assert data_type in ["train", "test", "val"]
        self.data_type = data_type

        super().__init__(
            # The CIFAR dataset doesn't need specify annotation file
            ann_file="",
            meta_info=meta_info,
            data_root=data_root,
            **kwargs
        )

    def load_data_info(self):
        if self.data_type == "train":
            downloaded_list = self.train_list
        else:
            downloaded_list = self.test_list

        # load the picked numpy arrays
        imgs_file = os.path.join(self.data_root, downloaded_list[0])
        labels_file = os.path.join(self.data_root, downloaded_list[1])

        # decode file
        imgs = self._decode_idx3_ubyte(imgs_file)
        gt_labels = self._decode_idx1_ubyte(labels_file)

        data_list = []
        for img, gt_label in zip(imgs, gt_labels):
            # info = {"img_path": img, "gt_cls": int(gt_label)}
            img = img.repeat(3, axis=-1)
            info = dict(img=img, label=np.array(int(gt_label)))
            data_list.append(info)
        return data_list

    def get_data_info(self, index):
        return self.data_list[index]

    def filter_data(self, data):
        return data

    def _decode_idx3_ubyte(self, idx3_ubyte_file):
        fb_data = get(idx3_ubyte_file, dict(backend="local"))
        offset = 0
        fmt_header = ">iiii"
        magic_number, num_images, num_rows, num_cols = struct.unpack_from(
            fmt_header, fb_data, 0
        )

        offset += struct.calcsize(fmt_header)
        fmt_image = ">" + str(num_rows * num_cols) + "B"

        images = np.empty((num_images, num_rows, num_cols))
        for i in range(num_images):
            im = struct.unpack_from(fmt_image, fb_data, offset)
            images[i] = np.array(im).reshape((num_rows, num_cols))
            offset += struct.calcsize(fmt_image)
        images = images[..., np.newaxis]  # convert to N, H, W, C
        return images

    def _decode_idx1_ubyte(self, idx1_ubyte_file):
        fb_data = get(idx1_ubyte_file, dict(backend="local"))
        offset = 0
        fmt_header = ">ii"  # read two unsinged int32
        magic_number, label_num = struct.unpack_from(fmt_header, fb_data, offset)

        offset += struct.calcsize(fmt_header)
        labels = []

        fmt_label = ">B"  # read one byte
        for i in range(label_num):
            labels.append(struct.unpack_from(fmt_label, fb_data, offset)[0])
            offset += struct.calcsize(fmt_label)
        return labels
