# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/29

import pickle
import os
import numpy as np
from ..base import BaseCVDataset
from algicm.fileio.backend.io import get_file_backend, get
from algicm.registry.common import DATASETS
from algicm.transform.annotation import Image


@DATASETS.register_module()
class CIFAR10(BaseCVDataset):
    base_folder = "cifar-10-batches-py"
    url = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
    filename = "cifar-10-python.tar.gz"
    tgz_md5 = "c58f30108f718f92721af3b95e74349a"
    train_list = [
        ["data_batch_1", "c99cafc152244af753f735de768cd75f"],
        ["data_batch_2", "d4bba439e000b95fd0a9bffe97cbabec"],
        ["data_batch_3", "54ebc095f3ab1f0389bbae665268c751"],
        ["data_batch_4", "634d18415352ddfa80567beed471001a"],
        ["data_batch_5", "482c414d41f54cd18b22e5b47cb7c3cb"],
    ]

    test_list = [
        ["test_batch", "40351d587109b95175f43aff81a1287e"],
    ]
    meta = {
        "filename": "batches.meta",
        "key": "label_names",
        "md5": "5ff9c542aee3614f3951f8cda6e48888",
    }
    _metainfo = {
        "classes": [
            "airplane",
            "automobile",
            "bird",
            "cat",
            "deer",
            "dog",
            "frog",
            "horse",
            "ship",
            "truck",
        ]
    }

    def __init__(
        self, data_root: str = "", test_mode: bool = False, meta_info=None, **kwargs
    ):
        super().__init__(
            # The CIFAR dataset doesn't need specify annotation file
            ann_file="",
            meta_info=meta_info,
            data_root=data_root,
            test_mode=test_mode,
            **kwargs
        )

    def load_data_info(self):
        backend = get_file_backend(self.data_root)

        if not self.test_mode:
            downloaded_list = self.train_list
        else:
            downloaded_list = self.test_list

        imgs = []
        gt_labels = []

        # load the picked numpy arrays
        for file_name, _ in downloaded_list:
            file_path = os.path.join(self.data_root, self.base_folder, file_name)
            entry = pickle.loads(get(file_path), encoding="latin1")
            imgs.append(entry["data"])
            if "labels" in entry:
                gt_labels.extend(entry["labels"])
            else:
                gt_labels.extend(entry["fine_labels"])

        imgs = np.vstack(imgs).reshape(-1, 3, 32, 32)
        imgs = imgs.transpose((0, 2, 3, 1))  # convert to HWC

        data_list = []
        for img, gt_label in zip(imgs, gt_labels):
            # info = {"img_path": img, "gt_cls": int(gt_label)}
            # data_list.append(info)
            data_list.append(dict(img=img, label=np.array(int(gt_label))))
        return data_list

    def get_data_info(self, index):
        return self.data_list[index]

    def filter_data(self, data):
        return data
