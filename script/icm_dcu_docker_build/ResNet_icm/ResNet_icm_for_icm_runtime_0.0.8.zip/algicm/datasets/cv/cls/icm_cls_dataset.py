import os.path as osp
import numpy as np
import json
from ..base import BaseCVDataset
from algicm.registry.common import DATASETS


@DATASETS.register_module()
class ClsDataset(BaseCVDataset):

    def __init__(self,
                 data_root: str = "",
                 ann_file="Annotations/annotations.json",
                 data_prefix=dict(img_path="Images"),
                 meta_info=None,
                 **kwargs):
        if meta_info is not None:
            self.num_classes = meta_info["num_classes"]
            self.load_meta_info(meta_info)
        super().__init__(ann_file=ann_file,
                         data_root=data_root,
                         data_prefix=data_prefix,
                         **kwargs)

    def load_data_info(self):
        """Load annotation from annotation file."""
        with open(self.ann_file, "r") as f:
            dataset = json.load(f)
        assert "images" in dataset, "Cls dataset should contain key `images`"
        # handle categories
        if len(self.metainfo) == 0:
            classes = [cls_dict["name"] for cls_dict in dataset["categories"]]
            self.num_classes = len(classes)
            id2cat_old = {
                cls_dict["id"]: cls_dict["name"]
                for cls_dict in dataset["categories"]
            }
            cat2id = {
                cls_dict["name"]: ids
                for ids, cls_dict in enumerate(dataset["categories"])
            }
            self.load_meta_info(
                dict(classes=classes,
                     id2cat_old=id2cat_old,
                     cat2id=cat2id,
                     num_classes=self.num_classes))

        # load all data info

        # id2cat in current datasets
        current_id2cat = {
            cls_dict["id"]: cls_dict["name"]
            for cls_dict in dataset["categories"]
        }
        data_list = []
        for ann in dataset["images"]:
            old_label_id = ann["annotations"]["imgCategory"]
            assert len(
                old_label_id) == 1, "No support multi label image classication"
            label_name = current_id2cat[old_label_id[0]]
            label = self.metainfo.get("cat2id")[label_name]
            img_path = ann["fileName"]
            data_list.append(
                dict(img_path=osp.join(self.data_prefix["img_path"], img_path),
                     label=np.array(label)))
        return data_list

    def load_meta_info(self, metainfo=None, classes=None):
        if metainfo is not None:
            assert "classes" in metainfo, "should contain classes" in metainfo
            assert "id2cat_old" in metainfo
            assert "cat2id" in metainfo
            self._update_metainfo(metainfo)
            return

        if classes is None:
            raise RuntimeError("Both metainfo and classes could not be None.")
        assert isinstance(classes, list)
        self._update_metainfo(dict(classes=classes))
