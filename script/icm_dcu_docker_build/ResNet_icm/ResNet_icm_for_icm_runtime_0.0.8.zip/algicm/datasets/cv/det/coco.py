"""
    This example shows a recommended way to utilize image_transform in PyTorch
    image object detection model train/validation/inference routines.
    This example focuses on the processing of image and annotations, model-related
    code is omitted.
"""
import os
import copy
import warnings

import pycocotools
from pycocotools.coco import COCO as _COCO
from pycocotools.cocoeval import COCOeval as _COCOeval
from ..base import BaseCVDataset
from algicm.registry.common import DATASETS
from collections import defaultdict
from typing import List, Optional, Union

import numpy as np


class COCO(_COCO):
    """This class is almost the same as official pycocotools package.

    It implements some snake case function aliases. So that the COCO class has
    the same interface as LVIS class.
    """

    def __init__(self, annotation_file=None):
        if getattr(pycocotools, "__version__", "0") >= "12.0.2":
            warnings.warn(
                'mmpycocotools is deprecated. Please install official pycocotools by "pip install pycocotools"',  # noqa: E501
                UserWarning,
            )
        super().__init__(annotation_file=annotation_file)
        self.img_ann_map = self.imgToAnns
        self.cat_img_map = self.catToImgs

    def get_ann_ids(self, img_ids=[], cat_ids=[], area_rng=[], iscrowd=None):
        return self.getAnnIds(img_ids, cat_ids, area_rng, iscrowd)

    def get_cat_ids(self, cat_names=[], sup_names=[], cat_ids=[]):
        return self.getCatIds(cat_names, sup_names, cat_ids)

    def get_img_ids(self, img_ids=[], cat_ids=[]):
        return self.getImgIds(img_ids, cat_ids)

    def load_anns(self, ids):
        return self.loadAnns(ids)

    def load_cats(self, ids):
        return self.loadCats(ids)

    def load_imgs(self, ids):
        return self.loadImgs(ids)


@DATASETS.register_module()
class COCODatasets(BaseCVDataset):
    _metainfo = {
        "classes": [
            "person",
            "bicycle",
            "car",
            "motorcycle",
            "airplane",
            "bus",
            "train",
            "truck",
            "boat",
            "traffic light",
            "fire hydrant",
            "stop sign",
            "parking meter",
            "bench",
            "bird",
            "cat",
            "dog",
            "horse",
            "sheep",
            "cow",
            "elephant",
            "bear",
            "zebra",
            "giraffe",
            "backpack",
            "umbrella",
            "handbag",
            "tie",
            "suitcase",
            "frisbee",
            "skis",
            "snowboard",
            "sports ball",
            "kite",
            "baseball bat",
            "baseball glove",
            "skateboard",
            "surfboard",
            "tennis racket",
            "bottle",
            "wine glass",
            "cup",
            "fork",
            "knife",
            "spoon",
            "bowl",
            "banana",
            "apple",
            "sandwich",
            "orange",
            "broccoli",
            "carrot",
            "hot dog",
            "pizza",
            "donut",
            "cake",
            "chair",
            "couch",
            "potted plant",
            "bed",
            "dining table",
            "toilet",
            "tv",
            "laptop",
            "mouse",
            "remote",
            "keyboard",
            "cell phone",
            "microwave",
            "oven",
            "toaster",
            "sink",
            "refrigerator",
            "book",
            "clock",
            "vase",
            "scissors",
            "teddy bear",
            "hair drier",
            "toothbrush",
        ]
    }

    def __init__(self, ignore_crowd=True, classes=None, **kwargs):
        self.ignore_crowd = ignore_crowd
        if classes is not None:
            assert isinstance(classes, (list, tuple))
            self._metainfo["classes"] = classes

        super().__init__(**kwargs)

    def load_data_info(self) -> List[dict]:
        """Load annotations from an annotation file named as ``self.ann_file``

        Returns:
            List[dict]: A list of annotation.
        """  # noqa: E501

        self.coco = COCO(self.ann_file)
        # The order of returned `cat_ids` will not
        # change with the order of the `classes`
        self.cat_ids = self.coco.get_cat_ids(cat_names=self._metainfo["classes"])
        self.cat2label = {cat_id: i for i, cat_id in enumerate(self.cat_ids)}
        self.cat_img_map = copy.deepcopy(self.coco.cat_img_map)

        img_ids = self.coco.get_img_ids()
        data_list = []
        total_ann_ids = []
        for img_id in img_ids:
            raw_img_info = self.coco.load_imgs([img_id])[0]
            raw_img_info["img_id"] = img_id

            ann_ids = self.coco.get_ann_ids(img_ids=[img_id])
            raw_ann_info = self.coco.load_anns(ann_ids)
            total_ann_ids.extend(ann_ids)

            parsed_data_info = self.parse_data_info(
                {"raw_ann_info": raw_ann_info, "raw_img_info": raw_img_info}
            )
            data_list.append(parsed_data_info)

        assert len(set(total_ann_ids)) == len(
            total_ann_ids
        ), f"Annotation ids in '{self.ann_file}' are not unique!"

        del self.coco

        return data_list

    def parse_data_info(self, raw_data_info: dict) -> Union[dict, List[dict]]:
        """Parse raw annotation to target format.

        Args:
            raw_data_info (dict): Raw data information load from ``ann_file``

        Returns:
            Union[dict, List[dict]]: Parsed annotation.
        """
        img_info = raw_data_info["raw_img_info"]
        ann_info = raw_data_info["raw_ann_info"]

        # TODO: need to change data_prefix['img'] to data_prefix['img_path']
        img_path = os.path.join(self.data_prefix["img_path"], img_info["file_name"])
        if self.data_prefix.get("seg", None):
            seg_map_path = os.path.join(
                self.data_prefix["seg"],
                img_info["file_name"].rsplit(".", 1)[0]
                + self.data_prefix.get("seg_map_suffix"),
            )
        else:
            seg_map_path = None

        instances = dict()
        instances["img_path"] = img_path
        instances["ori_height"] = img_info["height"]
        instances["ori_width"] = img_info["width"]
        instances["img_id"] = img_info["img_id"]
        bboxes = []
        bbox_labels = []
        for i, ann in enumerate(ann_info):

            if ann.get("ignore", False):
                continue
            x1, y1, w, h = ann["bbox"]
            inter_w = max(0, min(x1 + w, img_info["width"]) - max(x1, 0))
            inter_h = max(0, min(y1 + h, img_info["height"]) - max(y1, 0))
            if inter_w * inter_h == 0:
                continue
            if ann["area"] <= 0 or w < 1 or h < 1:
                continue
            if ann["category_id"] not in self.cat_ids:
                continue
            bbox = [x1, y1, x1 + w, y1 + h]

            bboxes.append(bbox)
            bbox_labels.append(self.cat2label[ann["category_id"]])

            # if ann.get("segmentation", None):
            #     instance["mask"] = ann["segmentation"]

        if len(bboxes) == 0:
            bboxes = np.zeros([0, 4], dtype=np.float32)
            bbox_labels = np.zeros([0], dtype=np.int32)
        else:
            bboxes = np.array(bboxes, dtype=np.float32)
            bbox_labels = np.array(bbox_labels, dtype=np.int32)
        instances["bboxes"] = bboxes
        instances["bbox_label"] = bbox_labels
        return instances

    def get_data_info(self, index):
        return self.data_list[index]

    def filter_data(self, data):
        # Not implement, do nothing here
        return data
