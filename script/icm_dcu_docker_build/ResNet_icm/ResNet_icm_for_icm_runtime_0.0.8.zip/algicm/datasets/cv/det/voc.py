import os
from ..base import BaseCVDataset
from algicm.registry.common import DATASETS


@DATASETS.register_module()
class VOCSegmentation(BaseCVDataset):
    class_labels = [
        "aeroplane",
        "bicycle",
        "bird",
        "boat",
        "bottle",
        "bus",
        "car",
        "cat",
        "chair",
        "cow",
        "diningtable",
        "dog",
        "horse",
        "motorbike",
        "person",
        "pottedplant",
        "sheep",
        "sofa",
        "train",
        "tvmonitor",
    ]

    def __init__(self, img_suffix=".jpg", seg_map_suffix=".png", classes=None, **kwargs):
        self.img_suffix = img_suffix
        self.seg_map_suffix = seg_map_suffix
        if classes is not None:
            assert isinstance(classes, (list, tuple))
            self._metainfo["classes"] = classes
        super().__init__(**kwargs)

    def load_data_info(self):
        img_dir = self.data_prefix.get("img_path", None)
        ann_dir = self.data_prefix.get("seg_map_path", None)
        data_list = []
        if not (os.path.isfile(self.ann_file) and self.ann_file.endswith("txt")):
            raise RuntimeError(f"Annotation file should be txt, but got {self.ann_file}")
        with open(self.ann_file, "r") as f:
            lines = f.read().split("\n")
        for line in lines:
            img_name = line.strip()
            if len(img_name) == 0:
                continue
            data_info = dict(img_path=os.path.join(img_dir, img_name + self.img_suffix))
            if ann_dir is not None:
                seg_map = img_name + self.seg_map_suffix
                data_info["seg_map_path"] = os.path.join(ann_dir, seg_map)
            data_list.append(data_info)

        return data_list
