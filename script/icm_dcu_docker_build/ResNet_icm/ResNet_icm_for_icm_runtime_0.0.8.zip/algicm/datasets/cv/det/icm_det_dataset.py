#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   icm_det_dataset.py
@Time    :   2023/08/25 17:01:35
@Author  :   htx 
"""
import json
import os.path as osp
import numpy as np
from ..base import BaseCVDataset
from algicm.registry.common import DATASETS


@DATASETS.register_module()
class DetDataset(BaseCVDataset):

    def __init__(self,
                 data_root: str = "",
                 ann_file="Annotations/annotations.json",
                 data_prefix=dict(img_path="Images"),
                 meta_info=None,
                 **kwargs):
        super().__init__(ann_file=ann_file,
                         data_root=data_root,
                         data_prefix=data_prefix,
                         **kwargs)
        if meta_info is not None:
            self.num_classes = meta_info["num_classes"]
            self.load_meta_info(meta_info)

    def load_data_info(self):
        """Load annotation from annotation file."""
        with open(self.ann_file, "r") as f:
            dataset = json.load(f)
        assert "images" in dataset, "Cls dataset should contain key `images`"
        # handle categories
        if len(self.metainfo) == 0:
            classes = [cls_dict["name"] for cls_dict in dataset["categories"]]
            self.num_classes = len(classes)
            id2cat_old = {
                cls_dict["id"]: cls_dict["name"]
                for cls_dict in dataset["categories"]
            }
            cat2id = {
                cls_dict["name"]: ids
                for ids, cls_dict in enumerate(dataset["categories"])
            }
            self.load_meta_info(
                dict(classes=classes,
                     id2cat_old=id2cat_old,
                     cat2id=cat2id,
                     num_classes=self.num_classes))

        # load all data info

        # id2cat in current datasets
        current_id2cat = {
            cls_dict["id"]: cls_dict["name"]
            for cls_dict in dataset["categories"]
        }
        data_list = []
        for ann in dataset["images"]:
            img_h, img_w = ann["height"], ann["width"]
            img_path = ann["fileName"]
            ann_dict = self._parse_ann_info(ann["annotations"], img_h, img_w,
                                            current_id2cat)
            ann_dict.update(
                dict(img_path=osp.join(self.data_prefix["img_path"], img_path),
                     ori_height=img_h,
                     ori_width=img_w))
            data_list.append(ann_dict)
        return data_list

    def load_meta_info(self, metainfo=None, classes=None):
        if metainfo is not None:
            assert "classes" in metainfo, "should contain classes" in metainfo
            assert "id2cat_old" in metainfo
            assert "cat2id" in metainfo
            self._update_metainfo(metainfo)
            return

        if classes is None:
            raise RuntimeError("Both metainfo and classes could not be None.")
        assert isinstance(classes, list)
        self._update_metainfo(dict(classes=classes))

    def _parse_ann_info(self, ann_info, img_h, img_w, current_id2cat):
        """Parse bbox and mask annotation.

        Args:
            ann_info (list[dict]): Annotation info of an image.

        Returns:
            dict: A dict containing the following keys: bboxes, bboxes_ignore,\
                labels, masks, seg_map. "masks" are raw annotations and not \
                decoded into binary masks.
        """
        gt_bboxes = []
        gt_labels = []
        gt_bboxes_labels = None

        # assert len(ann_info['bboxes']) == len(ann_info['polyPoints'])

        for i, ann in enumerate(ann_info["bboxes"]):
            box, cat_id_old = np.array(ann[:-1],
                                       dtype=np.float32), int(ann[-1])
            cat_name = current_id2cat[cat_id_old]

            x1, y1, w, h = box
            area = w * h
            inter_w = max(0, min(x1 + w, img_w) - max(x1, 0))
            inter_h = max(0, min(y1 + h, img_h) - max(y1, 0))
            if inter_w * inter_h == 0:
                continue
            if area <= 0 or w < 1 or h < 1:
                continue
            bbox = [x1, y1, x1 + w, y1 + h]

            gt_bboxes.append(bbox)
            gt_labels.append(self.metainfo.get("cat2id")[cat_name])

        if gt_bboxes:
            gt_bboxes = np.array(gt_bboxes, dtype=np.float32)
            gt_bboxes_labels = np.array(gt_labels, dtype=np.int64)
        else:
            gt_bboxes = np.zeros((0, 4), dtype=np.float32)
            gt_bboxes_labels = np.array([], dtype=np.int64)

        ann_dict = dict(gt_bboxes=gt_bboxes, gt_bboxes_labels=gt_bboxes_labels)
        return ann_dict
