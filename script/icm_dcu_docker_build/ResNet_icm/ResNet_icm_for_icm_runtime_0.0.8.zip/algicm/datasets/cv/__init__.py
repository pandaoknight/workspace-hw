from .cls import MNIST, CIFAR10 ,ClsDataset
from .det import COCODatasets,DetDataset
from .seg import SegDataset
