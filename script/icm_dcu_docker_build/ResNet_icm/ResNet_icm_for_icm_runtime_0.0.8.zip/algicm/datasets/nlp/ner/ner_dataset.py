# -*- coding=utf-8 -*-
import warnings
import numpy as np
import json

from algicm.datasets.nlp.base import BaseNLPDataset
from algicm.registry.common import DATASETS


@DATASETS.register_module()
class NERDataset(BaseNLPDataset):
    """Read ICM Ner data. For each text annotation:
    `text`: is the original text data.
    `span`: is the string of which entity.
    `labelName`: is the category of the entity.
    `mention`: is where the entity in text data.

    The format example of json file is:
    [{"text": "也许有的人会说阿拉伯国家石油那么多为什么还打不过以色列？",
    "entities": [{"span": "以色列", "labelName": "政治实体", "mention": [24, 27]},
    {"span": "阿拉伯国家", "labelName": "政治实体", "mention": [7, 12]}]}]
    """

    def __init__(self,
                 data_root="",
                 ann_file="",
                 pipelines=[],
                 ann_mode="BIOES",
                 meta_info=None,
                 **kwargs):
        assert ann_mode in ["BIOES"], "Current only support BIOES"

        super().__init__(data_root=data_root,
                         ann_file=ann_file,
                         pipelines=pipelines,
                         **kwargs)
        self.ann_mode = ann_mode
        if meta_info is not None:
            self.num_classes = meta_info["num_classes"]
            self.load_meta_info(meta_info=meta_info)

    def load_data_info(self):
        data_list = []
        with open(self.ann_file, "r", encoding="utf-8-sig") as f:
            data = json.load(f)

        classes = data.get("label_names", None)
        if len(self.metainfo) == 0:
            self.load_meta_info(classes=classes)

        classes_ = self.metainfo.get("classes")
        cat2id = self.metainfo.get("cat2id")
        text_lines = data["annotations"]
        for line in text_lines:
            text_o = line["text"]
            id = line["id"]
            text = list(text_o)
            entities = line["entities"]
            # for each entity
            text_label_ids = []
            # create text_label.
            text_label_str = ["OTHER"] * len(text)
            for entity in entities:
                # handle three case:
                # 1.label not in classes.
                # 2.length less than 0.
                # 3.text and its annotated text is not same.
                entity_text = entity["span"]
                entity_label = entity["labelName"]
                entity_mention = entity["mention"]
                if entity_label not in classes_:
                    warnings.warn(
                        f"{entity['labelName']} is not in the classes.")
                    continue

                if len(entity_text) <= 0:
                    warnings.warn(
                        f"{entity_text} length is zero, please check.")
                    continue
                if entity_text != "".join(
                        text[entity_mention[0]:entity_mention[1]]):
                    warnings.warn(
                        f"{entity_text} text and its index is not same.")
                    continue

                # create prefix for each class depending on its length.
                if len(entity_text) == 1:
                    text_label_str[entity_mention[0]] = "S-" + entity_label
                elif len(entity_text) == 2:
                    text_label_str[entity_mention[0]:entity_mention[1]] = [
                        "B-" + entity_label, "E-" + entity_label
                    ]
                else:
                    text_label_str[entity_mention[0]:entity_mention[1]] = (
                        ["B-" + entity_label] + [
                            "I-" + entity_label
                            for _ in range(len(entity_text) - 2)
                        ] + ["E-" + entity_label])
            # mapping string to ids, such as  "B-classA" -> 1, according to cat2id.
            text_label_ids = [cat2id[e] for e in text_label_str]

            data_list.append(
                dict(id=id, data=text_o, text=text,
                     token_label=text_label_ids))
        return data_list

    def load_meta_info(self, meta_info=None, classes=None):
        """Update metainfo using meta_info or classes,
          and create cat2id and id2cat mapping for dataset.


        Args:
            meta_info(dict|None): if not None, must contain three elements:
                                  classes, cat2id and id2cat.
            classes(dict|None): if not None, will create cat2id and id2cat mapping.
        """
        if meta_info is not None:
            assert "classes" in meta_info
            assert "cat2id" in meta_info
            assert "id2cat" in meta_info
            self._update_metainfo(meta_info)
            return

        # create id to ann_mode mapping dict
        # other is the last one.
        if classes is None:
            raise ValueError("Must pass classes or metainfo")
        assert isinstance(classes, list), "Classes should be list of str"
        cat2id, id2cat = self._BIOES_mapping(classes)
        self.num_classes = len(id2cat)
        metainfo = dict(classes=classes,
                        cat2id=cat2id,
                        id2cat=id2cat,
                        num_classes=self.num_classes)
        self._update_metainfo(metainfo)

    def _BIOES_mapping(self, classes):
        """Create category name to id mapping dict and reverse one.
           For cat2id: {"A":0, "B":1}
           For id2cat: {0:"A", 1:"B"}
        Note:
            It will automatically add class `OTHER` to last one.

        Args:
            classes(list[str]): name of all categories.

        Return:
            cat2id(dict) and id2cat(dict)

        """
        cat2id = dict()
        ids = 1
        for cls_name in classes:
            for t in ["B-", "I-", "E-", "S-"]:
                cat2id[t + cls_name] = ids
                ids += 1
        ## add class `other`.
        cat2id["OTHER"] = 0
        ## reverse cat2id -> id2cat
        id2cat = {v: k for k, v in cat2id.items()}
        return cat2id, id2cat

    def decode(self, seq, id2cat=None):
        if self.ann_mode == "BIOES":
            return self._BIOES_decode(seq, id2cat)
        else:
            raise NotImplementedError("Only support BIOES mode.")

    def _BIOES_decode(self, seq, id2cat=None):
        """Gets entities from sequence.
        note: BMEOS or BIEOS
        Args:
            seq (list): sequence of labels.
        Returns:
            list: list of (chunk_type, chunk_start, chunk_end).
        Example:
            # >>> seq = ['B-PER', 'E-PER', 'O', 'S-LOC']
            # >>> get_entity_bmoes(seq)
            [['PER', 0,2], ['LOC', 3, 4]]
        """
        chunks = []
        chunk = [-1, -1, -1]
        id2cat_ = self.metainfo.get("id2cat") if id2cat is None else id2cat
        for indx, tag in enumerate(seq):
            tag = id2cat_[tag]

            if "O" == tag:
                chunk = [-1, -1, -1]

            elif tag.startswith("S-"):
                chunk[1] = indx
                chunk[2] = indx + 1
                chunk[0] = tag.split("-")[1]
                chunks.append(chunk)
                chunk = [-1, -1, -1]

            elif tag.startswith("B-"):
                chunk = [-1, -1, -1]
                chunk[1] = indx
                chunk[0] = tag.split("-")[1]
            elif tag.startswith("I-") or tag.startswith("I-"):
                _type = tag.split("-")[1]
                if _type == chunk[0]:
                    pass
                else:
                    chunk = [-1, -1, -1]
            elif tag.startswith("E-"):
                _type = tag.split("-")[1]
                if _type == chunk[0]:
                    chunk[2] = indx + 1
                    chunks.append(chunk)
                chunk = [-1, -1, -1]
            else:
                chunk = [-1, -1, -1]
        return chunks
