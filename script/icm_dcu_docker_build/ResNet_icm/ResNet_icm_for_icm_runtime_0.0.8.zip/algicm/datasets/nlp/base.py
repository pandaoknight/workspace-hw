from ..base import BaseDataset
from .vocab import Vocab


class BaseNLPDataset(BaseDataset):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # filepath = vocab.get("filepath")
        # if filepath is not None:
        #     if filepath.endswith(".txt"):
        #         "dict(filepath=None, unk_token=None, pad_token=None, bos_token=None, eos_token=None)"
        #         self.vocab = Vocab.load_vocabulary(**vocab)
        #     elif filepath.endswith(".json"):
        #         self.vocab = Vocab.from_json(**vocab)
        #     else:
        #         raise TypeError("Other file format do not support now!")
        # else:
        #     raise ValueError("filepath is None in vocab.")

    def get_data_info(self, index):
        return self.data_list[index]

    def filter_data(self, data):
        return data
