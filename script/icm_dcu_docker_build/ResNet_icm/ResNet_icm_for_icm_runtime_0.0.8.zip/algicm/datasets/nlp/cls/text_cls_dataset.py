import os
import glob
import numpy as np
from algicm.datasets.nlp.base import BaseNLPDataset
from algicm.registry.common import DATASETS
from tqdm import tqdm
import json


@DATASETS.register_module()
class Text_Dataset(BaseNLPDataset):

    def __init__(self,
                 data_root="",
                 ann_file="",
                 pipelines=[],
                 test_mode=False,
                 meta_info=None,
                 max_refetch=500):
        super().__init__(
            data_root=data_root,
            ann_file=ann_file,
            pipelines=pipelines,
            test_mode=test_mode,
            max_refetch=max_refetch,
        )
        if meta_info is not None:
            self.num_classes = meta_info["num_classes"]
            self.load_meta_info(meta_info)

    def load_data_info(self):
        # load all data info into memory

        data_list = []
        with open(self.ann_file, "r", encoding="utf-8-sig") as f:
            data = json.load(f)

        cat_names = data.get("label_names", None)

        if len(self.metainfo) == 0:

            self.load_meta_info(classes=cat_names)

        annotations = data["annotations"]
        for line in tqdm(annotations):
            text, label, id = line["text"], line["label"], line["id"]
            data_list.append(
                dict(data=text,
                     text=text,
                     id=id,
                     label=np.array(self.metainfo.get("cat2id")[label])))

        return data_list

    def load_meta_info(self, metainfo=None, classes=None):
        if metainfo is not None:
            assert "classes" in metainfo, "should contain classes" in metainfo
            assert "cat2id" in metainfo
            assert "id2cat" in metainfo
            self._update_metainfo(metainfo)
            return

        if classes is None:
            raise RuntimeError("Both metainfo and classes could not be None.")
        assert isinstance(classes, list)
        cat2id, id2cat = self.create_meta_info(classes)
        self.num_classes = len(classes)
        self._update_metainfo(
            dict(classes=classes,
                 cat2id=cat2id,
                 id2cat=id2cat,
                 num_classes=self.num_classes))

    def create_meta_info(self, classes):
        cat2id = {cat: ids for ids, cat in enumerate(classes)}
        id2cat = {ids: cat for ids, cat in enumerate(classes)}
        return cat2id, id2cat
