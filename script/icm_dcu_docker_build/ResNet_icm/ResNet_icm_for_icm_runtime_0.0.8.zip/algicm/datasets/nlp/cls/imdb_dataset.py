import os
import glob
import numpy as np
from algicm.datasets.nlp.base import BaseNLPDataset
from algicm.registry.common import DATASETS
from tqdm import tqdm

@DATASETS.register_module()
class IMDBDataset(BaseNLPDataset):

    _metainfo = {
        "classes": [
            "pos",
            "neg",
        ]
    }

    def __init__(
        self,
        data_root="",
        pipelines=[],
        test_mode=False,
        meta_info=None,
        max_refetch=500,
    ):
        super().__init__(
    
            data_root=data_root,
            pipelines=pipelines,
            test_mode=test_mode,
            meta_info=meta_info,
            max_refetch=max_refetch,
        )

    def load_data_info(self):
        pos_path = os.path.join(self.data_root, "pos")
        neg_path = os.path.join(self.data_root, "neg")
        assert os.path.exists(pos_path) and os.path.exists(
            neg_path
        ), "Data_root path should contrain dir 'pos' and 'neg'."
        pos_files = glob.glob(os.path.join(pos_path, "*.txt"))
        neg_files = glob.glob(os.path.join(neg_path, "*.txt"))
        # load all data info into memory
        data_list = []
        for file in tqdm(pos_files):
            with open(file, "r") as f:
                text = f.read()

            data_list.append(dict(text=text, label=np.array(0)))

        for file in tqdm(neg_files):
            with open(file, "r") as f:
                text = f.read()

            data_list.append(dict(text=text, label=np.array(1)))
        return data_list
