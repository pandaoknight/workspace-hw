# -*- coding=utf-8 -*-
import json
from algicm.datasets.nlp.base import BaseNLPDataset

from algicm.registry.common import DATASETS


@DATASETS.register_module()
class RelationDataset(BaseNLPDataset):
    # 读入NER标注数据集，数据处理方法和论文保持一致

    def __init__(self,
                 data_root="",
                 ann_file="",
                 pipelines=[],
                 meta_info=None,
                 **kwargs):
        super().__init__(data_root=data_root,
                         ann_file=ann_file,
                         pipelines=pipelines,
                         **kwargs)
        if meta_info is not None:
            self.num_classes = meta_info["num_classes"]
            self.load_meta_info(meta_info=meta_info)

    def load_data_info(self):
        data_list = []
        # Read data
        with open(self.ann_file, "r", encoding="utf-8-sig") as f:
            data = json.load(f)

        entity_labels = data.get("label_names", None)
        relation_labels = data.get("relation_names", None)

        # update metainfo here
        if len(self.metainfo) == 0:

            self.load_meta_info(entity_labels=entity_labels,
                                relation_labels=relation_labels)
        for idx, ann in enumerate(data["annotations"]):
            text_o, text, sub_obj_list, entity_list, pair_label_list = self.parse_anns(
                ann)
            if len(pair_label_list) != 0:
                for rel_infos, entity, pair_label in zip(
                        sub_obj_list, entity_list, pair_label_list):
                    data_list.append(
                        dict(
                            index=idx,
                            id=ann["id"],
                            data=text_o,
                            entity=entity,
                            rel_infos=rel_infos,
                            text=text,
                            sub_obj=rel_infos,
                            rel_label=pair_label,
                        ))
            else:
                for rel_infos, entity in zip(sub_obj_list, entity_list):
                    data_list.append(
                        dict(index=idx,
                             id=ann["id"],
                             data=text_o,
                             entity=entity,
                             rel_infos=rel_infos,
                             text=text,
                             sub_obj=rel_infos))
        return data_list

    def load_meta_info(self,
                       meta_info=None,
                       entity_labels=None,
                       relation_labels=None):
        if meta_info is not None:
            assert "cat2id" in meta_info
            assert "rel2id" in meta_info
            assert "id2rel" in meta_info
            assert "ent2id" in meta_info
            assert "classes" in meta_info
            self._update_metainfo(meta_info)
            return

        # create id to ann_mode mapping dict
        # other is the last one.
        if entity_labels is None or relation_labels is None:
            raise ValueError(
                "Must pass entity_labels\relation_labels or meta_info")
        assert isinstance(entity_labels,
                          list), "entity_labels should be list of str"
        assert isinstance(relation_labels,
                          list), "relation_labels should be list of str"
        cat2id, rel2id, id2rel, ent2id, classes = self.create_ids_mapping(
            entity_labels, relation_labels)
        self.num_classes = len(relation_labels) + 1
        metainfo = dict(cat2id=cat2id,
                        rel2id=rel2id,
                        id2rel=id2rel,
                        ent2id=ent2id,
                        classes=classes,
                        num_classes=self.num_classes)
        self._update_metainfo(metainfo)

    def create_ids_mapping(self, entity_label, relation_label):
        classes = relation_label + entity_label
        cat2id = {cat: id for id, cat in enumerate(classes)}
        # add no relation here
        assert "NORELATION" not in relation_label
        relation_label_ = ["NORELATION"] + relation_label
        rel2id = {cat: id for id, cat in enumerate(relation_label_)}
        id2rel = {id: cat for id, cat in enumerate(relation_label_)}
        ent2id = {}
        ent_id = 0
        for ent in entity_label:
            for prefix in [
                    "SUBJ_START=", "SUBJ_END=", "OBJ_START=", "OBJ_END="
            ]:
                ent2id[prefix + ent] = "[unused" + str(ent_id + 2) + "]"
        return cat2id, rel2id, id2rel, ent2id, classes

    def parse_anns(self, ann):
        # for original text
        text_o = ann["text"]
        text = list(text_o)
        entities_labels = self.create_entity_labels(ann, text_o)
        # for all entities, construct `[start index, end_index] to label` map
        # entities_labels = dict()
        # classes = self.metainfo.get("classes")
        # for entity in ann["entities"]:
        #     entity_label = entity["labelName"]
        #     if entity_label not in classes:
        #         continue
        #     if entity["span"] != text_o[entity["mention"][0] : entity["mention"][1]]:
        #         continue
        #     entities_labels[(entity["mention"][0], entity["mention"][1])] = entity_label
        # entities_labels[(entity["mention"][0], entity["mention"][1] - 1)] = entity_label

        # for all relations, construct [subject start, subject end, object start, object end] to label map
        pair_label_list = []
        if "relations" in ann:
            rel2id = self.metainfo.get("rel2id")
            relation_labels = dict()
            for rel in ann["relations"]:
                rel_label = rel.get("relationName", None)

                if rel_label is not None and rel_label not in rel2id:
                    continue
                if (rel["subjectMention"][0],
                        rel["subjectMention"][1]) not in entities_labels:
                    continue
                if (rel["objectMention"][0],
                        rel["objectMention"][1]) not in entities_labels:
                    continue
                relation_labels[(
                    rel["subjectMention"][0],
                    rel["subjectMention"][1] - 1,
                    rel["objectMention"][0],
                    rel["objectMention"][1] - 1,
                )] = rel_label

        # for each entity pair
        # scan all possible pair for each entity
        sub_obj_list = []
        entity_list = []
        for first_entity, first_label in entities_labels.items():
            for second_entity, sencond_label in entities_labels.items():
                if first_entity == second_entity:
                    continue

                pair_entity = self.process_entity_pair(
                    [*first_entity, first_label],
                    [*second_entity, sencond_label])
                entity_list.append([
                    *first_entity, first_label, *second_entity, sencond_label
                ])
                sub_obj_list.append(pair_entity)
                # `NO` stands for no relation for this pair of entities
                if "relations" in ann:
                    pair_label = relation_labels.get(
                        (
                            pair_entity["sub_start"],
                            pair_entity["sub_end"],
                            pair_entity["obj_start"],
                            pair_entity["obj_end"],
                        ),
                        "NORELATION",
                    )
                    pair_label_list.append(pair_label)

        return text_o, text, sub_obj_list, entity_list, pair_label_list

    def create_entity_labels(self, ann, text):
        # for all entities, construct `[start index, end_index] to label` map
        entities_labels = dict()
        classes = self.metainfo.get("classes")
        for entity in ann["entities"]:
            entity_label = entity["labelName"]
            if entity_label not in classes:
                continue
            if entity["span"] != text[
                    entity["mention"][0]:entity["mention"][1]]:
                continue
            entities_labels[(entity["mention"][0],
                             entity["mention"][1])] = entity_label
        return entities_labels

    def process_entity_pair(self, first_entity, sencond_entity):
        pair_entity = {}
        pair_entity["sub_start"] = first_entity[0]
        pair_entity["sub_end"] = first_entity[1] - 1
        pair_entity["sub_type"] = first_entity[2]

        pair_entity["obj_start"] = sencond_entity[0]
        pair_entity["obj_end"] = sencond_entity[1] - 1
        pair_entity["obj_type"] = sencond_entity[2]
        return pair_entity
