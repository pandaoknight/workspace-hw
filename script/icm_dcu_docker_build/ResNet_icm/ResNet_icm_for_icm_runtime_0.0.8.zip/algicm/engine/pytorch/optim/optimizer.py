# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/22

import torch
from algicm.registry.pytorch import OPTIMIZER
from torch.optim.optimizer import required


@OPTIMIZER.register_module()
class SGD(torch.optim.SGD):
    def __init__(self, params, lr=required, momentum=0, weight_decay=0, nesterov=False):
        super(SGD, self).__init__(
            params=params,
            lr=lr,
            momentum=momentum,
            weight_decay=weight_decay,
            nesterov=nesterov,
        )


@OPTIMIZER.register_module()
class Adam(torch.optim.Adam):
    def __init__(
        self,
        params,
        lr=1e-3,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=0,
        amsgrad=False,
    ):
        super(Adam, self).__init__(
            params=params,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
        )


@OPTIMIZER.register_module()
class AdamW(torch.optim.AdamW):
    def __init__(
        self,
        params,
        lr=1e-3,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=1e-2,
        amsgrad=False,
    ):
        super(AdamW, self).__init__(
            params=params,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
        )


@OPTIMIZER.register_module()
class RMSprop(torch.optim.RMSprop):
    def __init__(
        self,
        params,
        lr=1e-2,
        alpha=0.99,
        eps=1e-8,
        weight_decay=0,
        momentum=0,
        centered=False,
    ):
        super(RMSprop, self).__init__(
            params=params,
            lr=lr,
            alpha=alpha,
            momentum=momentum,
            eps=eps,
            weight_decay=weight_decay,
            centered=centered,
        )

