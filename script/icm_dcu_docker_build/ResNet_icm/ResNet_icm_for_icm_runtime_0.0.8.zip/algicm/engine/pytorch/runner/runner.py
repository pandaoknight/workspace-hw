# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/22

import time
import random
import platform
import os
import torch
import torch.nn as nn

import numpy as np
import horovod.torch as hvd

from collections import OrderedDict

from algicm.engine.common import BaseRunner
from algicm.engine.common.optim import OptimWrapperDict

from algicm.registry.common import MODELS
from algicm.registry.pytorch import build_optimizer

from .utils import collect_env
from algicm.models.backend.core.pytorch.checkpoint import (
    load_checkpoint,
    save_checkpoint,
    _load_checkpoint_to_model,
)
from ..optim import OptimWrapper


class Runner(BaseRunner):

    @property
    def filename_posfix(self):
        """Model weights filename posfix according to deep learning platform"""
        return "pth"

    def _collect_env(self):
        return collect_env()

    def set_randomness(self, randomness_cfg):
        seed = randomness_cfg.get("seed")
        if seed is None:
            seed = np.random.randint(2**31)
            self.logger.info(f"Seed is None, Set a random seed {seed}")
            # for distributed training
            if self.world_size != 1:
                hvd.broadcast_object(seed)

        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

        self._seed = seed

    @classmethod
    def setup_env(self, env_cfg):
        """Prepare training environment before training, validation or testing.
            1.initial horovod.
            2.Set pytorch related.
            3.broadcast time to all node if distribtued.
            4.Set operation system related.

        Args:
            env_cfg(dict): config of environments.
        """
        # initialize hvd
        hvd.init()

        if env_cfg.get("cudnn_benchmark"):
            torch.backends.cudnn.benchmark = True

        # init distributed env first, since logger depends on the dist info.
        # if self.distributed and not is_distributed():
        #     dist_cfg: dict = env_cfg.get("dist_cfg", {})
        #     init_dist("pytorch", **dist_cfg)
        self._rank, self._world_size = hvd.rank(), hvd.size()

        # broadcast timestamp from 0 process to other processes
        timestamp = hvd.broadcast_object(time.time(), 0)
        # broadcast timestamp from 0 process to other processes
        self._timestamp = time.strftime("%Y%m%d_%H%M%S",
                                        time.localtime(timestamp))

        # https://github.com/pytorch/pytorch/issues/973
        # set resource limit
        if platform.system() != "Windows":
            import resource

            rlimit = resource.getrlimit(resource.RLIMIT_NOFILE)
            base_soft_limit = rlimit[0]
            hard_limit = rlimit[1]
            soft_limit = min(
                max(env_cfg.get("resource_limit", 4096), base_soft_limit),
                hard_limit)
            resource.setrlimit(resource.RLIMIT_NOFILE,
                               (soft_limit, hard_limit))

    def _load_framework_checkpoint(self, filename, map_location):
        """Load Pytorch model checkpoint from disk or other location.

        Args:
            filename(str): Path to checkpoint.
            map_location:(str): cpu or cuda

        Return:
            checkpoint(dict): checkpoint to store model,optimizer and other infos.

        """
        return load_checkpoint(filename, map_location=map_location)

    def _get_model_state(self, model):
        return model.state_dict()

    def _load_framework_checkpoint_to_model(self,
                                            model,
                                            checkpoint,
                                            strict=False,
                                            revise_keys=[(r"^module.", "")]):
        """Load chechpoint to model"""
        return _load_checkpoint_to_model(model,
                                         checkpoint,
                                         strict,
                                         revise_keys=revise_keys)

    def _save_framework_checkpoint(self, checkpoint, filepath, backend_args):
        """Save model checkpoint to destination"""
        if self.rank == 0:
            save_checkpoint(checkpoint, filepath, backend_args)

    def wrap_model(self, model):
        """wrap model such as ema"""
        return model

    def build_model(self, model):
        """Build model from configs."""
        if isinstance(model, nn.Module):
            return model
        elif isinstance(model, dict):
            return MODELS.build(cfg=model)
        else:
            raise TypeError("model should be a nn.Module object or dict, "
                            f"but got {type(model)}")

    def _init_weights(self):
        """Initialize the model weights.
        In Pytorch, weights are initialized when creation.
        """
        if hasattr(self.model, "init_weights"):
            self.model.init_weights()

    def _broadcast_parameters(self):
        hvd.broadcast_parameters(self.model.state_dict(), root_rank=0)
        if isinstance(self.optim_wrapper, OptimWrapper):
            hvd.broadcast_optimizer_state(self.optim_wrapper.optimizer,
                                          root_rank=0)
        elif isinstance(self.optim_wrapper, OptimWrapperDict):
            for name, optim in self.optim_wrapper.optim_wrappers.items():
                hvd.broadcast_optimizer_state(optim.optimizer, root_rank=0)
        else:
            raise TypeError(
                f"Optim_wrapper should be OptimWrapper or OptimWrapperDict, but got {type(self.optim_wrapper)}"
            )

    def build_optim(self, optimizer, model):
        """Build torch optimizer from config. Wrap optimier with horovod DistributedOptimizer that support distributed training.

        Args:
            optimizer(optional[dict, torch.optim.Optimizer]): Optimizer configs or optimizer instance.
            model(nn.Module): pytorch model.
        """
        if optimizer is None:
            return

        if isinstance(optimizer, torch.optim.Optimizer):
            return hvd.DistributedOptimizer(optimizer,
                                            model.named_parameters())

        if isinstance(optimizer, dict):
            if "type" in optimizer:
                optim = build_optimizer(optimizer, model)
                optim = hvd.DistributedOptimizer(optim,
                                                 model.named_parameters())
                return optim
            else:
                optim_dict = OrderedDict()
                for name, optim in optimizer.items():
                    if not hasattr(model, name):
                        raise AttributeError(
                            "When building multiple optimizer, "
                            "model should have name {name} that correspond to optimizer name"
                        )
                    submodel = getattr(model, name)
                    if isinstance(optim, torch.optim.Optimizer):
                        optim_dict[name] = hvd.DistributedOptimizer(
                            optim, submodel.named_parameters())
                    elif isinstance(optim, dict) and ("type" in optim.keys()):
                        optim_dict[name] = hvd.DistributedOptimizer(
                            build_optimizer(optim, submodel),
                            submodel.named_parameters(),
                        )
                    else:
                        raise ValueError(
                            "Each item mush be an optimizer object when "
                            '"type"  are not in optimizer,'
                            f"but got {name}={optim}")

        else:
            raise TypeError(
                f"Optimizer type should be torch.optim.Optimizer or dict, but got type {type(optimizer)}"
            )

    def build_optim_wrapper(self, optimizer, optim_wrapper_cfg=None):
        """Wrap optimizer with OptimizerWrapper."""

        if optimizer is None:
            return

        if isinstance(optimizer, torch.optim.Optimizer):
            optim_wrapper = OptimWrapper(optimizer, self.message_store)
            return optim_wrapper

        elif isinstance(optimizer, dict):
            for name, optim in optimizer.items():
                optim_wrapper_dict = OrderedDict()
                if isinstance(optim, torch.optim.Optimizer):
                    optim_wrapper_dict[name] = OptimWrapper(
                        optim, self.message_store)
                else:
                    raise ValueError(
                        "Each item mush be an optimizer object when building optim_wrapper,"
                        f"but got {name}={optim}")
            return OptimWrapperDict(**optim_wrapper_dict)
        else:
            raise TypeError("optimizer wrapper should be an OptimWrapper "
                            f"object or dict, but got {optim_wrapper}")

    def _convert_tensor_to_numpy(self, value, json_format=True):
        if isinstance(value, (int, float, str)):
            return value
        elif isinstance(value, (np.ndarray, np.array)):
            if value.size == 1:
                return value.item()
            else:
                return value.tolist()
        elif isinstance(value, torch.Tensor):
            if value.numel() == 1:
                return value.item()
            else:
                if json_format:
                    return value.detach().cpu().numpy().tolist()
                else:
                    return value.detach().cpu().numpy()
        else:
            raise TypeError(
                f"_convert_tensor_to_numpy expected value to be int,float,str,np.ndarry,torch.Tensor,"
                f"but got type {(type(value))}")

    def get_device(self):
        if torch.cuda.is_available():
            return "cuda"
        else:
            return "cpu"
