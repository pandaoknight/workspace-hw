# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/22

import warnings
import tensorflow as tf
import tensorflow_addons as tfa
import horovod.tensorflow as hvd

from collections import OrderedDict
from algicm.registry.tensorflow import OPTIMIZER

# DecoupledWeightDecayExtension = (
#     tfa.optimizers.weight_decay_optimizers.DecoupledWeightDecayExtension)


class OptimizerExtension:

    def __init__(self, params):
        # filter params with trainable==False
        self.params = params
        self.grads = []
        self.params_groups = []
        self.param_groups = []
        param_groups = list(params)
        if len(param_groups) == 0:
            raise ValueError("optimizer got an empty parameter list")
        if not isinstance(param_groups[0], dict):
            param_groups = [{"params": param_groups}]
        for param_group in param_groups:
            for name, default in self.defaults.items():
                param_group.setdefault(name, default)
            self.param_groups.append(param_group)

    def backward(self, loss, tape, **kwargs):
        """Compute gradients
        Args:
            loss:  tensorflow sum loss
            tape:  tf.GradientTape()
            **kwargs:

        Returns:

        """
        tape = hvd.DistributedGradientTape(tape)
        grads = tape.gradient(loss, self.params)
        self.update_grads(grads)

    def zero_grad(self, **kwargs):
        """Clear all gradients"""
        self.grads = []

    def update_grads(self, grads):
        """Add all gradients"""
        if self.grads:
            assert len(self.grads) == len(grads)
            ## accumulate grads
            for i, grad in enumerate(grads):
                self.grads[i] += grad
        else:
            self.grads = grads

    def step(self, **kwargs):
        """
        Args:
            **kwargs:

        Returns: Like torch 'optimizer.step()'

        """
        self.apply_gradients(zip(self.grads, self.params))

    def state_dict(self):
        """
        Returns: OrderDict of the optimizer weights
        """
        state = OrderedDict()
        state["state"] = OrderedDict()
        state["param_groups"] = []
        # add variables
        if hasattr(self, "weights"):
            for i, v in enumerate(self.weights):
                state["state"][i] = v
        # add other params
        for i, param_group in enumerate(self.param_groups):
            param_group_dict = OrderedDict()
            for k, v in param_group.items():
                if k == "params":
                    param_group_dict[k] = list(range(len(v)))
                    continue
                param_group_dict[k] = v
            state["param_groups"].append(param_group_dict)
        return state

    def load_state_dict(self, state_dict):
        """load state dict to current optimizer

        Args:
            state_dict: OrderDict of weights

        Returns:

        """
        groups = self.param_groups
        saved_groups = state_dict["param_groups"]
        if len(groups) != len(saved_groups):
            raise ValueError("loaded state dict has a different number of "
                             "parameter groups")

        # update
        param_lens = (len(g["params"]) for g in groups)
        saved_lens = (len(g["params"]) for g in saved_groups)
        if any(p_len != s_len for p_len, s_len in zip(param_lens, saved_lens)):
            raise ValueError(
                "loaded state dict contains a parameter group "
                "that doesn't match the size of optimizer's group")

        # if self.weights:
        #     raise RuntimeError('optimizer weights should be empty when load state dict')

        saved_state = state_dict["state"]
        weights = []
        for k, v in saved_state.items():
            weights.append(v)
            self.add_weight(v.name, v.shape)

        self.set_weights(weights)

        for param_group in saved_groups:
            hyper_params = self.convert_hyper_params(param_group)
            for k, v in hyper_params.items():
                self.update_hyper_params(k, v)

    def update_hyper_params(self, k, v):
        """update hyper parameters that used in current optimizer"""
        self.__setattr__(k, v)
        for i, param_group in enumerate(self.param_groups):
            if k in param_group:
                self.param_groups[i][k] = v

    def convert_hyper_params(self, hyper_param):
        """Some params that not used in optimizer will be filtered in this function
        Args:
            hyper_param:  dict

        Returns:

        """
        filter_hyper_params = {}
        for k, v in hyper_param.items():
            if k in self._used_hyper_params:
                filter_hyper_params[k] = v
        return filter_hyper_params


@OPTIMIZER.register_module()
class SGD(tf.keras.optimizers.SGD, OptimizerExtension):

    def __init__(self, params, lr, momentum=0, weight_decay=0, nesterov=False):
        self.defaults = dict(
            lr=lr,
            momentum=momentum,
            dampening=0,
            weight_decay=weight_decay,
            nesterov=nesterov,
            maximize=False,
        )
        self._used_hyper_params = [
            "lr",
            "momentum",
            "weight_decay",
            "nesterov",
            "maximize",
        ]
        super().__init__(
            weight_decay=weight_decay,
            learning_rate=lr,
            momentum=momentum,
            nesterov=nesterov,
        )
        OptimizerExtension.__init__(self, params)


@OPTIMIZER.register_module()
class Adam(tf.keras.optimizers.Adam, OptimizerExtension):

    def __init__(
            self,
            params,
            lr=1e-3,
            betas=(0.9, 0.999),
            eps=1e-8,
            weight_decay=0,
            amsgrad=False,
    ):
        self.defaults = dict(
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
            maximize=False,
        )
        self._used_hyper_params = [
            "lr", "betas", "weight_decay", "eps", "amsgrad"
        ]
        super(Adam, self).__init__(
            decay=weight_decay,
            learning_rate=lr,
            beta_1=betas[0],
            beta_2=betas[1],
            epsilon=eps,
            amsgrad=amsgrad,
        )

        OptimizerExtension.__init__(self, params)

    def convert_hyper_params(self, hyper_param):
        filter_hyper_params = {}
        for k, v in hyper_param.items():
            if k in self._used_hyper_params:
                if k == "betas":
                    filter_hyper_params["beta_1"] = v[0]
                    filter_hyper_params["beta_2"] = v[1]
                else:
                    filter_hyper_params[k] = v
        return filter_hyper_params


# DecoupledWeightDecayExtension, tf.keras.optimizers.Adam, OptimizerExtension
@OPTIMIZER.register_module()
class AdamW(tf.keras.optimizers.AdamW, OptimizerExtension
            ):  # tfa.optimizers.AdamW #tf.keras.optimizers.AdamW

    def __init__(
            self,
            params,
            lr=1e-3,
            betas=(0.9, 0.999),
            eps=1e-8,
            weight_decay=1e-2,
            amsgrad=False,
    ):
        self.defaults = dict(
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
            maximize=False,
        )

        self._used_hyper_params = [
            "lr", "betas", "weight_decay", "eps", "amsgrad"
        ]
        super(AdamW, self).__init__(
            weight_decay=weight_decay,
            learning_rate=lr,
            beta_1=betas[0],
            beta_2=betas[1],
            epsilon=eps,
            amsgrad=amsgrad,
        )

        OptimizerExtension.__init__(self, params)

    def convert_hyper_params(self, hyper_param):
        filter_hyper_params = {}
        for k, v in hyper_param.items():
            if k in self._used_hyper_params:
                if k == "betas":
                    filter_hyper_params["beta_1"] = v[0]
                    filter_hyper_params["beta_2"] = v[1]
                else:
                    filter_hyper_params[k] = v
        return filter_hyper_params

    def _update_step_xla(self, gradient, variable, key):
        return self._update_step(gradient, variable)


@OPTIMIZER.register_module()
class RMSprop(tf.keras.optimizers.RMSprop, OptimizerExtension):

    def __init__(
        self,
        params,
        lr=1e-2,
        alpha=0.99,
        eps=1e-8,
        weight_decay=0,
        momentum=0,
        centered=False,
    ):
        self.defaults = dict(
            lr=lr,
            momentum=momentum,
            alpha=alpha,
            eps=eps,
            centered=centered,
            weight_decay=weight_decay,
        )
        self._used_hyper_params = [
            "lr",
            "alpha",
            "eps",
            "weight_decay",
            "momentum",
            "centered",
        ]
        super().__init__(
            weight_decay=weight_decay,
            learning_rate=lr,
            rho=alpha,
            momentum=momentum,
            epsilon=eps,
            centered=centered,
        )
        OptimizerExtension.__init__(self, params)
