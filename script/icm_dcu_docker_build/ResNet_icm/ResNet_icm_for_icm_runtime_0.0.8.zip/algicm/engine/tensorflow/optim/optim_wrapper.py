# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/23

import tensorflow as tf
from contextlib import contextmanager
from algicm.engine.common.optim.optimizer import BaseOptimWrapper
from algicm.utils.logger import Logger


# TODO:add grad clip function
class OptimWrapper(BaseOptimWrapper):
    def __init__(self, optimizer, message_store, accumulative_counts=1, clip_grad=None):
        self._build_grad_clip(clip_grad)
        super(OptimWrapper, self).__init__(
            optimizer, message_store, accumulative_counts, clip_grad
        )

    def _build_grad_clip(self, clip_grad):
        return
        # raise NotImplementedError('Not implement grad clip in tensorflow')

    #     if clip_grad is not None:
    #         clip_type = clip_grad.pop('type', 'norm')
    #         if clip_type == 'norm':
    #             self.clip_func = torch.nn.utils.clip_grad_norm_
    #             self.grad_name = 'grad_norm'
    #         elif clip_type == 'value':
    #             self.clip_func = torch.nn.utils.clip_grad_value_
    #             self.grad_name = 'grad_value'
    #         else:
    #             raise ValueError('type of clip_grad should be "norm" or '
    #                              f'"value" but got {clip_type}')
    #         assert clip_grad, ('`clip_grad` should contain other arguments '
    #                            'besides `type`. The arguments should match '
    #                            'with the `torch.nn.utils.clip_grad_norm_` or '
    #                            'clip_grad_value_`')
    
    def update_params(self, loss) -> None:
        loss = self.scale_loss(loss)

        self.backward(loss)
        # Update parameters only if `self._inner_count` is divisible by
        # `self._accumulative_counts` or `self._inner_count` equals to
        # `self._max_counts`
        if self.should_update():
            self.step()
            self.zero_grad()

    def backward(self, loss, **kwargs) -> None:
        # all computations before update grads and weights should be done above
        self.tape_clear()
        self.optimizer.backward(loss, self.tape, **kwargs)
        self._inner_count += 1

    def zero_grad(self, **kwargs) -> None:
        self.optimizer.zero_grad(**kwargs)

    def step(self, **kwargs) -> None:
        if self.clip_grad_kwargs:
            self._clip_grad()
        self.optimizer.step(**kwargs)

    def state_dict(self) -> dict:
        return self.optimizer.state_dict()

    def load_state_dict(self, state_dict: dict) -> None:
        self.optimizer.load_state_dict(state_dict)

    @property
    def param_groups(self):
        return self.optimizer.param_groups

    @property
    def defaults(self):
        return self.optimizer.defaults

    def get_lr(self):
        """Get the learning rate of the optimizer.

        Provide unified interface to get learning rate of optimizer.

        Returns:
            Dict[str, List[float]]: Learning rate of the optimizer.
        """
        lr = [group["lr"] for group in self.param_groups]
        return dict(lr=lr)

    def get_momentum(self):
        """Get the momentum of the optimizer.

        Provide unified interface to get momentum of optimizer.

        Returns:
            Dict[str, List[float]]: Momentum of the optimizer.
        """
        momentum = []
        for group in self.param_groups:
            # Get momentum of SGD.
            if "momentum" in group.keys():
                momentum.append(group["momentum"])
            # Get momentum of Adam.
            elif "betas" in group.keys():
                momentum.append(group["betas"][0])
            else:
                momentum.append(0)
        return dict(momentum=momentum)

    @contextmanager
    def optim_context(self, model):
        """A Context for gradient accumulation and automatic mix precision
        training.

        If subclasses need to enable the context for mix precision training,
        e.g., ``:class:`AmpOptimWrapper``,  the corresponding context should be
        enabled in `optim_context`. Since ``OptimWrapper`` uses default fp32
        training, ``optim_context`` will only enable the context for
        blocking the unnecessary gradient synchronization during gradient
        accumulation

        If model is an instance with ``no_sync`` method (which means
        blocking the gradient synchronization) and
        ``self._accumulative_counts != 1``. The model will not automatically
        synchronize gradients if ``cur_iter`` is divisible by
        ``self._accumulative_counts``. Otherwise, this method will enable an
        empty context.

        Args:
            model (nn.Module): The training model.
        """
        # During gradient accumulation process, the gradient synchronize
        # should only happen before updating parameters.
        self.tape_enter()
        self.tape.watch(model.trainable_variables)
        if not self.should_sync() and hasattr(model, "no_sync"):
            with model.no_sync():
                yield
        else:
            yield

    def tape_clear(self):
        # tape exit fn
        if not hasattr(self, "tape"):
            raise ValueError(
                "When update gradients in optim_wrapper, call tape_enter() first'"
            )
        if self.tape._recording:
            self.tape._pop_tape()

    def tape_enter(self):
        # self.tape = tf.GradientTape()
        self.tape = tf.GradientTape(watch_accessed_variables=False)
        self.tape._push_tape()

    def _clip_grad(self) -> None:
        """Clip the gradients of parameters."""
        params = []
        for param_group in self.optimizer.param_groups:
            params.extend(param_group["params"])

        params = list(filter(lambda p: p.requires_grad and p.grad is not None, params))
        if len(params) > 0:
            grad = self.clip_func(params, **self.clip_grad_kwargs)
            # `torch.nn.utils.clip_grad_value_` will return None.
            if grad is not None:
                self.message_store.update_scalar(f"train/{self.grad_name}", float(grad))

    def initialize_count_status(self, model, init_counts: int, max_counts: int) -> None:
        """Initialize gradient accumulation related attributes.

        ``OptimWrapper`` can be used without calling
        ``initialize_iter_status``. However, Consider the case of  ``len(
        dataloader) == 10``, and the ``accumulative_iter == 3``. Since 10 is
        not divisible by 3, the last iteration will not trigger
        ``optimizer.step()``, resulting in one less parameter updating.

        Args:
            model (nn.Module): Training model
            init_counts (int): The initial value of the inner count.
            max_counts (int): The maximum value of the inner count.
        """
        logger = Logger.get_current_instance()
        self._inner_count = init_counts
        self._max_counts = max_counts
        if self._inner_count % self._accumulative_counts != 0:
            logger.info(
                "Resumed iteration number is not divisible by "
                "`_accumulative_counts` in `GradientCumulativeOptimizerHook`, "
                "which means the gradient of some iterations is lost and the "
                "result may be influenced slightly."
            )

        # if has_batch_norm(model) and self._accumulative_counts > 1:
        #     print_log(
        #         'Gradient accumulative may slightly decrease '
        #         'performance because the model has BatchNorm layers.')
        # Remainder of `_max_counts` divided by `_accumulative_counts`
        self._remainder_counts = self._max_counts % self._accumulative_counts
