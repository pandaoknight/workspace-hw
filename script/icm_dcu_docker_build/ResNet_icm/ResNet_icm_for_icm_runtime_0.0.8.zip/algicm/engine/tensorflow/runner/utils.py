#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   utils.py
@Time    :   2023/03/21 16:29:45
@Author  :   htx 
"""
import os.path as osp
import subprocess
import sys


import cv2
import re
import numpy as np
import tensorflow as tf
from tensorflow.python.client import device_lib
from collections import OrderedDict, defaultdict


def collect_env():
    """Collect the information of the running environments.

    Returns:
        dict: The environment information. The following fields are contained.

            - sys.platform: The variable of ``sys.platform``.
            - Python: Python version.
            - CUDA available: Bool, indicating if CUDA is available.
            - GPU devices: Device type of each GPU.
            - CUDA_HOME (optional): The env var ``CUDA_HOME``.
            - NVCC (optional): NVCC version.
            - GCC: GCC version, "n/a" if GCC is not installed.
            - MSVC: Microsoft Virtual C++ Compiler version, Windows only.
            - PyTorch: PyTorch version.
            - PyTorch compiling details: The output of \
                ``torch.__config__.show()``.
            - TorchVision (optional): TorchVision version.
            - OpenCV (optional): OpenCV version.
            - MMENGINE: MMENGINE version.
    """
    from distutils import errors

    env_info = OrderedDict()
    env_info["sys.platform"] = sys.platform
    env_info["Python"] = sys.version.replace("\n", "")

    cuda_available = len(tf.config.list_physical_devices("GPU")) > 0
    env_info["CUDA available"] = cuda_available

    env_info["numpy_random_seed"] = np.random.get_state()[1][0]

    if cuda_available:
        tf_devices = defaultdict(list)
        list_devices = device_lib.list_local_devices()
        for k in range(len(list_devices)):
            if list_devices[k].device_type == "CPU":
                continue
            name = re.search(
                r"name:.*?,", list_devices[k].physical_device_desc
            ).group()[6:-1]
            tf_devices[name].append(str(k))
        for name, device_ids in tf_devices.items():
            env_info["TF GPU " + ",".join(device_ids)] = name

        CUDA_HOME = "/usr/local/cuda"
        if osp.isdir(CUDA_HOME):
            try:
                nvcc = osp.join(CUDA_HOME, "bin/nvcc")
                nvcc = subprocess.check_output(f'"{nvcc}" -V', shell=True)
                nvcc = nvcc.decode("utf-8").strip()
                release = nvcc.rfind("Cuda compilation tools")
                build = nvcc.rfind("Build ")
                nvcc = nvcc[release:build].strip()
            except subprocess.SubprocessError:
                nvcc = "Not Available"
            env_info["NVCC"] = nvcc

    try:
        # Check C++ Compiler.
        # For Unix-like, sysconfig has 'CC' variable like 'gcc -pthread ...',
        # indicating the compiler used, we use this to get the compiler name
        import io
        import sysconfig

        cc = sysconfig.get_config_var("CC")
        if cc:
            cc = osp.basename(cc.split()[0])
            cc_info = subprocess.check_output(f"{cc} --version", shell=True)
            env_info["GCC"] = cc_info.decode("utf-8").partition("\n")[0].strip()
        else:
            # on Windows, cl.exe is not in PATH. We need to find the path.
            # distutils.ccompiler.new_compiler() returns a msvccompiler
            # object and after initialization, path to cl.exe is found.
            import locale
            import os
            from distutils.ccompiler import new_compiler

            ccompiler = new_compiler()
            ccompiler.initialize()
            cc = subprocess.check_output(
                f"{ccompiler.cc}", stderr=subprocess.STDOUT, shell=True
            )
            encoding = (
                os.device_encoding(sys.stdout.fileno()) or locale.getpreferredencoding()
            )
            env_info["MSVC"] = cc.decode(encoding).partition("\n")[0].strip()
            env_info["GCC"] = "n/a"
    except (subprocess.CalledProcessError, errors.DistutilsPlatformError):
        env_info["GCC"] = "n/a"
    except io.UnsupportedOperation as e:
        # JupyterLab on Windows changes sys.stdout, which has no `fileno` attr
        # Refer to: https://github.com/open-mmlab/mmengine/issues/931
        # TODO: find a solution to get compiler info in Windows JupyterLab,
        # while preserving backward-compatibility in other systems.
        env_info["MSVC"] = f"n/a, reason: {str(e)}"

    env_info["Tensorflow"] = tf.__version__
    env_info["OpenCV"] = cv2.__version__

    return env_info
