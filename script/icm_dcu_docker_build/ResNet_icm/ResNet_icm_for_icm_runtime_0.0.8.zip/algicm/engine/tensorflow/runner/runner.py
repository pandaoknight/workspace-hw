# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/22

import time
import random
import tensorflow as tf
import numpy as np

import horovod.tensorflow as hvd

from collections import OrderedDict
from algicm.engine.common import BaseRunner
from algicm.engine.common.optim import OptimWrapperDict

from algicm.registry.common import RUNNERS
from algicm.registry.common import MODELS
from algicm.registry.tensorflow import build_optimizer

from ..optim import OptimWrapper
from .utils import collect_env
from algicm.models.backend.core.tensorflow.checkpoint import (
    load_checkpoint,
    save_checkpoint,
    _load_checkpoint_to_model,
)


class Runner(BaseRunner):

    @property
    def filename_posfix(self):
        """Model weights filename posfix according to deep learning platform"""
        return "h5"

    def _collect_env(self):
        return collect_env()

    def set_randomness(self, randomness_cfg):
        seed = randomness_cfg.get("seed")
        if seed is None:
            seed = np.random.randint(2**31)
            self.logger.info(f"Seed is None, Set a random seed {seed}")
            # for distributed training
            if self.world_size != 1:
                hvd.broadcast_object(seed)

        random.seed(seed)
        np.random.seed(seed)
        tf.random.set_seed(int(seed))
        tf.keras.utils.set_random_seed(int(seed))
        # tf.config.experimental.enable_op_determinism()
        self._seed = seed

    @classmethod
    def setup_env(self, env_cfg):
        # init hvd
        hvd.init()
        # set rank and world size
        self._rank, self._world_size = hvd.rank(), hvd.size()

        # set growth memory
        # tf.compat.v1.enable_eager_execution()

        gpus = tf.config.experimental.list_physical_devices("GPU")
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        #     tf.config.experimental.set_virtual_device_configuration(
        # gpu, [tf.config.experimental.VirtualDeviceConfiguration(8192)])
        if gpus:
            tf.config.experimental.set_visible_devices(gpus[hvd.local_rank()],
                                                       "GPU")

        timestamp = hvd.broadcast_object(time.time(), 0)

        self._timestamp = time.strftime("%Y%m%d_%H%M%S",
                                        time.localtime(timestamp))

    def _load_framework_checkpoint(self, filename, map_location):
        """Load tensorflow model checkpoint from disk or other location.

        Args:
            filename(str): Path to checkpoint, end with h5.
            map_location:(str): cpu or cuda. Ignore in tensorflow

        Return:
            checkpoint(dict): checkpoint to store model,optimizer and other infos.

        """
        return load_checkpoint(filename, map_location=map_location)

    def _load_framework_checkpoint_to_model(self,
                                            model,
                                            checkpoint,
                                            strict=False,
                                            revise_keys=False):
        """Load chechpoint to model"""
        return _load_checkpoint_to_model(model,
                                         checkpoint,
                                         strict=strict,
                                         revise_keys=revise_keys)

    def _save_framework_checkpoint(self, checkpoint, filepath, backend_args):
        """Save model checkpoint to destination"""
        # only run on rank 0 to prevent other workers from corruption
        if self.rank != 0:
            return
        save_checkpoint(checkpoint, filepath, backend_args)

    def _get_model_state(self, model):
        return model.all_weights

    def build_model(self, model):
        """Build model from configs."""
        if isinstance(model, tf.keras.Model):
            return model
        elif isinstance(model, dict):
            return MODELS.build(cfg=model)
        else:
            raise TypeError(
                "model should be a tf.keras.layers.Layer object or dict, "
                f"but got {type(model)}")

    def wrap_model(self, model):
        """In tensorflow, weights are not initialized when creation."""
        model.forward = tf.function(model.forward)
        return model

    def _init_weights(self):
        """Initialize the model weights."""
        # run init_weights.
        if hasattr(self.model, "init_weights"):
            self.model.init_weights()

    def _broadcast_parameters(self, model, optim_wrapper):
        hvd.broadcast_variables(model.variables, root_rank=0)
        if isinstance(optim_wrapper, OptimWrapper):
            hvd.broadcast_variables(optim_wrapper.optimizer.varaibles(),
                                    root_rank=0)
        elif isinstance(optim_wrapper, OptimWrapperDict):
            for name, optim in optim_wrapper.optim_wrappers.items():
                hvd.broadcast_variables(optim.optimizer.variables(),
                                        root_rank=0)
        else:
            raise TypeError(
                f"Optim_wrapper should be OptimWrapper or OptimWrapperDict, but got {type(optim_wrapper)}"
            )

    def build_optim(self, optimizer, model):
        """Build tensorflow optimizer from config

        Args:
            optimizer(optional[dict, torch.optim.Optimizer]): Optimizer configs or optimizer instance.
            model(tf.keras.layers.Layers): pytorch model.
        """
        if optimizer is None:
            return

        if isinstance(optimizer, tf.keras.optimizers.Optimizer):
            return optimizer

        if isinstance(optimizer, dict):
            if "type" in optimizer:
                optim = build_optimizer(optimizer, model)
                return optim
            else:
                optim_dict = OrderedDict()
                for name, optim in optimizer.items():
                    if not hasattr(model, name):
                        raise AttributeError(
                            "When building multiple optimizer, "
                            "model should have name {name} that correspond to optimizer name"
                        )
                    submodel = getattr(model, name)
                    if isinstance(optim, tf.keras.optimizers.Optimizer):
                        optim_dict[name] = optim
                    elif isinstance(optim, dict) and ("type" in optim.keys()):
                        optim_dict[name] = build_optimizer(optim, submodel)

                    else:
                        raise ValueError(
                            "Each item mush be an optimizer object when "
                            '"type"  are not in optimizer,'
                            f"but got {name}={optim}")

        else:
            raise TypeError(
                f"Optimizer type should be torch.optim.Optimizer or dict, but got type {type(optimizer)}"
            )

    def build_optim_wrapper(self, optimizer, optim_wrapper_cfg=None):
        """Wrap optimizer with OptimizerWrapper."""

        if optimizer is None:
            return

        if isinstance(
                optimizer,
            (tf.keras.optimizers.Optimizer,
             tf.keras.optimizers.experimental.Optimizer),
        ):
            optim_wrapper = OptimWrapper(optimizer, self.message_store)
            return optim_wrapper

        elif isinstance(optim_wrapper, dict):
            for name, optim in optimizer.items():
                optim_wrapper_dict = OrderedDict()
                if isinstance(optim, tf.keras.optimizers.Optimizer):
                    optim_wrapper_dict[name] = OptimWrapper(
                        optim, self.message_store)
                else:
                    raise ValueError(
                        "Each item mush be an optimizer object when building optim_wrapper"
                        f"but got {name}={optim}")
            return OptimWrapperDict(**optim_wrapper_dict)
        else:
            raise TypeError("optimizer wrapper should be an OptimWrapper "
                            f"object or dict, but got {optim_wrapper}")

    def _convert_tensor_to_numpy(self, value, json_format=True):
        if isinstance(value, (int, float, str)):
            return value
        elif isinstance(value, (np.ndarray, np.array)):
            if value.size == 1:
                return value.item()
            else:
                return value.tolist()
        elif isinstance(value, (tf.Tensor, tf.Variable)):
            if tf.size(value) == 1:
                return value.numpy().item()
            else:
                if json_format:
                    return value.numpy().tolist()
                else:
                    return value.numpy()
        else:
            raise TypeError(
                f"_convert_tensor_to_numpy expected value to be int,float,str,np.ndarry,torch.Tensor,"
                f"but got type {(type(value))}")

    def get_device(self):
        if tf.test.is_gpu_available():
            return "cuda"
        else:
            return "cpu"
