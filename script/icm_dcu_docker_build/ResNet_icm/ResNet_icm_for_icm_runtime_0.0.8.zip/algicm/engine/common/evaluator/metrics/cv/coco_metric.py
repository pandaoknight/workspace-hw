from ..base import BaseMetric
from algicm.registry.common import METRICS
import pycocotools.mask as maskUtils
import numpy as np
from collections import defaultdict
from algicm.engine.common.message.kafka_station import KafkaStation


@METRICS.register_module()
class COCOMetric(BaseMetric):

    def __init__(self, num_classes=10) -> None:
        super().__init__()
        self.iouThrs = np.linspace(0.5,
                                   0.95,
                                   int(np.round((0.95 - 0.5) / 0.05)) + 1,
                                   endpoint=True)
        self.recThrs = np.linspace(0.0,
                                   1.00,
                                   int(np.round((1.00 - 0.0) / 0.01)) + 1,
                                   endpoint=True)
        self.maxDets = [1, 10, 100]
        self.areaRng = [
            [0**2, 1e5**2],
            [0**2, 32**2],
            [32**2, 96**2],
            [96**2, 1e5**2],
        ]  # [[0 ** 2, 1e5 ** 2], [0 ** 2, 32 ** 2], [32 ** 2, 96 ** 2], [96 ** 2, 1e5 ** 2]]
        self.areaRngLbl = ["all", "small", "medium",
                           "large"]  # ['all', 'small', 'medium', 'large']
        self.catIds = [i for i in range(num_classes)]
        self._gt_instance_id = 0
        self._dt_instance_id = 1
        self._img_num = 0
        self.evalRes = []
        self.stats = None

    @property
    def imgIds(self):
        return [i for i in range(self._img_num)]

    def xyxy2xywh(self, bbox: np.ndarray) -> list:
        """Convert ``xyxy`` style bounding boxes to ``xywh`` style for COCO
        evaluation.

        Args:
            bbox (numpy.ndarray): The bounding boxes, shape (4, ), in
                ``xyxy`` order.

        Returns:
            list[float]: The converted bounding boxes, in ``xywh`` order.
        """

        _bbox = bbox.tolist()
        return [
            _bbox[0],
            _bbox[1],
            _bbox[2] - _bbox[0],
            _bbox[3] - _bbox[1],
        ]

    def computeIoU(self, gts, dts, catId):
        gt = gts[catId]
        dt = dts[catId]

        if len(gt) == 0 and len(dt) == 0:
            return []
        inds = np.argsort([-d["score"] for d in dt], kind="mergesort")
        dt = [dt[i] for i in inds]
        if len(dt) > self.maxDets[-1]:
            dt = dt[0:self.maxDets[-1]]

        g = [g["bbox"] for g in gt]
        d = [d["bbox"] for d in dt]

        # compute iou between each dt and gt region
        iscrowd = [int(o["iscrowd"]) for o in gt]
        ious = maskUtils.iou(d, g, iscrowd)
        return ious

    def evaluateImg(self, _gts, _dts, ious, catId, aRng, maxDet):
        """
        perform evaluation for single category and image
        :return: dict (single image results)
        """

        gt = _gts[catId]
        dt = _dts[catId]

        if len(gt) == 0 and len(dt) == 0:
            return None

        for g in gt:
            if g.get("ignore", False) or (g["area"] < aRng[0]
                                          or g["area"] > aRng[1]):
                g["_ignore"] = 1
            else:
                g["_ignore"] = 0

        # sort dt highest score first, sort gt ignore last

        gtind = np.argsort([g["_ignore"] for g in gt], kind="mergesort")
        gt = [gt[i] for i in gtind]
        dtind = np.argsort([-d["score"] for d in dt], kind="mergesort")
        dt = [dt[i] for i in dtind[0:maxDet]]
        iscrowd = [int(o["iscrowd"]) for o in gt]

        # load computed ious
        # ious = ious[:, gtind] if len(ious) > 0 else ious

        T = len(self.iouThrs)
        G = len(gt)
        D = len(dt)
        gtm = np.zeros((T, G))
        dtm = np.zeros((T, D))
        gtIg = np.array([g["_ignore"] for g in gt])
        dtIg = np.zeros((T, D))
        if not len(ious) == 0:
            for tind, t in enumerate(self.iouThrs):
                for dind, d in enumerate(dt):
                    # information about best match so far (m=-1 -> unmatched)
                    iou = min([t, 1 - 1e-10])
                    m = -1
                    for gind, g in enumerate(gt):
                        # if this gt already matched, and not a crowd, continue
                        if gtm[tind, gind] > 0 and not iscrowd[gind]:
                            continue
                        # if dt matched to reg gt, and on ignore gt, stop
                        if m > -1 and gtIg[m] == 0 and gtIg[gind] == 1:
                            break
                        # continue to next gt unless better match made
                        if ious[dind, gind] < iou:
                            continue
                        # if match successful and best so far, store appropriately
                        iou = ious[dind, gind]
                        m = gind
                    # if match made store id of match for both dt and gt
                    if m == -1:
                        continue
                    dtIg[tind, dind] = gtIg[m]
                    dtm[tind, dind] = gt[m]["id"]
                    gtm[tind, m] = d["id"]
        # set unmatched detections outside of area range to ignore
        a = np.array([d["area"] < aRng[0] or d["area"] > aRng[1]
                      for d in dt]).reshape((1, len(dt)))
        dtIg = np.logical_or(dtIg, np.logical_and(dtm == 0, np.repeat(a, T,
                                                                      0)))
        # store results for given image and category
        return {
            "category_id": catId,
            "aRng": aRng,
            "maxDet": maxDet,
            "dtIds": [d["id"] for d in dt],
            "gtIds": [g["id"] for g in gt],
            "dtMatches": dtm,
            "gtMatches": gtm,
            "dtScores": [d["score"] for d in dt],
            "gtIgnore": gtIg,
            "dtIgnore": dtIg,
        }

    def accumulate(self, evalImgs):
        """
        Accumulate per image evaluation results and store the result in self.eval
        :param p: input params for evaluation
        :return: None
        """

        if not len(evalImgs) > 0:
            print("Please run evaluate() first")
        # allows input customized parameters
        T = len(self.iouThrs)
        R = len(self.recThrs)
        K = len(self.catIds)
        A = len(self.areaRng)
        M = len(self.maxDets)
        precision = -np.ones(
            (T, R, K, A, M))  # -1 for the precision of absent categories
        recall = -np.ones((T, K, A, M))
        scores = -np.ones((T, R, K, A, M))

        # create dictionary for future indexing

        catIds = self.catIds
        setK = set(catIds)
        setA = set(map(tuple, self.areaRng))
        setM = set(self.maxDets)
        setI = set(self.imgIds)
        # get inds to evaluate
        k_list = [n for n, k in enumerate(self.catIds) if k in setK]
        m_list = [m for n, m in enumerate(self.maxDets) if m in setM]
        a_list = [
            n for n, a in enumerate(map(lambda x: tuple(x), self.areaRng))
            if a in setA
        ]
        i_list = [n for n, i in enumerate(self.imgIds) if i in setI]
        I0 = len(self.imgIds)
        A0 = len(self.areaRng)
        # retrieve E at each category, area range, and max number of detections
        for k, k0 in enumerate(k_list):
            Nk = k0 * A0 * I0
            for a, a0 in enumerate(a_list):
                Na = a0 * I0
                for m, maxDet in enumerate(m_list):
                    E = [evalImgs[Nk + Na + i] for i in i_list]
                    E = [e for e in E if not e is None]
                    if len(E) == 0:
                        continue
                    dtScores = np.concatenate(
                        [e["dtScores"][0:maxDet] for e in E])

                    # different sorting method generates slightly different results.
                    # mergesort is used to be consistent as Matlab implementation.
                    inds = np.argsort(-dtScores, kind="mergesort")
                    dtScoresSorted = dtScores[inds]

                    dtm = np.concatenate(
                        [e["dtMatches"][:, 0:maxDet] for e in E], axis=1)[:,
                                                                          inds]
                    dtIg = np.concatenate(
                        [e["dtIgnore"][:, 0:maxDet] for e in E], axis=1)[:,
                                                                         inds]
                    gtIg = np.concatenate([e["gtIgnore"] for e in E])
                    npig = np.count_nonzero(gtIg == 0)
                    if npig == 0:
                        continue
                    tps = np.logical_and(dtm, np.logical_not(dtIg))
                    fps = np.logical_and(np.logical_not(dtm),
                                         np.logical_not(dtIg))

                    tp_sum = np.cumsum(tps, axis=1).astype(dtype=float)
                    fp_sum = np.cumsum(fps, axis=1).astype(dtype=float)
                    for t, (tp, fp) in enumerate(zip(tp_sum, fp_sum)):
                        tp = np.array(tp)
                        fp = np.array(fp)
                        nd = len(tp)
                        rc = tp / npig
                        pr = tp / (fp + tp + np.spacing(1))
                        q = np.zeros((R, ))
                        ss = np.zeros((R, ))

                        if nd:
                            recall[t, k, a, m] = rc[-1]
                        else:
                            recall[t, k, a, m] = 0

                        # numpy is slow without cython optimization for accessing elements
                        # use python array gets significant speed improvement
                        pr = pr.tolist()
                        q = q.tolist()

                        for i in range(nd - 1, 0, -1):
                            if pr[i] > pr[i - 1]:
                                pr[i - 1] = pr[i]

                        inds = np.searchsorted(rc, self.recThrs, side="left")
                        try:
                            for ri, pi in enumerate(inds):
                                q[ri] = pr[pi]
                                ss[ri] = dtScoresSorted[pi]
                        except:
                            pass
                        precision[t, :, k, a, m] = np.array(q)
                        scores[t, :, k, a, m] = np.array(ss)
        eval = {
            # 'params': p,
            "counts": [T, R, K, A, M],
            # 'date': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "precision": precision,
            "recall": recall,
            "scores": scores,
        }
        return eval

    def summarize(self, accumulated):
        """
        Compute and display summary metrics for evaluation results.
        Note this functin can *only* be applied on the default parameter setting
        """

        def _summarize(ap=1, iouThr=None, areaRng="all", maxDets=100):
            iStr = " {:<18} {} @[ IoU={:<9} | area={:>6s} | maxDets={:>3d} ] = {:0.3f}"
            titleStr = "Average Precision" if ap == 1 else "Average Recall"
            typeStr = "(AP)" if ap == 1 else "(AR)"
            iouStr = ("{:0.2f}:{:0.2f}".format(self.iouThrs[0],
                                               self.iouThrs[-1])
                      if iouThr is None else "{:0.2f}".format(iouThr))

            aind = [
                i for i, aRng in enumerate(self.areaRngLbl) if aRng == areaRng
            ]
            mind = [
                i for i, mDet in enumerate(self.maxDets) if mDet == maxDets
            ]
            if ap == 1:
                # dimension of precision: [TxRxKxAxM]
                s = accumulated["precision"]
                # IoU
                if iouThr is not None:
                    t = np.where(iouThr == self.iouThrs)[0]
                    s = s[t]
                s = s[:, :, :, aind, mind]
            else:
                # dimension of recall: [TxKxAxM]
                s = accumulated["recall"]
                if iouThr is not None:
                    t = np.where(iouThr == self.iouThrs)[0]
                    s = s[t]
                s = s[:, :, aind, mind]
            if len(s[s > -1]) == 0:
                mean_s = -1
            else:
                mean_s = np.mean(s[s > -1])
            print(
                iStr.format(titleStr, typeStr, iouStr, areaRng, maxDets,
                            mean_s))
            return mean_s

        def _summarizeDets():
            coco_metric_names = {
                "mAP": 0,
                "mAP_50": 1,
                "mAP_75": 2,
                "mAP_s": 3,
                "mAP_m": 4,
                "mAP_l": 5,
                "AR@100": 6,
                "AR@300": 7,
                "AR@1000": 8,
                "AR_s@1000": 9,
                "AR_m@1000": 10,
                "AR_l@1000": 11,
            }
            stats = {}
            stats["mAP"] = _summarize(1)
            stats["mAP_50"] = _summarize(1,
                                         iouThr=0.5,
                                         maxDets=self.maxDets[2])
            stats["mAP_75"] = _summarize(1,
                                         iouThr=0.75,
                                         maxDets=self.maxDets[2])
            stats["mAP_s"] = _summarize(1,
                                        areaRng="small",
                                        maxDets=self.maxDets[2])
            stats["mAP_m"] = _summarize(1,
                                        areaRng="medium",
                                        maxDets=self.maxDets[2])
            stats["mAP_l"] = _summarize(1,
                                        areaRng="large",
                                        maxDets=self.maxDets[2])
            stats["AR1"] = _summarize(0, maxDets=self.maxDets[0])
            stats["AR10"] = _summarize(0, maxDets=self.maxDets[1])
            stats["AR100"] = _summarize(0, maxDets=self.maxDets[2])
            stats["AR_s"] = _summarize(0,
                                       areaRng="small",
                                       maxDets=self.maxDets[2])
            stats["AR_m"] = _summarize(0,
                                       areaRng="medium",
                                       maxDets=self.maxDets[2])
            stats["AR_l"] = _summarize(0,
                                       areaRng="large",
                                       maxDets=self.maxDets[2])
            return stats

        return _summarizeDets()

    def process(self, runner, data_batch, outputs):
        """Convert format to coco style"""

        dts = outputs["pred_instances"]
        gts = outputs["gts"]
        assert len(dts) == len(gts), "Number of image should be equal."

        for gt, dt in zip(gts, dts):
            gt_bboxes, gt_catIds = gt["bboxes"], gt["labels"]
            dt_bboxes, dt_catIds, dt_scores = dt["bboxes"], dt["labels"], dt[
                "scores"]
            _gts = defaultdict(list)
            _dts = defaultdict(list)
            # format gt
            for box, catId in zip(gt_bboxes, gt_catIds):
                box = box.astype(np.int32)
                box = self.xyxy2xywh(box)
                area = box[2] * box[3]
                _gts[catId].append(
                    dict(
                        id=self._gt_instance_id,
                        category_id=int(catId),
                        bbox=box,
                        area=int(area),
                        iscrowd=0,
                    ))
                self._gt_instance_id += 1

            # format dt
            for box, catId, score in zip(dt_bboxes, dt_catIds, dt_scores):
                box = box.astype(np.int32)
                box = self.xyxy2xywh(box)
                area = box[2] * box[3]
                _dts[catId].append(
                    dict(
                        id=self._dt_instance_id,
                        category_id=int(catId),
                        bbox=box,
                        area=int(area),
                        score=float(score),
                    ))
                self._dt_instance_id += 1

            # compute ious
            for catId in self.catIds:
                ious = self.computeIoU(_gts, _dts, catId)
                for aRng in self.areaRng:
                    res = self.evaluateImg(_gts, _dts, ious, catId, aRng,
                                           self.maxDets[-1])
                    self.evalRes.append(res)

        self._img_num += len(gts)

    def evaluate(self, **kwargs):
        accumatelated_results = self.accumulate(self.evalRes)
        self.clear()
        return self.summarize(accumulated=accumatelated_results)

    def update(self) -> None:
        pass

    def clear(self) -> None:
        self._img_num = 0
        self.evalRes = []
        self._gt_instance_id = 0
        self._dt_instance_id = 1

    def reformat(self, metrics, datasets=None):
        """reformat is called during sendin``g metrics to ICM"""
        for k, v in metrics.items():
            if k in [
                    "mAP",
                    "mAP_50",
                    "mAP_75",
                    "mAP_s",
                    "mAP_m",
                    "mAP_l",
                    "AR1",
                    "AR10",
                    "AR100",
                    "AR_s",
                    "AR_m",
                    "AR_l",
            ]:
                metrics[k] = KafkaStation.add_gauge_value(name=k,
                                                          value=float(v))
        return metrics
