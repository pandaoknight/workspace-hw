# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/28

import numpy as np
from typing import Dict
from algicm.engine.common.evaluator.metrics.base import BaseMetric
from algicm.registry.common import METRICS
from algicm.engine.common.message.kafka_station import KafkaStation

from collections import Counter


@METRICS.register_module()
class NerTokenMetric(BaseMetric):
    metric_names = {
        "Precision": float,
        "F1Score": float,
        "Recall": float,
    }

    def __init__(self, num_classes: int):
        super().__init__()
        self.gt_num = 0
        self.pred_num = 0
        self.right_num = 0

    def process(self, runner, data_batch, outputs):
        """
        Args:
            runner:  BaseRunner
            data_batch (dict): contains data and ground truth
            outputs (dict): contains results
        Returns:
        """
        # move to numpy
        preds = outputs["preds"]
        labels = outputs["labels"]
        for pred, label in zip(preds, labels):
            predictions = runner.current_loop.dataloader.dataset.decode(pred)
            token_labels = runner.current_loop.dataloader.dataset.decode(label)
            self.update(predictions, token_labels)

    def update(self, predictions, token_labels) -> None:
        """
        Args:
            predictions (list): [N,3] eg: [[entity name, start_index, end_index]]
            labels: [N,]

        Returns:

        """
        for pred in predictions:
            if pred in token_labels:
                self.right_num += 1
        self.gt_num += len(token_labels)
        self.pred_num += len(predictions)

    def evaluate(self, **kwargs) -> Dict:
        """
        Get the metrics. For those classes with zero instance evaluated,
        the recall is 1.0; with zero positive predcition, the precision is 1.0.
        """

        recall = 0 if self.gt_num == 0 else (self.right_num / self.gt_num)
        precision = 0 if self.pred_num == 0 else (self.right_num /
                                                  self.pred_num)
        f1 = 0.0 if recall + precision == 0 else (2 * precision * recall) / (
            precision + recall)

        self.clear()
        return {
            "Recall": recall,
            "Precision": precision,
            "F1Score": f1,
        }

    def reformat(self, metrics, dataset=None):
        """reformat is called during sendin``g metrics to ICM"""
        for k, v in metrics.items():
            if k in [
                    "Recall",
                    "Precision",
                    "F1Score",
            ]:
                # sheet_name, idx_name, headers, rows
                metrics[k] = KafkaStation.add_gauge_value(name=k,
                                                          value=float(v))
        return metrics

    def clear(self) -> None:
        self.right_num = 0
        self.gt_num = 0
        self.pred_num = 0
