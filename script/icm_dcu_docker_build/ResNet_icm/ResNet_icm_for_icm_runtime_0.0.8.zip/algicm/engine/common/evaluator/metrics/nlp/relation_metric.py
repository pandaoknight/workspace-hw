import numpy as np
from typing import Dict, Any
from algicm.engine.common.evaluator.metrics.base import BaseMetric
from algicm.registry.common import METRICS
from algicm.engine.common.message.kafka_station import KafkaStation
from collections import Counter


@METRICS.register_module()
class RelationMetric(BaseMetric):
    metric_names = {
        "Precision": float,
        "F1Score": float,
        "Recall": float,
    }

    def __init__(self, num_classes: int):
        self.pred_num = 0
        self.gt_num = 0
        self.right_num = 0
        super().__init__()

    def update(self, predictions, labels) -> Any:
        """
        Args:
            predictions (ndarray, list): [N,C], N:number of samples, C: Number of classes
            labels: [N,]

        Returns:

        """
        self.pred_num += len(predictions)
        self.gt_num += len(labels)
        for pred, labels in zip(predictions, labels):
            if pred == labels:
                self.right_num += 1

    def process(self, runner, data_batch, outputs):
        """
        Args:
            runner:  BaseRunner
            data_batch (dict): contains data and ground truth
            outputs (dict): contains results
        Returns:
        """
        # move to numpy
        preds = outputs["preds"]
        labels = outputs["labels"]

        self.update(preds, labels)

    def evaluate(self, **kwargs) -> Dict:
        """
        Get the metrics. For those classes with zero instance evaluated,
        the recall is 1.0; with zero positive predcition, the precision is 1.0.

        Returns:
            Dict:{
            "recall": np.array, shape=(len(self.classes), )
            "mean_recall": float,
            "precision": np.array, shape=(len(self.classes), ),
            "mean_precision": float,
            "f1score": np.array, shape=(len(self.classes), ),
            "mean_f1score": float,
            "confusions": np.ndarray, shape=(len(self.classes), len(self.classes)),
            "count": int
        }
        """
        # compute true_positive, positive, true

        # compute metrics regardless of zero instance classes

        precision = 0 if self.pred_num == 0 else self.right_num / self.pred_num
        recall = 0 if self.gt_num == 0 else self.right_num / self.gt_num
        f1score = 0.0 if recall + precision == 0 else (
            2 * precision * recall) / (precision + recall)
        self.clear()
        return {
            "Recall": recall,
            "Precision": precision,
            "F1Score": f1score,
        }

    def reformat(self, metrics, dataset=None):
        """reformat is called during sendin``g metrics to ICM"""
        for k, v in metrics.items():
            if k in [
                    "Recall",
                    "Precision",
                    "F1Score",
            ]:
                metrics[k] = KafkaStation.add_gauge_value(name=k,
                                                          value=float(v))
        return metrics

    def clear(self) -> None:
        self.gt_num = 0
        self.pred_num = 0
        self.right_num = 0
