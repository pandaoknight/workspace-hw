# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/28

from abc import abstractmethod, ABC
from typing import Dict


class BaseMetric(ABC):
    _task = None
    _type = None

    def __init__(self):
        self.clear()
        self.results= []

    @abstractmethod
    def update(self, predictions, labels) -> None:
        pass

    @abstractmethod
    def process(self, runner, data_batch, outputs):
        pass

    @abstractmethod
    def evaluate(self, **kwargs) -> Dict:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass
