# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/21

from collections import Sequence
from .metrics import BaseMetric
from algicm.registry.common import EVALUATORS, METRICS


@EVALUATORS.register_module()
class Evaluator:
    """Wrapper class to compose multiple :class:`BaseMetric` instances.

    Args:
        metrics (dict or BaseMetric or Sequence): The config of metrics.
    """

    def __init__(self, metrics):
        self._dataset_meta = None
        if not isinstance(metrics, Sequence):
            metrics = [metrics]
        self.metrics = []
        for metric in metrics:
            if isinstance(metric, dict):
                self.metrics.append(METRICS.build(metric))
            elif isinstance(metric, BaseMetric):
                self.metrics.append(metric)
            else:
                raise TypeError(f"Expect metric to be BaseMetric or Dict, but got type {type(metric)}")

    def process(self, runner, data_samples, data_batch=None):
        """Convert ``BaseDataSample`` to dict and invoke process method of each
        metric.

        Args:
            data_samples (dict): predictions of the model,
                and the ground truth of the validation set.
            data_batch (Any, optional): A batch of data from the dataloader.
        """
        for metric in self.metrics:
            metric.process(runner, data_batch, data_samples)

    def evaluate(self, **kwargs) -> dict:
        """Invoke ``get_score`` method of each metric and collect the metrics
        dictionary.
        Returns:
            dict: Evaluation results of all metrics. The keys are the names
            of the metrics, and the values are corresponding results.
        """
        metrics = {}
        for metric in self.metrics:
            _results = metric.evaluate(**kwargs)

            # Check metric name conflicts
            for name in _results.keys():
                if name in metrics:
                    raise ValueError(
                        "There are multiple evaluation results with the same "
                        f"metric name {name}. Please make sure all metrics "
                        "have different prefixes."
                    )

            metrics.update(_results)
        return metrics

    def reformat(self, results, dataset):
        for metric in self.metrics:
            results = metric.reformat(results, dataset)
        return results
