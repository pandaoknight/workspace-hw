import numpy as np
from typing import Dict, Union
from algicm.engine.common.evaluator.metrics.base import BaseMetric
from algicm.registry.common import METRICS
from algicm.engine.common.message.kafka_station import KafkaStation

_eps = 1e-8


@METRICS.register_module()
class SegMetric(BaseMetric):
    metric_names = {"IoU": np.ndarray, "mean_IoU": float, "count": int}

    def __init__(self, num_classes: int) -> None:
        """Incrementally compute IoU of semantic segmentation.

        Args:
            num_class (int): the number of classes(including the background)
                             e.g., Pascal VOC dataset has 20 semantic classes,
                             then num_class=21.
        """
        self.num_class = int(num_classes)
        assert self.num_class >= 2
        super().__init__()

    def clear(self) -> None:
        self.ious = np.zeros(self.num_class, dtype=float)
        self.counts = np.zeros(self.num_class, dtype=int)

    def process(self, runner, data_batch, outputs):
        """
        Args:
            runner:  BaseRunner
            data_batch (dict): contains data and ground truth
            outputs (dict): contains results
        Returns:
        """
        # move to numpy
        preds = outputs["preds"]
        # arg_preds = preds.argmax(axis=1)
        labels = outputs["gt_seg"]
        self.update(preds, labels)

    def update(self, predictions: np.ndarray, labels: np.ndarray):
        """Update the IoU metrics.
        Args:
            predictions (list| np.ndarray): shape=(N, ...), dtype=np.int32 or np.int64
                The value should >= 0 and < self.num_class. with shape [B,H,W,C] or list of [H,W,C].
            labels (list|np.ndarray): same as predictions with shape [B,H,W].
        """
        # assert predictions.shape == labels.shape
        # N = predictions.shape[0]
        # predictions = predictions.reshape((N, -1))
        # labels = labels.reshape((N, -1))
        for prediction, label in zip(predictions, labels):
            prediction = prediction.argmax(axis=-1).reshape(-1)
            label = label.reshape(-1)
            # count the occurrance of the classes in prediction/label
            pred_classes, pred_counts = np.unique(prediction, return_counts=True)
            label_classes, label_counts = np.unique(label, return_counts=True)
            assert pred_classes.max() < self.num_class and pred_classes.min() >= 0
            assert label_classes.max() < self.num_class and label_classes.min() >= 0
            tp_classes, tp_counts = np.unique(label[prediction == label], return_counts=True)

            # count union + intersection
            ui_counts = np.zeros(self.num_class, dtype=int)
            for pred_class, pred_count in zip(pred_classes, pred_counts):
                ui_counts[pred_class] += pred_count
            for label_class, label_count in zip(label_classes, label_counts):
                ui_counts[label_class] += label_count

            # count intersection
            inter_counts = np.zeros(self.num_class, dtype=int)
            for tp_class, tp_count in zip(tp_classes, tp_counts):
                inter_counts[tp_class] += tp_count

            # update IoU
            for i in range(self.num_class):
                if ui_counts[i] > 0:
                    iou = (inter_counts[i] + _eps) / (ui_counts[i] - inter_counts[i] + _eps)
                    self.ious[i] = (self.counts[i] * self.ious[i] + iou) / (self.counts[i] + 1)
                    self.counts[i] += 1

    def evaluate(self, size=None) -> Dict[str, Union[float, np.ndarray]]:
        """Return IoU and mean IoU

        Returns:
            (Dict):
                {
                    "IoU": IoU of each class(np.ndarray, shape=(self.num_class, )).
                    "mean_IoU": Mean IoU(float),
                    "count": int
                }
        """
        ious = self.ious.copy()
        mean = self.ious.mean()
        # count = int(self.counts.sum())
        self.clear()
        return {"IoU": ious, "mean_IoU": mean}

    def reformat(self, metrics, datasets=None):
        """reformat is called during sendin``g metrics to ICM"""
        classes = datasets.metainfo.get("classes")
        for k, v in metrics.items():
            if k == "IoU":
                # sheet_name, idx_name, headers, rows
                metrics[k] = KafkaStation.add_sheet_values(
                    sheet_name=k,
                    idx_name="0",
                    headers=classes,
                    rows=[[float(v_) for v_ in v]],
                )
            elif k == "mean_IoU":
                metrics[k] = KafkaStation.add_gauge_value(name=k, value=float(v))
        return metrics
