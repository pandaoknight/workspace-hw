# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/28

import numpy as np
from typing import Dict
from algicm.engine.common.evaluator.metrics.base import BaseMetric
from algicm.registry.common import METRICS
from algicm.engine.common.message.kafka_station import KafkaStation


@METRICS.register_module()
class MulticlassAccuracy(BaseMetric):
    metric_names = {
        "Recall": np.ndarray,
        "MeanRecall": float,
        "Precision": np.ndarray,
        "MeanPrecision": float,
        "F1Score": np.ndarray,
        "MeanF1Score": float,
        "Confusion": np.ndarray,
        "Count": int,
    }

    def __init__(self, num_classes: int, eps: float = 1e-8):
        assert num_classes > 1
        self.num_classes = np.arange(num_classes).tolist()
        self.eps = eps
        self.confusion = np.zeros(
            (len(self.num_classes), len(self.num_classes)),
            dtype=np.int64,
        )
        super().__init__()

    def update(self, predictions, labels) -> None:
        """
        Args:
            predictions (ndarray, list): [N,C], N:number of samples, C: Number of classes
            labels: [N,]

        Returns:

        """
        for prediction, label in zip(predictions, labels):
            self.confusion[self.num_classes.index(prediction.argmax()),
                           self.num_classes.index(label), ] += 1

    def process(self, runner, data_batch, outputs):
        """
        Args:
            runner:  BaseRunner
            data_batch (dict): contains data and ground truth
            outputs (dict): contains results
        Returns:
        """
        # move to numpy
        preds = outputs["preds"]
        labels = outputs["labels"]
        self.update(preds, labels)

    def evaluate(self, **kwargs) -> Dict:
        """
        Get the metrics. For those classes with zero instance evaluated,
        the recall is 1.0; with zero positive predcition, the precision is 1.0.

        Returns:
            Dict:{
            "recall": np.array, shape=(len(self.classes), )
            "mean_recall": float,
            "precision": np.array, shape=(len(self.classes), ),
            "mean_precision": float,
            "f1score": np.array, shape=(len(self.classes), ),
            "mean_f1score": float,
            "confusions": np.ndarray, shape=(len(self.classes), len(self.classes)),
            "count": int
        }
        """
        # compute true_positive, positive, true
        true_positive = self.confusion.diagonal()
        num_instances = self.confusion.sum(axis=0)
        num_positive = self.confusion.sum(axis=1)

        # compute metrics regardless of zero instance classes
        recall = (true_positive + self.eps) / (num_instances + self.eps)
        precision = (true_positive + self.eps) / (num_positive + self.eps)
        f1score = (2 * recall * precision) / (recall + precision + self.eps)
        count = np.sum(self.confusion)
        confusion = self.confusion.copy()

        self.clear()
        return {
            "Recall": recall,
            "MeanRecall": float(recall.mean()),
            "Precision": precision,
            "MeanPrecision": float(precision.mean()),
            "F1Score": f1score,
            "MeanF1Score": float(f1score.mean()),
            "Confusion": confusion,
            "Count": int(count),
        }

    def reformat(self, metrics, datasets=None):
        """reformat is called during sendin``g metrics to ICM"""
        classes = datasets.metainfo.get("classes")
        for k, v in metrics.items():
            if k in [
                    "Recall",
                    "Precision",
                    "F1Score",
            ]:
                # sheet_name, idx_name, headers, rows
                metrics[k] = KafkaStation.add_sheet_values(
                    sheet_name=k,
                    idx_name="0",
                    headers=classes,
                    rows=[v.astype(np.str_).tolist()],
                )
            elif k == "Confusion":
                metrics[k] = KafkaStation.add_sheet_values(
                    sheet_name=k,
                    idx_name="0",
                    headers=classes,
                    rows=np.hstack(
                        [np.array(classes).reshape(-1, 1),
                         v.astype(np.str_)]).tolist(),
                )
            elif k in [
                    "MeanRecall",
                    "MeanPrecision",
                    "MeanF1Score",
                    "Count",
            ]:
                metrics[k] = KafkaStation.add_gauge_value(name=k,
                                                          value=float(v))
        return metrics

    def clear(self) -> None:
        self.confusion[...] = 0
        self.count = 0
