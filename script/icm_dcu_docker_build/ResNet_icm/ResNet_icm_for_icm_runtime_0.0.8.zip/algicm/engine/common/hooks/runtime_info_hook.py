# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/21

from algicm.engine.common.message.store import _is_valid_value
from algicm.registry.common import HOOKS
from .hook import Hook


@HOOKS.register_module()
class RuntimeInfoHook(Hook):
    """A hook that updates runtime information into message hub.

    E.g. ``epoch``, ``iter``, ``max_epochs``, and ``max_iters`` for the
    training state. Components that cannot access the runner can get runtime
    information through the message hub.
    """

    priority = "VERY_HIGH"

    def before_run(self, runner) -> None:
        """Update metainfo.

        Args:
            runner (Runner): The runner of the training process.
        """
        metainfo = dict(
            # cfg=runner.cfg.pretty_text,
            seed=runner.seed,
            experiment_name=runner.experiment_name,
        )
        runner.message_store.update_info_dict(metainfo)

    def before_train(self, runner) -> None:
        """Update resumed training state.

        Args:
            runner (Runner): The runner of the training process.
        """
        runner.message_store.update_info("epoch", runner.epoch)
        runner.message_store.update_info("iter", runner.iter)
        runner.message_store.update_info("max_epochs", runner.max_epochs)
        runner.message_store.update_info("max_iters", runner.max_iters)
        runner.message_store.update_info("eta", 0)

        if hasattr(runner.train_dataloader.dataset, "metainfo"):
            runner.message_store.update_info("dataset_meta", runner.train_dataloader.dataset.metainfo)

    def before_train_epoch(self, runner) -> None:
        """Update current epoch information before every epoch.

        Args:
            runner (Runner): The runner of the training process.
        """
        runner.message_store.update_info("epoch", runner.epoch)

    def before_train_iter(self, runner, batch_idx, data_batch=None) -> None:
        """Update current iter and learning rate information before every
        iteration.

        Args:
            runner (Runner): The runner of the training process.
            batch_idx (int): The index of the current batch in the train loop.
            data_batch (Sequence[dict], optional): Data from dataloader.
                Defaults to None.
        """
        runner.message_store.update_info("iter", runner.iter)
        lr_dict = runner.optim_wrapper.get_lr()
        if not isinstance(lr_dict, dict):
            msg = (
                "`runner.optim_wrapper.get_lr()` should return a dict "
                "of learning rate when training with OptimWrapper(single "
                "optimizer) or OptimWrapperDict(multiple optimizer), "
                f"but got {type(lr_dict)} please check your optimizer "
                "constructor return an `OptimWrapper` or `OptimWrapperDict` "
                "instance"
            )
            raise RuntimeError(msg)
        for name, lr in lr_dict.items():
            runner.message_store.update_scalar(f"train/{name}", lr[0])

    def after_train_iter(self, runner, batch_idx: int, data_batch=None, outputs=None) -> None:
        """Update ``log_vars`` in model outputs every iteration.

        Args:
            runner (Runner): The runner of the training process.
            batch_idx (int): The index of the current batch in the train loop.
            data_batch (Sequence[dict], optional): Data from dataloader.
                Defaults to None.
            outputs (dict, optional): Outputs from model. Defaults to None.
        """
        if outputs is not None:
            for key, value in outputs.items():
                if not _is_valid_value(value):
                    continue
                runner.message_store.update_scalar(f"train/{key}", value)

    def after_val_epoch(self, runner, metrics=None) -> None:
        """All subclasses should override this method, if they need any
        operations after each validation epoch.

        Args:
            runner (Runner): The runner of the validation process.
            metrics (Dict[str, float], optional): Evaluation results of all
                metrics on validation dataset. The keys are the names of the
                metrics, and the values are corresponding results.
        """
        if metrics is not None:
            for key, value in metrics.items():
                if not _is_valid_value(value):
                    continue
                runner.message_store.update_scalar(f"val/{key}", value)

    def after_test_epoch(self, runner, metrics=None, evaluator=None) -> None:
        """All subclasses should override this method, if they need any
        operations after each test epoch.

        Args:
            runner (Runner): The runner of the testing process.
            metrics (Dict[str, float], optional): Evaluation results of all
                metrics on test dataset. The keys are the names of the
                metrics, and the values are corresponding results.
        """
        if metrics is not None:
            for key, value in metrics.items():
                if not _is_valid_value(value):
                    continue
                runner.message_store.update_scalar(f"test/{key}", value)
