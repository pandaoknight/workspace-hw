#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   output_save_hook.py
@Time    :   2023/08/04 13:33:50
@Author  :   htx 
"""
import os
import json
from algicm.registry.common import HOOKS, TRANSFORMS
from algicm.fileio.handler.json_handler import JsonHandler
from .hook import Hook


@HOOKS.register_module()
class OutputSaveHook(Hook):
    """A hook that updates save output.

    E.g. ``epoch``, ``iter``, ``max_epochs``, and ``max_iters`` for the
    training state. Components that cannot access the runner can get runtime
    information through the message hub.
    """

    priority = "LOWEST"

    def __init__(self, formatter=None, work_dir=None) -> None:
        super().__init__()

        self._formatter = formatter
        self.results = []
        self.handler = JsonHandler()
        if work_dir is not None:
            self._work_dir = work_dir

    def before_run(self, runner) -> None:
        if not hasattr(self, "work_dir"):
            self._work_dir = runner.work_dir
        os.makedirs(self._work_dir, exist_ok=True)
        if isinstance(self._formatter, dict):
            formatter_cfg = self._formatter.copy()
            formatter_cfg.update(dict(work_dir=self._work_dir))
            self.formatter = TRANSFORMS.build(formatter_cfg)
        elif callable(self._formatter):
            self.formatter = self._formatter
        else:
            raise TypeError("formatter should be dict or callable method.")

    def after_test_iter(self,
                        runner,
                        batch_idx,
                        data_batch=None,
                        outputs=None) -> None:
        """All subclasses should override this method, if they need any
        operations after each test iterations.
        """
        result = self.formatter(
            dict(batch_idx=batch_idx, data_batch=data_batch, outputs=outputs),
            datasets=runner.test_loop.dataloader.dataset,
        )
        self.results.extend(result)

    def after_test_epoch(self, runner, metrics=None, evaluator=None) -> None:
        """All subclasses should override this method, if they need any
        operations after each test epoch.

        Args:
            runner (Runner): The runner of the testing process.
            metrics (Dict[str, float], optional): Evaluation results of all
                metrics on test dataset. The keys are the names of the
                metrics, and the values are corresponding results.
        """
        # 1.save output of the model test, in some case will merge results.
        if hasattr(runner.model, "merge_results"):
            results = runner.model.merge_results(self.results)
        else:
            results = self.results
        if hasattr(self.formatter, "collect"):
            results = self.formatter.collect(
                results, runner.test_loop.dataloader.dataset)

        with open(os.path.join(self._work_dir, "outputs.json"), "w") as f:
            self.handler.dump_to_file(results, f)
            # f.write(json.dumps(self.results))
        # 2.save metrics of the model
        # reformat metrics to icm format
        metrics = evaluator.reformat(metrics,
                                     runner.test_loop.dataloader.dataset)
        metric_list = []
        # flatten all metrics
        for k, v in metrics.items():
            metric_list.append(v)

        with open(os.path.join(self._work_dir, "metrics.json"), "w") as f:
            self.handler.dump_to_file(metric_list, f)
            # f.write(json.dumps(metric_list))
