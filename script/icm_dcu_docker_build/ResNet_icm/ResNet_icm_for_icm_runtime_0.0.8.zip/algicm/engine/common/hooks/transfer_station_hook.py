# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/21

import copy
import datetime
import os

from .hook import Hook
from algicm.registry.common import HOOKS
from algicm.utils.misc import is_tuple_of, scandir
from algicm.fileio.backend.io import get_file_backend
from algicm.engine.common.message.kafka_station import KafkaStation


@HOOKS.register_module()
class TransferStationHook(Hook):
    """Collect logs from different components of ``Runner`` and write them to
    terminal, JSON file, tensorboard and wandb .etc.

    ``LoggerHook`` is used to record logs formatted by ``LogProcessor`` during
    training/validation/testing phase. It is used to control following
    behaviors:

    - The frequency of logs update in terminal, local, tensorboad wandb.etc.
    - The frequency of show experiment information in terminal.
    - The work directory to save logs.

    Args:
        interval (int): Logging interval (every k iterations).
            Defaults to 10.
        ignore_last (bool): Ignore the log of last iterations in each epoch if
            the number of remaining iterations is less than :attr:`interval`.
            Defaults to True.
        interval_exp_name (int): Logging interval for experiment name. This
            feature is to help users conveniently get the experiment
            information from screen or log file. Defaults to 1000.
        out_dir (str or Path, optional): The root directory to save
            checkpoints. If not specified, ``runner.work_dir`` will be used
            by default. If specified, the ``out_dir`` will be the concatenation
            of ``out_dir`` and the last level directory of ``runner.work_dir``.
            For example, if the input ``our_dir`` is ``./tmp`` and
            ``runner.work_dir`` is ``./work_dir/cur_exp``, then the log will be
            saved in ``./tmp/cur_exp``. Defaults to None.
        out_suffix (Tuple[str] or str): Those files in ``runner._log_dir``
            ending with ``out_suffix`` will be copied to ``out_dir``. Defaults
            to ('json', '.log', '.py').
        keep_local (bool): Whether to keep local logs in the local machine
            when :attr:`out_dir` is specified. If False, the local log will be
            removed. Defaults to True.
        file_client_args (dict, optional): Arguments to instantiate a
            FileClient. See :class:`mmengine.fileio.FileClient` for details.
            Defaults to None. It will be deprecated in future. Please use
            `backend_args` instead.
        log_metric_by_epoch (bool): Whether to output metric in validation step
            by epoch. It can be true when running in epoch based runner.
            If set to True, `after_val_epoch` will set `step` to self.epoch in
            `runner.visualizer.add_scalars`. Otherwise `step` will be
            self.iter. Default to True.
        backend_args (dict, optional): Arguments to instantiate the
            preifx of uri corresponding backend. Defaults to None.
            New in v0.2.0.

    Examples:
        >>> # The simplest LoggerHook config.
        >>> logger_hook_cfg = dict(interval=20)
    """

    priority = "LOWEST"

    def __init__(
        self,
        kafka_address,
        task_id,
        topic,
        work_dir=None,
        name="kafka",
        interval=10,
        by_epoch=True,
        round_up=6,
    ):
        self.kafka_address = kafka_address
        self.task_id = task_id
        self.topic = topic
        self.name = name
        self.interval = interval
        self.work_dir = work_dir
        self.by_epoch = by_epoch

    def before_run(self, runner) -> None:
        # create dir first
        if self.work_dir is None:
            self.work_dir = runner.work_dir
        os.makedirs(self.work_dir, exist_ok=True)
        # Initialize kafka
        self.kafka_station = KafkaStation(
            self.name, self.kafka_address, self.task_id, self.topic, self.work_dir, round_up=6
        )

    def after_train_iter(self, runner, batch_idx: int, data_batch=None, outputs=None) -> None:
        """Record logs after training iteration.

        Args:
            runner (Runner): The runner of the training process.
            batch_idx (int): The index of the current batch in the train loop.
            data_batch (dict tuple or list, optional): Data from dataloader.
            outputs (dict, optional): Outputs from model.
        """
        # Print experiment name every n iterations.
        if runner.rank != 0:
            return

        if self.every_n_inner_iters(batch_idx, self.interval) or self.end_of_epoch(runner.train_dataloader, batch_idx):
            info_list = self._collect_values(runner=runner, batch_idx=batch_idx, outputs=outputs, mode="train")
            self.kafka_station.add_data_list(info_list)
            self.kafka_station.execute()

    def after_val_iter(self, runner, batch_idx, data_batch=None, outputs=None) -> None:
        """Record logs after validation iteration.

        Args:
            runner (Runner): The runner of the validation process.
            batch_idx (int): The index of the current batch in the validation
                loop.
            data_batch (dict or tuple or list, optional): Data from dataloader.
                Defaults to None.
            outputs (sequence, optional): Outputs from model.
        """
        if runner.rank != 0:
            return

        if self.every_n_inner_iters(batch_idx, self.interval):
            info_list = self._collect_values(runner=runner, batch_idx=batch_idx, outputs=outputs, mode="val")
            self.kafka_station.add_data_list(info_list)
            self.kafka_station.execute()

    def after_test_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        """Record logs after testing iteration.

        Args:
            runner (Runner): The runner of the testing process.
            batch_idx (int): The index of the current batch in the test loop.
            data_batch (dict or tuple or list, optional): Data from dataloader.
            outputs (sequence, optional): Outputs from model.
        """
        if runner.rank != 0:
            return
        if self.every_n_inner_iters(batch_idx, self.interval):
            info_list = self._collect_values(runner=runner, batch_idx=batch_idx, outputs=outputs, mode="test")
            self.kafka_station.add_data_list(info_list)
            self.kafka_station.execute()

    def after_run(self, runner) -> None:
        """Copy logs to ``self.out_dir`` if ``self.out_dir is not None``

        Args:
            runner (Runner): The runner of the training/testing/validation
                process.
        """
        if runner.rank != 0:
            return
        # copy or upload logs to self.out_dir
        self.kafka_station.add_data_list(
            [
                dict(name="progress", category="GAUGE", value="1"),
                dict(name="eta", category="GAUGE", value="0"),
            ]
        )
        self.kafka_station.execute()

    def _collect_values(self, runner, outputs, batch_idx, mode="train"):
        """1.Loss and lr will be format here
        2.collect eta and progress

        """
        # which time
        if mode in ["train", "val"]:
            if self.by_epoch and batch_idx is not None:
                current_iter = batch_idx + 1
            else:
                current_iter = runner.iter + 1
            epoch = runner.epoch + 1
            dataloader_len = len(runner.train_loop.dataloader)

            if self.by_epoch:
                xAxisValue = f"Epoch[{epoch}][{current_iter}/{dataloader_len}]"

            else:
                xAxisValue = f"Iter[{current_iter}/{runner.max_iters}]"
        else:
            if batch_idx is None:
                raise ValueError("batch_idx should not be None when testing")
            current_iter = batch_idx + 1
            dataloader_len = len(runner.test_loop.dataloader)
            xAxisValue = f"Iter[{current_iter}/{dataloader_len}]"

        info_list = []
        # parse output
        base_format = dict(category="LINE", xAxisValue=xAxisValue, xAxisName="Time")
        if outputs is not None:
            for key, value in outputs.items():
                # for loss
                if "loss" in key:
                    output_format = copy.deepcopy(base_format)

                    output_format.update(dict(graph_name=key, yAxisName=key, yAxisValue=value))
                    info_list.append(output_format)
                #
                elif isinstance(value, dict) and "category" in value:
                    info_list.append(value)

        # for eta
        eta = runner.message_store.get_info("eta")
        eta_infos = dict(
            name="eta",
            category="GAUGE",
            value=str(datetime.timedelta(seconds=int(eta))),
        )

        if mode in ["train", "val"]:
            # for lr
            lr_dict = runner.optim_wrapper.get_lr()
            for name, lr in lr_dict.items():
                output_format = copy.deepcopy(base_format)
                lr_ = runner._convert_tensor_to_numpy(lr[0])
                output_format.update(dict(graph_name=name, yAxisName=name, yAxisValue=lr_))
                info_list.append(output_format)

            # for progress
            progress_infos = dict(
                name="progress",
                category="GAUGE",
                value=str(runner.iter / runner.max_iters),
            )
        else:
            progress_infos = dict(
                name="progress",
                category="GAUGE",
                value=str(current_iter / dataloader_len),
            )

        info_list += [eta_infos, progress_infos]
        return info_list
