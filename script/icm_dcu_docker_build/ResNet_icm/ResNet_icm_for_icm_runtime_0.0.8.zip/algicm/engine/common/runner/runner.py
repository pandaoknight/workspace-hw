# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/21

import time
import copy
import json
import pickle
import os
import os.path as osp

from abc import abstractmethod
from collections import OrderedDict

from .utils import random_data, merge_test_cfg, add_classes
from .checkpoint import find_latest_checkpoint
from .priority import get_priority
from .log_processer import LogProcessor
from ..optim import BaseOptimWrapper, _ParamScheduler
from ..message.store import MessageStore
from ..hooks import Hook

from algicm.utils.config import Config
from algicm.utils.logger import Logger
from algicm.utils.misc import is_seq_of
from algicm.utils.collect_env import collect_env
from algicm.datasets import DataLoader, BaseDataset
from algicm.fileio.handler.pickle_handler import PickleHandler
import algicm.models.backend.functional as F

from .loops import (
    BaseLoop,
    EpochBasedTrainLoop,
    IterBasedTrainLoop,
)

from algicm.registry.common import (
    build_dataset,
    build_data_sampler,
    HOOKS,
    LOG_PROCESSORS,
    EVALUATORS,
    LOOPS,
)


class BaseRunner:

    def __init__(
            self,
            model,
            work_dir,
            train_dataloader=None,
            val_dataloader=None,
            test_dataloader=None,
            train_cfg=None,
            val_cfg=None,  # include val_evaluator
            test_cfg=None,  # include test_evaluator
            optimizer=None,
            param_scheduler=None,
            default_hooks=None,
            custom_hooks=None,
            load_from=None,
            resume_from=None,
            randomness=None,
            env_cfg=dict(),
            logger=dict(log_level="INFO"),
            experiment_name=None,
            cfg=None,
    ):
        # create work_dir
        self._work_dir = osp.abspath(work_dir)
        os.makedirs(self._work_dir, exist_ok=True)
        # copy cfg
        if cfg is not None:
            if isinstance(cfg, Config):
                self.cfg = copy.deepcopy(cfg)
            elif isinstance(cfg, dict):
                self.cfg = Config(cfg)
        else:
            self.cfg = Config(dict())
        # experiment_name

        self._experiment_name = experiment_name
        # setup environment
        self.setup_env(env_cfg)
        # build_logger
        self.logger = self.build_logger(logger)

        self._randomness_cfg = randomness
        self.set_randomness(randomness)

        # log env
        self._log_env(env_cfg)

        log_processor = dict()
        self.log_processor = self.build_log_processor(log_processor)

        # train related
        training_related = [train_dataloader, train_cfg, optimizer]
        if not (all(item is None for item in training_related)
                or all(item is not None for item in training_related)):
            msg = (
                "train_dataloader, train_cfg, and optimizer should be either "
                "all None or not None, but got "
                f"train_dataloader={train_dataloader}, "
                f"train_cfg={train_cfg}, "
                f"optimizer={optimizer}.")
            self.logger.error(msg)
            raise ValueError(msg)

        # build dataloader before build model
        if train_dataloader is not None:
            self._train_dataloader, self.num_classes = self.build_dataloader(
                train_dataloader)
        else:
            self._train_dataloader = train_dataloader
        self._train_loop = train_cfg

        # build training loop
        if self._train_dataloader is not None:
            self.logger.info("Start to build training phase")
            self._train_loop = self.build_train_loop(self._train_loop)
            self.logger.info("Success to build training phase")

        if param_scheduler is not None and self.optim_wrapper is None:
            msg = "param_scheduler should be None when optimizer is None, " f"but got {param_scheduler}"
            self.logger.error(msg)
            raise ValueError(msg)

        self._check_scheduler_cfg(param_scheduler)
        self.param_schedulers = param_scheduler

        val_related = [val_dataloader, val_cfg]

        if val_dataloader is not None and val_cfg is not None:
            for index, info in enumerate(val_cfg["evaluator"]["metrics"]):
                val_cfg["evaluator"]["metrics"][index][
                    "num_classes"] = self.num_classes

        if not (all(item is None
                    for item in val_related) or all(item is not None
                                                    for item in val_related)):
            msg = (
                "val_dataloader, val_cfg, and val_evaluator should be either "
                "all None or not None, but got "
                f"val_dataloader={val_dataloader}, val_cfg={val_cfg}")
            self.logger.error(msg)
            raise ValueError(msg)
        if val_dataloader is not None:
            self._val_dataloader = self.build_dataloader(val_dataloader)
        else:
            self._val_dataloader = val_dataloader
        self._val_loop = val_cfg

        if self._val_dataloader is not None:
            self.logger.info("Start to build validation phase")
            self._val_loop = self.build_val_loop(self._val_loop)
            self.logger.info("Success to build validation phase")

        test_related = [test_dataloader, test_cfg]

        if not (all(item is None for item in test_related)
                or all(item is not None for item in test_related)):
            msg = ("test_dataloader, test_cfg, and test_evaluator should be "
                   "either all None or not None, but got "
                   f"test_dataloader={test_dataloader}, test_cfg={test_cfg}")
            self.logger.error(msg)
            raise ValueError(msg)
        if train_dataloader is None or val_dataloader is None:
            self._test_dataloader, self.num_classes = self.build_dataloader(
                test_dataloader)
        else:
            self._test_dataloader = self.build_dataloader(test_dataloader)

        if test_dataloader and test_cfg is not None:
            for index, info in enumerate(test_cfg["evaluator"]["metrics"]):
                test_cfg["evaluator"]["metrics"][index][
                    "num_classes"] = self.num_classes

        self._test_loop = test_cfg

        if self._test_dataloader is not None:
            self.logger.info("Start to build test phase")
            self._test_loop = self.build_test_loop(
                self._test_loop)  # type: ignore
            self.logger.info("Success to build test phase")

        # Building message store to save training infos, such as loss etc.
        self.message_store = self.build_message_store()
        # load or resume
        self._load_from = load_from
        self._resume_from = resume_from
        self._has_loaded = False

        # build model
        self.logger.info("Start to build model, Please Wait a few seconds...")
        self.logger.info("Start to add num_classes")
        add_classes(model, self.num_classes)
        self.cfg.model = model
        self.model = self.build_model(model)
        self.model = F.move_to_device(self.model)

        # build optimizer before initialize weights
        optim = self.build_optim(optimizer, self.model)
        # TODO： specify optimizer wrapper configs
        self.optim_wrapper = self.build_optim_wrapper(optim)

        #initialize weights
        # self.model = self.verify_model(self.model, self.optim_wrapper)
        # from tmp.demo.cv.convert_weights_torch2tf import torch2tf
        # torch2tf("pretrain/faster_rcnn_pretrain_1class.pth", self.model)
        self.model = self.wrap_model(self.model)
        self.logger.info("Success to build model.")

        self._model_name = self.model.__class__.__name__
        self.logger.info(f"{self.model_name} model is ready.")
        self._hooks = []

        self.register_hooks(default_hooks, custom_hooks)
        self.logger.info("Finish initialze runner")

    @classmethod
    def from_cfg(cls, cfg):
        """Build a runner from config.

        Args:
            cfg (ConfigType): A config used for building runner. Keys of
                ``cfg`` can see :meth:`__init__`.

        Returns:
            Runner: A runner build from ``cfg``.
        """
        cfg = copy.deepcopy(cfg)
        runner = cls(
            model=cfg["model"],
            work_dir=cfg["work_dir"],
            train_dataloader=cfg.get("train_dataloader"),
            val_dataloader=cfg.get("val_dataloader"),
            test_dataloader=cfg.get("test_dataloader"),
            train_cfg=cfg.get("train_cfg"),
            val_cfg=cfg.get("val_cfg"),
            test_cfg=cfg.get("test_cfg"),
            optimizer=cfg.get("optimizer"),
            param_scheduler=cfg.get("param_scheduler"),
            env_cfg=cfg.get("env_cfg", dict()),
            default_hooks=cfg.get("default_hooks"),
            custom_hooks=cfg.get("custom_hooks"),
            load_from=cfg.get("load_from"),
            resume_from=cfg.get("resume_from"),
            randomness=cfg.get("randomness", dict(seed=None)),
            logger=cfg.get("logger", dict(log_level="INFO")),
            experiment_name=cfg.get("experiment_name"),
            cfg=cfg,
        )

        return runner

    @classmethod
    def from_test_cfg(cls, cfg):
        """Build a runner from config.

        Args:
            cfg (ConfigType): A config used for building runner. Keys of
                ``cfg`` can see :meth:`__init__`.

        Returns:
            Runner: A runner build from ``cfg``.
        """

        cfg = copy.deepcopy(cfg)
        test_cfg = merge_test_cfg(cfg)
        state_dict = test_cfg.pop("state_dict")
        if test_cfg["test_dataloader"]["dataset"].get("meta_info") is None:
            test_cfg["test_dataloader"]["dataset"][
                "meta_info"] = test_cfg.dataset_meta
        runner = cls.from_cfg(test_cfg)
        runner._load_framework_checkpoint_to_model(runner.model, state_dict)
        return runner

    @property
    def rank(self):
        """Submodule should implement self._rank
        int: Rank of current process.
        """
        if hasattr(self, "_rank"):
            return self._rank
        else:
            raise NotImplementedError

    @property
    def world_size(self):
        """Submodule should implement self._world_size
        int: Number of processes participating in the job.
        """
        if hasattr(self, "_world_size"):
            return self._world_size
        else:
            raise NotImplementedError

    @property
    def seed(self):
        """Submodule should implement self._seed
        int: A number to set random modules.
        """
        if hasattr(self, "_seed"):
            return self._seed
        else:
            raise NotImplementedError

    @property
    def timestamp(self):
        """Submodule should implement self._timestamp
        str: Timestamp when creating experiment."""
        if hasattr(self, "_timestamp"):
            return self._timestamp
        else:
            raise NotImplementedError

    @property
    def filename_posfix(self):
        """Model weights filename posfix according to deep learning platform"""
        # TODO:supports more type
        raise NotImplementedError

    @property
    def experiment_name(self):
        return self._experiment_name

    @property
    def model_name(self):
        return self._model_name

    @property
    def work_dir(self):
        return self._work_dir

    @property
    def task_max_iters(self):
        total_iters = 0
        train_loop_initilaized = False
        if isinstance(self.train_loop, BaseLoop):
            total_iters += self.train_loop.max_iters
            train_loop_initilaized = True

        if isinstance(self.val_loop, BaseLoop) and train_loop_initilaized:
            total_iters += len(self.val_loop.dataloader) * (
                (self.train_loop.max_epochs - self.train_loop.val_begin) //
                self.train_loop.val_interval)

        if isinstance(self.test_loop, BaseLoop):
            total_iters += len(self.test_loop.dataloader)
        return total_iters

    @property
    def task_current_iters(self):
        cur_iters = 0
        if isinstance(self.train_loop, BaseLoop):
            cur_iters += self.train_loop.max_iters
            train_loop_initilaized = True

        if isinstance(self.val_loop, BaseLoop) and train_loop_initilaized:
            cur_iters += self.val_loop.iter

        if isinstance(self.test_loop, BaseLoop):
            cur_iters += self.val_loop.iter
        return cur_iters

    @property
    def max_epochs(self):
        """int: Total epochs to train model."""
        if isinstance(self.train_loop, BaseLoop):
            return self.train_loop.max_epochs
        else:
            return 0

    @property
    def max_iters(self):
        """int: Total iterations to train model."""
        if isinstance(self.train_loop, BaseLoop):
            return self.train_loop.max_iters
        else:
            return 0

    @property
    def epoch(self):
        """int: Current epoch."""
        if isinstance(self.train_loop, BaseLoop):
            return self.train_loop.epoch
        else:
            return 0

    @property
    def iter(self):
        """int: Current iteration."""
        if isinstance(self.train_loop, BaseLoop):
            return self.train_loop.iter
        else:
            return 0

    @property
    def hooks(self):
        return self._hooks

    @property
    def train_loop(self):
        """:obj:`BaseLoop`: A loop to run training."""
        if isinstance(self._train_loop, BaseLoop) or self._train_loop is None:
            return self._train_loop
        else:
            self._train_loop = self.build_train_loop(self._train_loop)
            return self._train_loop

    @property
    def val_loop(self):
        """:obj:`BaseLoop`: A loop to run validation."""
        if isinstance(self._val_loop, BaseLoop) or self._val_loop is None:
            return self._val_loop
        else:
            self._val_loop = self.build_val_loop(self._val_loop)
            return self._val_loop

    @property
    def test_loop(self):
        """:obj:`BaseLoop`: A loop to run testing."""
        if isinstance(self._test_loop, BaseLoop) or self._test_loop is None:
            return self._test_loop
        else:
            self._test_loop = self.build_test_loop(self._test_loop)
            return self._test_loop

    @property
    def train_dataloader(self):
        """The data loader for training."""
        return self.train_loop.dataloader

    @property
    def val_dataloader(self):
        """The data loader for validation."""
        return self.val_loop.dataloader

    @property
    def test_dataloader(self):
        """The data loader for testing."""
        return self.test_loop.dataloader

    @property
    def val_evaluator(self):
        """:obj:`Evaluator`: An evaluator for validation."""
        return self.val_loop.evaluator

    @property
    def test_evaluator(self):
        """:obj:`Evaluator`: An evaluator for testing."""
        return self.test_loop.evaluator

    @property
    def val_interval(self):
        """int: Interval to run validation during training."""
        return self.train_loop.val_interval

    @property
    def val_begin(self):
        """int: The epoch/iteration to start running validation during
        training."""
        return self.train_loop.val_begin

    @property
    def current_loop(self):
        if hasattr(self, "_current_loop"):
            return self._current_loop
        else:
            raise AttributeError("Runner do not initialize current_loop")

    @abstractmethod
    def setup_env(self, env_cfg):
        """
        Framework specified method to do following things:
        1.start to initialize frame
        2.create timestamp. If distributed, broadcast it to all processes
        """
        pass

    @abstractmethod
    def _collect_env(self):
        """Collect environment infos with running environments"""
        pass

    @abstractmethod
    def build_model(self, model):
        """Build model according to its framework"""
        raise NotImplementedError

    @abstractmethod
    def wrap_model(self, model):
        """wrap model such as ema"""
        pass

    @abstractmethod
    def _init_weights(self):
        """Initialize the model and optimizer weights"""
        pass

    @abstractmethod
    def _broadcast_parameters(self):
        pass

    def verify_model(self, model, optim_wrapper):
        # check which dataloader is used, and run one step forward
        # maker sure that all weights are initialized.
        if self._train_dataloader is not None:
            data_loader = self._train_loop.dataloader
        elif self._val_dataloader is not None:
            data_loader = self._val_loop.dataloader
        elif self._test_dataloader is not None:
            data_loader = self._test_loop.dataloader
        else:
            raise ValueError("Must set one of dataloader: train/val/test.")

        # run one step forward
        data = random_data(data_loader)
        model.set_train()
        model.verify(data, optim_wrapper)
        return model

    def build_dataloader(self, dataloader):
        """To build dataloader that is framework free.
        Only support algicm dataloader.
        """
        if isinstance(dataloader, DataLoader) or (dataloader is None):
            return dataloader

        dataloader_cfg = copy.deepcopy(dataloader)
        # build dataset
        dataset_cfg = dataloader_cfg.pop("dataset")
        if isinstance(dataset_cfg, dict):
            dataset = build_dataset(dataset_cfg)
            if hasattr(dataset, "full_init"):
                dataset.full_init()
        else:
            # fallback to raise error in dataloader
            # if `dataset_cfg` is not a valid type
            dataset = dataset_cfg

        # build sampler
        sampler_cfg = dataloader_cfg.pop("sampler")
        if isinstance(sampler_cfg, dict):
            sampler = build_data_sampler(
                sampler_cfg,
                default_args=dict(
                    rank=self.rank,
                    world_size=self.world_size,
                    seed=self.seed,
                    dataset=dataset,
                ),
            )
        else:
            # fallback to raise error in dataloader
            # if `sampler_cfg` is not a valid type
            sampler = sampler_cfg

        # build batch sampler
        batch_sampler_cfg = dataloader_cfg.pop("batch_sampler", None)
        if batch_sampler_cfg is None:
            batch_sampler = None
        elif isinstance(batch_sampler_cfg, dict):
            batch_sampler = build_data_sampler(
                batch_sampler_cfg,
                default_args=dict(
                    rank=self.rank,
                    world_size=self.world_size,
                    dataset=dataset,
                    sampler=sampler,
                    seed=self.seed,
                    batch_size=dataloader_cfg.pop("batch_size"),
                ),
            )
        else:
            # fallback to raise error in dataloader
            # if `batch_sampler_cfg` is not a valid type
            batch_sampler = batch_sampler_cfg

        data_loader = DataLoader(
            dataset=dataset,
            sampler=sampler if batch_sampler is None else None,
            batch_sampler=batch_sampler,
            **dataloader_cfg,
        )
        if hasattr(dataset, "num_classes"):
            return data_loader, dataset.num_classes
        else:
            return data_loader

    @abstractmethod
    def build_optim(self, optimizer, model):
        """Build framework specified optimizer"""
        pass

    @abstractmethod
    def build_optim_wrapper(self, optim, optim_wrapper_cfg=None):
        """Build optimizer wrapper.
        OptimWrapper unify functions to have similary usage
        """
        pass

    @abstractmethod
    def build_param_scheduler(self):
        """Build parameter schedulers, to change optimizer parameters during training"""
        pass

    @abstractmethod
    def get_device(self):
        """
        Returns: Device of cuda or cpu
        """
        pass

    @abstractmethod
    def _get_model_state(self, model):
        """Get model state_dict"""
        pass

    @abstractmethod
    def _load_framework_checkpoint(self, filename, map_location):
        """
        Framework specified loading method
        Return Dict
        """
        raise NotImplementedError

    @abstractmethod
    def _load_framework_checkpoint_to_model(self,
                                            model,
                                            checkpoint,
                                            strict=False,
                                            revise_keys=[(r"^module.", "")]):
        """
        Framework specified, load k,v to model
        Return Dict
        """
        pass

    @abstractmethod
    def _save_framework_checkpoint(self, checkpoint, file_path, backend_args):
        """
        Framework specified, save to h5 or pth
        Return Dict
        """
        pass

    @abstractmethod
    def set_randomness(self, randomness_cfg):
        """Implement to set seed in difference deep learning framework,
        because broadcast method is different when distributed.
        """
        pass

    @abstractmethod
    def _convert_tensor_to_numpy(self, tensor, json_format=True):
        pass

    def build_log_processor(self, log_processor) -> LogProcessor:
        """Build test log_processor.

        Examples of ``log_processor``:

            # `LogProcessor` will be used
            log_processor = dict()

            # custom log_processor
            log_processor = dict(type='CustomLogProcessor')

        Args:
            log_processor (LogProcessor or dict): A log processor or a dict
            to build log processor. If ``log_processor`` is a log processor
            object, just returns itself.

        Returns:
            :obj:`LogProcessor`: Log processor object build from
            ``log_processor_cfg``.
        """
        if isinstance(log_processor, LogProcessor):
            return log_processor
        elif not isinstance(log_processor, dict):
            raise TypeError(
                "log processor should be a LogProcessor object or dict, but"
                f"got {log_processor}")

        log_processor_cfg = copy.deepcopy(log_processor)  # type: ignore

        if "type" in log_processor_cfg:
            log_processor = LOG_PROCESSORS.build(log_processor_cfg)
        else:
            log_processor = LogProcessor(**log_processor_cfg)  # type: ignore

        return log_processor  # type: ignore

    def save_checkpoint(
        self,
        out_dir: str,
        filename: str,
        save_optimizer: bool = True,
        save_param_scheduler: bool = True,
        meta: dict = None,
        by_epoch: bool = True,
        backend_args={"backend": "local"},
    ):
        """Save checkpoints.

        ``CheckpointHook`` invokes this method to save checkpoints
        periodically.

        Args:
            out_dir (str): The directory that checkpoints are saved.
            filename (str): The checkpoint filename.
            file_client_args (dict, optional): Arguments to instantiate a
                FileClient. See :class:`mmengine.fileio.FileClient` for
                details. Defaults to None. It will be deprecated in future.
                Please use `backend_args` instead.
            save_optimizer (bool): Whether to save the optimizer to
                the checkpoint. Defaults to True.
            save_param_scheduler (bool): Whether to save the param_scheduler
                to the checkpoint. Defaults to True.
            meta (dict, optional): The meta information to be saved in the
                checkpoint. Defaults to None.
            by_epoch (bool): Whether the scheduled momentum is updated by
                epochs. Defaults to True.
            backend_args (dict, optional): Arguments to instantiate the
                preifx of uri corresponding backend. Defaults to None.
                New in v0.2.0.
        """
        if self.rank != 0:
            return

        if meta is None:
            meta = {}
        elif not isinstance(meta, dict):
            raise TypeError(
                f"meta should be a dict or None, but got {type(meta)}")

        if by_epoch:
            # self.epoch increments 1 after
            # `self.call_hook('after_train_epoch)` but `save_checkpoint` is
            # called by `after_train_epoch`` method of `CheckpointHook` so
            # `epoch` should be `self.epoch + 1`
            meta.update(epoch=self.epoch + 1, iter=self.iter)
        else:
            meta.update(epoch=self.epoch, iter=self.iter + 1)

        filepath = osp.join(out_dir, filename)

        meta.update(
            # cfg=pickle.dumps(self.cfg),
            seed=self.seed,
            experiment_name=self.experiment_name,
            time=time.strftime("%Y%m%d_%H%M%S", time.localtime()),
        )

        if hasattr(self.train_dataloader.dataset, "metainfo"):
            meta.update(dataset_meta=self.train_dataloader.dataset.metainfo)

        checkpoint = {
            "meta": meta,
            "state_dict": self._get_model_state(self.model),
            "message_hub": self.message_store.state_dict(),
        }

        try:
            handler = PickleHandler()

            cfg_str = handler.dump_to_str(self.cfg)
            checkpoint["cfg"] = cfg_str
        except:
            self.logger.warning("Trying to save config file, but it fails.")

        # save optimizer state dict to checkpoint
        if save_optimizer:
            if isinstance(self.optim_wrapper, BaseOptimWrapper):
                checkpoint["optimizer"] = self.optim_wrapper.state_dict()
            else:
                raise TypeError(
                    "self.optim_wrapper should be an `OptimWrapper` "
                    "or `OptimWrapperDict` instance, but got "
                    f"{self.optim_wrapper}")

        # save param scheduler state dict
        if save_param_scheduler and self.param_schedulers is None:
            self.logger.warning(
                "`save_param_scheduler` is True but `self.param_schedulers` "
                "is None, so skip saving parameter schedulers")
            save_param_scheduler = False
        if save_param_scheduler:
            if isinstance(self.param_schedulers, dict):
                checkpoint["param_schedulers"] = dict()
                for name, schedulers in self.param_schedulers.items():
                    checkpoint["param_schedulers"][name] = []
                    for scheduler in schedulers:
                        state_dict = scheduler.state_dict()
                        checkpoint["param_schedulers"][name].append(state_dict)
            else:
                checkpoint["param_schedulers"] = []
                for scheduler in self.param_schedulers:  # type: ignore
                    state_dict = scheduler.state_dict()  # type: ignore
                    checkpoint["param_schedulers"].append(state_dict)

        self.call_hook("before_save_checkpoint", checkpoint=checkpoint)
        self._save_framework_checkpoint(checkpoint, filepath, backend_args)

    def load_checkpoint(
        self,
        filename,
        map_location="cpu",
        strict=False,
        revise_keys: list = [(r"^models.", "")],
    ):
        checkpoint = self._load_framework_checkpoint(filename,
                                                     map_location=map_location)

        # Add comments to describe the usage of `after_load_ckpt`
        self.call_hook("after_load_checkpoint", checkpoint=checkpoint)

        model = self._load_framework_checkpoint_to_model(
            self.model, checkpoint, strict, revise_keys=revise_keys)

        self._has_loaded = True

        self.logger.info(f"Load checkpoint from {filename}")

        return checkpoint

    def resume(
        self,
        filename,
        resume_optimizer=True,
        resume_param_scheduler=True,
        map_location="default",
    ) -> None:
        """Resume model from checkpoint.

        Args:
            filename (str): Accept local filepath, URL, ``torchvision://xxx``,
                ``open-mmlab://xxx``.
            resume_optimizer (bool): Whether to resume optimizer state.
                Defaults to True.
            resume_param_scheduler (bool): Whether to resume param scheduler
                state. Defaults to True.
            map_location (str or callable):A string or a callable function to
                specifying how to remap storage locations.
                Defaults to 'default'.
        """
        if map_location == "default":
            device = self.get_device()
            checkpoint = self.load_checkpoint(filename, map_location=device)
        else:
            checkpoint = self.load_checkpoint(filename,
                                              map_location=map_location)

        self.train_loop._epoch = checkpoint["meta"]["epoch"]
        self.train_loop._iter = checkpoint["meta"]["iter"]

        # check whether the number of GPU used for current experiment
        # is consistent with resuming from checkpoint
        if "config" in checkpoint["meta"]:
            config = Config.fromstring(checkpoint["meta"]["config"],
                                       file_format=".py")
            previous_gpu_ids = config.get("gpu_ids", None)
            if previous_gpu_ids is not None and len(
                    previous_gpu_ids) > 0 and len(
                        previous_gpu_ids) != self.world_size:
                # TODO, should we modify the iteration?
                self.logger.warning(
                    "Number of GPU used for current experiment is not "
                    "consistent with resuming from checkpoint")
                # if (self.auto_scale_lr is None
                #         or not self.auto_scale_lr.get('enable', False)):
                #     raise RuntimeError(
                #         'Cannot automatically rescale lr in resuming. Please '
                #         'make sure the number of GPU is consistent with the '
                #         'previous training state resuming from the checkpoint '
                #         'or set `enable` in `auto_scale_lr to False.')

        # resume random seed
        resumed_seed = checkpoint["meta"].get("seed", None)
        current_seed = self._randomness_cfg.get("seed")
        if resumed_seed is not None and resumed_seed != current_seed:
            if current_seed is not None:
                self.logger.warning(f"The value of random seed in the "
                                    f'checkpoint "{resumed_seed}" is '
                                    f"different from the value in "
                                    f'`randomness` config "{current_seed}"')
            self._randomness_cfg.update(seed=resumed_seed)
            self.set_randomness(**self._randomness_cfg)

        resumed_dataset_meta = checkpoint["meta"].get("dataset_meta", None)
        dataset_meta = getattr(self.train_dataloader.dataset, "metainfo", None)

        # `resumed_dataset_meta` and `dataset_meta` could be object like
        # np.ndarray, which cannot be directly judged as equal or not,
        # therefore we just compared their dumped results.
        if pickle.dumps(resumed_dataset_meta) != pickle.dumps(dataset_meta):
            self.logger.warning(
                "The dataset metainfo from the resumed checkpoint is "
                "different from the current training dataset, please "
                "check the correctness of the checkpoint or the training "
                "dataset.")

        self.message_store.load_state_dict(checkpoint["message_hub"])

        # resume optimizer
        if "optimizer" in checkpoint and resume_optimizer:
            # self.optim_wrapper = self.build_optim_wrapper(self.optim_wrapper)
            self.optim_wrapper.load_state_dict(
                checkpoint["optimizer"])  # type: ignore

        # resume param scheduler
        if resume_param_scheduler and self.param_schedulers is None:
            self.logger.warning(
                "`resume_param_scheduler` is True but `self.param_schedulers` "
                "is None, so skip resuming parameter schedulers")
            resume_param_scheduler = False
        if "param_schedulers" in checkpoint and resume_param_scheduler:
            self.param_schedulers = self.build_param_scheduler(  # type: ignore
                self.param_schedulers)  # type: ignore
            if isinstance(self.param_schedulers, dict):
                for name, schedulers in self.param_schedulers.items():
                    for scheduler, ckpt_scheduler in zip(
                            schedulers, checkpoint["param_schedulers"][name]):
                        scheduler.load_state_dict(ckpt_scheduler)
            else:
                for scheduler, ckpt_scheduler in zip(
                        self.param_schedulers,  # type: ignore
                        checkpoint["param_schedulers"],
                ):
                    scheduler.load_state_dict(ckpt_scheduler)

        self._has_loaded = True

        self.logger.info(f"resumed epoch: {self.epoch}, iter: {self.iter}")

    def build_message_store(self, message_store=None):
        """Build a global asscessable MessageStore.

        Args:
            message_hub (dict, optional): A dict to build MessageHub object.
                If not specified, default config will be used to build
                MessageHub object. Defaults to None.

        Returns:
            MessageHub: A MessageHub object build from ``message_hub``.
        """
        if message_store is None:
            message_store = dict(name=self.experiment_name)
        elif isinstance(message_store, dict):
            # ensure message_hub containing name key
            message_store.setdefault("name", self.experiment_name)
        else:
            raise TypeError(
                f"message_hub should be dict or None, but got {message_store}")

        return MessageStore(**message_store)

    def train(self):
        if not hasattr(self.model, "train_step"):
            msg = "Model must has an attribute train_step"
            raise RuntimeError(msg)

        if not hasattr(self.model, "val_step"):
            msg = "Model must has an attribute val_step, when validating"
            raise RuntimeError(msg)

        if self._train_loop is None:
            msg = "If you want to train model, must specify train loop"
            raise RuntimeError(msg)

        # if self.param_schedulers is not None:
        #     self.param_schedulers = self.build_param_scheduler(  # type: ignore
        #         self.param_schedulers
        #     )

        self._current_loop = self.train_loop

        if self._val_loop is not None:
            self._val_loop = self.build_val_loop(self._val_loop)

        self.call_hook("before_run")

        self._init_weights()

        #before resume model should run verify_model to init tensorflow's optim params
        self.verify_model(self.model, self.optim_wrapper)

        self.load_or_resume()

        # self._broadcast_parameters()

        self.optim_wrapper.initialize_count_status(
            self.model,
            self._train_loop.iter,  # type: ignore
            self._train_loop.max_iters,
        )  # type: ignore

        # update classes info
        classes = self.train_dataloader.dataset.metainfo.get("classes")

        # run train
        model = self.train_loop.run()  # type: ignore
        self.call_hook("after_run")

    def val(self) -> dict:
        """Launch validation.

        Returns:
            dict: A dict of metrics on validation set.
        """
        if self._val_loop is None:
            msg = "val loop config seems to be None, please check"
            self.logger.info(msg)
            raise RuntimeError(msg)

        # type: ignore

        self.call_hook("before_run")
        self.model.set_eval()
        # make sure checkpoint-related hooks are triggered after `before_run`
        self.load_or_resume()

        metrics = self.val_loop.run()  # type: ignore
        self.call_hook("after_run")
        return metrics

    def test(self) -> dict:
        """Launch test.

        Returns:
            dict: A dict of metrics on testing set.
        """
        if self._test_loop is None:
            raise RuntimeError(
                "test loop config seems to be None, please check")

        self._current_loop = self.test_loop

        self.call_hook("before_run")

        # make sure checkpoint-related hooks are triggered after `before_run`
        self.load_or_resume()

        metrics = self.test_loop.run()  # type: ignore
        self.call_hook("after_run")
        return metrics

    def call_hook(self, fn_name: str, **kwargs) -> None:
        """Call all hooks.

        Args:
            fn_name (str): The function name in each hook to be called, such as
                "before_train_epoch".
            **kwargs: Keyword arguments passed to hook.
        """
        for hook in self._hooks:
            # support adding additional custom hook methods
            if hasattr(hook, fn_name):
                try:
                    getattr(hook, fn_name)(self, **kwargs)
                except TypeError as e:
                    raise TypeError(f"{e} in {hook}") from None

    def load_or_resume(self) -> None:
        """load or resume checkpoint."""

        if self.rank != 0:
            return None

        if self._has_loaded:
            return None

        # decide to load from checkpoint or resume from checkpoint
        # resume_from = None
        # if self._resume and self._load_from is None:
        #     # auto resume from the latest checkpoint
        #     resume_from = find_latest_checkpoint(self.work_dir, self.logger)
        #     self.logger.info(
        #         f"Auto resumed from the latest checkpoint {resume_from}.")
        # elif self._resume and self._load_from is not None:
        #     # resume from the specified checkpoint
        #     resume_from = self._load_from

        if self._resume_from is not None:
            self.logger.info(
                f"Start to resume checkpoint from {self._resume_from}, Please wait"
            )
            self.resume(self._resume_from)
            self._has_loaded = True

        elif self._load_from is not None:
            self.logger.info(
                f"Start to load checkpoint from {self._load_from}, Please wait"
            )
            self.load_checkpoint(self._load_from)
            self._has_loaded = True

    def build_train_loop(self, loop):
        """Build training loop.

        Examples of ``loop``::

            # `EpochBasedTrainLoop` will be used
            loop = dict(by_epoch=True, max_epochs=3)

            # `IterBasedTrainLoop` will be used
            loop = dict(by_epoch=False, max_epochs=3)

            # custom training loop
            loop = dict(type='CustomTrainLoop', max_epochs=3)

        Args:
            loop (BaseLoop or dict): A training loop or a dict to build
                training loop. If ``loop`` is a training loop object, just
                returns itself.

        Returns:
            :obj:`BaseLoop`: Training loop object build from ``loop``.
        """

        if isinstance(loop, BaseLoop):
            return loop
        elif not isinstance(loop, dict):
            raise TypeError(
                f"loop should be a Loop object or dict, but got {loop}")

        loop_cfg = copy.deepcopy(loop)

        if "type" in loop_cfg and "by_epoch" in loop_cfg:
            msg = "Only one of `type` or `by_epoch` can exist in `loop_cfg`."
            self.logger.error(msg)
            raise RuntimeError(msg)

        if "type" in loop_cfg:
            loop_type = loop_cfg.pop("type")
            loop = LOOPS.get(loop_type)(**loop_cfg,
                                        runner=self,
                                        dataloader=self._train_dataloader)
        else:
            by_epoch = loop_cfg.pop("by_epoch")
            if by_epoch:
                loop = EpochBasedTrainLoop(**loop_cfg,
                                           runner=self,
                                           dataloader=self._train_dataloader)
            else:
                loop = IterBasedTrainLoop(**loop_cfg,
                                          runner=self,
                                          dataloader=self._train_dataloader)
        return loop  # type: ignore

    def build_val_loop(self, loop) -> BaseLoop:
        """Build validation loop.

        Examples of ``loop``:

            # `ValLoop` will be used
            loop = dict()

            # custom validation loop
            loop = dict(type='CustomValLoop')

        Args:
            loop (BaseLoop or dict): A validation loop or a dict to build
                validation loop. If ``loop`` is a validation loop object, just
                returns itself.

        Returns:
            :obj:`BaseLoop`: Validation loop object build from ``loop``.
        """
        if isinstance(loop, BaseLoop):
            return loop
        elif not isinstance(loop, dict):
            raise TypeError(
                f"train_loop should be a Loop object or dict, but got {loop}")

        loop_cfg = copy.deepcopy(loop)

        val_loop_type = loop_cfg.pop("type")
        if val_loop_type is None:
            raise ValueError("type must contains in val_loop")
        val_evaluator_cfg = loop_cfg.pop("evaluator")
        if val_evaluator_cfg is None:
            raise ValueError("Evaluator type must contain in val_loop")
        loop = LOOPS.get(val_loop_type)(
            **loop_cfg,
            runner=self,
            dataloader=self._val_dataloader,
            evaluator=val_evaluator_cfg,
        )
        return loop  # type: ignore

    def build_test_loop(self, loop) -> BaseLoop:
        """Build test loop.

        Examples of ``loop``::

            # `TestLoop` will be used
            loop = dict()

            # custom test loop
            loop = dict(type='CustomTestLoop')

        Args:
            loop (BaseLoop or dict): A test loop or a dict to build test loop.
                If ``loop`` is a test loop object, just returns itself.

        Returns:
            :obj:`BaseLoop`: Test loop object build from ``loop_cfg``.
        """
        if isinstance(loop, BaseLoop):
            return loop
        elif not isinstance(loop, dict):
            raise TypeError(
                f"train_loop should be a Loop object or dict, but got {loop}")

        loop_cfg = copy.deepcopy(loop)  # type: ignore

        test_loop_type = loop_cfg.pop("type")
        if test_loop_type is None:
            raise ValueError("type must contains in test_loop")
        test_evaluator_cfg = loop_cfg.pop("evaluator")
        if test_evaluator_cfg is None:
            raise ValueError("Evaluator type must contain in test_loop")
        loop = LOOPS.get(test_loop_type)(
            **loop_cfg,
            runner=self,
            dataloader=self._test_dataloader,
            evaluator=test_evaluator_cfg,
        )

        return loop  # type: ignore

    def build_logger(self, logger_cfg):
        """Build logger to print all messages
        log_level (str): Supports INFO, DEBUG, ERROR, WARNING, default is INFO

        """
        if self._experiment_name is None:
            self._experiment_name = "experiment_temp"

        log_level = logger_cfg.get("log_level", "INFO")

        if logger_cfg.get("log_file", True):
            log_file = osp.join(
                self._work_dir, f"{self.experiment_name}_{self.timestamp}.log")
        else:
            log_file = None
        logger = Logger.get_instance(self.experiment_name,
                                     rank=self.rank,
                                     log_file=log_file,
                                     log_level=log_level)
        return logger

    def register_hooks(self, default_hooks=None, custom_hooks=None):
        """Register default hooks and custom hooks into hook list.

        Args:
            default_hooks (dict[str, dict] or dict[str, Hook], optional): Hooks
                to execute default actions like updating model parameters and
                saving checkpoints.  Defaults to None.
            custom_hooks (list[dict] or list[Hook], optional): Hooks to execute
                custom actions like visualizing images processed by pipeline.
                Defaults to None.
        """
        self.register_default_hooks(default_hooks)

        if custom_hooks is not None:
            self.register_custom_hooks(custom_hooks)

    def register_custom_hooks(self, hooks) -> None:
        """Register custom hooks into hook list.

        Args:
            hooks (list[Hook | dict]): List of hooks or configs to be
                registered.
        """
        for hook in hooks:
            self.register_hook(hook)

    def register_hook(self, hook, priority=None) -> None:
        """Register a hook into the hook list.

        The hook will be inserted into a priority queue, with the specified
        priority (See :class:`Priority` for details of priorities).
        For hooks with the same priority, they will be triggered in the same
        order as they are registered.

        Priority of hook will be decided with the following priority:

        - ``priority`` argument. If ``priority`` is given, it will be priority
          of hook.
        - If ``hook`` argument is a dict and ``priority`` in it, the priority
          will be the value of ``hook['priority']``.
        - If ``hook`` argument is a dict but ``priority`` not in it or ``hook``
          is an instance of ``hook``, the priority will be ``hook.priority``.

        Args:
            hook (:obj:`Hook` or dict): The hook to be registered.
            priority (int or str or :obj:`Priority`, optional): Hook priority.
                Lower value means higher priority.
        """
        if not isinstance(hook, (Hook, dict)):
            raise TypeError(
                f"hook should be an instance of Hook or dict, but got {hook}")

        _priority = None
        if isinstance(hook, dict):
            if "priority" in hook:
                _priority = hook.pop("priority")

            hook_obj = HOOKS.build(hook)
        else:
            hook_obj = hook

        if priority is not None:
            hook_obj.priority = priority
        elif _priority is not None:
            hook_obj.priority = _priority

        inserted = False
        for i in range(len(self._hooks) - 1, -1, -1):
            if get_priority(hook_obj.priority) >= get_priority(
                    self._hooks[i].priority):
                self._hooks.insert(i + 1, hook_obj)
                inserted = True
                break
        if not inserted:
            self._hooks.insert(0, hook_obj)

    def register_default_hooks(self, hooks=None) -> None:
        """Register default hooks into hook list.

        ``hooks`` will be registered into runner to execute some default
        actions like updating model parameters or saving checkpoints.

        Default hooks and their priorities:

        +----------------------+-------------------------+
        | Hooks                | Priority                |
        +======================+=========================+
        | RuntimeInfoHook      | VERY_HIGH (10)          |
        +----------------------+-------------------------+
        | IterTimerHook        | NORMAL (50)             |
        +----------------------+-------------------------+
        | DistSamplerSeedHook  | NORMAL (50)             |
        +----------------------+-------------------------+
        | LoggerHook           | BELOW_NORMAL (60)       |
        +----------------------+-------------------------+
        | ParamSchedulerHook   | LOW (70)                |
        +----------------------+-------------------------+
        | CheckpointHook       | VERY_LOW (90)           |
        +----------------------+-------------------------+

        If ``hooks`` is None, above hooks will be registered by
        default::

            default_hooks = dict(
                runtime_info=dict(type='RuntimeInfoHook'),
                timer=dict(type='IterTimerHook'),
                sampler_seed=dict(type='DistSamplerSeedHook'),
                logger=dict(type='LoggerHook'),
                param_scheduler=dict(type='ParamSchedulerHook'),
                checkpoint=dict(type='CheckpointHook', interval=1),
            )

        If not None, ``hooks`` will be merged into ``default_hooks``.
        If there are None value in default_hooks, the corresponding item will
        be popped from ``default_hooks``::

            hooks = dict(timer=None)

        The final registered default hooks will be :obj:`RuntimeInfoHook`,
        :obj:`DistSamplerSeedHook`, :obj:`LoggerHook`,
        :obj:`ParamSchedulerHook` and :obj:`CheckpointHook`.

        Args:
            hooks (dict[str, Hook or dict], optional): Default hooks or configs
                to be registered.
        """

        default_hooks = dict(
            runtime_info=dict(type="RuntimeInfoHook"),
            timer=dict(type="IterTimerHook"),
            sampler_seed=dict(type="DistSamplerSeedHook"),
            logger=dict(type="LoggerHook"),
            param_scheduler=dict(type="ParamSchedulerHook"),
            checkpoint=dict(type="CheckpointHook", interval=1),
        )
        if hooks is not None:
            for name, hook in hooks.items():
                if name in default_hooks and hook is None:
                    # remove hook from _default_hooks
                    default_hooks.pop(name)
                else:
                    assert hook is not None
                    default_hooks[name] = hook

        for hook in default_hooks.values():
            self.register_hook(hook)

    def _check_scheduler_cfg(self, param_scheduler) -> None:
        """Parse `param_scheduler` to a list of parameter schedulers, or a
        `dict` of which each value is a list of parameter schedulers.

        If only one optimizer is used, the parsed config should be a
        list of parameter scheduler configs or instances. If multiple
        optimizers are used, the parsed config should be `dict`.
        Its key should be consistent with the optimizer `dict` and its value
        should be a list of parameter scheduler configs or instances. See
        :meth:`build_param_scheduler` for more details.

        Examples:
            >>> # valid scheduler:
            >>> # empty scheduler
            >>> scheduler = None
            >>> # Single scheduler
            >>> scheduler = dict(type='MultiStepLR', milestones=[1, 2])
            >>> # Single list schedulers
            >>> scheduler = [dict(type='MultiStepLR', milestones=[1, 2]),
            >>>              dict(type='MultiStepLR', milestones=[2, 3])]
            >>> # `dict` of schedulers
            >>> scheduler = dict(linear1=dict(type='MultiStepLR', milestones=[1, 2]),
            >>>                  linear2=dict(type='MultiStepLR', milestones=[1, 2]))
            >>> # `dict` of `list` of schedulers
            >>> scheduler = dict(linear1=[dict(type='MultiStepLR', milestones=[1, 2])],
            >>>                  linear2=[dict(type='MultiStepLR', milestones=[1, 2])])
            >>> # Single built scheduler
            >>> from mmengine.optim import MultiStepLR
            >>> scheduler = MultiStepLR(milestones=[1, 2], optimizer=optimizer)
            >>> # Single built list schedulers
            >>> scheduler = [MultiStepLR(milestones=[1, 2], optimizer=optimizer)]
            >>> # dict of built scheduler
            >>> scheduler = dict(linear1=MultiStepLR(milestones=[1, 2], optimizer=optimizer),
            >>>                  linear2=MultiStepLR(milestones=[1, 2], optimizer=optimizer))
            >>> # dict of built list schedulers
            >>> scheduler = dict(linear1=[MultiStepLR(milestones=[1, 2], optimizer=optimizer)],
            >>>                  linear2=[MultiStepLR(milestones=[1, 2], optimizer=optimizer)])

        Args:
            param_scheduler (dict or list): The original parameter scheduler.
        """  # noqa: E501
        if param_scheduler is None:
            return
        if isinstance(param_scheduler, _ParamScheduler):
            return
        if is_seq_of(param_scheduler, _ParamScheduler):
            return

        if is_seq_of(param_scheduler, dict):
            for _param_scheduler in param_scheduler:
                if "type" not in _param_scheduler:
                    msg = f"Each parameter sheduler should contain the key type, but got {_param_scheduler}"
                    self.logger.error(msg)
                    raise ValueError(msg)
        elif isinstance(param_scheduler, dict):
            if "type" not in param_scheduler:
                for key, _param_scheduler in param_scheduler.items():
                    assert isinstance(
                        _param_scheduler,
                        (dict, tuple, list, _ParamScheduler)), (
                            "Each value of `param_scheduler` should be a "
                            f"dict or a list, but got {_param_scheduler} with "
                            f"type {type(_ParamScheduler)}")

        else:
            msg = (
                "`param_scheduler` should be a `_ParamScheduler`, `dict`, "
                f"list or a tuple, but got {type(param_scheduler)}. If "
                "`param_scheduler` is a list of dict, it means a list of "
                "scheduler configs for single optimizer. If it is a dict and "
                "contains key `type`, it means a scheduler config for a "
                "single optimizer. If it does not contain key `type`, it "
                "means multiple lists of schedulers for multiple optimizers.")
            self.logger.error(msg)
            raise TypeError(msg)

    def _log_env(self, env_cfg: dict) -> None:
        """Logging environment information of the current task.

        Args:
            env_cfg (dict): The environment config of the runner.
        """
        # Collect and log environment information.
        env = self._collect_env()
        runtime_env = OrderedDict()
        runtime_env.update(env_cfg)
        runtime_env.update(self._randomness_cfg)
        runtime_env["Distributed training"] = self.world_size > 1
        runtime_env["GPU number"] = self.world_size

        env_info = "\n    " + "\n    ".join(f"{k}: {v}"
                                            for k, v in env.items())
        runtime_env_info = "\n    " + "\n    ".join(
            f"{k}: {v}" for k, v in runtime_env.items())
        dash_line = "-" * 60
        self.logger.info("\n" + dash_line + "\nSystem environment:" +
                         env_info + "\n"
                         "\nRuntime environment:" + runtime_env_info + "\n" +
                         dash_line + "\n")
        try:
            self.logger.info(f"Config:\n{self.cfg.pretty_text}")
        except:
            self.logger.info(f"Configs:\n{self.cfg}")
