#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   utils.py
@Time    :   2023/03/20 15:34:47
@Author  :   htx 
"""

import pickle
from algicm.models.backend.core import load_checkpoint


def add_classes(model, num_classes):
    if "roi_head" in model.keys():
        model["roi_head"]["bbox_head"]["num_classes"] = num_classes
        return
    for name in model.keys():
        if "head" in name:
            model[name]["num_classes"] = num_classes


def random_data(dataloader):
    """Random data from dataloader and reset"""
    _iterator = dataloader.__iter__()
    data = next(_iterator)
    if hasattr(dataloader._iterator, "_reset"):
        dataloader._iterator._reset(dataloader)
    return data


def merge_test_cfg(cfg_json):
    # 1.get model checkpoint file path
    ckpt_path = cfg_json.pop("load_from")
    # 2.read ckpt file
    checkpoint = load_checkpoint(ckpt_path, map_location="cpu")
    if "cfg" not in checkpoint:
        raise RuntimeError("Cfg not in checkpoint.")

    if "meta" not in checkpoint:
        raise RuntimeError("meta not in checkpoint.")
    # if "classes" not in checkpoint["meta"]["dataset_meta"]:
    #     raise RuntimeError("meta not in checkpoint.")
    dataset_meta = checkpoint["meta"]["dataset_meta"]
    ckpt_cfg = pickle.loads(checkpoint["cfg"])
    ckpt_cfg.update(cfg_json)
    ckpt_cfg["state_dict"] = checkpoint["state_dict"]
    ckpt_cfg["dataset_meta"] = dataset_meta
    # 3.remove keys not related to test
    train_keys = [
        "train_dataloader",
        "val_dataloader",
        "train_cfg",
        "val_cfg",
        "optimizer",
        "param_scheduler",
        "load_from",
        "resume_from",
    ]
    for k in train_keys:
        ckpt_cfg.pop(k, None)

    return ckpt_cfg
