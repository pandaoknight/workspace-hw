#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# File    :   infer_runner.py
# Time    :   2023/07/26 15:12:30
# Author  :   Tianqi

import pickle
import copy
import time
import os
import os.path as osp
import algicm.models.backend.functional as F

from .loops import BaseInferenceLoop
from algicm.registry.common import MODELS, LOOPS
from algicm.transform.transform import Compose
from algicm.transform.format import HttpOutputFormat
from algicm.utils.logger import Logger
from algicm.models.backend.core import load_checkpoint, _load_checkpoint_to_model
from algicm.registry.common import build_dataset
from .utils import add_classes


@MODELS.register_module()
class InferRunner:

    def __init__(
            self,
            checkpoint,
            model=None,
            work_dir="work_dir",
            datasets=None,
            run_loop=None,
            pre_formatter=[],
            post_formatter=[],
            logger_cfg=dict(log_level="INFO"),
    ) -> None:
        # 1.set up environmnet: logger and work_dir
        self.setup_env(dict(work_dir=work_dir, logger_cfg=logger_cfg))

        # 2. load checkpoint from file.
        if isinstance(checkpoint, str):
            checkpoint = self._load_framework_checkpoint(checkpoint,
                                                         map_location="cpu")

        if "cfg" in checkpoint:
            ckpt_cfg = pickle.loads(checkpoint["cfg"])
        else:
            ckpt_cfg = None

        # 3. build model
        if model is None:
            if ckpt_cfg is None:
                raise RuntimeError("Should specify model architecture.")
            model = ckpt_cfg.get("model", None)
            if model is None:
                raise RuntimeError(
                    "Model architecture is not in the checkpoint.")
        if "meta_info" not in datasets:
            assert "meta" in checkpoint
            num_classes = checkpoint["meta"]["dataset_meta"]["num_classes"]
            add_classes(model, num_classes)
        model = self.build_model(model)
        self._load_framework_checkpoint_to_model(model, checkpoint)
        model = F.move_to_device(model)
        model.set_eval()
        self.model = model

        # 4. handle with pipelines
        if datasets is None:
            if ckpt_cfg is None:
                raise RuntimeError("Should specify pipelines.")

            if "test_dataloader" in ckpt_cfg:
                dataloader_cfg = ckpt_cfg.get("test_dataloader", None)
            elif "val_dataloader" in ckpt_cfg:
                dataloader_cfg = ckpt_cfg.get("val_dataloader", None)
            else:
                raise RuntimeError(
                    "Test/val dataloader is not in the checkpoint")
            self.logger.log_msg(
                "Please specify pipelines in datasets, using Test/Val dataloader pipelines may cause errors."
            )
            pipelines = dataloader_cfg.get("dataset",
                                           dict()).get("pipelines", [])
            # get train datasets
            assert "train_dataloader" in ckpt_cfg
            dataset_type = ckpt_cfg.get("train_dataloader",
                                        None).get("dataset")
            datasets = dict(type=dataset_type, pipelines=pipelines)

        # using dataset meta
        if "meta_info" not in datasets:
            assert "meta" in checkpoint
            meta_info = checkpoint["meta"]["dataset_meta"]
            datasets.update(meta_info=meta_info)
        self.datasets = build_dataset(datasets)
        # 5.build pre_formatter and post_formatter

        self.pre_formatter = Compose(pre_formatter)
        self.post_formatter = Compose(post_formatter)

        # 6.add running loop
        self.execute_fn = HttpOutputFormat()
        if run_loop is None:
            self.loop = BaseInferenceLoop(runner=self)
        elif isinstance(run_loop, dict):
            self.loop = LOOPS.build(dict(**run_loop, runner=self))
        else:
            raise TypeError(f"Not support type {run_loop}")

    @classmethod
    def from_cfg(cls, cfg_json):
        """Infer Engine is to run single model inference without using datasets."""
        cfg = copy.deepcopy(cfg_json)
        checkpoint = cfg_json.pop("load_from", None)
        if checkpoint is None:
            raise RuntimeError("Load_from is None.")
        runner = cls(
            checkpoint=checkpoint,
            model=cfg.get("model", None),
            work_dir=cfg.get("model", "work_dir"),
            datasets=cfg.get("datasets", None),
            pre_formatter=cfg.get("pre_formatter", []),
            post_formatter=cfg.get("post_formatter", []),
            run_loop=cfg.get("run_loop", None),
            logger_cfg=cfg.get("log_info", dict(log_level="INFO")),
        )
        return runner

    def setup_env(self, cfg_json):
        if os.environ.get("ALGICM_BACKEND") == "tensorflow":
            import tensorflow as tf

            gpus = tf.config.experimental.list_physical_devices("GPU")
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)

        work_dir = cfg_json.get("work_dir", "work_dir")
        os.makedirs(work_dir, exist_ok=True)

        logger_cfg = cfg_json.get("logger_cfg", dict(log_level="INFO"))
        log_level = logger_cfg.get("log_level", "INFO")
        log_file = logger_cfg.get("log_file")

        if log_file is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S",
                                      time.localtime(time.time()))
            log_file = osp.join(work_dir, f"{timestamp}.log")
        log_name = logger_cfg.get("log_name", "Inference")
        self.logger = Logger.get_instance(log_name,
                                          log_file=log_file,
                                          log_level=log_level)

    def build_model(self, model):
        if isinstance(model, dict):
            return MODELS.build(model)
        return model

    def load_checkpoint(
        self,
        filename,
        map_location="cpu",
    ):
        checkpoint = self._load_framework_checkpoint(filename,
                                                     map_location=map_location)

        self.logger.log_msg(f"Load checkpoint from {filename}")

        return checkpoint

    def _load_framework_checkpoint_to_model(self,
                                            model,
                                            checkpoint,
                                            strict=False,
                                            revise_keys=[(r"^models.", "")]):
        """Load chechpoint to model"""
        return _load_checkpoint_to_model(model,
                                         checkpoint,
                                         strict,
                                         revise_keys=revise_keys)

    def _load_framework_checkpoint(self, filename, map_location):
        return load_checkpoint(filename, map_location=map_location)

    def run(self):
        results = self.loop.run()
        return self.execute_fn(results)
