import pickle
import os
import argparse
import torch
import sys
import json

sys.path.insert(0, "/".join(os.path.abspath(__file__).split("/")[:2]))


def parse_args():
    parser = argparse.ArgumentParser(
        description="ICM algorithms training script.")
    parser.add_argument(
        "--ner_work_dir",
        default="work_dir/relation",
        help="ner workdir",
    )
    parser.add_argument(
        "--rel_work_dir",
        default="work_dir/relation",
        help="rel work_dir",
    )
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    ends = (".pth", ".h5")
    # args = parse_args()
    root_path = "/".join(os.path.abspath(__file__).split("/")[:-3])
    work_dir = json.load(open(f"{root_path}/configs.json",
                              "r")).get("work_dir")
    # assert args.ner_work_dir == args.ner_work_dir, "work_dir should be same"
    ner_file_name = os.listdir(work_dir)
    rel_file_name = os.listdir(work_dir)
    for ner_name in ner_file_name:
        if "ner" in ner_name.lower() and ner_name.endswith(ends):
            ner_ckpt = os.path.join(work_dir, ner_name)
            break
    for rel_name in rel_file_name:
        if "rel" in rel_name.lower() and rel_name.endswith(ends):
            rel_ckpt = os.path.join(work_dir, rel_name)
            break
    if ner_ckpt.endswith(".h5") or rel_ckpt.endswith(".h5"):
        import tensorflow as tf
        with open(ner_ckpt, 'rb') as f:
            ner_ = pickle.load(f)

        with open(rel_ckpt, 'rb') as f:
            rel_ = pickle.load(f)

        data = {"ner": ner_, "rel": rel_}

        with open(os.path.join(work_dir, "merged.h5"), 'wb') as f:
            pickle.dump(data, f)
            os.remove(ner_ckpt)
            os.remove(rel_ckpt)
    else:
        ner_ = torch.load(ner_ckpt, map_location="cpu")
        rel_ = torch.load(rel_ckpt, map_location="cpu")
        data = {"ner": ner_, "rel": rel_}
        torch.save(data, os.path.join(work_dir, "merged.pth"))
        os.remove(ner_ckpt)
        os.remove(rel_ckpt)
