#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   logger.py
@Time    :   2023/03/03 15:40:16
@Author  :   htx 
"""

import logging
import os
import sys
import threading
from collections import OrderedDict
from colorlog import ColoredFormatter
from colorlog.formatter import ColoredRecord
from .manager import ManagerMixin

_lock = threading.RLock()


def _accquire_lock() -> None:
    """Acquire the module-level lock for serializing access to shared data.

    This should be released with _release_lock().
    """
    if _lock:
        _lock.acquire()


def _release_lock() -> None:
    """Release the module-level lock acquired by calling _accquire_lock()."""
    if _lock:
        _lock.release()


class Formatter(ColoredFormatter):
    """Colorful format for Logger. If the log level is error, the logger will
    additionally output the location of the code.

    Args:
        color (bool): Whether to use colorful format. filehandler is not
            allowed to use color format, otherwise it will be garbled.
        **kwargs: Keyword arguments passed to
            :meth:`logging.Formatter.__init__`.
    """

    _color_mapping = dict(
        ERROR="red", WARN="yellow", WARNING="yellow", INFO="white", DEBUG="green"
    )

    def __init__(self, color=True, **kwargs):
        if color:
            color_config = self._color_mapping
        else:
            color_config = None
        super().__init__(log_colors=color_config, **kwargs)

        self.err_format = (
            "%(log_color)s%(asctime)s %(levelname)+5s %(process)d "
            "--- [%(threadName)+3s] %(module)+10s %(pathname)s %(funcName)s %(lineno)d: %(message)s"
        )
        self.debug_format = self.info_format = self.warn_format = (
            "%(log_color)s%(asctime)s %(levelname)+5s %(process)d "
            "--- [%(threadName)+3s] %(module)+10s : %(message)s"
        )

    def formatMessage(self, record):
        """Format a message from a record object."""

        if record.levelno == logging.ERROR:
            self._style._fmt = self.err_format
        elif record.levelno == logging.WARNING:
            self._style._fmt = self.warn_format
        elif record.levelno == logging.INFO:
            self._style._fmt = self.info_format
        elif record.levelno == logging.DEBUG:
            self._style._fmt = self.debug_format

        record.asctime = self.formatTime(record, self.datefmt)
        escapes = self._escape_code_map(record.levelname)
        wrapper = ColoredRecord(record, escapes)
        message = self._style.format(wrapper)  # type: ignore
        message = self._append_reset(message, escapes)
        return message


class Logger(logging.Logger, ManagerMixin):
    """Formatted logger used to record messages.

    ``Logger`` can create formatted logger to log message with different
    log levels and get instance in the same way as ``ManagerMixin``.
    ``Logger`` has the following features:

    - Distributed log storage, ``Logger`` can choose whether to save log of
      different ranks according to `log_file`.
    - Message with different log levels will have different colors and format
      when displayed on terminal.

    Note:
        - The `name` of logger and the ``instance_name`` of ``Logger`` could
          be different. We can only get ``Logger`` instance by
          ``Logger.get_instance`` but not ``logging.getLogger``. This feature
          ensures ``Logger`` will not be incluenced by third-party logging
          config.
        - Different from ``logging.Logger``, ``Logger`` will not log warning
          or error message without ``Handler``.

    Examples:
        >>> logger = Logger.get_instance(name='algicm',
        >>>                                logger_name='Logger')
        >>> # Although logger has name attribute just like `logging.Logger`
        >>> # We cannot get logger instance by `logging.getLogger`.
        >>> assert logger.name == 'Logger'
        >>> assert logger.instance_name = 'Logger'
        >>> assert id(logger) != id(logging.getLogger('Logger'))
        >>> # Get logger that do not store logs.
        >>> logger1 = Logger.get_instance('logger1')
        >>> # Get logger only save rank0 logs.
        >>> logger2 = Logger.get_instance('logger2', log_file='out.log')
        >>> # Get logger only save multiple ranks logs.
        >>> logger3 = Logger.get_instance('logger3', rank=[required], log_file='out.log',
        >>>                                 distributed=True)

    Args:
        name (str): Global instance name.
        logger_name (str): ``name`` attribute of ``Logging.Logger`` instance.
            If `logger_name` is not defined, defaults to 'mmengine'.
        log_file (str, optional): The log filename. If specified, a
            ``FileHandler`` will be added to the logger. Defaults to None.
        log_level (str): The log level of the handler and logger. Defaults to
            "NOTSET".
        file_mode (str): The file mode used to open log file. Defaults to 'w'.
        distributed (bool): Whether to save distributed logs, Defaults to
            false.
    """

    _instance_dict = OrderedDict()

    def __init__(
        self,
        name,
        rank=0,
        logger_name="algicm",
        log_file=None,
        log_level="INFO",
        file_mode="w",
        color=True,
        distributed=False,
    ):
        logging.Logger.__init__(self, logger_name)
        ManagerMixin.__init__(self, name)

        # Config stream_handler. If `rank != 0`. stream_handler can only
        # export ERROR logs.
        stream_handler = logging.StreamHandler(stream=sys.stdout)
        # `StreamHandler` record month, day, hour, minute, and second
        # timestamp.
        stream_handler.setFormatter(Formatter(color=color, datefmt="%m/%d %H:%M:%S"))
        # Only rank0 `StreamHandler` will log messages below error level.
        stream_handler.setLevel(log_level) if rank == 0 else stream_handler.setLevel(
            logging.ERROR
        )
        self.handlers.append(stream_handler)

        if log_file is not None:
            if rank != 0:
                # rename `log_file` with rank suffix.
                path_split = log_file.split(os.sep)
                if "." in path_split[-1]:
                    filename_list = path_split[-1].split(".")
                    filename_list[-2] = f"{filename_list[-2]}_rank{rank}"
                    path_split[-1] = ".".join(filename_list)
                else:
                    path_split[-1] = f"{path_split[-1]}_rank{rank}"
                log_file = os.sep.join(path_split)
            # Save multi-ranks logs if distributed is True. The logs of rank0
            # will always be saved.
            if rank == 0 or distributed:
                # Here, the default behaviour of the official logger is 'a'.
                # Thus, we provide an interface to change the file mode to
                # the default behaviour. `FileHandler` is not supported to
                # have colors, otherwise it will appear garbled.
                file_handler = logging.FileHandler(log_file, file_mode)
                # `StreamHandler` record year, month, day hour, minute,
                # and second timestamp. file_handler will only record logs
                # without color to avoid garbled code saved in files.
                file_handler.setFormatter(
                    Formatter(color=False, datefmt="%Y/%m/%d %H:%M:%S")
                )
                file_handler.setLevel(log_level)
                self.handlers.append(file_handler)

    @classmethod
    def get_current_instance(cls):
        """Get latest created instance.

        Before calling ``get_current_instance``, The subclass must have called
        ``get_instance(xxx)`` at least once.

        Examples
            >>> instance = GlobalAccessible.get_current_instance()
            AssertionError: At least one of name and current needs to be set
            >>> instance = GlobalAccessible.get_instance('name1')
            >>> instance.instance_name
            name1
            >>> instance = GlobalAccessible.get_current_instance()
            >>> instance.instance_name
            name1

        Returns:
            object: Latest created instance.
        """
        _accquire_lock()
        if not cls._instance_dict:
            return cls
        name = next(iter(reversed(cls._instance_dict)))
        _release_lock()
        return cls._instance_dict[name]

    def callHandlers(self, record):
        """Pass a record to all relevant handlers.

        Override ``callHandlers`` method in ``logging.Logger`` to avoid
        multiple warning messages in DDP mode. Loop through all handlers of
        the logger instance and its parents in the logger hierarchy. If no
        handler was found, the record will not be output.

        Args:
            record (LogRecord): A ``LogRecord`` instance contains logged
                message.
        """
        for handler in self.handlers:
            if record.levelno >= handler.level:
                handler.handle(record)

    def setLevel(self, level):
        """Set the logging level of this logger.

        If ``logging.Logger.selLevel`` is called, all ``logging.Logger``
        instances managed by ``logging.Manager`` will clear the cache. Since
        ``Logger`` is not managed by ``logging.Manager`` anymore,
        ``Logger`` should override this method to clear caches of all
        ``Logger`` instance which is managed by :obj:`ManagerMixin`.

        level must be an int or a str.
        """
        self.level = logging.checkLevel(level)
        _accquire_lock()
        # The same logic as `logging.Manager._clear_cache`.
        for logger in Logger._instance_dict.values():
            logger._cache.clear()
        _release_lock()

    @classmethod
    def log_msg(cls, msg, level="INFO"):
        """Print a log message

        Args:
            msg (str): The message to be logged.
            level (int): Logging level. Only available when `logger` is a Logger
            object, "current", or a created logger instance name.
        """
        logger_instance = cls.get_current_instance()
        if not logger_instance._instance_dict:
            print(msg)
        else:
            if not isinstance(level, str):
                raise TypeError(
                    f"log_msg expect level to be str, but got type {type(level)}"
                )

            if level == "DEBUG":
                logger_instance.log(logging.DEBUG, msg)
            elif level == "INFO":
                logger_instance.log(logging.INFO, msg)
            elif level == "ERROR":
                logger_instance.log(logging.ERROR, msg, exc_info=True)
            elif level == "WARN":
                logger_instance.log(logging.WARNING, msg)
            elif level == "WARNING":
                logger_instance.log(logging.WARNING, msg)
            else:
                raise ValueError(
                    f"Level expect to be DEBUG/INFO/ERROR/WARN/WARNING, but got {level}"
                )

    @classmethod
    def debug(cls, msg):
        cls.log_msg(msg, level="DEBUG")

    @classmethod
    def info(cls, msg):
        cls.log_msg(msg, level="INFO")

    @classmethod
    def error(cls, msg):
        cls.log_msg(msg, level="ERROR")

    @classmethod
    def warn(cls, msg):
        cls.log_msg(msg, level="WARNING")

    @classmethod
    def warning(cls, msg):
        cls.log_msg(msg, level="WARNING")
