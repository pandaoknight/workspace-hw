# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/21
import os
import os.path as osp
import subprocess
import sys
from collections import OrderedDict, defaultdict
from distutils import errors

import cv2
import numpy as np
import re


def _get_cuda_home():
    return os.environ["CUDA_HOME"] if "CUDA_HOME" in os.environ else None


def collect_env():
    """Collect the information of the running environments.

    Returns:
        dict: The environment information. The following fields are contained.

            - sys.platform: The variable of ``sys.platform``.
            - Python: Python version.
            - CUDA available: Bool, indicating if CUDA is available.
            - GPU devices: Device type of each GPU.
            - CUDA_HOME (optional): The env var ``CUDA_HOME``.
            - NVCC (optional): NVCC version.
            - GCC: GCC version, "n/a" if GCC is not installed.
            - MSVC: Microsoft Virtual C++ Compiler version, Windows only.
            - PyTorch: PyTorch version.
            - PyTorch compiling details: The output of \
                ``torch.__config__.show()``.
            - TorchVision (optional): TorchVision version.
            - OpenCV (optional): OpenCV version.
            - MMENGINE: MMENGINE version.
    """
    env_info = OrderedDict()
    env_info["sys.platform"] = sys.platform
    env_info["Python"] = sys.version.replace("\n", "")

    # torch cuda
    try:
        import torch

        torch_version = torch.__version__
        torch_cuda_available = torch.cuda.is_available()
        torch_build_config = torch.__config__.show()
        env_info["TORCH_CUDA_AVAILABLE"] = torch_cuda_available
        env_info["TORCH_VERSION"] = torch_version
        env_info["TORCH_BUILD_CONFIG"] = torch_build_config
    except:
        torch_cuda_available = False
        torch_version = None
        torch_build_config = None

    # tensorflow cuda
    try:
        import tensorflow as tf
        from tensorflow.python.client import device_lib

        tf_cuda_available = len(tf.config.list_physical_devices("GPU")) > 0
        tf_version = tf.__version__
        env_info["TF_CUDA_AVAILABLE"] = tf_cuda_available
        env_info["TF_VERSION"] = tf_version
    except:
        tf_cuda_available = False
        tf_version = None

    env_info["numpy_random_seed"] = np.random.get_state()[1][0]

    CUDA_HOME = _get_cuda_home()
    env_info["CUDA_HOME"] = CUDA_HOME

    if torch_cuda_available:
        devices = defaultdict(list)
        for k in range(torch.cuda.device_count()):
            devices[torch.cuda.get_device_name(k)].append(str(k))
        for name, device_ids in devices.items():
            env_info["Torch GPU " + ",".join(device_ids)] = name

    if tf_cuda_available:
        tf_devices = defaultdict(list)
        list_devices = device_lib.list_local_devices()
        for k in range(len(list_devices)):
            if list_devices[k].device_type == "CPU":
                continue
            name = re.search(
                r"name:.*?,", list_devices[k].physical_device_desc
            ).group()[6:-1]
            tf_devices[name].append(str(k))
        for name, device_ids in tf_devices.items():
            env_info["TF GPU " + ",".join(device_ids)] = name

    if CUDA_HOME is not None and osp.isdir(CUDA_HOME):
        try:
            nvcc = osp.join(CUDA_HOME, "bin/nvcc")
            nvcc = subprocess.check_output(f'"{nvcc}" -V', shell=True)
            nvcc = nvcc.decode("utf-8").strip()
            release = nvcc.rfind("Cuda compilation tools")
            build = nvcc.rfind("Build ")
            nvcc = nvcc[release:build].strip()
        except subprocess.SubprocessError:
            nvcc = "Not Available"
        env_info["NVCC"] = nvcc

    try:
        # Check C++ Compiler.
        # For Unix-like, sysconfig has 'CC' variable like 'gcc -pthread ...',
        # indicating the compiler used, we use this to get the compiler name
        import sysconfig

        cc = sysconfig.get_config_var("CC")
        if cc:
            cc = osp.basename(cc.split()[0])
            cc_info = subprocess.check_output(f"{cc} --version", shell=True)
            env_info["GCC"] = cc_info.decode("utf-8").partition("\n")[0].strip()
        else:
            # on Windows, cl.exe is not in PATH. We need to find the path.
            # distutils.ccompiler.new_compiler() returns a msvccompiler
            # object and after initialization, path to cl.exe is found.
            import locale
            import os
            from distutils.ccompiler import new_compiler

            ccompiler = new_compiler()
            ccompiler.initialize()
            cc = subprocess.check_output(
                f"{ccompiler.cc}", stderr=subprocess.STDOUT, shell=True
            )
            encoding = (
                os.device_encoding(sys.stdout.fileno()) or locale.getpreferredencoding()
            )
            env_info["MSVC"] = cc.decode(encoding).partition("\n")[0].strip()
            env_info["GCC"] = "n/a"
    except (subprocess.CalledProcessError, errors.DistutilsPlatformError):
        env_info["GCC"] = "n/a"

    try:
        import torchvision

        env_info["TorchVision"] = torchvision.__version__
    except ModuleNotFoundError:
        pass

    env_info["OpenCV"] = cv2.__version__

    return env_info
