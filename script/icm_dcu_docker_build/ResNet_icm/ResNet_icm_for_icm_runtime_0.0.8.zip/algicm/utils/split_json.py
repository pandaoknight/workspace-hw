import os
import json
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="ICM json split")
    parser.add_argument(
        "--config",
        default="end2end.json",
        help="json path.",
    )
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = parse_args()
    root = "/".join(args.config.split("/")[:-1])
    with open(args.config, "r") as f:
        cfg = json.load(f)
    backend = cfg.get("backend")
    work_dir = cfg.get("work_dir")
    kafka_config = cfg.get("kafka")
    train_data_root_config = cfg.get("train_data_root")
    val_data_root_config = cfg.get("val_data_root")
    load_from = cfg.get("load_from", None)
    ann_config = cfg.get("ann_file")

    ner_json = cfg.get("ner")
    rel_json = cfg.get("rel")

    ner_json["backend"] = backend
    ner_json["work_dir"] = work_dir
    ner_json["default_hooks"]["kafka"] = kafka_config
    ner_json["train_dataloader"]["dataset"][
        "data_root"] = train_data_root_config
    ner_json["train_dataloader"]["dataset"]["ann_file"] = ann_config
    ner_json["val_dataloader"]["dataset"]["data_root"] = val_data_root_config
    ner_json["val_dataloader"]["dataset"]["ann_file"] = ann_config

    rel_json["backend"] = backend
    rel_json["work_dir"] = work_dir
    rel_json["default_hooks"]["kafka"] = kafka_config
    rel_json["train_dataloader"]["dataset"][
        "data_root"] = train_data_root_config
    rel_json["train_dataloader"]["dataset"]["ann_file"] = ann_config
    rel_json["val_dataloader"]["dataset"]["data_root"] = val_data_root_config
    rel_json["val_dataloader"]["dataset"]["ann_file"] = ann_config
    if load_from is not None:
        ner_json["load_from"] = load_from
        rel_json["load_from"] = load_from
    json.dump(ner_json, open(os.path.join(root, "ner.json"), "w"))
    json.dump(rel_json, open(os.path.join(root, "rel.json"), "w"))
