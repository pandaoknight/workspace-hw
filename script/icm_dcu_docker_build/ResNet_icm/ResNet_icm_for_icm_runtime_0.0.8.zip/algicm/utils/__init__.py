from .misc import is_seq_of,_pair
from .logger import Logger