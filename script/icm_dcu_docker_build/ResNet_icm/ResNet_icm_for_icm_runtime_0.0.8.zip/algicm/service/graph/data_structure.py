from abc import abstractmethod
from functools import partial
from typing import Any
import copy
import queue
# from ..format import *

class CallableNode:
    def __init__(
        self,
        inputs=None,
        outputs=None,
        name=None,
    ) -> None:
        self.name = name
        self.inputs = inputs
        self.outputs = outputs

    @abstractmethod
    def call(self, context):
        pass

    def __call__(self, *args, **kwargs) -> Any:
        return self.call(*args, **kwargs)


class ClassNode(CallableNode):
    def __init__(self, method, inputs, outputs, name=None, attr=None) -> None:

        if type(method) == "type":
            self.method = method(**attr)
        elif isinstance(method, dict) :
            from .all_method import Methods
            from algicm.engine.common.runner.infer_runner import InferRunner
            self.method = Methods()(method)
            
        super().__init__(inputs=inputs, outputs=outputs, name=name)

    def call(self, context):
        inputs = [context.get(input_index) for input_index in self.inputs]
        return [self.method(*inputs)]


class FunctionNode(CallableNode):
    def __init__(self, method, inputs, outputs, name=None, attr=None) -> None:
        if attr is None:
            attr = dict()
        if callable(method):
            self.method = partial(method, **attr)
        elif isinstance(method, str):
            self.method = eval(method)

        super().__init__(name=name, inputs=inputs, outputs=outputs)

    def call(self, context):
        inputs = [context.get(input_index) for input_index in self.inputs]
        return [self.method(*inputs)]


class ConditionNode(CallableNode):
    def __init__(
        self, graph_then, graph_else, inputs=None, outputs=None, name=None
    ) -> None:
        super().__init__(inputs=inputs, outputs=outputs, name=name)
        self.graph_then = Graph.from_json(graph_then)
        self.graph_else = Graph.from_json(graph_else)

    def call(self, context):
        condition = context.get(self.inputs[0])
        if condition:
            inputs = [
                context.get(input_index) for input_index in self.graph_then.inputs
            ]
            return self.graph_then(*inputs)
        else:
            inputs = [
                context.get(input_index) for input_index in self.graph_else.inputs
            ]
            return self.graph_else(*inputs)


class Graph(CallableNode):
    """Demo:


    a --->                       --->true: add[a+b]-1
        add[a+b] -> ifcondition
    b --->                       --->false: add[a+b]^2

    >>>
        def add(a,b):
            return a+b

        def ifcondition(a):
            if a>0:
                return True
            else:
                return False

        def minusone(a):
            return a - 1

        def squre(a):
            return a**2

        Computing graph def:
        graph = dict(inputs=['1','2'], outputs=['6'],
            graph=[dict(name='op1', op_type='function',
            method=add, inputs=['1','2'], outputs=['3']),
            dict(name='op2', op_type='function', method=ifcondition, inputs=['3'], outputs=['4']),
            dict(name='op3', op_type='condition',
                graph_then=dict(inputs=['3'], outputs=['6'],
                graph=[dict(name='op4', op_type='function', method=minusone, inputs=['3'], outputs=['6'])]),
                graph_else=dict(inputs=['3'], outputs=['6'],
                graph=[dict(name='op5', op_type='function', method=squre, inputs=['3'], outputs=['6'])]), inputs=['4'], outputs=['6']),
        ])

        graph_exec = Graph.from_json(graph)

        graph_exec(-4,0)
        >>> 16
    """

    def __init__(
        self,
        order,
        name=None,
        inputs=None,
        outputs=None,
    ):
        super().__init__(name=name, inputs=inputs, outputs=outputs)
        self.order = order

    @classmethod
    def from_json(cls, cfg):
        assert isinstance(cfg, dict)
        order = cls.parse(cfg.get("graph"), cfg.get("inputs"))
        return cls(
            order=order,
            name=cfg.get("name"),
            inputs=cfg.get("inputs"),
            outputs=cfg.get("outputs"),
        )

    @classmethod
    def parse(cls, graph, inputs, outputs=None):
        tmp_value = copy.deepcopy(inputs)
        orders = []
        q = queue.Queue()
        for node in graph:
            q.put(node)

        num_tries = 0
        while not q.empty():
            node = q.get()
            print(node)
            print(tmp_value)
            op_type = node.get("op_type")
            node_inputs = node.get("inputs")
            if not all(map(tmp_value.__contains__, node_inputs)):
                num_tries += 1
                if num_tries > q.qsize():
                    raise RuntimeError("Graph is not correct.")
                continue

            if op_type == "function":
                op = FunctionNode(
                    node.get("method"),
                    inputs=node_inputs,
                    outputs=node.get("outputs"),
                    name=node.get("name"),
                    attr=node.get("attr"),
                )
            elif op_type == "class":
                op = ClassNode(
                    node.get("method"),
                    inputs=node_inputs,
                    outputs=node.get("outputs"),
                    name=node.get("name"),
                    attr=node.get("attr"),
                )
            else:
                op = ConditionNode(
                    graph_then=node.get("graph_then"),
                    graph_else=node.get("graph_else"),
                    inputs=node_inputs,
                    outputs=node.get("outputs"),
                    name=node.get("name"),
                )
            orders.append(op)
            tmp_value += node.get("outputs")
            num_tries = 0

        return orders

    def call(self, *args):
        assert len(args) == len(self.inputs)
        context = dict()
        for index, value in zip(self.inputs, args):
            context[index] = value

        for op in self.order:
            outputs = op(context)
            for output_index, value in zip(op.outputs, outputs):
                context[output_index] = value

        return [context.get(output_index) for output_index in self.outputs]
