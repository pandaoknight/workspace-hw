from algicm.registry.common import MODELS, ALL_METHODS, TRANSFORMS, INFER_RUNNER
from algicm.engine.common.runner.infer_runner import InferRunner


class Methods:

    def __init__(self):
        self.type = [MODELS, TRANSFORMS, INFER_RUNNER]

    def __call__(self, methods):
        self.add_all_methods()
        if methods.get("type") == 'GraphInfer':
            method = InferRunner.from_cfg(methods.get("config"))
        else:
            method = ALL_METHODS.build(methods)
        return method

    def add_all_methods(self):
        for type in self.type:
            ALL_METHODS._module_dict.update(type._module_dict)
