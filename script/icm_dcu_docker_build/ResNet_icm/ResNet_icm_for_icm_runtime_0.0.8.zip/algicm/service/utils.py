import socket
import tempfile
import json
import psutil
import signal
import sys
import os
from flask import jsonify
from algicm.utils.manager import _accquire_lock, _release_lock
from algicm.utils.logger import Logger
from algicm.fileio.handler.json_handler import JsonHandler

json_handler = JsonHandler()


def update_app_info(current_app, name2pid, pid2port, mode="ADD"):
    assert mode in ["ADD", "REPLACE"]
    assert isinstance(name2pid, dict) and isinstance(pid2port, dict)

    _accquire_lock()
    if mode == "ADD":
        current_app.name2pid.update(name2pid)
        current_app.pid2port.update(pid2port)
    else:
        current_app.name2pid = name2pid
        current_app.pid2port = pid2port
    _release_lock()


def _create_pid_file(current_app):
    """Create a pid file to store all process infomations, includes url/pid/port.
    Args:
        current_app (Flask): current app

    Retruns:
        FileName of its pid file.

    """
    if os.path.isfile(current_app.PID_FILE):
        pass
    else:
        if not isinstance(current_app.PID_FILE, str):
            current_app.PID_FILE = ".pid"
        # create a empty file
        write_pid(current_app, [])
    return current_app.PID_FILE


def _create_url_map(current_app):
    """Create a url map contains which url register in this server

    Args:
        current_app (Flask): current app

    """
    if not hasattr(current_app, "name2pid"):
        current_app.name2pid = {}
    if not hasattr(current_app, "pid2port"):
        current_app.pid2port = {}


def write_pid(current_app, contents, mode="w"):
    """Using lock to Write url/pid/port to pid file.
    Args:
        current_app (Flask): current app
        contents (list[str]): each str contains url/pid/port, eg: ['url pid port\n'].
        mode (str): mode to open file.

    """
    _accquire_lock()
    with open(current_app.PID_FILE, mode) as fp:
        for content in contents:
            fp.write(content)
    _release_lock()


def read_pid(current_app):
    """Read url/pid/port from pid file.
    Args:
        current_app (Flask): current app
    Return:
        name2pid(dict): a mapping dict from url to pid.
        pid2port(dict):a mapping dict from pid to port.

    """
    filename = _create_pid_file(current_app)
    name2pid = dict()
    pid2port = dict()
    with open(filename, "r") as f:
        name_with_pid = f.read().split("\n")

    for line in name_with_pid:
        if len(line) == 0:
            continue
        server_name, pid, port = line.split(" ")
        if psutil.pid_exists(int(pid)):
            name2pid[server_name] = pid
            pid2port[pid] = port
    return name2pid, pid2port


def check_port_used(port):
    """To check whether port is used.
    Args:
        port(int): port.
    Return:
        bool: port status


    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(("0.0.0.0", port))
    if result == 0:
        return True
    else:
        return False


def find_free_port():
    """To find an unused port.

    Return:
        port (int): a free port
    """
    temp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    temp_socket.bind(("localhost", 0))  # 绑定到本地地址的一个随机端口
    temp_socket.listen(1)  # 监听连接
    port = temp_socket.getsockname()[1]  # 获取随机端口号
    temp_socket.close()  # 关闭临时套接字
    return port


def find_all_urls(app):
    """To determine whether url is used.

    Args:
        current_app (Flask): current app
    """
    _create_url_map(app)

    return list(app.name2pid.keys())


def wrap_jsonify(code, msg, **kwargs):
    """wrap jsonify resutls with dict.

    Args:
        status (int): status code, 200 stands for success.
        message(str): messages of the status
    Return:
        a jsonify object, directly used in flask return.

    """
    return json_handler.dump_to_str(dict(code=code, msg=msg, **kwargs))


def unregister_route(route, current_app):
    """Remove url in records.

    Args:
        route(str): url to remove, start with a slash.
        current_app (Flask): current app.


    """
    pid = current_app.name2pid.get(route)
    if pid:
        current_app.name2pid.pop(route)
        current_app.pid2port.pop(str(pid))

    # if len(list(current_app.url_map.iter_rules(endpoint))) == 1:
    #     if str(current_app.url_map._rules_by_endpoint[endpoint][0]) == route:
    #         # if binding one route, just remove method
    #         current_app.url_map._rules_by_endpoint.pop(endpoint)
    #     else:
    #         warnings.warn(f"Route {route} is not in the registry.")
    # else:
    #     # if binding multiple route, just remove one of routes
    #     for endpoint_url in current_app.url_map._rules_by_endpoint[endpoint]:
    #         if str(endpoint_url) == route:
    #             current_app.url_map._rules_by_endpoint[endpoint].remove(endpoint_url)


def update_status(current_app):
    """Make sure pid file and routes mapping is matched.
    Args:
        current_app (Flask): current app.

    """
    routes = find_all_urls(current_app)

    # step 1: read pid file. containts: url, pid and port.
    name2pid, pid2port = read_pid(current_app)
    # step 2: check all routes is running
    for route in routes:
        if str(route) not in name2pid.keys():
            unregister_route(route, current_app)

    # step 3: update to current app
    update_app_info(current_app,
                    name2pid=name2pid,
                    pid2port=pid2port,
                    mode="REPLACE")
    # step 4:  write current status

    contents = []
    for k, v in name2pid.items():
        contents.append(f"{k} {v} {pid2port[v]}\n")

    write_pid(current_app, contents, mode="w")


def start_server(config, current_app):
    """Start a new server.

    Args:
        config(dict): config to start a server, fllowing args supported.
                    1. url (str|required): request url.
                    2. port (int|required): server port, need to be unused, if not, random a port.
                    3. executable(str|optional): python path used to start the server.
                    4. working_dir(str|optional): path to where the new server project is.
                    5. execute_file(str|optional): which file to execute.
                    6. env(dict|optional): environment variables.

    Return:
        A jsonify object.

    """

    ## step 1: read config file to get url
    with open(config, "r") as f:
        cfg = json.loads(f.read())
    Logger.log_msg(
        f"Using cfg to start server: {cfg}.",
        level="INFO",
    )
    url = cfg.get("url")
    if url is None:
        return wrap_jsonify(500, "Param url should not be None")

    # tep 2: check url is already used
    used_routes = find_all_urls(current_app)
    if url in used_routes:
        return wrap_jsonify(500, "Url already registered in current server")

    # step 3: check port is used, if so, random a free port
    port = cfg.get("port")
    # not assign port
    if port is None:
        port = find_free_port()
        Logger.log_msg(f"Port is not assigned, use a random port {port}",
                       level="WARN")
    elif check_port_used(port):
        # port is used
        port = find_free_port()
        Logger.log_msg(f"Port is used, use a random port {port}", level="WARN")
    # step 4: create a  temp file
    cfg_copy = cfg.copy()
    cfg_copy["port"] = port

    temp_file = tempfile.NamedTemporaryFile(mode="w",
                                            delete=False,
                                            suffix=".json")
    with open(temp_file.name, "w") as f:
        f.write(json.dumps(cfg_copy))

    # step 5: start a  server
    executable = cfg.get("executable", sys.executable)
    working_dir = cfg.get("working_dir", os.getcwd())
    execute_file = cfg.get("execute_file", "inference.py")
    backend = cfg.get("backend")
    env = cfg.get("env")
    if env is None:
        env = {}

    env.update(dict(USE_CONTROLLER="False", ALGICM_BACKEND=backend))
    process = psutil.Popen(
        # [executable, execute_file, "--config", temp_file.name],
        [f"{executable}  {execute_file} --config {temp_file.name}"],
        cwd=working_dir,
        env=env,
        shell=True,
    )

    Logger.log_msg(
        f"Using port:{port}, executable:{executable}, working_dir:{working_dir},"
        f"execute_file:{execute_file}, env: {env}",
        level="INFO",
    )
    pid = str(process.pid + 1)
    # step 6: record urls and it pid
    update_app_info(current_app, {str(url): str(pid)}, {str(pid): str(port)},
                    mode="ADD")
    write_pid(current_app, [f"{url} {pid} {port}\n"], mode="a+")

    return wrap_jsonify(200,
                        "Success to start a server",
                        pid=pid,
                        port=port,
                        url=url)


def stop_server(config, current_app):
    """stop a server.

    Args:
        config(dict): dict to pass either url or pid.
        current_app (Flask): current app.

    Return:
        A jsonify object.

    """
    server_route = config.get("url")
    server_pid = config.get("pid")
    name2pid, pid2port = read_pid(current_app)
    pid2name = {v: k for k, v in name2pid.items()}

    sname = None
    spid = None
    if server_route:
        sname = server_route
        spid = name2pid.get(sname)
    elif server_pid:
        sname = pid2name.get(str(server_pid))
        spid = str(server_pid)
    else:
        wrap_jsonify(500, "Pid and url are both None")

    if sname:
        unregister_route(sname, current_app)
        if sname in name2pid.keys():
            pid2port.pop(name2pid[sname])
            name2pid.pop(sname)
    if spid and psutil.pid_exists(int(spid)):
        process = psutil.Process(int(spid))
        process.kill()
        process.wait(timeout=3)
        if process.is_running():
            Logger.log_msg(f"Force killing zombie process with PID: {spid}",
                           level="WARNING")
            os.kill(int(spid), signal.SIGKILL)

    contents = []
    if sname in name2pid.keys():
        contents.append([f"{sname} {spid} {pid2port[spid]}\n"])
    update_app_info(current_app, name2pid, pid2port, mode="REPLACE")
    write_pid(current_app, contents, mode="w")
    return wrap_jsonify(200, "Success to stop a server")
