from flask import Flask, request
from .utils import wrap_jsonify
from algicm.engine.common.runner.infer_runner import InferRunner
from algicm.utils.logger import Logger
import requests
import json
import os
import torch
import pickle

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False


def inference():
    try:
        if request.method == "GET":
            return wrap_jsonify(code=200, msg="Server is health")
        else:
            return runner.run()

    except Exception as e:
        Logger.log_msg(f"{str(e)}", level="ERROR")
        return wrap_jsonify(400, str(e))


def rel_inference():
    try:
        if request.method == "GET":
            return wrap_jsonify(code=200, msg="Server is health")
        else:
            return rel_runner.run()

    except Exception as e:
        Logger.log_msg(f"{str(e)}", level="ERROR")
        return wrap_jsonify(400, str(e))


def ner_inference():
    try:
        if request.method == "GET":
            return wrap_jsonify(code=200, msg="Server is health")
        else:
            ner_output = ner_runner.run()
            content = json.loads(ner_output)['content']['annotations'][0]

            result = requests.post(f'http://localhost:{port}/rel_infer',
                                   json=content)
            return result.text

    except Exception as e:
        Logger.log_msg(f"{str(e)}", level="ERROR")
        return wrap_jsonify(400, str(e))


def run_server(cfg):
    ner_config = cfg.get("ner", None)
    rel_config = cfg.get("rel", None)
    if ner_config is not None and rel_config is not None:

        global ner_runner
        global rel_runner
        global port
        ner_work_dir = "/".join(
            ner_config.get("load_from").split("/")[:-1]) + "/ner"
        rel_work_dir = "/".join(
            rel_config.get("load_from").split("/")[:-1]) + "/rel"
        os.makedirs(ner_work_dir, exist_ok=True)
        os.makedirs(rel_work_dir, exist_ok=True)
        ner_ckpt_path = ner_config.get("load_from")
        rel_ckpt_path = rel_config.get("load_from")
        if ner_ckpt_path.endswith(".pth"):
            merged_ckpt = torch.load(ner_ckpt_path)
            ner_ckpt_save_path = os.path.join(ner_work_dir, "ner.pth")
            torch.save(merged_ckpt["ner"], ner_ckpt_save_path)
            ner_config["load_from"] = ner_ckpt_save_path
        else:
            import tensorflow as tf
            merged_ckpt = pickle.load(open(ner_ckpt_path, "rb"))
            ner_ckpt_save_path = os.path.join(ner_work_dir, "ner.h5")
            pickle.dump(merged_ckpt["ner"], open(ner_ckpt_save_path, "wb"))
            ner_config["load_from"] = ner_ckpt_save_path

        if rel_ckpt_path.endswith(".pth"):
            merged_ckpt = torch.load(rel_ckpt_path)
            rel_ckpt_save_path = os.path.join(rel_work_dir, "rel.pth")
            torch.save(merged_ckpt["rel"], rel_ckpt_save_path)
            rel_config["load_from"] = rel_ckpt_save_path
        else:
            import tensorflow as tf
            merged_ckpt = pickle.load(open(rel_ckpt_path, "rb"))
            rel_ckpt_save_path = os.path.join(rel_work_dir, "rel.h5")
            pickle.dump(merged_ckpt["rel"], open(rel_ckpt_save_path, "wb"))
            rel_config["load_from"] = rel_ckpt_save_path

        ner_runner = InferRunner.from_cfg(ner_config)

        rel_runner = InferRunner.from_cfg(rel_config)

        port = int(cfg["service"].get("port", 18080))

        app.route(cfg["service"].get("url", "/infer"),
                  methods=["POST", "GET"])(ner_inference)

        app.route(cfg["service"].get("url", "/rel_infer"),
                  methods=["POST", "GET"])(rel_inference)

        app.run(host="0.0.0.0", port=port, debug=False)
    else:
        global runner

        runner = InferRunner.from_cfg(cfg)

        app.route(cfg["service"].get("url", "/infer"),
                  methods=["POST", "GET"])(inference)
        app.run(host="0.0.0.0",
                port=int(cfg["service"].get("port", 18080)),
                debug=False)
