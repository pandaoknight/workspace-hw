import os
import json
import time
from flask import Flask, request, redirect, abort
from .utils import (
    wrap_jsonify,
    find_all_urls,
    update_status,
    start_server,
    stop_server,
)
from algicm.utils.logger import Logger


app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False


@app.route("/register", methods=["POST"])
def register():
    try:
        config = json.loads(str(request.data, "utf-8"))
        cfg_file = config.get("file")
        Logger.log_msg(f"start a server with config: {config}", level="INFO")
        return start_server(cfg_file, current_app=app)
    except Exception as e:
        Logger.log_msg(f"Unknown error with {str(e)}", level="ERROR")
        return wrap_jsonify(500, str(e))


@app.route("/unregister", methods=["POST"])
def unregister():
    try:
        config = json.loads(str(request.data, "utf-8"))
        Logger.log_msg(f"stop a server with config: {config}", level="INFO")
        return stop_server(config, current_app=app)
    except Exception as e:
        Logger.log_msg(f"Unknown error with {str(e)}", level="ERROR")
        return wrap_jsonify(500, str(e))


@app.route("/<path:url>", methods=["POST", "GET"])
def run(url):
    url = "/" + url
    routes = find_all_urls(app)
    Logger.log_msg(f"find valid url: {url}")
    Logger.log_msg(f"request route is:{routes}")
    if url not in routes:
        Logger.log_msg(f"{url} is not in valid url", level="WARNING")
        abort(404)
    try:
        if request.method == "GET":
            Logger.log_msg(f"{url} is in valid url")
        elif request.method != "POST":
            Logger.log_msg(f"{url} request method is {request.method}", level="WARNING")
            return wrap_jsonify(500, "Only support method POST or GET.")

        Logger.log_msg(f"url {url}, redirect to port {app.pid2port[app.name2pid[url]]}")
        return redirect(f"http://0.0.0.0:{app.pid2port[app.name2pid[url]]}{url}")

    except Exception as e:
        Logger.log_msg(f"Unknown error with {str(e)}", level="ERROR")
        return wrap_jsonify(500, f"Unknown error: {str(e)}.")


@app.route("/update", methods=["POST"])
def update():

    Logger.log_msg(f"Update server and url infos.")
    try:
        Logger.log_msg(
            f"Before infos: \n name2pid: {str(app.name2pid)} \n pid2port: {str(app.pid2port)} \n"
        )
        update_status(app)
        Logger.log_msg(
            f"Updated Infos: \n name2pid: {str(app.name2pid)} \n pid2port: {str(app.pid2port)} \n"
        )
        return wrap_jsonify(200, f"Success to update info.")
    except Exception as e:
        Logger.log_msg(f"Unknown error with {str(e)}", level="ERROR")
        return wrap_jsonify(500, f"Unknown error: {str(e)}.")



def run_controller(config):
    """To run a controller that is used to start or stop a server.

    Args:
        config (dict): config to start a server,  the following args optional to be passed.
        port (int|required):  server port
        work_dir (str|optional): used to store log file
        log_file (str|optional): log file used to record message, if not, random log file will be created.
    """

    work_dir = config.get("work_dir")
    log_file = config.get("log_file")

    if work_dir is None:
        work_dir = "./"
    os.makedirs(work_dir, exist_ok=True)
    if log_file is None:
        log_file = time.strftime("%Y%m%d_%H%M%S", time.localtime(time.time())) + ".log"
    # initialize logger
    logger = Logger.get_instance("Inference", log_file=os.path.join(work_dir, log_file))
    logger.log_msg(f"Start Inferent controller with config: {config}")
    port = config.get("port")
    if port is None:
        raise ValueError("port must be passed into config file")
    # create pid file for app
    app.PID_FILE = os.path.join(work_dir, ".pid")
    app.name2pid = {}
    app.pid2port = {}
    # update for abnormal case
    update_status(app)

    logger.log_msg(f"Update registered url: {str(app.name2pid.keys())}")
    # run server
    app.run(host="0.0.0.0", port=int(port), debug=False)
