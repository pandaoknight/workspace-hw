#!/usr/bin/env python
# -*- encoding: utf-8 -*-
#File    :   bussiness_logic.py
#Time    :   2023/07/27 11:23:26
#Author  :   Tianqi 

def format(output):
    pass
