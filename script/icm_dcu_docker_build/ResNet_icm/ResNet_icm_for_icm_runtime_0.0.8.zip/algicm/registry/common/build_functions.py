# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/29

import inspect
from ..registry import Registry


def build_from_cfg(cfg, registry, default_args=None):
    """Build a models from config dict.

    Args:
        cfg (dict): Config dict. It should at least contain the key "type".
        registry (:obj:`Registry`): The registry to search the type from.
        default_args (dict, optional): Default initialization arguments.

    Returns:
        object: The constructed object.
    """
    if not isinstance(cfg, dict):
        raise TypeError(f"cfg must be a dict, but got {type(cfg)}")
    if "type" not in cfg:
        if default_args is None or "type" not in default_args:
            raise KeyError(
                '`cfg` or `default_args` must contain the key "type", '
                f"but got {cfg}\n{default_args}")
    if not isinstance(registry, Registry):
        raise TypeError("registry must be an algicm.Registry object, "
                        f"but got {type(registry)}")
    if not (isinstance(default_args, dict) or default_args is None):
        raise TypeError("default_args must be a dict or None, "
                        f"but got {type(default_args)}")

    args = cfg.copy()

    if default_args is not None:
        for name, value in default_args.items():
            args.setdefault(name, value)

    obj_type = args.pop("type")
    if isinstance(obj_type, str):
        obj_cls = registry.get(obj_type)
        if obj_cls is None:
            raise KeyError(
                f"{obj_type} is not in the {registry.name} registry")
    elif inspect.isclass(obj_type):
        obj_cls = obj_type
    else:
        raise TypeError(
            f"type must be a str or valid type, but got {type(obj_type)}")
    try:
        return obj_cls(**args)
    except Exception as e:
        # Normal TypeError does not print class name.
        raise type(e)(f"{obj_cls.__name__}: {e}")


def build_dataset(cfg, default_args=None):
    """Build dataset

    Args:
        cfg (dict): cfg of dataset
        default_args (dict): default arguments pass to dataset
    """
    from .registry_type import DATASETS

    return build_from_cfg(cfg, DATASETS, default_args=default_args)


def build_data_sampler(cfg, default_args=None):
    """Build data sampler

    Args:
        cfg (dict): cfg of data samplers
        default_args (dict): default arguments pass to data samplers
    """
    from .registry_type import DATA_SAMPLERS

    return build_from_cfg(cfg, DATA_SAMPLERS, default_args=default_args)


def build_layer(cfg, default_args=None):
    from .registry_type import LAYERS

    return build_from_cfg(cfg, LAYERS, default_args=default_args)


def build_conv_layer(cfg, *args, **kwargs):
    """Build convolution layer.

    Args:
        cfg (None or dict): The conv layer config, which should contain:
            - type (str): Layer type.
            - layer args: Args needed to instantiate an conv layer.
        args (argument list): Arguments passed to the `__init__`
            method of the corresponding conv layer.
        kwargs (keyword arguments): Keyword arguments passed to the `__init__`
            method of the corresponding conv layer.

    Returns:
        nn.Module: Created conv layer.
    """
    from .registry_type import CONV_LAYERS

    if cfg is None:
        cfg_ = dict(type="Conv2d")
    else:
        if not isinstance(cfg, dict):
            raise TypeError("cfg must be a dict")
        if "type" not in cfg:
            raise KeyError('the cfg dict must contain the key "type"')
        cfg_ = cfg.copy()

    layer_type = cfg_.pop("type")
    if layer_type not in CONV_LAYERS:
        raise KeyError(f"Unrecognized layer type {layer_type}")
    else:
        conv_layer = CONV_LAYERS.get(layer_type)

    layer = conv_layer(*args, **kwargs, **cfg_)

    return layer


def build_norm_layer(cfg, num_features, postfix=""):
    """Build normalization layer.

    Args:
        cfg (dict): The norm layer config, which should contain:

            - type (str): Layer type.
            - layer args: Args needed to instantiate a norm layer.
            - requires_grad (bool, optional): Whether stop gradient updates.
        num_features (int): Number of input channels.
        postfix (int | str): The postfix to be appended into norm abbreviation
            to create named layer.

    Returns:
        tuple[str, nn.Module]: The first element is the layer name consisting
        of abbreviation and postfix, e.g., bn1, gn. The second element is the
        created norm layer.
    """
    from .registry_type import NORM_LAYERS
    from algicm.models.backend import utils

    if not isinstance(cfg, dict):
        raise TypeError("cfg must be a dict")
    if "type" not in cfg:
        raise KeyError('the cfg dict must contain the key "type"')
    cfg_ = cfg.copy()

    layer_type = cfg_.pop("type")
    if layer_type not in NORM_LAYERS:
        raise KeyError(f"Unrecognized norm type {layer_type}")

    norm_layer = NORM_LAYERS.get(layer_type)
    abbr = utils.infer_abbr(norm_layer)

    assert isinstance(postfix, (int, str))
    name = abbr + str(postfix)

    cfg_.setdefault("eps", 1e-5)
    if layer_type != "GN":
        layer = norm_layer(num_features, **cfg_)
        if layer_type == "SyncBN" and hasattr(layer, "_specify_ddp_gpu_num"):
            layer._specify_ddp_gpu_num(1)
    else:
        assert "num_groups" in cfg_
        layer = norm_layer(num_channels=num_features, **cfg_)

    return name, layer


def build_activation_layer(cfg, default_args=None):
    from .registry_type import ACTIVATION_LAYERS

    return build_from_cfg(cfg, ACTIVATION_LAYERS, default_args=default_args)


def build_padding_layer(cfg, default_args=None):
    from .registry_type import PADDING_LAYERS

    return build_from_cfg(cfg, PADDING_LAYERS, default_args=default_args)


def build_dropout_layer(cfg, *args, **kwargs):
    from .registry_type import DROPOUT_LAYERS

    if cfg is None:
        cfg_ = dict(type="Dropout")
    else:
        if not isinstance(cfg, dict):
            raise TypeError("cfg must be a dict")
        if "type" not in cfg:
            raise KeyError('the cfg dict must contain the key "type"')
        cfg_ = cfg.copy()

    layer_type = cfg_.pop("type")
    if layer_type not in DROPOUT_LAYERS:
        raise KeyError(f"Unrecognized layer type {layer_type}")
    else:
        dropout_layer = DROPOUT_LAYERS.get(layer_type)

    layer = dropout_layer(*args, **kwargs, **cfg_)

    return layer


def build_upsample_layer(cfg, *args, **kwargs):
    from .registry_type import UPSAMPLE_LAYERS

    cfg_ = cfg.copy()
    layer_type = cfg_.pop("type")
    if layer_type not in UPSAMPLE_LAYERS:
        raise KeyError(f"Unrecognized layer type {layer_type}")
    else:
        upsample_layer = UPSAMPLE_LAYERS.get(layer_type)
    layer = upsample_layer(*args, **kwargs, **cfg_)
    return layer


def build_assigner(cfg, **default_args):
    """Builder of box assigner."""
    from .registry_type import BBOX_ASSIGNERS
    return build_from_cfg(cfg, BBOX_ASSIGNERS, default_args)


def build_sampler(cfg, **default_args):
    """Builder of box sampler."""
    from .registry_type import BBOX_SAMPLERS
    return build_from_cfg(cfg, BBOX_SAMPLERS, default_args)


def build_bbox_coder(cfg, **default_args):
    """Builder of box coder."""
    from .registry_type import BBOX_CODERS
    return build_from_cfg(cfg, BBOX_CODERS, default_args)


def build_prior_generator(cfg, default_args=None):
    from .registry_type import PRIOR_GENERATORS
    return build_from_cfg(cfg, PRIOR_GENERATORS, default_args)


def build_iou_calculator(cfg, default_args=None):
    """Builder of IoU calculator."""
    from .registry_type import IOU_CALCULATORS
    return build_from_cfg(cfg, IOU_CALCULATORS, default_args)