# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/29

from ..registry import Registry

# Dataset pipelines -> algicm.datasets.backend
TRANSFORMS = Registry("data transforms")
DATASETS = Registry("datasets")
DATA_SAMPLERS = Registry("data sampler")

# evaluator -> algicm.engine.evaluator
EVALUATORS = Registry("evaluator")

# metrics -> algicm.engine.evaluator.metrics
METRICS = Registry("metrics")

# train,val, test loops -> algicm.engine.backend.runner
LOOPS = Registry("loops")
HOOKS = Registry("hooks")
PARAM_SCHEDULERS = Registry("param scheduler")

EVALUATOR = Registry("evaluator")
LOG_PROCESSORS = Registry("log processors")
RUNNERS = Registry("runners")

# for layers
LAYERS = Registry("Layer")
ACTIVATION_LAYERS = Registry("Activation layers")
CONV_LAYERS = Registry("Conv layers")
DROPOUT_LAYERS = Registry("Drop out layers")
LINNEAR_LAYERS = Registry("Linear layers")
NORM_LAYERS = Registry("Norm layers")
POOLING_LAYERS = Registry("Pooling layers")
PADDING_LAYERS = Registry("padding layers")
UPSAMPLE_LAYERS = Registry("Upsample layers")
LOSS_LAYERS = Registry("loss Layers")
TASK_UTILS = Registry("task utils ")
EMBEDDING_LAYERS = Registry("embeding layers")
MODELS = Registry("models")
DATA_STRUCTURE = Registry("data_structure")

WEIGHT_INITIALIZERS = Registry("weight initializer")

ALL_METHODS = Registry("build graph")
INFER_RUNNER = Registry("infer runner")

BBOX_ASSIGNERS = Registry('bbox_assigner')
BBOX_SAMPLERS = Registry('bbox_sampler')
BBOX_CODERS = Registry('bbox_coder')
PRIOR_GENERATORS = Registry('Generator for anchors and points')
IOU_CALCULATORS = Registry('IoU calculator')
ROI_EXTRACTORS = MODELS