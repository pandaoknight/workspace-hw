# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/29

from .registry import Registry
# from .common import build_from_cfg
from algicm.models.backend import BACKEND

if BACKEND == 'tensorflow':
    from .tensorflow import *
elif BACKEND == 'torch':
    from .pytorch import *
else:
    raise NotImplementedError("This backend is not supported")
