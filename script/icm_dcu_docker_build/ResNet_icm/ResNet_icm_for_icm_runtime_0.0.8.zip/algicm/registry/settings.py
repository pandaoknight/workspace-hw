# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/26

_IS_INITIALIZED = False
_FRAMEWORK_BACKEND = None
_SUPPORTED_BACKEND = ["pytorch", "tensorflow"]


def get_framework_backend():
    return _FRAMEWORK_BACKEND


def get_checkpoint_filename_postfix():
    if _FRAMEWORK_BACKEND == "pytorch":
        return ".pth"
    elif _FRAMEWORK_BACKEND == "tensorflow":
        return ".h5"
    raise TypeError(
        f"Support backend are {_SUPPORTED_BACKEND}, but got {_FRAMEWORK_BACKEND}"
    )


def is_env_initialized():
    return _IS_INITIALIZED


def set_framework_backend(name):
    global _FRAMEWORK_BACKEND, _IS_INITIALIZED
    if name not in _SUPPORTED_BACKEND:
        raise ValueError(
            f"Supported deep learning framework "
            f"are {_SUPPORTED_BACKEND}, but got {name}"
        )
    _FRAMEWORK_BACKEND = name
    _IS_INITIALIZED = True