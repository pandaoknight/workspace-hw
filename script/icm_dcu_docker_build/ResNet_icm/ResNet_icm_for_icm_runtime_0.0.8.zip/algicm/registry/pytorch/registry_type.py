#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   registry_type.py
@Time    :   2023/03/08 11:14:19
@Author  :   htx 
"""

from ..registry import Registry


OPTIMIZER = Registry("torch optimizers")
PARAM_SCHEDULERS = Registry("parameter schedulers")
TRANSFORMS = Registry("transform")
