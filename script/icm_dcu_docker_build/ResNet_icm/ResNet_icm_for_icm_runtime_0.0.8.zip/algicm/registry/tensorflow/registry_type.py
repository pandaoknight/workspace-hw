#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   registry_type.py
@Time    :   2023/03/09 18:24:44
@Author  :   htx 
"""


from ..registry import Registry


OPTIMIZER = Registry("optimizers")
PARAM_SCHEDULERS = Registry("param scheduler")

TRANSFORMS = Registry("transform")
