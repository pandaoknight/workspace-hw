#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   build_functions.py
@Time    :   2023/03/08 11:20:45
@Author  :   htx 
"""

import copy
from algicm.registry.common import build_from_cfg
import tensorflow as tf


def build_optimizer(cfg, model, default_args=None):
    from .registry_type import OPTIMIZER

    cfg_ = copy.deepcopy(cfg)
    model.set_train()
    cfg_.update(params=tf.nest.flatten(model.trainable_weights))
    return build_from_cfg(cfg_, OPTIMIZER, default_args=default_args)
