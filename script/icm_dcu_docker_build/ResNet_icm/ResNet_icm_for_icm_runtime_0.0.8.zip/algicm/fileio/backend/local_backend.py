# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/29

import os
import os.path as osp

from .base import BaseBackend


class LocalBackend(BaseBackend):
    '''Read Local system files

    '''

    def get(self, filepath):
        '''
        Args:
            filepath (str) file path

        Returns: value(bytes)
        '''
        with open(filepath, 'rb') as f:
            value = f.read()
        return value

    def get_text(self, filepath, encoding='utf-8'):
        ''' Read text from a given filepath

        Args:
            filepath (str): Path to read data.
            encoding (str): encoding format, default to utf-8

        Returns:
            value (str): encoding format strings.
        '''
        with open(filepath, encoding=encoding) as f:
            text = f.read()
        return text

    def put(self, obj, filepath):
        '''Write bytes to file
        Args:
            obj (bytes): Data to be written.
            filepath (str): Path to write data.

        Returns: None

        '''
        with open(filepath, 'wb') as f:
            f.write(obj)

    def put_text(self, obj, filepath, encoding='utf-8'):
        ''' Write text to file

        Args:
            obj (str): Data to be written.
            filepath (str): Path to write data.
            encoding (str): The encoding format used to open the ``filepath``.
                Defaults to 'utf-8'.

        Returns: None

        '''
        with open(filepath, 'w', encoding=encoding) as f:
            f.write(obj)