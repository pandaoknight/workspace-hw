# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/29

from abc import ABCMeta, abstractmethod

class BaseBackend(metaclass=ABCMeta):

    @abstractmethod
    def get(self, filepath):
        '''Implement method that read file to bytes
        '''
        pass

    @abstractmethod
    def get_text(self, filepath):
        '''Implement method that read file to text
        '''
        pass