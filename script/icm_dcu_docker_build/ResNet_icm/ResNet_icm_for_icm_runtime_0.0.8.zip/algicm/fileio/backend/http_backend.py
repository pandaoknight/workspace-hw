# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/11/29

from urllib.request import urlopen

from .base import BaseBackend


class HTTPBackend(BaseBackend):

    def get(self, filepath):
        return urlopen(filepath).read()

    def get_text(self, filepath, encoding='utf-8'):
        return urlopen(filepath).read().decode(encoding)
