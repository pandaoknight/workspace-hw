#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   yolov_head.py
@Time    :   2023/03/28 15:21:48
@Author  :   htx 
"""

import math
import warnings
from typing import List, Sequence
import copy
from algicm.models.backend.utils import float32, int32, float64
from ..task_utils.utils.misc import make_divisible
from algicm.models.backend import BaseModule, bias_init_with_prob, constant_init, normal_init
from algicm.models.backend.core import ModuleList
from algicm.models.layers import Conv2d
from algicm.models.backend import functional as F
from algicm.utils.logger import Logger
import numpy as np
from ..task_utils.utils.misc import (
    images_to_levels,
    multi_apply,
    filter_scores_and_topk,
)
from algicm.registry.common import MODELS, TASK_UTILS, LOSS_LAYERS
from ..task_utils.utils.nms import nms


@MODELS.register_module()
class YOLOv5HeadModule(BaseModule):
    """YOLOv5Head head module used in `YOLOv5`.

    Args:
        num_classes (int): Number of categories excluding the background
            category.
        in_channels (Union[int, Sequence]): Number of channels in the input
            feature map.
        widen_factor (float): Width multiplier, multiply number of
            channels in each layer by this amount. Defaults to 1.0.
        num_base_priors (int): The number of priors (points) at a point
            on the feature grid.
        featmap_strides (Sequence[int]): Downsample factor of each feature map.
             Defaults to (8, 16, 32).
        init_cfg (:obj:`ConfigDict` or list[:obj:`ConfigDict`] or dict or
            list[dict], optional): Initialization config dict.
            Defaults to None.
    """

    def __init__(
            self,
            num_classes,
            in_channels,
            widen_factor: float = 1.0,
            num_base_priors: int = 3,
            featmap_strides: Sequence[int] = (8, 16, 32),
            init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)
        self.num_classes = num_classes
        self.widen_factor = widen_factor

        self.featmap_strides = featmap_strides
        self.num_out_attrib = 5 + self.num_classes
        self.num_levels = len(self.featmap_strides)
        self.num_base_priors = num_base_priors

        if isinstance(in_channels, int):
            self.in_channels = [make_divisible(in_channels, widen_factor)
                                ] * self.num_levels
        else:
            self.in_channels = [
                make_divisible(i, widen_factor) for i in in_channels
            ]

        self._init_layers()

    def _init_layers(self):
        """initialize conv layers in YOLOv5 head."""
        self.convs_pred = ModuleList()
        for i in range(self.num_levels):
            conv_pred = Conv2d(self.in_channels[i],
                               self.num_base_priors * self.num_out_attrib, 1)

            self.convs_pred.append(conv_pred)

    # def init_weights(self):
    #     """Initialize the bias of YOLOv5 head."""
    #     super().init_weights()
    #     for mi, s in zip(self.convs_pred, self.featmap_strides):  # from
    #         b = mi.bias.data.view(self.num_base_priors, -1)
    #         # obj (8 objects per 640 image)
    #         b.data[:, 4] += math.log(8 / (640 / s) ** 2)
    #         b.data[:, 5:] += math.log(0.6 / (self.num_classes - 0.999999))

    #         mi.bias.data = b.view(-1)

    def forward(self, x):
        """Forward features from the upstream network.

        Args:
            x (Tuple[Tensor]): Features from the upstream network, each is
                a 4D-tensor.
        Returns:
            Tuple[List]: A tuple of multi-level classification scores, bbox
            predictions, and objectnesses.
        """
        assert len(x) == self.num_levels
        return multi_apply(self.forward_single, x, self.convs_pred)

    def forward_single(self, x, convs):
        """Forward feature of a single scale level."""

        pred_map = convs(x)
        bs, _, ny, nx = pred_map.shape
        pred_map = F.reshape(
            pred_map, (bs, self.num_base_priors, self.num_out_attrib, ny, nx))

        cls_score = F.reshape(pred_map[:, :, 5:, ...], (bs, -1, ny, nx))
        bbox_pred = F.reshape(pred_map[:, :, :4, ...], (bs, -1, ny, nx))
        objectness = F.reshape(pred_map[:, :, 4:5, ...], (bs, -1, ny, nx))

        return cls_score, bbox_pred, objectness


@MODELS.register_module()
class YOLOv5Head(BaseModule):
    """YOLOv5Head head used in `YOLOv5`.

    Args:
        head_module(ConfigType): Base module used for YOLOv5Head
        prior_generator(dict): Points generator feature maps in
            2D points-based detectors.
        bbox_coder (:obj:`ConfigDict` or dict): Config of bbox coder.
        loss_cls (:obj:`ConfigDict` or dict): Config of classification loss.
        loss_bbox (:obj:`ConfigDict` or dict): Config of localization loss.
        loss_obj (:obj:`ConfigDict` or dict): Config of objectness loss.
        prior_match_thr (float): Defaults to 4.0.
        ignore_iof_thr (float): Defaults to -1.0.
        obj_level_weights (List[float]): Defaults to [4.0, 1.0, 0.4].
        train_cfg (:obj:`ConfigDict` or dict, optional): Training config of
            anchor head. Defaults to None.
        test_cfg (:obj:`ConfigDict` or dict, optional): Testing config of
            anchor head. Defaults to None.
        init_cfg (:obj:`ConfigDict` or list[:obj:`ConfigDict`] or dict or
            list[dict], optional): Initialization config dict.
            Defaults to None.
    """

    def __init__(
        self,
        head_module,
        num_classes,
        prior_generator=dict(
            type="YOLOAnchorGenerator",
            base_sizes=[
                [(10, 13), (16, 30), (33, 23)],
                [(30, 61), (62, 45), (59, 119)],
                [(116, 90), (156, 198), (373, 326)],
            ],
            strides=[8, 16, 32],
        ),
        bbox_coder=dict(type="YOLOv5BBoxCoder"),
        loss_cls=dict(type="CrossEntropyLoss",
                      use_sigmoid=True,
                      reduction="mean",
                      loss_weight=0.5),
        loss_bbox=dict(
            type="IoULoss",
            iou_mode="ciou",
            bbox_format="xywh",
            eps=1e-7,
            reduction="mean",
            loss_weight=0.05,
            return_iou=True,
        ),
        loss_obj=dict(type="CrossEntropyLoss",
                      use_sigmoid=True,
                      reduction="mean",
                      loss_weight=1.0),
        prior_match_thr: float = 4.0,
        near_neighbor_thr: float = 0.5,
        ignore_iof_thr: float = -1.0,
        obj_level_weights: List[float] = [4.0, 1.0, 0.4],
        train_cfg=None,
        test_cfg=None,
        init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)
        head_module["num_classes"] = num_classes
        self.head_module = MODELS.build(head_module)
        self.num_classes = num_classes
        self.featmap_strides = self.head_module.featmap_strides
        self.num_levels = len(self.featmap_strides)

        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

        self.loss_cls = LOSS_LAYERS.build(loss_cls)
        self.loss_bbox = LOSS_LAYERS.build(loss_bbox)
        self.loss_obj = LOSS_LAYERS.build(loss_obj)

        self.prior_generator = TASK_UTILS.build(prior_generator)
        self.bbox_coder = TASK_UTILS.build(bbox_coder)
        self.num_base_priors = self.prior_generator.num_base_priors[0]

        self.featmap_sizes = [1] * self.num_levels

        self.prior_match_thr = prior_match_thr
        self.near_neighbor_thr = near_neighbor_thr
        self.obj_level_weights = obj_level_weights
        self.ignore_iof_thr = ignore_iof_thr

        self.special_init()

    def special_init(self):
        """Since YOLO series algorithms will inherit from YOLOv5Head, but
        different algorithms have special initialization process.

        The special_init function is designed to deal with this situation.
        """
        assert (len(self.obj_level_weights) == len(self.featmap_strides) ==
                self.num_levels)
        logger = Logger.get_current_instance()
        if self.prior_match_thr != 4.0:
            logger.warning(
                "!!!Now, you've changed the prior_match_thr "
                "parameter to something other than 4.0. Please make sure "
                "that you have modified both the regression formula in "
                "bbox_coder and before loss_box computation, "
                "otherwise the accuracy may be degraded!!!")

        if self.num_classes == 1:
            logger.warning(
                "!!!You are using `YOLOv5Head` with num_classes == 1."
                " The loss_cls will be 0. This is a normal phenomenon.")

        priors_base_sizes = F.convert_to_tensor(
            self.prior_generator.base_sizes, dtype=float32)
        featmap_strides = F.convert_to_tensor(self.featmap_strides,
                                              dtype=float32)[:, None, None]
        # self.register_buffer(
        #     "priors_base_sizes", priors_base_sizes / featmap_strides, persistent=False
        # )
        self.priors_base_sizes = F.Variable(priors_base_sizes /
                                            featmap_strides,
                                            "priors_base_sizes",
                                            trainable=False)
        grid_offset = F.convert_to_tensor(
            [
                [0, 0],  # center
                [1, 0],  # left
                [0, 1],  # up
                [-1, 0],  # right"""  """
                [0, -1],  # bottom
            ],
            dtype=float32)
        # self.register_buffer("grid_offset", grid_offset[:, None], persistent=False)
        self.grid_offset = F.Variable(grid_offset[:, None],
                                      "grid_offset",
                                      trainable=False)
        prior_inds = (F.reshape(
            F.arange(0, self.num_base_priors, dtype=float32),
            (self.num_base_priors, 1)))
        # self.register_buffer("prior_inds", prior_inds, persistent=False)
        self.prior_inds = F.Variable(prior_inds, "prior_inds", trainable=False)

    def forward(self, x):
        """Forward features from the upstream network.

        Args:
            x (Tuple[Tensor]): Features from the upstream network, each is
                a 4D-tensor.
        Returns:
            Tuple[List]: A tuple of multi-level classification scores, bbox
            predictions, and objectnesses.
        """
        return self.head_module(x)

    def predict_by_feat(self,
                        cls_scores,
                        bbox_preds,
                        objectnesses=None,
                        rescale=False,
                        with_nms=True,
                        data_meta=None):
        """Transform a batch of output features extracted by the head into
        bbox results.
        Args:
            cls_scores (list[Tensor]): Classification scores for all
                scale levels, each is a 4D-tensor, has shape
                (batch_size, num_priors * num_classes, H, W).
            bbox_preds (list[Tensor]): Box energies / deltas for all
                scale levels, each is a 4D-tensor, has shape
                (batch_size, num_priors * 4, H, W).
            objectnesses (list[Tensor], Optional): Score factor for
                all scale level, each is a 4D-tensor, has shape
                (batch_size, 1, H, W).
            rescale (bool): If True, return boxes in original image space.
                Defaults to False.
            with_nms (bool): If True, do nms before return boxes.
                Defaults to True.

        Returns:
            list[:obj:`InstanceData`]: Object detection results of each image
            after the post process. Each item usually contains following keys.

            - scores (Tensor): Classification scores, has a shape
              (num_instance, )
            - labels (Tensor): Labels of bboxes, has a shape
              (num_instances, ).
            - bboxes (Tensor): Has a shape (num_instances, 4),
              the last dimension 4 arrange as (x1, y1, x2, y2).
        """
        # np.random.seed(123)
        # cls_scores1 = np.random.randn(1, 3, 80, 80)
        # cls_scores2 = np.random.randn(1, 3, 40, 40)
        # cls_scores3 = np.random.randn(1, 3, 20, 20)
        # cls_scores1 = F.convert_to_tensor(cls_scores1, device="gpu")
        # cls_scores2 = F.convert_to_tensor(cls_scores2, device="gpu")
        # cls_scores3 = F.convert_to_tensor(cls_scores3, device="gpu")
        # cls_scores = [cls_scores1, cls_scores2, cls_scores3]

        # bbox_preds1 = np.random.randn(1, 12, 80, 80)
        # bbox_preds2 = np.random.randn(1, 12, 40, 40)
        # bbox_preds3 = np.random.randn(1, 12, 20, 20)
        # bbox_preds1 = F.convert_to_tensor(bbox_preds1, device="gpu")
        # bbox_preds2 = F.convert_to_tensor(bbox_preds2, device="gpu")
        # bbox_preds3 = F.convert_to_tensor(bbox_preds3, device="gpu")
        # bbox_preds = [bbox_preds1, bbox_preds2, bbox_preds3]

        # objectnesses1 = np.random.randn(1, 3, 80, 80)
        # objectnesses2 = np.random.randn(1, 3, 40, 40)
        # objectnesses3 = np.random.randn(1, 3, 20, 20)
        # objectnesses1 = F.convert_to_tensor(objectnesses1, device="gpu")
        # objectnesses2 = F.convert_to_tensor(objectnesses2, device="gpu")
        # objectnesses3 = F.convert_to_tensor(objectnesses3, device="gpu")
        # objectnesses = [objectnesses1, objectnesses2, objectnesses3]

        assert len(cls_scores) == len(bbox_preds)
        if objectnesses is None:
            with_objectnesses = False
        else:
            with_objectnesses = True
            assert len(cls_scores) == len(objectnesses)

        num_imgs = cls_scores[0].shape[0]
        featmap_sizes = [cls_score.shape[2:] for cls_score in cls_scores]

        # If the shape does not change, use the previous mlvl_priors
        if featmap_sizes != self.featmap_sizes:
            self.mlvl_priors = self.prior_generator.grid_priors(
                featmap_sizes, dtype=cls_scores[0].dtype, device="GPU")
            self.featmap_sizes = featmap_sizes
        flatten_priors = F.concat(self.mlvl_priors, axis=0)

        mlvl_strides = [
            F.new_full(flatten_priors,
                       (F.numel(featmap_size) * self.num_base_priors, ),
                       stride) for featmap_size, stride in zip(
                           featmap_sizes, self.featmap_strides)
        ]
        flatten_stride = F.concat(mlvl_strides, axis=0)

        # flatten cls_scores, bbox_preds and objectness
        flatten_cls_scores = [
            F.reshape(F.transpose(cls_score, (0, 2, 3, 1)),
                      (num_imgs, -1, self.num_classes))
            for cls_score in cls_scores
        ]
        flatten_bbox_preds = [
            F.reshape(F.transpose(bbox_pred, (0, 2, 3, 1)), (num_imgs, -1, 4))
            for bbox_pred in bbox_preds
        ]

        flatten_cls_scores = F.sigmoid(F.concat(flatten_cls_scores, axis=1))
        flatten_bbox_preds = F.concat(flatten_bbox_preds, axis=1)
        flatten_decoded_bboxes = self.bbox_coder.decode(
            flatten_priors[None], flatten_bbox_preds, flatten_stride)

        if with_objectnesses:
            flatten_objectness = [
                F.reshape(F.transpose(objectness, (0, 2, 3, 1)),
                          (num_imgs, -1)) for objectness in objectnesses
            ]
            flatten_objectness = F.sigmoid(F.concat(flatten_objectness,
                                                    axis=1))
        else:
            flatten_objectness = [None for _ in range(num_imgs)]

        results_list = []
        for (bboxes, scores, objectness) in zip(
                flatten_decoded_bboxes,
                flatten_cls_scores,
                flatten_objectness,
        ):

            score_thr = self.test_cfg.get("score_thr", -1)
            # yolox_style does not require the following operations
            if objectness is not None and score_thr > 0:
                conf_inds = objectness > score_thr
                bboxes = F.mask_select(bboxes, conf_inds)
                scores = F.mask_select(scores, conf_inds)
                objectness = F.mask_select(objectness, conf_inds)

            if objectness is not None:
                # conf = obj_conf * cls_conf
                scores *= objectness[:, None]

            if scores.shape[0] == 0:
                # empty_results.bboxes = bboxes
                # empty_results.scores = scores[:, 0]
                # empty_results.labels = scores[:, 0].int()
                bboxes = F.convert_to_numpy(bboxes)
                scores = F.convert_to_numpy(scores)
                results_dict = dict(bboxes=bboxes,
                                    scores=scores[:, 0],
                                    labels=scores[:, 0].astype(np.int32))
                results_list.append(results_dict)
                continue

            nms_pre = self.test_cfg.get("nms_pre", 100000)
            if self.test_cfg["multi_label"] is False:

                scores, labels = F.reduce_max(
                    scores, axis=1, keepdims=True), F.argmax(scores,
                                                             axis=1,
                                                             keepdim=True)
                scores, _, keep_idxs, results = filter_scores_and_topk(
                    scores,
                    score_thr,
                    nms_pre,
                    results=dict(labels=labels[:, 0]))
                labels = results["labels"]
            else:
                scores, labels, keep_idxs, _ = filter_scores_and_topk(
                    scores, score_thr, nms_pre)

            results = [F.gather(bboxes, keep_idxs), labels, scores]
            # pad_param = np.array([  0.,   0., 106., 106.])
            pad_param = None
            for i in data_meta["data_meta"][0]:
                if "classes" in i.keys():
                    classes = i["classes"]

                elif "records" in i.keys():
                    meta_records = i["records"]
            factor = meta_records["scale_factor"]
            self.scale_factor = np.array([factor[1], factor[0]])

            results = self._bbox_post_process(
                results=results,
                cfg=self.test_cfg,
                with_nms=with_nms,
                img_meta=None,
            )
            # results.bboxes[:, 0::2].clamp_(0, ori_shape[1])
            # results.bboxes[:, 1::2].clamp_(0, ori_shape[0])

            # results_dict = dict(bboxes = results[0],
            #                     scores = results[1],
            #                     labels = [classes[int(i)] for i in results[2]] )

            # warnings.warn("have some bug")
            rescale_bbox = copy.deepcopy(results[0])
            if rescale and len(rescale_bbox) > 0:
                if pad_param is not None:

                    results[0] -= F.convert_to_tensor([
                        pad_param[2], pad_param[0], pad_param[2], pad_param[0]
                    ],
                                                      dtype=float32)
                rescale_bbox = F.convert_to_tensor(
                    rescale_bbox, device=flatten_decoded_bboxes.device)
                rescale_bbox /= F.to_device(F.tile(
                    F.convert_to_tensor(self.scale_factor, dtype=float32), 2),
                                            device="GPU")
                rescale_bbox = F.convert_to_numpy(rescale_bbox)
            # else:
            #     rescale_bbox = None
            results_dict = dict(bboxes=results[0],
                                scores=results[1],
                                labels=results[2],
                                rescale_bboxes=rescale_bbox)
            results_list.append(results_dict)
        return results_list

    def compute_loss(
        self,
        cls_scores,
        bbox_preds,
        objectnesses,
        gt_bboxes,
        gt_labels,
        img_shape,
    ) -> dict:
        """Calculate the loss based on the features extracted by the detection
        head.

        Args:
            cls_scores (Sequence[Tensor]): Box scores for each scale level,
                each is a 4D-tensor, the channel number is
                num_priors * num_classes.
            bbox_preds (Sequence[Tensor]): Box energies / deltas for each scale
                level, each is a 4D-tensor, the channel number is
                num_priors * 4.
            objectnesses (Sequence[Tensor]): Score factor for
                all scale level, each is a 4D-tensor, has shape
                (batch_size, 1, H, W).
            batch_gt_instances (Sequence[InstanceData]): Batch of
                gt_instance. It usually includes ``bboxes`` and ``labels``
                attributes.
            batch_img_metas (Sequence[dict]): Meta information of each image,
                e.g., image size, scaling factor, etc.
            batch_gt_instances_ignore (list[:obj:`InstanceData`], optional):
                Batch of gt_instances_ignore. It includes ``bboxes`` attribute
                data that is ignored during training and testing.
                Defaults to None.
        Returns:
            dict[str, Tensor]: A dictionary of losses.
        """
        # if self.ignore_iof_thr != -1:
        #     # TODO: Support fast version
        #     # convert ignore gt
        #     batch_target_ignore_list = []
        #     for i, gt_instances_ignore in enumerate(batch_gt_instances_ignore):
        #         bboxes = gt_instances_ignore.bboxes
        #         labels = gt_instances_ignore.labels
        #         index = bboxes.new_full((len(bboxes), 1), i)
        #         # (batch_idx, label, bboxes)
        #         target = torch.cat((index, labels[:, None].float(), bboxes), dim=1)
        #         batch_target_ignore_list.append(target)

        #     # (num_bboxes, 6)
        #     batch_gt_targets_ignore = torch.cat(batch_target_ignore_list, dim=0)
        #     if batch_gt_targets_ignore.shape[0] != 0:
        #         # Consider regions with ignore in annotations
        #         return self._loss_by_feat_with_ignore(
        #             cls_scores,
        #             bbox_preds,
        #             objectnesses,
        #             batch_gt_instances=batch_gt_instances,
        #             batch_img_metas=batch_img_metas,
        #             batch_gt_instances_ignore=batch_gt_targets_ignore,
        # )

        # 1. Convert gt to norm format
        batch_targets_normed = self._convert_gt_to_norm_format(
            gt_bboxes, gt_labels, img_shape)
        #------------------- test---------------------------
        # np.random.seed(123)
        # cls_scores1 = np.random.randn(1, 240, 80, 80)
        # cls_scores2 = np.random.randn(1, 240, 40, 40)
        # cls_scores3 = np.random.randn(1, 240, 20, 20)
        # cls_scores1 = F.convert_to_tensor(cls_scores1, device="gpu")
        # cls_scores2 = F.convert_to_tensor(cls_scores2, device="gpu")
        # cls_scores3 = F.convert_to_tensor(cls_scores3, device="gpu")
        # cls_scores = [cls_scores1, cls_scores2, cls_scores3]

        # bbox_preds1 = np.random.randn(1, 12, 80, 80)
        # bbox_preds2 = np.random.randn(1, 12, 40, 40)
        # bbox_preds3 = np.random.randn(1, 12, 20, 20)
        # bbox_preds1 = F.convert_to_tensor(bbox_preds1, device="gpu")
        # bbox_preds2 = F.convert_to_tensor(bbox_preds2, device="gpu")
        # bbox_preds3 = F.convert_to_tensor(bbox_preds3, device="gpu")
        # bbox_preds = [bbox_preds1, bbox_preds2, bbox_preds3]

        # objectnesses1 = np.random.randn(1, 3, 80, 80)
        # objectnesses2 = np.random.randn(1, 3, 40, 40)
        # objectnesses3 = np.random.randn(1, 3, 20, 20)
        # objectnesses1 = F.convert_to_tensor(objectnesses1, device="gpu")
        # objectnesses2 = F.convert_to_tensor(objectnesses2, device="gpu")
        # objectnesses3 = F.convert_to_tensor(objectnesses3, device="gpu")
        # objectnesses = [objectnesses1, objectnesses2, objectnesses3]

        # batch_targets_normed = F.convert_to_tensor(np.array(
        #     [[[0., 9., 0.5109375, 0.78125, -0.1703125, -0.21875, 0.]],
        #      [[0., 9., 0.5109375, 0.78125, -0.1703125, -0.21875, 1.]],
        #      [[0., 9., 0.5109375, 0.78125, -0.1703125, -0.21875, 2.]]]),
        #                                            dtype=float32,
        #                                            device="gpu")
        #----------------------------- test ---------------------------------

        device = cls_scores[0].device
        loss_cls = F.zeros(1, device=device)
        loss_box = F.zeros(1, device=device)
        loss_obj = F.zeros(1, device=device)
        scaled_factor = F.ones(7, device=device)

        for i in range(self.num_levels):
            batch_size, _, h, w = bbox_preds[i].shape
            target_obj = F.zeros_like(objectnesses[i])

            # empty gt bboxes
            if batch_targets_normed.shape[1] == 0:
                loss_box += F.reduce_sum(bbox_preds[i]) * 0
                loss_cls += F.reduce_sum(cls_scores[i]) * 0
                loss_obj += (self.loss_obj(objectnesses[i], target_obj) *
                             self.obj_level_weights[i])
                continue

            priors_base_sizes_i = self.priors_base_sizes[i]
            # feature map scale whwh
            new_values = F.conver_dtype(
                F.gather(
                    F.convert_to_tensor(bbox_preds[i].shape,
                                        device=bbox_preds[i].device),
                    [3, 2, 3, 2]), float32)
            indices = [[2], [3], [4], [5]]
            scaled_factor = F.tensor_scatter_nd_update(scaled_factor, indices,
                                                       new_values)
            # Scale batch_targets from range 0-1 to range 0-features_maps size.
            # (num_base_priors, num_bboxes, 7)
            batch_targets_scaled = batch_targets_normed * scaled_factor

            # 2. Shape match
            wh_ratio = batch_targets_scaled[...,
                                            4:6] / priors_base_sizes_i[:, None]
            match_inds = (F.reduce_max(F.maximum(wh_ratio, 1 / wh_ratio), 2) <
                          self.prior_match_thr)
            batch_targets_scaled = F.mask_select(batch_targets_scaled,
                                                 match_inds)

            # no gt bbox matches anchor
            if batch_targets_scaled.shape[0] == 0:
                loss_box += F.reduce_sum(bbox_preds[i]) * 0
                loss_cls += F.reduce_sum(cls_scores[i]) * 0
                loss_obj += (self.loss_obj(objectnesses[i], target_obj) *
                             self.obj_level_weights[i])
                continue

            # 3. Positive samples with additional neighbors

            # check the left, up, right, bottom sides of the
            # targets grid, and determine whether assigned
            # them as positive samples as well.
            batch_targets_cxcy = batch_targets_scaled[:, 2:4]
            grid_xy = F.gather(scaled_factor, [2, 3]) - batch_targets_cxcy
            left, up = F.transpose(
                ((batch_targets_cxcy % 1 < self.near_neighbor_thr)
                 & (batch_targets_cxcy > 1)))
            right, bottom = F.transpose(
                ((grid_xy % 1 < self.near_neighbor_thr) & (grid_xy > 1)))
            offset_inds = F.stack((F.ones_like(left), left, up, right, bottom))

            batch_targets_scaled = F.reshape(
                F.tile(batch_targets_scaled, (5, 1)), [
                    5, batch_targets_scaled.shape[0],
                    batch_targets_scaled.shape[1]
                ])
            batch_targets_scaled = F.mask_select(batch_targets_scaled,
                                                 offset_inds)
            retained_offsets = F.mask_select(
                F.tile(self.grid_offset, (1, offset_inds.shape[1], 1)),
                offset_inds)

            # prepare pred results and positive sample indexes to
            # calculate class loss and bbox lo
            _chunk_targets = F.split(batch_targets_scaled, [2, 2, 2, 1], 1)
            img_class_inds, grid_xy, grid_wh, priors_inds = _chunk_targets
            priors_inds, (img_inds, class_inds) = (
                F.reshape(F.conver_dtype(priors_inds, dtype=int32), -1),
                F.transpose(F.conver_dtype(img_class_inds, dtype=int32)),
            )

            grid_xy_long = F.conver_dtype(
                (grid_xy - retained_offsets * self.near_neighbor_thr),
                dtype=int32)
            grid_x_inds, grid_y_inds = F.transpose(grid_xy_long)
            grid_xy_long = F.conver_dtype(grid_xy_long, float32)
            bboxes_targets = F.concat((grid_xy - grid_xy_long, grid_wh), 1)
            grid_xy_long = F.conver_dtype(grid_xy_long, dtype=int32)

            # 4. Calculate loss
            # bbox loss

            retained_bbox_pred = F.reshape(
                bbox_preds[i], (batch_size, self.num_base_priors, -1, h, w))

            index = F.convert_to_tensor(
                np.array([
                    F.convert_to_numpy(img_inds),
                    F.convert_to_numpy(priors_inds),
                    F.convert_to_numpy(grid_y_inds),
                    F.convert_to_numpy(grid_x_inds)
                ]).T)
            range_index = F.arange(0, 4)
            slice_index = F.expand_dims(F.reshape(
                F.repeat(range_index, img_inds.shape[0]),
                (4, img_inds.shape[0])),
                                        axis=-1)
            slice_index = F.cast(slice_index, dtype=int32)
            index2 = F.repeat(F.expand_dims(index, 0), 4, axis=0)
            ind = F.concat([index2[:, :, :2], slice_index, index2[:, :, 2:]],
                           axis=-1)
            ind = F.convert_to_tensor(ind, device=img_inds.device)
            retained_bbox_pred = F.transpose(
                F.gather_nd(retained_bbox_pred, indices=ind))

            priors_base_sizes_i = F.gather(priors_base_sizes_i, (priors_inds))
            decoded_bbox_pred = self._decode_bbox_to_xywh(
                retained_bbox_pred, priors_base_sizes_i)
            # bboxes_targets = F.cover_dtype(bboxes_targets,float64)
            loss_box_i, iou = self.loss_bbox(decoded_bbox_pred, bboxes_targets)
            loss_box_i = F.conver_dtype(loss_box_i, float32)
            loss_box += loss_box_i

            # obj loss
            iou = F.clip_by_value(F.detach(iou), 0, 9999)

            index_ = F.stack([img_inds, priors_inds, grid_y_inds, grid_x_inds],
                             axis=1)
            iou = F.conver_dtype(iou, target_obj.dtype)
            target_obj = F.tensor_scatter_nd_update(target_obj, index_, iou)

            tmp_ = F.conver_dtype(
                self.loss_obj(objectnesses[i], target_obj) *
                self.obj_level_weights[i], loss_obj.dtype)
            loss_obj += tmp_

            # cls loss
            if self.num_classes > 1:
                pred_cls_scores = F.reshape(
                    cls_scores[i],
                    (batch_size, self.num_base_priors, -1, h, w))

                index = F.convert_to_tensor(
                    np.array([
                        F.convert_to_numpy(img_inds),
                        F.convert_to_numpy(priors_inds),
                        F.convert_to_numpy(grid_y_inds),
                        F.convert_to_numpy(grid_x_inds)
                    ]).T)
                range_index = F.arange(0, self.num_classes)
                slice_index = F.expand_dims(F.reshape(
                    F.repeat(range_index, img_inds.shape[0]),
                    (self.num_classes, img_inds.shape[0])),
                                            axis=-1)
                slice_index = F.cast(slice_index, dtype=int32)
                index2 = F.repeat(F.expand_dims(index, 0),
                                  self.num_classes,
                                  axis=0)
                ind = F.concat(
                    [index2[:, :, :2], slice_index, index2[:, :, 2:]], axis=-1)
                pred_cls_scores = F.transpose(
                    F.gather_nd(pred_cls_scores, indices=ind))

                target_class = F.new_full(pred_cls_scores,
                                          pred_cls_scores.shape, 0.0)
                inedx_target = F.stack([
                    F.arange(batch_targets_scaled.shape[0],
                             device=batch_targets_scaled.device), class_inds
                ],
                                       axis=1)
                target_class = F.tensor_scatter_nd_update(
                    target_class,
                    inedx_target,
                    F.ones(class_inds.shape, device=class_inds.device),
                    cls_loss=True)

                # pred_cls_scores = F.cover_dtype(pred_cls_scores,float32)
                loss_cls += self.loss_cls(pred_cls_scores, target_class)
            else:
                loss_cls += F.reduce_sum(cls_scores[i]) * 0

        return dict(loss_cls=loss_cls, loss_obj=loss_obj, loss_bbox=loss_box)

    def _convert_gt_to_norm_format(
        self,
        gt_bboxes,
        gt_labels,
        img_shape,
    ):

        batch_target_list = []
        for i in range(len(gt_labels)):
            bboxes = gt_bboxes[i]
            bboxes = F.convert_to_tensor(F.convert_to_numpy(bboxes),
                                         device=bboxes.device)
            labels = gt_labels[i]

            xy1, xy2 = F.split(bboxes, (2, 2), axis=-1)
            bboxes = F.conver_dtype(
                F.concat([(xy2 + xy1) / 2, (xy2 - xy1)], axis=-1), float32)

            indices = [[i, j] for i in range(bboxes.shape[0]) for j in (1, 3)]
            new_values = F.reshape((bboxes[:, 1::2] / img_shape[0]), -1)
            bboxes = F.tensor_scatter_nd_update(bboxes, indices, new_values)
            indices = [[i, j] for i in range(bboxes.shape[0]) for j in (0, 2)]
            new_values = F.reshape((bboxes[:, 0::2] / img_shape[1]), -1)
            bboxes = F.tensor_scatter_nd_update(bboxes, indices, new_values)

            index = F.conver_dtype(F.new_full(bboxes, (len(bboxes), 1), i),
                                   dtype=float32)
            # (batch_idx, label, normed_bbox)
            target = F.concat(
                (index, F.conver_dtype(labels[:, None], dtype=float32),
                 F.conver_dtype(bboxes, float32)),
                axis=1)
            batch_target_list.append(target)

        concat_ = F.concat(batch_target_list, axis=0)
        # (num_base_priors, num_bboxes, 6)
        batch_targets_normed = F.reshape(
            F.tile(concat_, (self.num_base_priors, 1)),
            [self.num_base_priors, concat_.shape[0], concat_.shape[1]])

        # (num_base_priors, num_bboxes, 1)
        batch_targets_prior_inds = F.tile(
            self.prior_inds, (1, batch_targets_normed.shape[1]))[..., None]
        # (num_base_priors, num_bboxes, 7)
        # (img_ind, labels, bbox_cx, bbox_cy, bbox_w, bbox_h, prior_ind)
        batch_targets_normed = F.concat(
            (batch_targets_normed, batch_targets_prior_inds), 2)
        return batch_targets_normed

    def _decode_bbox_to_xywh(self, bbox_pred, priors_base_sizes):
        # priors_base_sizes = F.cover_dtype(priors_base_sizes,float64)
        bbox_pred = F.sigmoid(bbox_pred)
        pred_xy = bbox_pred[:, :2] * 2 - 0.5
        pred_wh = (bbox_pred[:, 2:] * 2)**2 * priors_base_sizes
        decoded_bbox_pred = F.concat((pred_xy, pred_wh), axis=-1)
        return decoded_bbox_pred

    def _bbox_post_process(
        self,
        results,
        cfg,
        with_nms: bool = True,
        img_meta=None,
    ):
        """bbox post-processing method.

        The boxes would be rescaled to the original image scale and do
        the nms operation. Usually `with_nms` is False is used for aug test.

        Args:
            results (:obj:`InstaceData`): Detection instance results,
                each item has shape (num_bboxes, ).
            cfg (ConfigDict): Test / postprocessing configuration,
                if None, test_cfg would be used.
            with_nms (bool): If True, do nms before return boxes.
                Default to True.
            img_meta (dict, optional): Image meta info. Defaults to None.

        Returns:
            :obj:`InstanceData`: Detection results of each image
            after the post process.
            Each item usually contains following keys.

                - scores (Tensor): Classification scores, has a shape
                  (num_instance, )
                - labels (Tensor): Labels of bboxes, has a shape
                  (num_instances, ).
                - bboxes (Tensor): Has a shape (num_instances, 4),
                  the last dimension 4 arrange as (x1, y1, x2, y2).
        """
        # if rescale:
        #     # assert img_meta.get("scale_factor") is not None
        #     # scale_factor = [1 / s for s in img_meta["scale_factor"]]
        #     # results.bboxes = scale_boxes(results.bboxes, scale_factor)
        #     pass

        if hasattr(results, "score_factors"):
            # TODO： Add sqrt operation in order to be consistent with
            #  the paper.
            score_factors = results.pop("score_factors")
            results.scores = results.scores * score_factors

        # filter small size bboxes
        if cfg.get("min_bbox_size", -1) >= 0:
            # w, h = get_box_wh(results.bboxes)
            # valid_mask = (w > cfg.min_bbox_size) & (h > cfg.min_bbox_size)
            # if not valid_mask.all():
            #     results = results[valid_mask]
            pass

        # TODO: deal with `with_nms` and `nms_cfg=None` in test_cfg
        if with_nms and F.numel(results[0]) > 0:
            # bboxes = get_box_tensor(results.bboxes)
            concat_input = F.concat([
                results[0], results[2][:, None],
                F.conver_dtype(results[1], float32)[:, None]
            ],
                                    axis=-1)
            concat_input = F.convert_to_numpy(concat_input)
            results = nms(concat_input, "iou", cfg["nms"])

            # some nms would reweight the score, such as softnms
            # results.scores = det_bboxes[:, -1]
            # results = results[: cfg.max_per_img]
        else:
            results = [
                F.convert_to_numpy(results[0]),
                F.convert_to_numpy(results[2]),
                F.convert_to_numpy(results[1])
            ]
        return results
