#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   crf_head.py
@Time    :   2023/08/23 14:51:06
@Author  :   htx 
"""


from algicm.models.backend.core import BaseModule
from algicm.registry.common import MODELS, LAYERS
from algicm.models.layers.linear import Linear
from algicm.models.modules.module_utils import CRFModule


@MODELS.register_module()
class CRFHead(BaseModule):
    """Linear classifier head.

    Args:
        num_classes (int): Number of categories excluding the background
            category.
        in_channels (int): Number of channels in the input feature map.
        loss (dict): Config of classification loss. Defaults to
            ``dict(type='CrossEntropyLoss', loss_weight=1.0)``.
        topk (int | Tuple[int]): Top-k accuracy. Defaults to ``(1, )``.
        cal_acc (bool): Whether to calculate accuracy during training.
            If you use batch augmentations like Mixup and CutMix during
            training, it is pointless to calculate accuracy.
            Defaults to False.
        init_cfg (dict, optional): the config to control the initialization.
            Defaults to ``dict(type='Normal', layer='Linear', std=0.01)``.
    """

    def __init__(
        self,
        num_classes,
        in_channels,
        loss: dict = dict(type="ReductionLoss", loss_weight=1.0),
        init_cfg=dict(type="Normal", layer="Linear", std=0.01),
        **kwargs,
    ):
        super(CRFHead, self).__init__(init_cfg=init_cfg, **kwargs)

        self.in_channels = in_channels
        self.num_classes = num_classes
        self.crf = CRFModule(self.num_classes, batch_first=True)  # 创建crfceng
        self.loss_module = LAYERS.build(loss)
        # self.crf=LAYERS.build(loss)#crf
        if self.num_classes <= 0:
            raise ValueError(f"num_classes={num_classes} must be a positive integer")

        self.fc = Linear(self.in_channels, self.num_classes)

    def forward(self, feats):
        """The forward process."""
        # The final classification head.
        cls_score = self.fc(feats)
        return cls_score

    def compute_loss(self, numerator, denominator):
        """Unpack data samples and compute loss."""
        # compute loss
        losses = dict()
        loss = self.loss_module(denominator, numerator)  # For negative sign
        losses["loss"] = loss
        return losses

    def encode(self, cls_score, labels, mask):
        return self.crf.encode(cls_score, labels, mask=mask)

    def decode(self, feats, mask=None):
        return self.crf(feats, mask)
