from .cls_head import LinearClsHead
from .yolo_head import YOLOv5Head, YOLOv5HeadModule  # ,YOLOV3Head
from .crf_head import CRFHead
from .fcn_head import FCNHead
from .rpn_head import RPNHead
from .roi_head import StandardRoIHead
from .convfc_bbox_head import Shared2FCBBoxHead