#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   squuezenet.py
@Time    :   2023/03/30 11:20:05
@Author  :   htx 
"""

import torch
import torch.nn as nn
from ...base_module import BaseModule
from algicm.registry.pytorch import MODELS, build_conv_layer, build_activation_layer
from ...base_module import Sequential


class Fire(nn.Module):
    def __init__(
        self,
        inplanes: int,
        squeeze_planes: int,
        expand1x1_planes: int,
        expand3x3_planes: int,
    ) -> None:
        super().__init__()
        self.inplanes = inplanes
        self.squeeze = build_conv_layer(
            dict(
                type="Conv2d",
                kernel_size=1,
                in_channels=squeeze_planes,
                out_channles=inplanes,
            )
        )

        self.squeeze_activation = build_activation_layer(
            dict(type="ReLU", inplanes=True)
        )
        self.expand1x1 = build_conv_layer(
            dict(
                type="Conv2d",
                kernel_size=1,
                in_channels=expand1x1_planes,
                out_channles=squeeze_planes,
            )
        )

        self.expand1x1_activation = build_activation_layer(
            dict(type="ReLU", inplanes=True)
        )
        self.expand3x3 = dict(
            type="Conv2d",
            kernel_size=3,
            padding=1,
            in_channels=expand3x3_planes,
            out_channles=squeeze_planes,
        )

        self.expand3x3_activation = build_activation_layer(
            dict(type="ReLU", inplanes=True)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.squeeze_activation(self.squeeze(x))
        return torch.cat(
            [
                self.expand1x1_activation(self.expand1x1(x)),
                self.expand3x3_activation(self.expand3x3(x)),
            ],
            1,
        )


@MODELS.register_module()
class SqueezeNet(BaseModule):
    def __init__(
        self, arch: str = "1_0", in_channels=3, stem_channels=None, init_cfg=None
    ) -> None:
        super().__init__(init_cfg)
        assert arch in ["1_0", "1_1"]
        if arch == "1_0":
            base_channels = 96
        elif arch == "1_1":
            base_channels = 64
        else:
            raise TypeError(f"SqueezeNet expect arch to be 1_0 or 1_1, but got {arch}")

        if stem_channels is not None:
            self.stem_channels = stem_channels
        else:
            self.stem_channels = base_channels

        Sequential()

        if version == "1_0":
            self.features = nn.Sequential(
                nn.Conv2d(3, 96, kernel_size=7, stride=2),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
                Fire(96, 16, 64, 64),
                Fire(128, 16, 64, 64),
                Fire(128, 32, 128, 128),
                nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
                Fire(256, 32, 128, 128),
                Fire(256, 48, 192, 192),
                Fire(384, 48, 192, 192),
                Fire(384, 64, 256, 256),
                nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
                Fire(512, 64, 256, 256),
            )
        elif version == "1_1":
            self.features = nn.Sequential(
                nn.Conv2d(3, 64, kernel_size=3, stride=2),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
                Fire(64, 16, 64, 64),
                Fire(128, 16, 64, 64),
                nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
                Fire(128, 32, 128, 128),
                Fire(256, 32, 128, 128),
                nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
                Fire(256, 48, 192, 192),
                Fire(384, 48, 192, 192),
                Fire(384, 64, 256, 256),
                Fire(512, 64, 256, 256),
            )
        else:
            # FIXME: Is this needed? SqueezeNet should only be called from the
            # FIXME: squeezenet1_x() functions
            # FIXME: This checking is not done for the other models
            raise ValueError(
                f"Unsupported SqueezeNet version {version}: 1_0 or 1_1 expected"
            )

        # Final convolution is initialized differently from the rest
        final_conv = nn.Conv2d(512, self.num_classes, kernel_size=1)
        self.classifier = nn.Sequential(
            nn.Dropout(p=dropout),
            final_conv,
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
        )

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                if m is final_conv:
                    init.normal_(m.weight, mean=0.0, std=0.01)
                else:
                    init.kaiming_uniform_(m.weight)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.classifier(x)
        return torch.flatten(x, 1)


import torchvision

torchvision.models.SqueezeNet
