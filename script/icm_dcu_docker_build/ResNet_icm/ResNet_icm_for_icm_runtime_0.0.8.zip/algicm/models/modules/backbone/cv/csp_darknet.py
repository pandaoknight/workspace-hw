#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   darknet.py
@Time    :   2023/03/28 11:26:11
@Author  :   htx 
"""
from ...module_utils import (
    ConvModule,
    CSPLayer,
    SPPFBottleneck,
)
from algicm.models.backend.core import BaseModule
from ...task_utils.utils.misc import make_divisible, make_round

# from torch.nn.modules.batchnorm import _BatchNorm
from algicm.registry.common import MODELS
from algicm.models.backend import core
from algicm.models.backend import functional as F


class Focus(BaseModule):
    """Focus width and height information into channel space.

    Args:
        in_channels (int): The input channels of this Module.
        out_channels (int): The output channels of this Module.
        kernel_size (int): The kernel size of the convolution. Default: 1
        stride (int): The stride of the convolution. Default: 1
        conv_cfg (dict): Config dict for convolution layer. Default: None,
            which means using conv2d.
        norm_cfg (dict): Config dict for normalization layer.
            Default: dict(type='BN2d', momentum=0.03, eps=0.001).
        act_cfg (dict): Config dict for activation layer.
            Default: dict(type='Swish').
    """

    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size=1,
            stride=1,
            conv_cfg=None,
            norm_cfg=dict(type="BN2d", momentum=0.03, eps=0.001),
            act_cfg=dict(type="Swish"),
    ):
        super().__init__()
        self.conv = ConvModule(
            in_channels * 4,
            out_channels,
            kernel_size,
            stride,
            padding=(kernel_size - 1) // 2,
            conv_cfg=conv_cfg,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
        )

    def forward(self, x):
        # shape of x (b,c,w,h) -> y(b,4c,w/2,h/2)
        patch_top_left = x[..., ::2, ::2]
        patch_top_right = x[..., ::2, 1::2]
        patch_bot_left = x[..., 1::2, ::2]
        patch_bot_right = x[..., 1::2, 1::2]
        x = F.concat(
            (
                patch_top_left,
                patch_bot_left,
                patch_top_right,
                patch_bot_right,
            ),
            axis=1,
        )
        return self.conv(x)


@MODELS.register_module()
class YOLOv5CSPDarknet(BaseModule):
    """CSP-Darknet backbone used in YOLOv5.
    Args:
        arch (str): Architecture of CSP-Darknet, from {P5, P6}.
            Defaults to P5.
        plugins (list[dict]): List of plugins for stages, each dict contains:
            - cfg (dict, required): Cfg dict to build plugin.
            - stages (tuple[bool], optional): Stages to apply plugin, length
              should be same as 'num_stages'.
        deepen_factor (float): Depth multiplier, multiply number of
            blocks in CSP layer by this amount. Defaults to 1.0.
        widen_factor (float): Width multiplier, multiply number of
            channels in each layer by this amount. Defaults to 1.0.
        input_channels (int): Number of input image channels. Defaults to: 3.
        out_indices (Tuple[int]): Output from which stages.
            Defaults to (2, 3, 4).
        frozen_stages (int): Stages to be frozen (stop grad and set eval
            mode). -1 means not freezing any parameters. Defaults to -1.
        norm_cfg (dict): Dictionary to construct and config norm layer.
            Defaults to dict(type='2', requires_grad=True).
        act_cfg (dict): Config dict for activation layer.
            Defaults to dict(type='SiLU', inplace=True).
        norm_eval (bool): Whether to set norm layers to eval mode, namely,
            freeze running stats (mean and var). Note: Effect on Batch Norm
            and its variants only. Defaults to False.
        init_cfg (Union[dict,list[dict]], optional): Initialization config
            dict. Defaults to None.
    Example:
        >>> from mmyolo.models import YOLOv5CSPDarknet
        >>> import torch
        >>> model = YOLOv5CSPDarknet()
        >>> model.eval()
        >>> inputs = torch.rand(1, 3, 416, 416)
        >>> level_outputs = model(inputs)
        >>> for level_out in level_outputs:
        ...     print(tuple(level_out.shape))
        ...
        (1, 256, 52, 52)
        (1, 512, 26, 26)
        (1, 1024, 13, 13)
    """

    # From left to right:
    # in_channels, out_channels, num_blocks, add_identity, use_spp
    arch_settings = {
        "P5": [
            [64, 128, 3, True, False],
            [128, 256, 6, True, False],
            [256, 512, 9, True, False],
            [512, 1024, 3, True, True],
        ],
        "P6": [
            [64, 128, 3, True, False],
            [128, 256, 6, True, False],
            [256, 512, 9, True, False],
            [512, 768, 3, True, False],
            [768, 1024, 3, True, True],
        ],
    }

    def __init__(
            self,
            arch: str = "P5",
            plugins=None,
            deepen_factor: float = 1.0,
            widen_factor: float = 1.0,
            input_channels: int = 3,
            out_indices=(2, 3, 4),
            frozen_stages: int = -1,
            norm_cfg=dict(type="BN2d", momentum=0.03, eps=0.001),
            act_cfg=dict(type="SiLU"),
            norm_eval: bool = False,
            init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)
        arch_setting = self.arch_settings[arch]
        self.num_stages = len(arch_setting)
        self.arch_setting = arch_setting

        assert set(out_indices).issubset(i
                                         for i in range(len(arch_setting) + 1))

        if frozen_stages not in range(-1, len(arch_setting) + 1):
            raise ValueError('"frozen_stages" must be in range(-1, '
                             "len(arch_setting) + 1). But received "
                             f"{frozen_stages}")

        self.input_channels = input_channels
        self.out_indices = out_indices
        self.frozen_stages = frozen_stages
        self.widen_factor = widen_factor
        self.deepen_factor = deepen_factor
        self.norm_eval = norm_eval
        self.norm_cfg = norm_cfg
        self.act_cfg = act_cfg
        self.plugins = plugins

        self.stem = self.build_stem_layer()
        self.layers = ["stem"]

        for idx, setting in enumerate(arch_setting):
            stage = []
            stage += self.build_stage_layer(idx, setting)
            self.add_module(f"stage{idx + 1}", core.Sequential(*stage))
            self.layers.append(f"stage{idx + 1}")

    def build_stem_layer(self):
        """Build a stem layer."""
        return ConvModule(
            self.input_channels,
            make_divisible(self.arch_setting[0][0], self.widen_factor),
            kernel_size=6,
            stride=2,
            padding=2,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg,
        )

    def build_stage_layer(self, stage_idx: int, setting: list) -> list:
        """Build a stage layer.

        Args:
            stage_idx (int): The index of a stage layer.
            setting (list): The architecture setting of a stage layer.
        """
        in_channels, out_channels, num_blocks, add_identity, use_spp = setting

        in_channels = make_divisible(in_channels, self.widen_factor)
        out_channels = make_divisible(out_channels, self.widen_factor)
        num_blocks = make_round(num_blocks, self.deepen_factor)
        stage = []
        conv_layer = ConvModule(
            in_channels,
            out_channels,
            kernel_size=3,
            stride=2,
            padding=1,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg,
        )
        stage.append(conv_layer)
        csp_layer = CSPLayer(
            out_channels,
            out_channels,
            num_blocks=num_blocks,
            add_identity=add_identity,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg,
        )
        stage.append(csp_layer)
        if use_spp:
            spp = SPPFBottleneck(
                out_channels,
                out_channels,
                kernel_sizes=5,
                norm_cfg=self.norm_cfg,
                act_cfg=self.act_cfg,
            )
            stage.append(spp)
        return stage

    # def train(self, mode: bool = True):
    #     """Convert the model into training mode while keep normalization layer
    #     frozen."""
    #     super().train(mode)
    #     self._freeze_stages()
    #     if mode and self.norm_eval:
    #         for m in self.modules():
    #             if isinstance(m, _BatchNorm):
    #                 m.eval()
    # def set_train(self, mode=True):
    #     if not isinstance(mode, bool):
    #         raise ValueError("training mode is expected to be boolean")
    #     # self.is_train = mode
    #     # self.trainable = mode
    #     self.training = mode
    #     for module in self.children():
    #         if hasattr(module, "set_train"):
    #             module.set_train(mode)
    #         else:
    #             module.train(mode)

    #     return self

    def forward(self, x) -> tuple:
        """Forward batch_inputs from the data_preprocessor."""
        outs = []
        for i, layer_name in enumerate(self.layers):
            layer = getattr(self, layer_name)
            x = layer(x)
            if i in self.out_indices:
                outs.append(x)

        return tuple(outs)

    def freeze_stages(self):
        """Freeze the parameters of the specified stage so that they are no
        longer updated."""
        if self.frozen_stages >= 0:
            for i in range(self.frozen_stages + 1):
                m = getattr(self, self.layers[i])
                m.set_eval()
                # F.freeze_stages(m)

    def set_train(self, mode=True):
        super().set_train(mode=mode)
        self.freeze_stages()

    # def init_weights(self):
    #     """Initialize the parameters."""
    #     if self.init_cfg is None:
    #         for m in self.modules():
    #             if isinstance(m, torch.nn.Conv2d):
    #                 # In order to be consistent with the source code,
    #                 # reset the Conv2d initialization parameters
    #                 m.reset_parameters()
    #     else:
    #         super().init_weights()
