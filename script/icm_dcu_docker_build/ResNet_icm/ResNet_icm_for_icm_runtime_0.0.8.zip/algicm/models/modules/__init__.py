#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   __init__.py
@Time    :   2023/03/08 12:05:33
@Author  :   htx 
"""

from .backbone.cv import ResNet  # , Darknet, YOLOv5CSPDarknet

from .neck import GlobalAveragePooling, BertNeck, YOLOv5PAFPN, FPN  # ,YOLOV3Neck, YOLOv5PAFPN,
from .head import LinearClsHead, FCNHead, CRFHead  # ,YOLOv5Head,YOLOv5HeadModule #,YOLOV3Head
