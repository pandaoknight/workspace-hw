#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   random_sampler.py
@Time    :   2023/03/28 16:48:42
@Author  :   htx 
"""

from ..box_assigners import AssignResult
from .sampling_results import SamplingResult
from algicm.registry.common import BBOX_SAMPLERS
from algicm.models.backend.utils import uint8, Tensor, int64
from .base_sampler import BaseSampler
import algicm.models.backend.functional as F


@BBOX_SAMPLERS.register_module()
class RandomSampler(BaseSampler):
    """Random sampler.

    Args:
        num (int): Number of samples
        pos_fraction (float): Fraction of positive samples
        neg_pos_up (int, optional): Upper bound number of negative and
            positive samples. Defaults to -1.
        add_gt_as_proposals (bool, optional): Whether to add ground truth
            boxes as proposals. Defaults to True.
    """

    def __init__(self,
                 num,
                 pos_fraction,
                 neg_pos_ub=-1,
                 add_gt_as_proposals=True,
                 **kwargs):
        from .sampling_results import ensure_rng
        super(RandomSampler, self).__init__(num, pos_fraction, neg_pos_ub,
                                            add_gt_as_proposals)
        self.rng = ensure_rng(kwargs.get('rng', None))

    def random_choice(self, gallery, num):
        """Random select some elements from the gallery.

        If `gallery` is a Tensor, the returned indices will be a Tensor;
        If `gallery` is a ndarray or list, the returned indices will be a
        ndarray.

        Args:
            gallery (Tensor | ndarray | list): indices pool.
            num (int): expected sample num.

        Returns:
            Tensor or ndarray: sampled indices.
        """
        assert len(gallery) >= num

        is_tensor = isinstance(gallery, Tensor)
        if not is_tensor:
            gallery = F.convert_to_tensor(gallery, dtype=int64, device="gpu")
        # This is a temporary fix. We can revert the following code
        # when PyTorch fixes the abnormal return of torch.randperm.
        # See: https://github.com/open-mmlab/mmdetection/pull/5014
        perm = F.to_device(F.randperm(F.numel(gallery))[:num], device="GPU")
        rand_inds = F.gather(gallery, perm)
        if not is_tensor:
            rand_inds = F.convert_to_numpy(rand_inds)
        return rand_inds

    def _sample_pos(self, assign_result, num_expected, **kwargs):
        """Randomly sample some positive samples."""
        pos_inds = F.nonzero(assign_result.gt_inds > 0)
        if F.numel(pos_inds) != 0:
            pos_inds = F.squeeze(pos_inds, 1)
        if F.numel(pos_inds) <= num_expected:
            return pos_inds
        else:
            return self.random_choice(pos_inds, num_expected)

    def _sample_neg(self, assign_result, num_expected, **kwargs):
        """Randomly sample some negative samples."""
        neg_inds = F.nonzero(assign_result.gt_inds == 0)
        if F.numel(neg_inds) != 0:
            neg_inds = F.squeeze(neg_inds, axis=1)
        if len(neg_inds) <= num_expected:
            return neg_inds
        else:
            return self.random_choice(neg_inds, num_expected)
