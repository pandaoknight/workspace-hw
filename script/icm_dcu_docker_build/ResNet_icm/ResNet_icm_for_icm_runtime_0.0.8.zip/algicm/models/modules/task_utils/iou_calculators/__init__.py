# Copyright (c) OpenMMLab. All rights reserved.

from .iou2d_calculator import BboxOverlaps2D, bbox_overlaps
