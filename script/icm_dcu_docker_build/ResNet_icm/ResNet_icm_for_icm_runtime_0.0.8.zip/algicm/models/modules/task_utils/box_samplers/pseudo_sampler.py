#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   pseudo_sampler.py
@Time    :   2023/03/28 16:42:30
@Author  :   htx 
"""

from ..box_assigners import AssignResult
from .sampling_results import SamplingResult
from algicm.registry.common import BBOX_SAMPLERS
from algicm.models.backend.utils import uint8
from .base_sampler import BaseSampler
import algicm.models.backend.functional as F


@BBOX_SAMPLERS.register_module()
class PseudoSampler(BaseSampler):
    """A pseudo sampler that does not do sampling actually."""

    def __init__(self, **kwargs):
        pass

    def _sample_pos(self, **kwargs):
        """Sample positive samples."""
        raise NotImplementedError

    def _sample_neg(self, **kwargs):
        """Sample negative samples."""
        raise NotImplementedError

    def sample(self, assign_result: AssignResult, gt_bboxes, priors, *args,
               **kwargs):
        """Directly returns the positive and negative indices  of samples.

        Args:
            assign_result (:obj:`AssignResult`): Bbox assigning results.
            gt_bboxes (torch.Tensor): Instances of model
                predictions. It includes ``priors``, and the priors can
                be anchors, points, or bboxes predicted by the model,
                shape(n, 4).
            priors (torch.Tensor): Ground truth of instance
                annotations. It usually includes ``bboxes`` and ``labels``
                attributes.

        Returns:
            :obj:`SamplingResult`: sampler results
        """

        pos_inds = F.unique(F.squeeze(F.nonzero(assign_result.gt_inds > 0),
                                      -1))
        neg_inds = F.unique(
            F.squeeze(F.nonzero(assign_result.gt_inds == 0), -1))

        gt_flags = F.zeros(priors.shape[0], dtype=uint8, device=priors.device)
        sampling_result = SamplingResult(
            pos_inds=pos_inds,
            neg_inds=neg_inds,
            priors=priors,
            gt_bboxes=gt_bboxes,
            assign_result=assign_result,
            gt_flags=gt_flags,
            avg_factor_with_neg=False,
            box_dim=kwargs.get("box_dim", 4),
        )
        return sampling_result
