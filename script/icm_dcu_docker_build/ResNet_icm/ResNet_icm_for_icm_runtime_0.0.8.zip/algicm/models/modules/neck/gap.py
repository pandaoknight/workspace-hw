from algicm.registry.common import MODELS
import algicm.models.backend.functional as F
import algicm.models.backend.nn as nn
from algicm.models.backend import utils
from ...layers import AdaptiveAvgPool1d, AdaptiveAvgPool2d, AdaptiveAvgPool3d
from algicm.models.backend.core import BaseModule as Module


@MODELS.register_module()
class GlobalAveragePooling(Module):
    """Global Average Pooling neck.

    Note that we use `view` to remove extra channel after pooling. We do not
    use `squeeze` as it will also remove the batch dimension when the tensor
    has a batch dimension of size 1, which can lead to unexpected errors.

    Args:
        dim (int): Dimensions of each sample channel, can be one of {1, 2, 3}.
            Default: 2
    """

    def __init__(self, dim=2):
        super(GlobalAveragePooling, self).__init__()
        assert dim in [1, 2, 3], (
            "GlobalAveragePooling dim only support " f"{1, 2, 3}, get {dim} instead."
        )
        if dim == 1:
            self.gap = AdaptiveAvgPool1d(1)
        elif dim == 2:
            self.gap = AdaptiveAvgPool2d((1, 1))
        else:
            self.gap = AdaptiveAvgPool3d((1, 1, 1))

    def init_weights(self):
        pass

    def forward(self, inputs):
        if isinstance(inputs, tuple):
            outputs = tuple([self.gap(x) for x in inputs])
            outputs = tuple(
                [F.reshape(out, (x.shape[0], -1)) for out, x in zip(outputs, inputs)]
            )
        else:
            outputs = tuple([F.reshape(self.gap(inputs), (inputs.shape[0], -1))])

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True
        return outputs
