
from algicm.registry.common import MODELS
from algicm.models.backend.core import BaseModule as Module
from algicm.models.layers.dropout import Dropout

@MODELS.register_module()
class BertNeck(Module):

    def __init__(self, p, return_first=False,return_hidden_out = False, with_dropout=True):
        super(BertNeck, self).__init__()
        self.with_dropout = with_dropout
        self.return_first = return_first
        self.return_hidden_out = return_hidden_out
        if with_dropout:
            self.dropout = Dropout(p = p)
        
            
    def forward(self, inputs):
        if self.return_first:
            pooler_out = inputs[1]
            pooler_out =self.dropout(pooler_out)
            hidden_out = inputs[0]
            hidden_out =self.dropout(hidden_out)
            return (hidden_out, pooler_out)
        elif self.return_hidden_out:
            hidden_out = inputs[0]
            hidden_out =self.dropout(hidden_out)
            return hidden_out
        else:
            pooler_out = inputs[1]
            pooler_out =self.dropout(pooler_out)
            return pooler_out