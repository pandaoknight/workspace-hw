from .gap import GlobalAveragePooling
from .yolov_neck import YOLOv5PAFPN  #,YOLOV3Neck
from .bert_cls_neck import BertNeck
from .fpn import FPN