# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# """
# @File    :   bert_module.py
# @Time    :   2023/07/27 14:33:34
# @Author  :   htx 
# """


# import warnings
# import algicm.models.backend.functional as F
# import algicm.models.backend as backend
# from typing import Dict, Optional, Tuple, Union
# from algicm.models.backend.core import BaseModule, constant_init, kaiming_init
# from algicm.models.layers.embedding import Embedding
# from algicm.models.layers.norm import BertLayerNorm
# from algicm.models.layers.dropout import Dropout
# from algicm.registry.common import (
#     MODELS,
#     build_activation_layer,
#     build_norm_layer,
#     build_padding_layer,
#     build_conv_layer,
# )


# class BertEmbeddings(BaseModule):
#     """Construct the embeddings from word, position and token_type embeddings."""

#     def __init__(
#         self,
#         vocab_size,
#         hidden_size,
#         max_position_embeddings,
#         type_vocab_size,
#         hidden_dropout_prob,
#     ):
#         super(BertEmbeddings, self).__init__()
#         self.word_embeddings = Embedding(vocab_size, hidden_size)
#         self.position_embeddings = Embedding(max_position_embeddings, hidden_size)
#         self.token_type_embeddings = Embedding(type_vocab_size, hidden_size)

#         # self.LayerNorm is not snake-cased to stick with TensorFlow model variable name and be able to load
#         # any TensorFlow checkpoint file
#         self.LayerNorm = BertLayerNorm(hidden_size, eps=1e-12)
#         self.dropout = Dropout(hidden_dropout_prob)

#     def forward(
#         self, input_ids, token_type_ids=None, position_ids=None, inputs_embeds=None
#     ):
#         seq_length = input_ids.shape[1]

#         if input_ids is not None:

#             inputs_embeds = F.gather(params=self.weight, indices=input_ids)

#         if position_ids is None:
#             position_ids = F.arange(0, seq_length, dtype=backend.int32)
#             position_ids = F.expand_dims(position_ids, 0)

#             F.gather()

#         torch.arange(seq_length, dtype=torch.long, device=input_ids.device)
#         position_ids = position_ids.unsqueeze(0).expand_as(input_ids)
#         if token_type_ids is None:
#             token_type_ids = torch.zeros_like(input_ids)

#         words_embeddings = self.word_embeddings(input_ids)
#         position_embeddings = self.position_embeddings(position_ids)
#         token_type_embeddings = self.token_type_embeddings(token_type_ids)

#         embeddings = words_embeddings + position_embeddings + token_type_embeddings
#         embeddings = self.LayerNorm(embeddings)
#         embeddings = self.dropout(embeddings)
#         return embeddings
