from typing import List, Optional

import algicm.models.backend.functional as F
from algicm.models.backend.core import BaseModule as Module
from algicm.registry.common import LAYERS, LOSS_LAYERS
from algicm.models.backend.utils import uint8, float32, int64


@LAYERS.register_module()
@LOSS_LAYERS.register_module()
class CRFModule(Module):
    """Conditional random field.

    This module implements a conditional random field [LMP01]_. The forward computation
    of this class computes the log likelihood of the given sequence of tags and
    emission score tensor. This class also has `~CRF.decode` method which finds
    the best tag sequence given an emission score tensor using `Viterbi algorithm`_.

    Args:
        num_tags: Number of tags.
        batch_first: Whether the first dimension corresponds to the size of a minibatch.

    Attributes:
        start_transitions (`~torch.nn.Parameter`): Start transition score tensor of size
            ``(num_tags,)``.
        end_transitions (`~torch.nn.Parameter`): End transition score tensor of size
            ``(num_tags,)``.
        transitions (`~torch.nn.Parameter`): Transition score tensor of size
            ``(num_tags, num_tags)``.


    .. [LMP01] Lafferty, J., McCallum, A., Pereira, F. (2001).
       "Conditional random fields: Probabilistic models for segmenting and
       labeling sequence data". *Proc. 18th International Conf. on Machine
       Learning*. Morgan Kaufmann. pp. 282–289.

    .. _Viterbi algorithm: https://en.wikipedia.org/wiki/Viterbi_algorithm
    """

    def __init__(self, num_tags: int, batch_first: bool = False, reduction: str = "mean") -> None:
        if num_tags <= 0:
            raise ValueError(f"invalid number of tags: {num_tags}")
        super().__init__()
        self.reduction = reduction
        self.num_tags = num_tags
        self.batch_first = batch_first
        self.start_transitions = F.Variable(F.random_uniform([num_tags], -0.1, 0.1), "start_transitions")
        self.end_transitions = F.Variable(F.random_uniform([num_tags], -0.1, 0.1), "end_transitions")
        self.transitions = F.Variable(F.random_uniform([num_tags, num_tags], -0.1, 0.1), "transitions")
        # self.reset_parameters()

    # def reset_parameters(self) -> None:
    #     """Initialize the transition parameters.

    #     The parameters will be initialized randomly from a uniform distribution
    #     between -0.1 and 0.1.
    #     """
    #     nn.init.uniform_(self.start_transitions, -0.1, 0.1)
    #     nn.init.uniform_(self.end_transitions, -0.1, 0.1)
    #     nn.init.uniform_(self.transitions, -0.1, 0.1)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(num_tags={self.num_tags})"

    def encode(
        self,
        emissions,
        tags,
        mask=None,
    ):
        """Compute the conditional log likelihood of a sequence of tags given emission scores.

        Args:
            emissions (`~torch.Tensor`): Emission score tensor of size
                ``(seq_length, batch_size, num_tags)`` if ``batch_first`` is ``False``,
                ``(batch_size, seq_length, num_tags)`` otherwise.
            tags (`~torch.LongTensor`): Sequence of tags tensor of size
                ``(seq_length, batch_size)`` if ``batch_first`` is ``False``,
                ``(batch_size, seq_length)`` otherwise.
            mask (`~torch.ByteTensor`): Mask tensor of size ``(seq_length, batch_size)``
                if ``batch_first`` is ``False``, ``(batch_size, seq_length)`` otherwise.
            reduction: Specifies  the reduction to apply to the output:
                ``none|sum|mean|token_mean``. ``none``: no reduction will be applied.
                ``sum``: the output will be summed over batches. ``mean``: the output will be
                averaged over batches. ``token_mean``: the output will be averaged over tokens.

        Returns:
            `~torch.Tensor`: The log likelihood. This will have size ``(batch_size,)`` if
            reduction is ``none``, ``()`` otherwise.
        """
        # self._validate(emissions, tags=tags, mask=mask)
        if self.reduction not in ("none", "sum", "mean", "token_mean"):
            raise ValueError(f"invalid reduction: {self.reduction}")
        if mask is None:
            mask = F.ones_like(tags, dtype=uint8)

        if self.batch_first:
            emissions = F.transpose(emissions, perm=[1, 0, 2])
            tags = F.transpose(tags, perm=[1, 0])
            mask = F.transpose(mask, perm=[1, 0])

        # shape: (batch_size,)
        numerator = self._compute_score(emissions, tags, mask)
        # shape: (batch_size,)
        denominator = self._compute_normalizer(emissions, mask)
        # shape: (batch_size,)
        return numerator, denominator
        # llh = numerator - denominator

        # if self.reduction == "none":
        #     return -(llh)
        # if self.reduction == "sum":
        #     return -(F.reduce_sum(llh))
        # if self.reduction == "mean":
        #     return -(F.reduce_mean(llh))
        # assert self.reduction == "token_mean"
        # return -(F.reduce_sum(llh) / F.reduce_sum(F.conver_dtype(mask, float32)))

    def forward(self, emissions, mask=None) -> List[List[int]]:
        """Find the most likely tag sequence using Viterbi algorithm.

        Args:
            emissions (`~torch.Tensor`): Emission score tensor of size
                ``(seq_length, batch_size, num_tags)`` if ``batch_first`` is ``False``,
                ``(batch_size, seq_length, num_tags)`` otherwise.
            mask (`~torch.ByteTensor`): Mask tensor of size ``(seq_length, batch_size)``
                if ``batch_first`` is ``False``, ``(batch_size, seq_length)`` otherwise.

        Returns:
            List of list containing the best tag sequence for each batch.
        """
        self._validate(emissions, mask=mask)
        if mask is None:
            mask = F.ones(emissions.shape[:2], dtype=uint8, device=emissions.device)

        if self.batch_first:
            emissions = F.transpose(emissions, perm=[1, 0, 2])
            mask = F.transpose(mask, perm=[1, 0])

        return self._viterbi_decode(emissions, mask)

    def _validate(self, emissions, tags=None, mask=None) -> None:
        if emissions.ndim != 3:
            raise ValueError(f"emissions must have dimension of 3, got {emissions.ndim}")
        if emissions.shape[2] != self.num_tags:
            raise ValueError(f"expected last dimension of emissions is {self.num_tags}, " f"got {emissions.shape[2]}")

        if tags is not None:
            if emissions.shape[:2] != tags.shape:
                raise ValueError(
                    "the first two dimensions of emissions and tags must match, "
                    f"got {tuple(emissions.shape[:2])} and {tuple(tags.shape)}"
                )

        if mask is not None:
            if emissions.shape[:2] != mask.shape:
                raise ValueError(
                    "the first two dimensions of emissions and mask must match, "
                    f"got {tuple(emissions.shape[:2])} and {tuple(mask.shape)}"
                )
            no_empty_seq = not self.batch_first and F.all(mask[0])
            no_empty_seq_bf = self.batch_first and F.all(mask[:, 0])
            if not no_empty_seq and not no_empty_seq_bf:
                raise ValueError("mask of the first timestep must all be on")

    def _compute_score(self, emissions, tags, mask):
        # emissions: (seq_length, batch_size, num_tags)
        # tags: (seq_length, batch_size)
        # mask: (seq_length, batch_size)

        assert emissions.ndim == 3 and tags.ndim == 2
        assert emissions.shape[:2] == tags.shape
        assert emissions.shape[2] == self.num_tags
        assert mask.shape == tags.shape
        assert F.all(mask[0])

        seq_length, batch_size = tags.shape
        mask = F.conver_dtype(mask, float32)

        # Start transition score and first emission
        # shape: (batch_size,)
        score = F.gather(self.start_transitions, tags[0])
        index = F.stack(
            [
                F.to_device(F.repeat(F.zeros(1, dtype=int64), [batch_size]), "GPU"),
                F.conver_dtype(F.to_device(F.arange(batch_size), "GPU"), int64),
                tags[0],
            ],
            axis=1,
        )
        score += F.gather_nd(emissions, index)

        for i in range(1, seq_length):
            # Transition score to next tag, only added if next timestep is valid (mask == 1)
            # shape: (batch_size,)
            try:
                index_transitions = F.stack([tags[i - 1], tags[i]], axis=1)
                score += F.gather_nd(self.transitions, index_transitions) * mask[i]
            except IndexError:
                print(tags)
            # Emission score for next tag, only added if next timestep is valid (mask == 1)
            # shape: (batch_size,)
            index_emissions = F.stack(
                [
                    F.to_device(F.repeat(F.convert_to_tensor(i, dtype=int64), [batch_size]), "GPU"),
                    F.conver_dtype(F.to_device(F.arange(batch_size), "GPU"), int64),
                    tags[i],
                ],
                axis=1,
            )
            score += F.gather_nd(emissions, index_emissions) * mask[i]

        # End transition score
        # shape: (batch_size,)
        seq_ends = F.reduce_sum(F.conver_dtype(mask, int64), axis=0) - 1
        # shape: (batch_size,)
        index_tags = F.stack([seq_ends, F.conver_dtype(F.to_device(F.arange(batch_size), "GPU"), int64)], axis=1)
        last_tags = F.gather_nd(tags, index_tags)
        # shape: (batch_size,)
        score += F.gather(self.end_transitions, last_tags)

        return score

    def _compute_normalizer(self, emissions, mask):
        # emissions: (seq_length, batch_size, num_tags)
        # mask: (seq_length, batch_size)
        assert emissions.ndim == 3 and mask.ndim == 2
        assert emissions.shape[:2] == mask.shape
        assert emissions.shape[2] == self.num_tags
        assert F.all(mask[0])

        seq_length = emissions.shape[0]

        # Start transition score and first emission; score has size of
        # (batch_size, num_tags) where for each batch, the j-th column stores
        # the score that the first timestep has tag j
        # shape: (batch_size, num_tags)
        score = self.start_transitions + emissions[0]

        for i in range(1, seq_length):
            # Broadcast score for every possible next tag
            # shape: (batch_size, num_tags, 1)
            broadcast_score = F.expand_dims(score, axis=2)

            # Broadcast emission score for every possible current tag
            # shape: (batch_size, 1, num_tags)
            broadcast_emissions = F.expand_dims(emissions[i], axis=1)

            # Compute the score tensor of size (batch_size, num_tags, num_tags) where
            # for each sample, entry at row i and column j stores the sum of scores of all
            # possible tag sequences so far that end with transitioning from tag i to tag j
            # and emitting
            # shape: (batch_size, num_tags, num_tags)
            next_score = broadcast_score + self.transitions + broadcast_emissions

            # Sum over all possible current tags, but we're in score space, so a sum
            # becomes a log-sum-exp: for each sample, entry i stores the sum of scores of
            # all possible tag sequences so far, that end in tag i
            # shape: (batch_size, num_tags)
            next_score = F.logsumexp(next_score, axis=1)

            # Set score to the next score if this timestep is valid (mask == 1)
            # shape: (batch_size, num_tags)
            score = F.where(F.expand_dims(mask[i], axis=1), next_score, score)

        # End transition score
        # shape: (batch_size, num_tags)
        score += self.end_transitions

        # Sum (log-sum-exp) over all possible tags
        # shape: (batch_size,)
        return F.logsumexp(score, axis=1)

    def _viterbi_decode(self, emissions, mask) -> List[List[int]]:
        # emissions: (seq_length, batch_size, num_tags)
        # mask: (seq_length, batch_size)
        assert emissions.ndim == 3 and mask.ndim == 2
        assert emissions.shape[:2] == mask.shape
        assert emissions.shape[2] == self.num_tags
        assert F.all(mask[0])

        seq_length, batch_size = mask.shape

        # Start transition and first emission
        # shape: (batch_size, num_tags)
        score = self.start_transitions + emissions[0]
        history = []

        # score is a tensor of size (batch_size, num_tags) where for every batch,
        # value at column j stores the score of the best tag sequence so far that ends
        # with tag j
        # history saves where the best tags candidate transitioned from; this is used
        # when we trace back the best tag sequence

        # Viterbi algorithm recursive case: we compute the score of the best tag sequence
        # for every possible next tag
        for i in range(1, seq_length):
            # Broadcast viterbi score for every possible next tag
            # shape: (batch_size, num_tags, 1)
            broadcast_score = F.expand_dims(score, axis=2)

            # Broadcast emission score for every possible current tag
            # shape: (batch_size, 1, num_tags)
            broadcast_emission = F.expand_dims(emissions[i], axis=1)

            # Compute the score tensor of size (batch_size, num_tags, num_tags) where
            # for each sample, entry at row i and column j stores the score of the best
            # tag sequence so far that ends with transitioning from tag i to tag j and emitting
            # shape: (batch_size, num_tags, num_tags)
            next_score = broadcast_score + self.transitions + broadcast_emission

            # Find the maximum score over all possible current tag
            # shape: (batch_size, num_tags)
            next_score, indices = F.reduce_max(next_score, axis=1), F.argmax(next_score, axis=1)

            # Set score to the next score if this timestep is valid (mask == 1)
            # and save the index that produces the next score
            # shape: (batch_size, num_tags)
            score = F.where(F.expand_dims(mask[i], axis=1), next_score, score)
            history.append(indices)

        # End transition score
        # shape: (batch_size, num_tags)
        score += self.end_transitions

        # Now, compute the best path for each sample

        # shape: (batch_size,)
        seq_ends = F.reduce_sum(F.conver_dtype(mask, dtype=int64), axis=0) - 1
        best_tags_list = []

        for idx in range(batch_size):
            # Find the tag which maximizes the score at the last timestep; this is our best tag
            # for the last timestep
            _, best_last_tag = F.reduce_max(score[idx], axis=0), F.argmax(score[idx], axis=0)
            best_tags = [F.item(best_last_tag)]

            # We trace back where the best last tag comes from, append that to our best tag
            # sequence, and trace it back again, and so on
            for hist in reversed(history[: seq_ends[idx]]):
                best_last_tag = hist[idx][best_tags[-1]]
                best_tags.append(F.item(best_last_tag))

            # Reverse the order because we start from the last timestep
            best_tags.reverse()
            best_tags_list.append(best_tags)

        return best_tags_list
