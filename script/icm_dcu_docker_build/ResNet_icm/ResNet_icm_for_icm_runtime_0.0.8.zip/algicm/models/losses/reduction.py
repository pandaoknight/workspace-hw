#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   reduction.py
@Time    :   2023/08/23 14:33:14
@Author  :   htx 
"""

import warnings
from ..backend.core import BaseModule as Module
from algicm.registry.common import LAYERS, LOSS_LAYERS
import algicm.models.backend.functional as F


def negative_minus(cls_score, labels, mask=None):
    return cls_score - labels


def reduce_sum(cls_score, labels, mask=None):
    return F.reduce_sum(cls_score - labels)


def reduce_mean(cls_score, labels, mask=None):
    return F.reduce_mean(cls_score - labels)


@LAYERS.register_module()
@LOSS_LAYERS.register_module()
class ReductionLoss(Module):
    def __init__(
        self,
        reduction="mean",
        loss_weight=1.0,
        name=None,
    ):
        """Reduction Loss.

        Args:

            reduction (str, optional): . Defaults to 'mean'.
                Options are "none", "mean" and "sum".
            loss_weight (float, optional): Weight of the loss. Defaults to 1.0.
        """
        super(ReductionLoss, self).__init__(name=name)
        assert isinstance(reduction, str) and reduction in ["none", "mean", "sum"]
        self.reduction = reduction
        self.loss_weight = loss_weight

        if self.reduction == "none":
            self.cls_criterion = negative_minus
        elif self.reduction == "mean":
            self.cls_criterion = reduce_mean
        else:
            self.cls_criterion = reduce_sum

    def extra_repr(self):
        """Extra repr."""
        s = f"ReductionLoss[reduction={self.reduction}]"
        return s

    def forward(
        self,
        cls_score,
        label,
        mask=None,
        **kwargs,
    ):
        """Forward function.

        Args:
            cls_score (torch.Tensor): The prediction.
            label (torch.Tensor): The learning label of the prediction.
            weight (torch.Tensor, optional): Sample-wise loss weight.
            avg_factor (int, optional): Average factor that is used to average
                the loss. Defaults to None.
            reduction_override (str, optional): The method used to reduce the
                loss. Options are "none", "mean" and "sum".
            ignore_index (int | None): The label index to be ignored.
                If not None, it will override the default value. Default: None.
        Returns:
            torch.Tensor: The calculated loss.
        """
        loss_cls = self.loss_weight * self.cls_criterion(
            cls_score,
            label,
            mask,
            **kwargs,
        )
        return loss_cls
