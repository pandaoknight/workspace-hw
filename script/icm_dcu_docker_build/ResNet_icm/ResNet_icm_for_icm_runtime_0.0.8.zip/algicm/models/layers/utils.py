from algicm import BACKEND

import algicm.models.backend.functional as F
import algicm.models.backend.nn as nn
from algicm.models.backend import utils
from ..backend.core import BaseModule as Module

def get_variable_with_initializer(scope_name, var_name, shape, init, trainable=True,**kwargs):
    # FIXME: documentation needed
    var_name = scope_name + "/" + var_name
    # FIXME: not sure whether this is correct?
    # TODO mindspore weights shape : [out_channel, in_channel, kernel_h, kernel_w]
    if BACKEND == "mindspore":
        if len(shape) == 2:
            pass
        else:
            shape = shape[::-1]

    initial_value = init(shape=shape,**kwargs)

    if BACKEND == "dragon":
        return initial_value

    var = F.Variable(initial_value=initial_value, name=var_name, trainable=trainable)
    return var
