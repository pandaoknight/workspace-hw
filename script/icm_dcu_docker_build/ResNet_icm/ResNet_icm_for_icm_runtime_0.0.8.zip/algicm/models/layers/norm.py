#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   norm.py
@Time    :   2023/05/12 17:36:02
@Author  :   htx 
"""

import algicm.models.backend.functional as F
import algicm.models.backend.nn as nn
from algicm.models.backend import utils
from functools import partial
from algicm.registry.common import NORM_LAYERS
from ..backend.core import BaseModule as Module


@NORM_LAYERS.register_module()
class BatchNorm(Module):
    r"""
    This interface is used to construct a callable object of the BatchNorm class. For more details, refer to code examples.
    It implements the function of the Batch Normalization Layer and can be used as a normalizer function for conv2d and fully connected operations.
    The data is normalized by the mean and variance of the channel based on the current batch data.

    the :math:`\mu_{\beta}`
    and :math:`\sigma_{\beta}^{2}` are the statistics of one mini-batch.
    Calculated as follows:

    ..  math::

        \mu_{\beta} &\gets \frac{1}{m} \sum_{i=1}^{m} x_i \qquad &
        //\ mini-batch\ mean \\
        \sigma_{\beta}^{2} &\gets \frac{1}{m} \sum_{i=1}^{m}(x_i - \mu_{\beta})^2 \qquad &
        //\ mini-batch\ variance \\

    - :math:`x` : mini-batch data
    - :math:`m` : the size of the mini-batch data

    the :math:`\mu_{\beta}`
    and :math:`\sigma_{\beta}^{2}` are not the statistics of one mini-batch.
    They are global or running statistics (moving_mean and moving_variance). It usually got from the
    pre-trained model. Calculated as follows:

    .. math::
        moving\_mean = moving\_mean * momentum + \mu_{\beta} * (1. - momentum) \quad &// global mean \\
        moving\_variance = moving\_variance * momentum + \sigma_{\beta}^{2} * (1. - momentum) \quad &// global variance \\

    The normalization function formula is as follows:

    ..  math::

        \hat{x_i} &\gets \frac{x_i - \mu_\beta} {\sqrt{\
        \sigma_{\beta}^{2} + \eps}} \qquad &//\ normalize \\
        y_i &\gets \gamma \hat{x_i} + \beta \qquad &//\ scale\ and\ shift


    - :math:`\eps` : add a smaller value to the variance to prevent division by zero
    - :math:`\gamma` : trainable proportional parameter
    - :math:`\beta` : trainable deviation parameter

    Parameters
    ----------
    momentum : float
        The value used for the moving_mean and moving_var computation. Default: 0.9.
    eps : float
         a value added to the denominator for numerical stability. Default: 1e-5
    act : activation function
        The activation function of this layer.
    is_train : boolean
        Is being used for training or inference.
    beta_init : initializer or str
        The initializer for initializing beta, if None, skip beta.
        Usually you should not skip beta unless you know what happened.
    gamma_init : initializer or str
        The initializer for initializing gamma, if None, skip gamma.
        When the batch normalization layer is use instead of 'biases', or the next layer is linear, this can be
        disabled since the scaling can be done by the next layer. see `Inception-ResNet-v2 <https://github.com/tensorflow/models/blob/master/research/slim/nets/inception_resnet_v2.py>`__
    moving_mean_init : initializer or str
        The initializer for initializing moving mean, if None, skip moving mean.
    moving_var_init : initializer or str
        The initializer for initializing moving var, if None, skip moving var.
    num_features: int
        Number of features for input tensor. Useful to build layer if using BatchNorm1d, BatchNorm2d or BatchNorm3d,
        but should be left as None if using BatchNorm. Default None.
    data_format : str
        channels_last 'channel_last' (default) or channels_first.
    name : None or str
        A unique layer name.

    Examples
    ---------
    With TensorLayerX

    >>> net = tlx.nn.Input([10, 50, 50, 32], name='input')
    >>> net = tlx.nn.BatchNorm()(net)

    Notes
    -----
    The :class:`BatchNorm` is universally suitable for 3D/4D/5D input in static model, but should not be used
    in dynamic model where layer is built upon class initialization. So the argument 'num_features' should only be used
    for subclasses :class:`BatchNorm1d`, :class:`BatchNorm2d` and :class:`BatchNorm3d`. All the three subclasses are
    suitable under all kinds of conditions.

    References
    ----------
    - `Source <https://github.com/ry/tensorflow-resnet/blob/master/resnet.py>`__
    - `stackoverflow <http://stackoverflow.com/questions/38312668/how-does-one-do-inference-with-batch-normalization-with-tensor-flow>`__

    """

    def __init__(
        self,
        num_features,
        momentum=0.9,
        eps=0.00001,
        data_format="channels_first",
        affine=True,
        name=None,
    ):
        super(BatchNorm, self).__init__(name=name)
        self.momentum = momentum
        self.eps = eps
        self.data_format = data_format
        self.num_features = num_features
        self.affine = affine

        self.axes = None
        self.build(None)
        self._built = True

        if self.momentum < 0.0 or 1.0 < self.momentum:
            raise ValueError("momentum should be between 0 to 1")

    def __repr__(self):
        s = "{classname}(num_features={num_features}, eps={eps}, momentum={momentum},affine={affine})"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def _get_param_shape(self, inputs_shape):
        if self.data_format == "channels_last":
            axis = -1
        elif self.data_format == "channels_first":
            axis = 1
        else:
            raise ValueError(
                "data_format should be either %s or %s"
                % ("channels_last", "channels_first")
            )

        channels = inputs_shape[axis]
        params_shape = [channels]

        return params_shape

    def _check_input_shape(self, inputs):
        if inputs.ndim <= 1:
            raise ValueError(
                "expected input at least 2D, but got {}D input".format(inputs.ndim)
            )

    def build(self, inputs_shape):
        params_shape = self.num_features
        self.weight, self.bias = None, None
        if self.affine:
            self.weight = self._get_weights(
                var_name="weight",
                shape=[params_shape],
                init=partial(F.ones, dtype=utils.float32),
            )
            self.bias = self._get_weights(
                var_name="bias",
                shape=[params_shape],
                init=partial(F.zeros, dtype=utils.float32),
            )

        self.moving_mean = self._get_weights(
            var_name="moving_mean",
            shape=[params_shape],
            init=partial(F.zeros, dtype=utils.float32),
            trainable=False,
        )
        self.moving_var = self._get_weights(
            var_name="moving_var",
            shape=[params_shape],
            init=partial(F.ones, dtype=utils.float32),
            trainable=False,
        )

        self.batchnorm = nn.BatchNorm(
            decay=self.momentum,
            eps=self.eps,
            gamma=self.weight,
            beta=self.bias,
            moving_mean=self.moving_mean,
            moving_var=self.moving_var,
            num_features=self.num_features,
            data_format=self.data_format
        )

    def forward(self, inputs):
        self._check_input_shape(inputs)
        if self._forward_state == False:
            if self._built == False:
                self.build(F.get_tensor_shape(inputs))
                self._built = True
            self._forward_state = True

        if not self.is_train:
            self.batchnorm = nn.BatchNorm(
                decay=self.momentum,
                eps=self.eps,
                gamma=self.weight,
                beta=self.bias,
                moving_mean=self.moving_mean,
                moving_var=self.moving_var,
                num_features=self.num_features,
                data_format=self.data_format
            )
        outputs = self.batchnorm(inputs=inputs,is_train = self.is_train)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True
        return outputs

@NORM_LAYERS.register_module(name="BN1d")
class BatchNorm1d(BatchNorm):
    """The :class:`BatchNorm1d` applies Batch Normalization over 2D/3D input (a mini-batch of 1D
    inputs (optional) with additional channel dimension), of shape (N, C) or (N, L, C) or (N, C, L).
    See more details in :class:`BatchNorm`.

    Examples
    ---------
    With TensorLayerX

    >>> # in static model, no need to specify num_features
    >>> net = tlx.nn.Input([10, 50, 32], name='input')
    >>> net = tlx.nn.BatchNorm1d()(net)
    >>> # in dynamic model, build by specifying num_features
    >>> conv = tlx.nn.Conv1d(32, 5, 1, in_channels=3)
    >>> bn = tlx.nn.BatchNorm1d(num_features=32)

    """

    def _check_input_shape(self, inputs):
        if len(inputs.shape) != 2 and len(inputs.shape) != 3:
            raise ValueError(
                "expected input to be 2D or 3D, but got {}D input".format(inputs.ndim)
            )


@NORM_LAYERS.register_module(name="BN2d")
@NORM_LAYERS.register_module(name="BN")
class BatchNorm2d(BatchNorm):
    """The :class:`BatchNorm2d` applies Batch Normalization over 4D input (a mini-batch of 2D
    inputs with additional channel dimension) of shape (N, H, W, C) or (N, C, H, W).
    See more details in :class:`BatchNorm`.

    Examples
    ---------
    With TensorLayer

    >>> # in static model, no need to specify num_features
    >>> net = tlx.nn.Input([10, 50, 50, 32], name='input')
    >>> net = tlx.nn.BatchNorm2d()(net)
    >>> # in dynamic model, build by specifying num_features
    >>> conv = tlx.nn.Conv2d(32, (5, 5), (1, 1), in_channels=3)
    >>> bn = tlx.nn.BatchNorm2d(num_features=32)

    """

    def _check_input_shape(self, inputs):
        if len(inputs.shape) != 4:
            raise ValueError(
                "expected input to be 4D, but got {}D input".format(inputs.ndim)
            )


@NORM_LAYERS.register_module(name="BN3d")
class BatchNorm3d(BatchNorm):
    """The :class:`BatchNorm3d` applies Batch Normalization over 5D input (a mini-batch of 3D
    inputs with additional channel dimension) with shape (N, D, H, W, C) or (N, C, D, H, W).
    See more details in :class:`BatchNorm`.

    Examples
    ---------
    With TensorLayer

    >>> # in static model, no need to specify num_features
    >>> net = tlx.nn.Input([10, 50, 50, 50, 32], name='input')
    >>> net = tlx.nn.BatchNorm3d()(net)
    >>> # in dynamic model, build by specifying num_features
    >>> conv = tlx.nn.Conv3d(32, (5, 5, 5), (1, 1), in_channels=3)
    >>> bn = tlx.nn.BatchNorm3d(num_features=32)

    """

    def _check_input_shape(self, inputs):
        if len(inputs.shape) != 5:
            raise ValueError(
                "expected input to be 5D, but got {}D input".format(inputs.ndim)
            )


@NORM_LAYERS.register_module(name="LN")
class LayerNorm(Module):
    """
    It implements the function of the Layer Normalization Layer and can be applied to mini-batch input data.

    Parameters
    ----------
    normalized_shape : int or list
        input shape from an expected input of size
    eps : float
        a value added to the denominator for numerical stability. Default: 1e-5
    gamma_init : initializer or str
        The initializer for initializing gamma, if None, skip gamma.
    beta_init : initializer or str
        The initializer for initializing beta, if None, skip beta.
        Usually you should not skip beta unless you know what happened.
    act : activation function
        The activation function of this layer.
    name : None or str
        A unique layer name.

    Examples
    ---------
    With TensorLayer

    >>> net = tlx.nn.Input([10, 50, 50, 32], name='input')
    >>> net = tlx.nn.LayerNorm((50,50,32))(net)


    References
    ----------
    - `Layer Normalization <https://arxiv.org/pdf/1607.06450v1.pdf>`__

    """

    def __init__(
        self,
        normalized_shape,
        eps=1e-05,
        input_shape=None,
        name=None,
    ):
        super(LayerNorm, self).__init__(name)
        if isinstance(normalized_shape, int):
            normalized_shape = [normalized_shape]
        self.normalized_shape = list(normalized_shape)
        self.eps = eps
        self.build(input_shape)

    def __repr__(self):
        s = "{classname}(normalized_shape={normalized_shape}, eps={eps})"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def build(self, input_shape):
        self.weight = self._get_weights(
            var_name="weight",
            shape=self.normalized_shape,
            init=partial(F.ones, dtype=utils.float32),
            order=True,
        )

        self.bias = self._get_weights(
            var_name="beta",
            shape=self.normalized_shape,
            init=partial(F.zeros, dtype=utils.float32),
            order=True,
        )

        self.layernorm = nn.layernorm(
            self.normalized_shape, self.weight, self.bias, self.eps, input_shape
        )

    def forward(self, inputs):
        if self._forward_state == False:
            if self._built == False:
                self.build(F.get_tensor_shape(inputs))
                self._built = True
            self._forward_state = True

        outputs = self.layernorm(inputs)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True

        return outputs


@NORM_LAYERS.register_module(name="GN")
class GroupNorm(Module):
    def __init__(
        self,
        num_groups,
        num_channels,
        eps=1e-5,
        data_format="channels_first",
        name=None,
    ):
        super().__init__(name=name)
        self.num_groups = num_groups
        self.num_channels = num_channels
        self.data_format = data_format
        self.eps = eps

    def __repr__(self):
        s = "{classname}(num_groups={num_groups}, num_channels={num_channels},eps={eps})"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def _check_input_shape(self, inputs):
        if inputs.ndim <= 1:
            raise ValueError(
                "expected input at least 2D, but got {}D input".format(inputs.ndim)
            )

    def build(self, input_shape):
        self.weight = self._get_weights(
            var_name="weight",
            shape=[self.num_channels],
            init=partial(F.ones, dtype=utils.float32),
            order=True,
        )

        self.bias = self._get_weights(
            var_name="beta",
            shape=[self.num_channels],
            init=partial(F.zeros, dtype=utils.float32),
            order=True,
        )

        self.groupnorm = nn.GroupNorm(
            self.num_groups,
            beta=self.weight,
            gamma=self.bias,
            eps=self.eps,
            data_format=self.data_format,
        )

    def forward(self, inputs):
        self._check_input_shape(inputs)
        if self._forward_state == False:
            if self._built == False:
                self.build(F.get_tensor_shape(inputs))
                self._built = True
            self._forward_state = True

        outputs = self.groupnorm(inputs=inputs)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True
        return outputs


@NORM_LAYERS.register_module()
class InstanceNorm(Module):
    """TODO: ADD NOTES"""

    def __init__(
        self,
        num_features,
        momentum=0.9,
        eps=0.00001,
        data_format="channels_first",
        affine=True,
        name=None,
    ):
        super(InstanceNorm, self).__init__(name=name)
        self.momentum = momentum
        self.eps = eps
        self.data_format = data_format
        self.num_features = num_features
        self.affine = affine
        self.is_train = True

        self.axes = None
        self.build(None)
        self._built = True

        if self.momentum < 0.0 or 1.0 < self.momentum:
            raise ValueError("momentum should be between 0 to 1")

    def __repr__(self):
        s = "{classname}(num_features={num_features}, eps={eps}, momentum={momentum}, affine={affine})"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def _get_param_shape(self, inputs_shape):
        if self.data_format == "channels_last":
            axis = -1
        elif self.data_format == "channels_first":
            axis = 1
        else:
            raise ValueError(
                "data_format should be either %s or %s"
                % ("channels_last", "channels_first")
            )

        channels = inputs_shape[axis]
        params_shape = [channels]

        return params_shape

    def _check_input_shape(self, inputs):
        if inputs.ndim <= 1:
            raise ValueError(
                "expected input at least 2D, but got {}D input".format(inputs.ndim)
            )

    def build(self, inputs_shape):
        params_shape = self.num_features
        self.weight, self.bias = None, None
        if self.affine:
            self.weight = self._get_weights(
                var_name="weight",
                shape=[params_shape],
                init=partial(F.ones, dtype=utils.float32),
            )
            self.bias = self._get_weights(
                var_name="bias",
                shape=[params_shape],
                init=partial(F.zeros, dtype=utils.float32),
            )

        self.instancenorm = nn.InstanceNorm(
            eps=self.eps,
            beta=self.weight,
            gamma=self.bias,
            num_features=self.num_features,
            data_format=self.data_format,
        )

    def forward(self, inputs):
        self._check_input_shape(inputs)
        if self._forward_state == False:
            if self._built == False:
                self.build(F.get_tensor_shape(inputs))
                self._built = True
            self._forward_state = True

        outputs = self.instancenorm(inputs=inputs)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True
        return outputs


@NORM_LAYERS.register_module(name="IN1d")
class InstanceNorm1d(InstanceNorm):
    """The :class:`InstanceNorm1d` applies Batch Normalization over 2D/3D input (a mini-batch of 1D
    inputs (optional) with additional channel dimension), of shape (N, C) or (N, L, C) or (N, C, L).
    See more details in :class:`InstanceNorm`.

    Examples
    ---------
    With TensorLayerX

    >>> # in static model, no need to specify num_features
    >>> net = tlx.nn.Input([10, 50, 32], name='input')
    >>> net = tlx.nn.BatchNorm1d()(net)
    >>> # in dynamic model, build by specifying num_features
    >>> conv = tlx.nn.Conv1d(32, 5, 1, in_channels=3)
    >>> bn = tlx.nn.InstanceNorm1d(num_features=32)

    """

    def _check_input_shape(self, inputs):
        if len(inputs.shape) != 2 and len(inputs.shape) != 3:
            raise ValueError(
                "expected input to be 2D or 3D, but got {}D input".format(inputs.ndim)
            )


@NORM_LAYERS.register_module(name="IN2d")
class InstanceNorm2d(InstanceNorm):
    """The :class:`InstanceNorm2d` applies Batch Normalization over 4D input (a mini-batch of 2D
    inputs with additional channel dimension) of shape (N, H, W, C) or (N, C, H, W).
    See more details in :class:`InstanceNorm`.

    Examples
    ---------
    With TensorLayer

    >>> # in static model, no need to specify num_features
    >>> net = tlx.nn.Input([10, 50, 50, 32], name='input')
    >>> net = tlx.nn.InstanceNorm2d()(net)
    >>> # in dynamic model, build by specifying num_features
    >>> conv = tlx.nn.Conv2d(32, (5, 5), (1, 1), in_channels=3)
    >>> bn = tlx.nn.InstanceNorm2d(num_features=32)

    """

    def _check_input_shape(self, inputs):
        if len(inputs.shape) != 4:
            raise ValueError(
                "expected input to be 4D, but got {}D input".format(inputs.ndim)
            )


@NORM_LAYERS.register_module(name="IN3d")
class InstanceNorm3d(InstanceNorm):
    """The :class:`InstanceNorm3d` applies Batch Normalization over 5D input (a mini-batch of 3D
    inputs with additional channel dimension) with shape (N, D, H, W, C) or (N, C, D, H, W).
    See more details in :class:`BatchNorm`.

    Examples
    ---------
    With TensorLayer

    >>> # in static model, no need to specify num_features
    >>> net = tlx.nn.Input([10, 50, 50, 50, 32], name='input')
    >>> net = tlx.nn.InstanceNorm3d()(net)
    >>> # in dynamic model, build by specifying num_features
    >>> conv = tlx.nn.Conv3d(32, (5, 5, 5), (1, 1), in_channels=3)
    >>> bn = tlx.nn.InstanceNorm3d(num_features=32)

    """

    def _check_input_shape(self, inputs):
        if len(inputs.shape) != 5:
            raise ValueError(
                "expected input to be 5D, but got {}D input".format(inputs.ndim)
            )


@NORM_LAYERS.register_module(name="BertLN")
class BertLayerNorm(Module):
    """
    It implements the function of the Layer Normalization Layer and can be applied to mini-batch input data.

    Parameters
    ----------
    normalized_shape : int or list
        input shape from an expected input of size
    eps : float
        a value added to the denominator for numerical stability. Default: 1e-5
    gamma_init : initializer or str
        The initializer for initializing gamma, if None, skip gamma.
    beta_init : initializer or str
        The initializer for initializing beta, if None, skip beta.
        Usually you should not skip beta unless you know what happened.
    act : activation function
        The activation function of this layer.
    name : None or str
        A unique layer name.

    Examples
    ---------
    With TensorLayer

    >>> net = tlx.nn.Input([10, 50, 50, 32], name='input')
    >>> net = tlx.nn.LayerNorm((50,50,32))(net)


    References
    ----------
    - `Layer Normalization <https://arxiv.org/pdf/1607.06450v1.pdf>`__

    """

    def __init__(
        self,
        hidden_size,
        eps=1e-05,
        name=None,
    ):
        super(BertLayerNorm, self).__init__(name)
        self.hidden_size = [hidden_size]
        self.eps = eps
        self.build(None)
        self._built = True

    def __repr__(self):
        s = "{classname}(hidden_size={hidden_size}, eps={eps})"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def build(self, input_shape):
        self.weight = self._get_weights(
            var_name="weight",
            shape=self.hidden_size,
            init=partial(F.ones, dtype=utils.float32),
            order=True,
        )

        self.bias = self._get_weights(
            var_name="beta",
            shape=self.hidden_size,
            init=partial(F.zeros, dtype=utils.float32),
            order=True,
        )

        # self.layernorm = nn.layernorm(
        #     self.hidden_size, self.weight, self.bias, self.eps, input_shape
        # )

    def forward(self, inputs):
        if self._forward_state == False:
            if self._built == False:
                self.build(F.get_tensor_shape(inputs))
                self._built = True
            self._forward_state = True

        u = F.reduce_mean(inputs, axis=-1, keepdims=True)
        s = F.reduce_mean(F.pow(inputs - u, 2), axis=-1, keepdims=True)
        inputs = F.divide((inputs - u), F.sqrt(s + self.eps))
        outputs = self.weight * inputs + self.bias

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True

        return outputs
