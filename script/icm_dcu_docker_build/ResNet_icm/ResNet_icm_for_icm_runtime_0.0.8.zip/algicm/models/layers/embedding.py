import math
import algicm.models.backend.functional as F
import algicm.models.backend.nn as nn
from functools import partial
from algicm.models.backend import utils
from algicm.registry.common import EMBEDDING_LAYERS
from ..backend.core import BaseModule as Module


class Embedding(Module):
    """
    A simple lookup table that stores embeddings of a fixed dictionary and size.

    This module is often used to store word embeddings and retrieve them using indices.
    The input to the module is a list of indices, and the output is the corresponding word embeddings.

    Parameters
    ----------
    num_embeddings : int
        size of the dictionary of embeddings.
    embedding_dim  : int
         the size of each embedding vector.
    E_init : initializer or str
        The initializer for the embedding matrix.
    E_init_args : dictionary
        The arguments for embedding matrix initializer.
    name : str
        A unique layer name.

    Attributes
    ----------
    outputs : tensor
        The embedding layer output is a 3D tensor in the shape: (batch_size, num_steps(num_words), embedding_dim).

    Examples
    --------
    >>> import tensorlayerx as tlx
    >>> input = tlx.nn.Input([8, 100], dtype=tlx.int32)
    >>> embed = tlx.nn.Embedding(num_embeddings=1000, embedding_dim=50, name='embed')
    >>> print(embed)
    Embedding(num_embeddings=1000, embedding_dim=50)
    >>> tensor = embed(input)
    >>> print(tensor)
    Tensor([...], shape=(8, 100, 50), dtype=float32)

    """

    def __init__(
        self,
        num_embeddings,
        embedding_dim,
        padding_idx=None,
        name=None,  #'embedding',
    ):
        super(Embedding, self).__init__(name)
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        if padding_idx is not None:
            if padding_idx > 0:
                assert (
                    padding_idx < self.num_embeddings
                ), "Padding_idx must be within num_embeddings"
            elif padding_idx < 0:
                assert (
                    padding_idx >= -self.num_embeddings
                ), "Padding_idx must be within num_embeddings"
                padding_idx = self.num_embeddings + padding_idx
        self.padding_idx = padding_idx

        if not self._built:
            self.build(tuple())
            self._built = True

    def __repr__(self):
        s = "{classname}("
        s += "num_embeddings={num_embeddings}"
        s += ", embedding_dim={embedding_dim}"
        s += ")"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def build(self, inputs_shape):
        """
        Parameters
        ----------
        inputs_shape : tuple
            the shape of inputs tensor
        """
        self.weight = self._get_weights(
            "weight",
            shape=(self.num_embeddings, self.embedding_dim),
            init=F.random_normal,
        )

        if self.padding_idx is not None:
            with F.no_grad():
                F.fill_(self.weight[self.padding_idx], 0)

        self.embedding_lookup = nn.EmbeddingLookup()

    def forward(self, inputs):
        """
        Parameters
        ----------
        inputs : Tensor
            The input of a network.
        """
        outputs = self.embedding_lookup(params=self.weight, ids=inputs)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True
        return outputs
