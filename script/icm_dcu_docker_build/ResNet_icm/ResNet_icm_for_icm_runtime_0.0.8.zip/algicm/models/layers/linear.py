from ..backend.core import BaseModule as Module
import algicm.models.backend.functional as F
import algicm.models.backend.nn as nn
from algicm.models.backend import utils
from functools import partial
import math

class Linear(Module):
    """Applies a linear transformation to the incoming data: :math:`y = xA^T + b`

    Parameters
    ----------
    out_features : int
        The number of units of this layer.
    act : activation function
        The activation function of this layer.
    W_init : initializer or str
        The initializer for the weight matrix.
    b_init : initializer or None or str
        The initializer for the bias vector. If None, skip biases.
    in_features: int
        The number of channels of the previous layer.
        If None, it will be automatically detected when the layer is forwarded for the first time.
    name : None or str
        A unique layer name. If None, a unique name will be automatically generated.

    Examples
    --------
    With TensorLayerx

    >>> net = tlx.nn.Input([100, 50], name='input')
    >>> linear = tlx.nn.Linear(out_features=800, act=tlx.ReLU, in_features=50, name='linear_1')
    >>> tensor = tlx.nn.Linear(out_features=800, act=tlx.ReLU, name='linear_2')(net)

    Notes
    -----
    If the layer input has more than two axes, it needs to be flatten by using :class:`Flatten`.

    """

    def __init__(
        self,
        in_features,
        out_features,
        bias=True,
        name=None,  # 'linear',
    ):

        super(Linear, self).__init__(name)

        self.out_features = out_features
        self.has_bias = bias
        self.in_features = in_features

        if self.in_features is not None:
            self.build(self.in_features)
            self._built = True

       

    def __repr__(self):
        
        s = ('{classname}(out_features={out_features}, ' )
        if self.in_features is not None:
            s += ', in_features=\'{in_features}\''
        if self.name is not None:
            s += ', name=\'{name}\''
        s += ')'
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def build(self, inputs_shape):
        if self.in_features is None and len(inputs_shape) < 2:
            raise AssertionError("The dimension of input should not be less than 2")
        if self.in_features:
            shape = [self.out_features, self.in_features]
        else:
            self.in_features = inputs_shape[-1]
            shape = [self.out_features, self.in_features]

        self.weight = self._get_weights(
            "weight",
            shape=tuple(shape),
            init=partial(F.kaiming_normal, a=5, dtype=utils.float32),
        )
        if self.has_bias:
            fan_in, _ = F.compute_fans(self.weight.shape)
            if fan_in != 0:
                bound = 1 / math.sqrt(fan_in)
                b_init = partial(
                    F.random_uniform, minval=-bound, maxval=bound, dtype=utils.float32
                )
            else:
                b_init = partial(F.zeros, dtype=utils.float32)
            self.bias = self._get_weights(
                "bias", shape=(self.out_features,), init=b_init
            )
            

    def forward(self, inputs):
        if self._forward_state == False:
            if self._built == False:
                self.build(F.get_tensor_shape(inputs))
                self._built = True
            self._forward_state = True

        z = F.linear(inputs, self.weight, self.bias)


        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, z)
            self._nodes_fixed = True
        return z

