from ..backend.core import BaseModule as Module
import algicm.models.backend.functional as F
import algicm.models.backend.nn as nn
from algicm.models.backend import utils
from algicm.registry.common import ACTIVATION_LAYERS


@ACTIVATION_LAYERS.register_module()
class ReLU(Module):

    """This function is ReLU.

    The function return the following results:
      - When x < 0: ``f(x) = 0``.
      - When x >= 0: ``f(x) = x``.

    Parameters
    ----------
    x : Tensor
        Support input type ``float``, ``double``, ``int32``, ``int64``, ``uint8``, ``int16``, or ``int8``.

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.ReLU()(net)

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    """

    def __init__(self, inplace=False):
        super(ReLU, self).__init__()
        self.inplace = inplace
        self._built = True
        self._relu = nn.ReLU(inplace=inplace)

    def forward(self, x):
        outputs = self._relu(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class ReLU6(Module):
    """This function is ReLU6.

    The function return the following results:
      - ReLU6(x)=min(max(0,x),6)

    Parameters
    ----------
    x : Tensor
        Support input type ``float``, ``double``, ``int32``, ``int64``, ``uint8``, ``int16``, or ``int8``.

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.ReLU6()(net)

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    """

    def __init__(self):
        super(ReLU6, self).__init__()
        self._built = True
        self._relu6 = nn.ReLU6()

    def forward(self, x):
        outputs = self._relu6(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class LeakyReLU(Module):
    r"""Applies the element-wise function:

    .. math::
        \text{LeakyReLU}(x) = \max(0, x) + negative\_slope * \min(0, x)

    Parameters
    ----------
    negative_slope : float
        Controls the angle of the negative slope. Default: 1e-2
    name : str
        The function name (optional).

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.LeakyReLU(alpha=0.5)(net)

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    References
    ----------
    - `Rectifier Nonlinearities Improve Neural Network Acoustic Models [A. L. Maas et al., 2013] <https://ai.stanford.edu/~amaas/papers/relu_hybrid_icml2013_final.pdf>`__

    """

    def __init__(self, negative_slope=0.01):
        super(LeakyReLU, self).__init__()
        self._built = True
        self.negative_slope = negative_slope
        self._leakyrelu = nn.LeakyReLU(negative_slope=self.negative_slope)

    def forward(self, x):
        outputs = self._leakyrelu(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class PRelu(Module):
    r"""Applies the element-wise function:

    .. math::
        \text{PReLU}(x) = \max(0,x) + a * \min(0,x)

    Parameters
    ----------
    num_parameters : int
        number of `a` to learn.  1, or the number of channels at input. Default: 1
    init : float
        the initial value of `a`. Default: 0.25
    data_format : str
        Data format that specifies the layout of input. It may be 'channels_last' or 'channels_first'. Default is 'channels_last'.
    name : None or str
        A unique layer name.

    Examples
    -----------
    >>> inputs = tlx.nn.Input([10, 5, 10])
    >>> prelulayer = tlx.nn.PRelu(num_parameters=5, init=0.25, data_format='channels_first')(inputs)

    References
    -----------
    - `Delving Deep into Rectifiers: Surpassing Human-Level Performance on ImageNet Classification <http://arxiv.org/abs/1502.01852>`__
    - `Convolutional Deep Belief Networks on CIFAR-10 [A. Krizhevsky, 2010] <http://www.cs.utoronto.ca/~kriz/conv-cifar10-aug2010.pdf>`__

    """

    def __init__(
        self,
        num_parameters=1,
        init=0.25,
        data_format="channels_first",
        name=None,
    ):
        super(PRelu, self).__init__(name)
        self.num_parameters = num_parameters
        self.init = init
        self.data_format = data_format
        self.build()
        self._built = True

    def __repr__(self):
        s = "{classname}("
        s += "num_parameters={num_parameters},"
        s += "init={init},"
        s += "name={name}"
        s += ")"
        return s.format(classname=self.__class__.__name__, **self.__dict__)

    def build(self):
        init = F.constant
        w_shape = (self.num_parameters,)
        self.alpha = self._get_weights(
            "alpha", shape=w_shape, init=init, init_num=self.init
        )
        self.prelu = nn.PReLU(data_format=self.data_format)

    def forward(self, inputs):
        output = self.prelu(inputs, self.alpha)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, output)
            self._nodes_fixed = True
        return output


@ACTIVATION_LAYERS.register_module()
class RReLU(Module):
    def __init__(self, lower=0.125, upper=1 / 3, inplace=True, **kwargs):
        super(RReLU, self).__init__(**kwargs)
        self.lower = lower
        self.upper = upper
        self._built = True
        self._RReLU = nn.RReLU(lower=self.lower, upper=self.upper)

    def forward(self, inputs):
        outputs = self._RReLU(inputs, self.is_train)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(inputs, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class ELU(Module):
    r"""Applies the element-wise function:

    .. math::
        \text{ELU}(x) = \begin{cases}
        x, & \text{ if } x > 0\\
        \alpha * (\exp(x) - 1), & \text{ if } x \leq 0
        \end{cases}

    Parameters
    ----------
    alpha : float
        the :math:`\alpha` value for the ELU formulation. Default: 1.0
    name : str
        The function name (optional).

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.ELU(alpha=0.5)(net)

    """

    def __init__(self, alpha=1.0):
        super(ELU, self).__init__()
        self._built = True
        self.alpha = alpha
        self._elu = nn.ELU(alpha=alpha)

    def forward(self, x):
        outputs = self._elu(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class Sigmoid(Module):
    """Computes sigmoid of x element-wise.
    Formula for calculating sigmoid(x) = 1/(1+exp(-x))

    Parameters
    ----------
    x : Tensor
        Support input type ``float``, ``double``, ``int32``, ``int64``, ``uint8``, ``int16``, or ``int8``.

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.Sigmoid()(net)

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    """

    def __init__(self):
        super(Sigmoid, self).__init__()
        self._built = True
        self._sigmoid = nn.Sigmoid()

    def forward(self, x):
        outputs = self._sigmoid(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class Tanh(Module):
    """Applies the Hyperbolic Tangent (Tanh) function element-wise.

    Parameters
    ----------
    x : Tensor
        Support input type ``float``, ``double``, ``int32``, ``int64``, ``uint8``, ``int16``, or ``int8``.

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.Tanh()(net)

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    """

    def __init__(self):
        super(Tanh, self).__init__()
        self._built = True
        self._tanh = nn.Tanh()

    def forward(self, x):
        outputs = self._tanh(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class Softmax(Module):
    """Applies the Softmax function to an n-dimensional input Tensor rescaling them so that the elements of the n-dimensional output Tensor lie in the range [0,1] and sum to 1.

    Parameters
    ----------
    axis : int
         A dimension along which Softmax will be computed

    Examples
    --------
    >>> net = tlx.nn.Input([10, 200])
    >>> net = tlx.nn.Softmax()(net)

    Returns
    -------
    Tensor
        A ``Tensor`` in the same type as ``x``.

    """

    def __init__(self, axis=-1):
        super(Softmax, self).__init__()
        self._built = True
        self.axis = axis
        self._softmax = nn.Softmax(axis)

    def forward(self, x):
        outputs = self._softmax(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class SiLU(Module):
    def __init__(self):
        super(SiLU, self).__init__()
        self._built = True

        self._silu = nn.SiLU()

    def forward(self, x):
        outputs = self._silu(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs


@ACTIVATION_LAYERS.register_module()
class Gelu(Module):
    def __init__(self):
        super(Gelu, self).__init__()
        self._built = True

        self._GeLU = nn.GeLU()

    def forward(self, x):
        outputs = self._GeLU(x)

        if not self._nodes_fixed and self._build_graph:
            self._add_node(x, outputs)
            self._nodes_fixed = True
        return outputs
