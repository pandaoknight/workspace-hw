from .two_stage_detector import TwoStageDetector
from algicm.registry.common import MODELS
import algicm.models.backend.functional as F
import copy


@MODELS.register_module()
class FasterRCNN(TwoStageDetector):
    r"""Implementation of YOLO Series

    Args:
        backbone (:obj:`ConfigDict` or dict): The backbone config.
        neck (:obj:`ConfigDict` or dict): The neck config.
        bbox_head (:obj:`ConfigDict` or dict): The bbox head config.
        train_cfg (:obj:`ConfigDict` or dict, optional): The training config
            of YOLO. Defaults to None.
        test_cfg (:obj:`ConfigDict` or dict, optional): The testing config
            of YOLO. Defaults to None.
        data_preprocessor (:obj:`ConfigDict` or dict, optional): Config of
            :class:`DetDataPreprocessor` to process the input data.
            Defaults to None.
        init_cfg (:obj:`ConfigDict` or list[:obj:`ConfigDict`] or dict or
            list[dict], optional): Initialization config dict.
            Defaults to None.
        use_syncbn (bool): whether to use SyncBatchNorm. Defaults to True.
    """

    def __init__(self,
                 backbone,
                 neck,
                 rpn_head,
                 roi_head,
                 train_cfg=None,
                 test_cfg=None,
                 data_preprocessor=None,
                 init_cfg=None,
                 proposals=None,
                 gt_masks=None,
                 gt_bboxes_ignore=None):
        self.proposals = proposals
        self.gt_masks = gt_masks
        self.gt_bboxes_ignore = gt_bboxes_ignore
        super().__init__(
            backbone=backbone,
            neck=neck,
            rpn_head=rpn_head,
            roi_head=roi_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            data_preprocessor=data_preprocessor,
            init_cfg=init_cfg,
        )

    def train_step(self, data, optim_wrapper, **kwargs):
        with optim_wrapper.optim_context(self):
            img_meta = copy.deepcopy(data)
            data = self.data_preprocessor(data, True)
            # extract image and label
            img, gt_bboxes, gt_labels = (
                data["img"],
                data["gt_bboxes"],
                data["gt_bboxes_labels"],
            )

            output = self(img)

            losses = dict()

            # RPN forward and loss
            if self.with_rpn:
                proposal_cfg = self.train_cfg.get('rpn_proposal',
                                                  self.test_cfg["rpn"])
                rpn_losses, proposal_list = self.rpn_head.forward_train(
                    output,
                    img_meta,
                    gt_bboxes,
                    gt_labels=None,
                    gt_bboxes_ignore=self.gt_bboxes_ignore,
                    proposal_cfg=proposal_cfg,
                    **kwargs)
                losses.update(rpn_losses)
            else:
                proposal_list = self.proposals

            roi_losses = self.roi_head.forward_train(output, img_meta,
                                                     proposal_list, gt_bboxes,
                                                     gt_labels,
                                                     self.gt_bboxes_ignore,
                                                     self.gt_masks, **kwargs)
            losses.update(roi_losses)

        parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        optim_wrapper.update_params(parsed_losses)
        return log_vars

    def val_step(self, data):
        """``BaseModel`` implements ``test_step`` the same as ``val_step``.

        Args:
            data (dict or tuple or list): Data sampled from dataset.

        Returns:
            list: The predictions of given data.
        """
        img_meta = copy.deepcopy(data)
        data = self.data_preprocessor(data, False)
        img = data["img"]
        output = self(img)
        proposal_list = self.rpn_head.simple_test_rpn(output, img_meta)
        sample = self.roi_head.simple_test(output, proposal_list, img_meta)
        data["pred_instances"] = sample
        gts = [
            dict(bboxes=F.convert_to_numpy(i), labels=F.convert_to_numpy(j))
            for i, j in zip(data["gt_bboxes"], data["gt_bboxes_labels"])
        ]
        data["gts"] = gts
        return data

    def test_step(self, data, rescale=False):
        """``BaseModel`` implements ``test_step`` the same as ``val_step``.

        Args:
            data (dict or tuple or list): Data sampled from dataset.

        Returns:
            list: The predictions of given data.
        """
        img_meta = copy.deepcopy(data)
        data = self.data_preprocessor(data, False)
        output = self(data["img"])
        proposal_list = self.rpn_head.simple_test_rpn(output, img_meta)
        sample = self.roi_head.simple_test(output,
                                           proposal_list,
                                           img_meta,
                                           rescale=rescale)
        data["pred_instances"] = sample
        if data.get("gt_bboxes") is not None:
            gts = [
                dict(bboxes=F.convert_to_numpy(bboxes),
                     labels=F.convert_to_numpy(bboxe_labels))
                for bboxes, bboxe_labels in zip(data["gt_bboxes"],
                                                data["gt_bboxes_labels"])
            ]
            data["gts"] = gts
        return data

    def verify(self, data, optim_wrapper):
        """BaseModel`` implements ``verify``. Given Input data, verify all parameters are initialized."""
        self.train_step(data, optim_wrapper)