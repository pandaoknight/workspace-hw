#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   encoder_decoder.py
@Time    :   2023/08/10 13:38:55
@Author  :   htx 
"""

import numpy as np
import algicm.models.backend.functional as F
from algicm.models.backend.core import BaseModel, ModuleList
from algicm.registry.common import MODELS
from typing import List, Optional
from algicm.models.backend.utils import int64
from algicm.transform.annotation.mask import Mask


def add_prefix(inputs, prefix):
    """Add prefix for dict.

    Args:
        inputs (dict): The input dict with str keys.
        prefix (str): The prefix to add.

    Returns:

        dict: The dict with keys updated with ``prefix``.
    """

    outputs = dict()
    for name, value in inputs.items():
        outputs[f"{prefix}.{name}"] = value

    return outputs


@MODELS.register_module()
class EncoderDecoder(BaseModel):
    """Encoder Decoder segmentors.

    EncoderDecoder typically consists of backbone, decode_head, auxiliary_head.
    Note that auxiliary_head is only used for deep supervision during training,
    which could be dumped during inference.

    1. The ``loss`` method is used to calculate the loss of model,
    which includes two steps: (1) Extracts features to obtain the feature maps
    (2) Call the decode head loss function to forward decode head model and
    calculate losses.

    .. code:: text

     loss(): extract_feat() -> _decode_head_forward_train() -> _auxiliary_head_forward_train (optional)
     _decode_head_forward_train(): decode_head.loss()
     _auxiliary_head_forward_train(): auxiliary_head.loss (optional)

    2. The ``predict`` method is used to predict segmentation results,
    which includes two steps: (1) Run inference function to obtain the list of
    seg_logits (2) Call post-processing function to obtain list of
    ``SegDataSampel`` including ``pred_sem_seg`` and ``seg_logits``.

    .. code:: text

     predict(): inference() -> postprocess_result()
     infercen(): whole_inference()/slide_inference()
     whole_inference()/slide_inference(): encoder_decoder()
     encoder_decoder(): extract_feat() -> decode_head.predict()

    3. The ``_forward`` method is used to output the tensor by running the model,
    which includes two steps: (1) Extracts features to obtain the feature maps
    (2)Call the decode head forward function to forward decode head model.

    .. code:: text

     _forward(): extract_feat() -> _decode_head.forward()

    Args:

        backbone (ConfigType): The config for the backnone of segmentor.
        decode_head (ConfigType): The config for the decode head of segmentor.
        neck (OptConfigType): The config for the neck of segmentor.
            Defaults to None.
        auxiliary_head (OptConfigType): The config for the auxiliary head of
            segmentor. Defaults to None.
        train_cfg (OptConfigType): The config for training. Defaults to None.
        test_cfg (OptConfigType): The config for testing. Defaults to None.
        data_preprocessor (dict, optional): The pre-process config of
            :class:`BaseDataPreprocessor`.
        pretrained (str, optional): The path for pretrained model.
            Defaults to None.
        init_cfg (dict, optional): The weight initialized config for
            :class:`BaseModule`.
    """  # noqa: E501

    def __init__(
            self,
            backbone,
            decode_head,
            neck=None,
            auxiliary_head=None,
            train_cfg=None,
            test_cfg=dict(mode="whole"),
            data_preprocessor=None,
            init_cfg=None,
    ):
        super().__init__(data_preprocessor=data_preprocessor,
                         init_cfg=init_cfg)
        self.backbone = MODELS.build(backbone)
        if neck is not None:
            self.neck = MODELS.build(neck)
        self._init_decode_head(decode_head)
        self._init_auxiliary_head(auxiliary_head)

        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

        assert self.with_decode_head

    @property
    def with_auxiliary_head(self):
        """bool: whether the segmentor has auxiliary head"""
        return hasattr(self,
                       "auxiliary_head") and self.auxiliary_head is not None

    @property
    def with_neck(self):
        """bool: whether the segmentor has neck"""
        return hasattr(self, "neck") and self.neck is not None

    @property
    def with_decode_head(self):
        """bool: whether the segmentor has decode head"""
        return hasattr(self, "decode_head") and self.decode_head is not None

    def _init_decode_head(self, decode_head) -> None:
        """Initialize ``decode_head``"""
        self.decode_head = MODELS.build(decode_head)
        self.align_corners = self.decode_head.align_corners
        self.num_classes = self.decode_head.num_classes
        self.out_channels = self.decode_head.out_channels

    def _init_auxiliary_head(self, auxiliary_head) -> None:
        """Initialize ``auxiliary_head``"""
        if auxiliary_head is not None:
            if isinstance(auxiliary_head, list):
                self.auxiliary_head = ModuleList()
                for head_cfg in auxiliary_head:
                    self.auxiliary_head.append(MODELS.build(head_cfg))
            else:
                self.auxiliary_head = MODELS.build(auxiliary_head)

    def _forward_decode(self, x):
        x = self.backbone(x)
        if self.with_neck:
            x = self.neck(x)

        seg_logits_decode = self.decode_head(x)
        return seg_logits_decode

    def forward(self, inputs):
        """Extract features from images."""
        x = self.backbone(inputs)
        if self.with_neck:
            x = self.neck(x)

        seg_logits_decode = self.decode_head(x)
        outs = []
        if self.with_auxiliary_head:
            if isinstance(self.auxiliary_head, ModuleList):
                for aux_head in self.auxiliary_head:
                    output = aux_head(x)
                    outs.append(output)
            else:
                output = self.auxiliary_head(x)
                outs.append(output)
        return seg_logits_decode, tuple(outs)

    def train_step(self, data_batch, optim_wrapper):
        loss_dict = dict()
        with optim_wrapper.optim_context(self):
            data = self.data_preprocessor(data_batch, True)
            # extract image and label
            img, gt_seg = data["img"], data["gt_seg"]
            # image_class_label format is [tensor, ...],  need to be stacked with last dims
            seg_logits_decode, seg_logits_aux = self(img)
            # for decode head
            gt_seg = F.conver_dtype(gt_seg, int64)
            loss_decode = self.decode_head.compute_loss(
                seg_logits_decode, gt_seg)
            loss_dict.update(add_prefix(loss_decode, "decode"))
            # for aux head

            if self.with_auxiliary_head:
                if isinstance(self.auxiliary_head, ModuleList):
                    for idx, (seg_logits_aux_i, aux_head) in enumerate(
                            zip(seg_logits_aux, self.auxiliary_head)):
                        loss_aux_i = aux_head.compute_loss(
                            seg_logits_aux_i, gt_seg)
                        loss_dict.update(add_prefix(loss_aux_i, f"aux_{idx}"))
                else:
                    loss_aux = self.auxiliary_head.compute_loss(
                        seg_logits_aux[0], gt_seg)
                    loss_dict.update(add_prefix(loss_aux, f"aux"))

        parsed_losses, log_vars = self.parse_losses(loss_dict)  # type: ignore
        optim_wrapper.update_params(parsed_losses)
        return log_vars

    def val_step(self, data_batch):
        data = self.data_preprocessor(data_batch, True)
        img, gt_seg = data["img"], data["gt_seg"]
        seg_logit = self.whole_inference(img)
        seg_logit = F.convert_to_numpy(self._transpose(seg_logit))
        gt_seg = F.convert_to_numpy(self._transpose(gt_seg))
        return dict(preds=F.convert_to_numpy(seg_logit),
                    gt_seg=F.convert_to_numpy(gt_seg))

    def test_step(self, data_batch, rescale=False):
        data = self.data_preprocessor(data_batch, True)
        img, gt_seg = data["img"], data.get("gt_seg", None)

        if self.test_cfg.get("mode", "whole"):
            seg_logit = self.whole_inference(img)
        else:
            seg_logit = self.slide_inference(img)

        seg_logit_list = self.post_process(seg_logit, data["data_meta"])
        if gt_seg is not None:
            seg_map_list = self.post_process(data["gt_seg"], data["data_meta"])
            return dict(preds=seg_logit_list, gt_seg=seg_map_list)
        else:
            return dict(preds=seg_logit_list)

    def post_process(self, preds, data_metas):
        assert len(preds) == len(
            data_metas), "Number of images and data meta should be same."
        preds_list = []

        preds = self._transpose(preds)
        preds = F.convert_to_numpy(preds)
        for pred, meta in zip(preds, data_metas):
            for t in reversed(meta):
                if t["type"] == "RandomFlip":
                    pred = self._flip(pred, t["records"])
                if t["type"] == "Resize":
                    pred = self._resize(pred, t["records"])
            preds_list.append(pred)
        return preds_list

    def _transpose(self, masks):
        """Transpose mask
        Args:
            mask (tensor): shape [B,C,H,W] or [B,H,W]
        """
        if len(masks.shape) == 4:
            # tranpose from [B,C,H,W]->[B,H,W,C]
            masks = F.transpose(masks, [0, 2, 3, 1])
        return masks

    def _flip(self, pred, flip_record):
        """Flip seg map back.
        Args:
            pred(np.ndarray): seg map of prediction, with shape (H,W,C).
            flip_record(dict): store flip direction.


        """

        direction = flip_record["flip"]
        return Mask.flip_(pred, direction)

    def _resize(self, pred, pred_record):
        # resize back
        scale_factor = pred_record["scale_factor"]  # H,W
        h_scale, w_scale = scale_factor
        h_scale_o, w_scale_o = 1 / h_scale, 1 / w_scale
        return Mask.resize_(pred, (h_scale_o, w_scale_o))

    def slide_inference(self, inputs):
        """Inference by sliding-window with overlap.

        If h_crop > h_img or w_crop > w_img, the small patch will be used to
        decode without padding.

        Args:
            inputs (tensor): the tensor should have a shape NxCxHxW,
                which contains all images in the batch.
            batch_img_metas (List[dict]): List of image metainfo where each may
                also contain: 'img_shape', 'scale_factor', 'flip', 'img_path',
                'ori_shape', and 'pad_shape'.
                For details on the values of these keys see
                `mmseg/datasets/pipelines/formatting.py:PackSegInputs`.

        Returns:
            Tensor: The segmentation results, seg_logits from model of each
                input image.
        """

        h_stride, w_stride = self.test_cfg.get("stride")
        h_crop, w_crop = self.test_cfg.get("crop_size")
        batch_size, _, h_img, w_img = inputs.shape
        out_channels = self.out_channels
        h_grids = max(h_img - h_crop + h_stride - 1, 0) // h_stride + 1
        w_grids = max(w_img - w_crop + w_stride - 1, 0) // w_stride + 1
        preds = F.zeros([batch_size, out_channels, h_img, w_img],
                        dtype=inputs.dtype,
                        device=inputs.device)
        count_mat = F.zeros([batch_size, 1, h_img, w_img],
                            dtype=inputs.dtype,
                            device=inputs.device)
        for h_idx in range(h_grids):
            for w_idx in range(w_grids):
                y1 = h_idx * h_stride
                x1 = w_idx * w_stride
                y2 = min(y1 + h_crop, h_img)
                x2 = min(x1 + w_crop, w_img)
                y1 = max(y2 - h_crop, 0)
                x1 = max(x2 - w_crop, 0)
                crop_img = inputs[:, :, y1:y2, x1:x2]
                # the output of encode_decode is seg logits tensor map
                # with shape [N, C, H, W]
                crop_seg_logit = self._forward_decode(crop_img)
                preds += F.pad(crop_seg_logit,
                               (int(x1), int(preds.shape[3] - x2), int(y1),
                                int(preds.shape[2] - y2)))

                count_mat[:, :, y1:y2, x1:x2] += 1
        assert (count_mat == 0).sum() == 0
        seg_logits = preds / count_mat

        return seg_logits

    def whole_inference(self, inputs, batch_img_metas=None):
        """Inference with full image.

        Args:
            inputs (Tensor): The tensor should have a shape NxCxHxW, which
                contains all images in the batch.
            batch_img_metas (List[dict]): List of image metainfo where each may
                also contain: 'img_shape', 'scale_factor', 'flip', 'img_path',
                'ori_shape', and 'pad_shape'.
                For details on the values of these keys see
                `mmseg/datasets/pipelines/formatting.py:PackSegInputs`.

        Returns:
            Tensor: The segmentation results, seg_logits from model of each
                input image.
        """

        seg_logits = self._forward_decode(inputs)

        return seg_logits

    def aug_test(self, inputs, batch_img_metas, rescale=True):
        """Test with augmentations.

        Only rescale=True is supported.
        """
        # aug_test rescale all imgs back to ori_shape for now
        assert rescale
        # to save memory, we get augmented seg logit inplace
        seg_logit = self.inference(inputs[0], batch_img_metas[0], rescale)
        for i in range(1, len(inputs)):
            cur_seg_logit = self.inference(inputs[i], batch_img_metas[i],
                                           rescale)
            seg_logit += cur_seg_logit
        seg_logit /= len(inputs)
        seg_pred = seg_logit.argmax(dim=1)
        # unravel batch dim
        seg_pred = list(seg_pred)
        return seg_pred

    def verify(self, data, optim_wrapper):
        self.train_step(data, optim_wrapper)
