from typing import List, Tuple, Union
from algicm.registry.common import MODELS
from algicm.models.backend.core import BaseModel


@MODELS.register_module()
class SingleStageDetector(BaseModel):
    """Base class for single-stage detectors.

    Single-stage detectors directly and densely predict bounding boxes on the
    output features of the backbone+neck.
    """

    def __init__(
        self,
        backbone,
        neck=None,
        head=None,
        train_cfg=None,
        test_cfg=None,
        data_preprocessor=None,
        init_cfg=None,
    ) -> None:
        super().__init__(data_preprocessor=data_preprocessor,
                         init_cfg=init_cfg)
        self.backbone = MODELS.build(backbone)
        if neck is not None:
            self.neck = MODELS.build(neck)
        head.update(train_cfg=train_cfg)
        head.update(test_cfg=test_cfg)
        if head is not None:
            self.head = MODELS.build(head)
        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

    @property
    def with_neck(self) -> bool:
        """bool: whether the detector has a neck"""
        return hasattr(self, "neck") and self.neck is not None

    def forward(self, x):
        x = self.backbone(x)
        if self.with_neck:
            x = self.neck(x)
        outs = self.head(x)
        return outs

    def train_step(self, data, optim_wrapper):
        # with optim_wrapper.optim_context(self):
        #     data = self.data_preprocessor(data, True)
        #     # extract image and label
        #     img, gt_bboxes, gt_labels = (
        #         data["img"],
        #         data["gt_bboxes"],
        #         data["gt_labels"],
        #     )
        #     output = self(img)
        #     losses = self.head.compute_loss(output, gt_bboxes, gt_labels)  # type: ignore
        # parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        # optim_wrapper.update_params(parsed_losses)
        # return log_vars
        raise NotImplementedError

    def val_step(self, data):
        raise NotImplementedError

    def test_step(self, data):
        raise NotImplementedError

    def loss(self, batch_inputs, batch_data_samples) -> Union[dict, list]:
        """Calculate losses from a batch of inputs and data samples.

        Args:
            batch_inputs (Tensor): Input images of shape (N, C, H, W).
                These should usually be mean centered and std scaled.
            batch_data_samples (list[:obj:`DetDataSample`]): The batch
                data samples. It usually includes information such
                as `gt_instance` or `gt_panoptic_seg` or `gt_sem_seg`.

        Returns:
            dict: A dictionary of loss components.
        """
        x = self.extract_feat(batch_inputs)
        losses = self.head.loss(x, batch_data_samples)
        return losses

    def predict(self, batch_inputs, batch_data_samples, rescale: bool = True):
        """Predict results from a batch of inputs and data samples with post-
        processing.

        Args:
            batch_inputs (Tensor): Inputs with shape (N, C, H, W).
            batch_data_samples (List[:obj:`DetDataSample`]): The Data
                Samples. It usually includes information such as
                `gt_instance`, `gt_panoptic_seg` and `gt_sem_seg`.
            rescale (bool): Whether to rescale the results.
                Defaults to True.

        Returns:
            list[:obj:`DetDataSample`]: Detection results of the
            input images. Each DetDataSample usually contain
            'pred_instances'. And the ``pred_instances`` usually
            contains following keys.

                - scores (Tensor): Classification scores, has a shape
                    (num_instance, )
                - labels (Tensor): Labels of bboxes, has a shape
                    (num_instances, ).
                - bboxes (Tensor): Has a shape (num_instances, 4),
                    the last dimension 4 arrange as (x1, y1, x2, y2).
        """
        x = self.extract_feat(batch_inputs)
        results_list = self.head.predict(x,
                                         batch_data_samples,
                                         rescale=rescale)
        batch_data_samples = self.add_pred_to_datasample(
            batch_data_samples, results_list)
        return batch_data_samples

    def _forward(self, batch_inputs, batch_data_samples=None):
        """Network forward process. Usually includes backbone, neck and head
        forward without any post-processing.

         Args:
            batch_inputs (Tensor): Inputs with shape (N, C, H, W).
            batch_data_samples (list[:obj:`DetDataSample`]): Each item contains
                the meta information of each image and corresponding
                annotations.

        Returns:
            tuple[list]: A tuple of features from ``head`` forward.
        """
        x = self.extract_feat(batch_inputs)
        results = self.head.forward(x)
        return results

    def extract_feat(self, batch_inputs):
        """Extract features.

        Args:
            batch_inputs (Tensor): Image tensor with shape (N, C, H ,W).

        Returns:
            tuple[Tensor]: Multi-level features that may have
            different resolutions.
        """
        x = self.backbone(batch_inputs)
        if self.with_neck:
            x = self.neck(x)
        return x
