#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@File    :   __init__.py
@Time    :   2023/03/08 18:18:34
@Author  :   htx 
"""

from .image_cls import ImageClassifier
from .yolo_detector import YOLODetector
from .encoder_decoder import EncoderDecoder
from .faster_rcnn import FasterRCNN