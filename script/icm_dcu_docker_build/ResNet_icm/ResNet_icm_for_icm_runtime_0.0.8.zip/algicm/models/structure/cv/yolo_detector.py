from .single_stage_detector import SingleStageDetector
from algicm.registry.common import MODELS
import algicm.models.backend.functional as F


@MODELS.register_module()
class YOLODetector(SingleStageDetector):
    r"""Implementation of YOLO Series

    Args:
        backbone (:obj:`ConfigDict` or dict): The backbone config.
        neck (:obj:`ConfigDict` or dict): The neck config.
        bbox_head (:obj:`ConfigDict` or dict): The bbox head config.
        train_cfg (:obj:`ConfigDict` or dict, optional): The training config
            of YOLO. Defaults to None.
        test_cfg (:obj:`ConfigDict` or dict, optional): The testing config
            of YOLO. Defaults to None.
        data_preprocessor (:obj:`ConfigDict` or dict, optional): Config of
            :class:`DetDataPreprocessor` to process the input data.
            Defaults to None.
        init_cfg (:obj:`ConfigDict` or list[:obj:`ConfigDict`] or dict or
            list[dict], optional): Initialization config dict.
            Defaults to None.
        use_syncbn (bool): whether to use SyncBatchNorm. Defaults to True.
    """

    def __init__(
        self,
        backbone,
        neck,
        head,
        train_cfg=None,
        test_cfg=None,
        data_preprocessor=None,
        init_cfg=None,
    ):
        super().__init__(
            backbone=backbone,
            neck=neck,
            head=head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            data_preprocessor=data_preprocessor,
            init_cfg=init_cfg,
        )

    def train_step(self, data, optim_wrapper):
        with optim_wrapper.optim_context(self):
            data = self.data_preprocessor(data, True)
            # extract image and label
            img, gt_bboxes, gt_labels = (
                data["img"],
                data["gt_bboxes"],
                data["gt_bboxes_labels"],
            )

            output = self(img)
            losses = self.head.compute_loss(
                *output, gt_bboxes, gt_labels,
                [img.shape[-2], img.shape[-1]])  # type: ignore
        parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        optim_wrapper.update_params(parsed_losses)
        return log_vars

    def val_step(self, data):
        """``BaseModel`` implements ``test_step`` the same as ``val_step``.

        Args:
            data (dict or tuple or list): Data sampled from dataset.

        Returns:
            list: The predictions of given data.
        """
        data = self.data_preprocessor(data, False)
        img = self(data["img"])
        sample = self.head.predict_by_feat(*img, data_meta=data)
        data["pred_instances"] = sample
        gts = [
            dict(bboxes=F.convert_to_numpy(i), labels=F.convert_to_numpy(j))
            for i, j in zip(data["gt_bboxes"], data["gt_bboxes_labels"])
        ]
        data["gts"] = gts
        return data

    def test_step(self, data, rescale=True):
        """``BaseModel`` implements ``test_step`` the same as ``val_step``.

        Args:
            data (dict or tuple or list): Data sampled from dataset.

        Returns:
            list: The predictions of given data.
        """
        data = self.data_preprocessor(data, False)
        img = self(data["img"])
        sample = self.head.predict_by_feat(*img,
                                           data_meta=data,
                                           rescale=rescale)
        data["pred_instances"] = sample
        if data.get("gt_bboxes") is not None:
            gts = [
                dict(bboxes=F.convert_to_numpy(bboxes),
                     labels=F.convert_to_numpy(bboxe_labels))
                for bboxes, bboxe_labels in zip(data["gt_bboxes"],
                                                data["gt_bboxes_labels"])
            ]
            data["gts"] = gts
        return data

    def verify(self, data, optim_wrapper):
        """BaseModel`` implements ``verify``. Given Input data, verify all parameters are initialized."""
        self.train_step(data, optim_wrapper)
