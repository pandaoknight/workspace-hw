#!/usr/bin/env python
# -*- coding: utf-8 -*-

import algicm.models.backend.functional as F
from algicm.registry.common import MODELS
from algicm.models.backend.core import BaseModel


@MODELS.register_module()
class RelationModel(BaseModel):

    def __init__(self, data_preprocessor, backbone, neck, head, init_cfg=None):
        super().__init__(
            init_cfg=init_cfg,
            data_preprocessor=data_preprocessor,
        )

        backbone = MODELS.build(backbone)
        neck = MODELS.build(neck)
        head = MODELS.build(head)

        self.backbone = backbone
        self.neck = neck
        self.head = head

    @property
    def with_neck(self) -> bool:
        """Whether the classifier has a neck."""
        return hasattr(self, "neck") and self.neck is not None

    @property
    def with_head(self) -> bool:
        """Whether the classifier has a head."""
        return hasattr(self, "head") and self.head is not None

    def forward(self, data):
        """The unified entry for a forward process in both training and test.


        Args:
            inputs (torch.Tensor): The input tensor with shape
                (N, C, ...) in general.


        Returns:
            outputs (torch.Tensor): The output of runing forward impl
        """
        sub_obj = data["sub_obj"]
        x = self.backbone(**data)  # 经过bert
        if self.with_neck:
            x = self.neck(x)  # 获得last_hiddenstate
        if self.with_head:
            x = self.contate(x, sub_obj)  #
            x = self.head(x)  # get last latent
        return x

    def contate(self, sequence_output, sub_obj):  # 将关系和向量对应
        sub_obj_outputs = []
        for idx, (seq,
                  sub_obj_index) in enumerate(zip(sequence_output, sub_obj)):
            sub_obj_output = F.concat([
                F.expand_dims(seq[sub_obj_index[0]], axis=0),
                F.expand_dims(seq[sub_obj_index[1]], axis=0)
            ], -1)
            sub_obj_outputs.append(sub_obj_output)
        sub_obj_outputs = F.concat(sub_obj_outputs, 0)
        return sub_obj_outputs

    def train_step(self, data, optim_wrapper):
        with optim_wrapper.optim_context(self):
            data = self.data_preprocessor(data, True)

            inputs = dict(
                inputs=data["text"],
                token_type_ids=data["token_type_ids"],
                attention_mask=data["attention_mask"],
                sub_obj=data["sub_obj"],
            )
            output = self(inputs)
            losses = self.head.compute_loss(output,
                                            F.reshape(data["rel_label"],
                                                      -1))  # type: ignore
        parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        optim_wrapper.update_params(parsed_losses)

        return log_vars

    def val_step(self, data):
        data = self.data_preprocessor(data, False)

        inputs = dict(
            inputs=data["text"],
            token_type_ids=data["token_type_ids"],
            attention_mask=data["attention_mask"],
            sub_obj=data["sub_obj"],
        )
        preds = self(inputs)

        preds_np = F.convert_to_numpy(F.argmax(preds, -1)).tolist()
        labels_np = F.convert_to_numpy(data["rel_label"])
        labels_np = labels_np.reshape(-1)
        return dict(preds=preds_np, labels=labels_np)

    def test_step(self, data, rescale=False):
        data = self.data_preprocessor(data, False)

        inputs = dict(
            inputs=data["text"],
            token_type_ids=data["token_type_ids"],
            attention_mask=data["attention_mask"],
            sub_obj=data["sub_obj"],
        )
        preds = self(inputs)

        preds_np = F.convert_to_numpy(F.argmax(preds, -1)).tolist()
        outputs = dict(preds=preds_np)
        if "rel_label" in data:
            labels_np = F.convert_to_numpy(data["rel_label"])
            labels_np = labels_np.reshape(-1).tolist()
            outputs.update(dict(labels=labels_np))
        return outputs

    def merge_results(self, results_list):
        """Merge results of relation recognition results.
        Merge results according its id. Whether to use its original text is undetermined.
        For a single result of text relation recognition is :
            relations_dict = dict(
            id=data["id"],  # text id
            relationName=pred_name, # relation label name
            subjectSpan=subject_span, # text of subject entity
            objectSpan=object_span, # text of object entity
            subjectMention=[sub_start, sub_end], # index range of subject entity
            objectMention=[obj_start, obj_end]) # index range of object entity
        Output format should contains:text, entities, relations
        """
        output_dict = {}
        for result in results_list:
            id = result.get("id")
            text_id = result["index"]
            text = result["text"]
            # only a pair of entities
            entity_list = result[
                "entity"]  # [start index, end index, cateogry, start index, end index, cateogry ]
            # if not exist, create an empty dict.
            if str(text_id) not in output_dict:
                output_dict[str(text_id)] = dict(text=result["text"],
                                                 id=id,
                                                 entities=[],
                                                 relations=[])
            # format entities and relations is not changed.
            entities = [
                dict(
                    span=text[entity_list[0]:entity_list[1]],
                    labelName=entity_list[2],
                    mention=[entity_list[0], entity_list[1]],
                ),
                dict(
                    span=text[entity_list[3]:entity_list[4]],
                    labelName=entity_list[5],
                    mention=[entity_list[3], entity_list[4]],
                ),
            ]
            # check wheter entity is in list
            for ent in entities:
                if ent not in output_dict[str(text_id)]["entities"]:
                    output_dict[str(text_id)]["entities"].append(ent)

            # add relation
            if result.get("relations", None) is not None:
                output_dict[str(text_id)]["relations"].append(
                    result["relations"])

        # put all data in annotations:
        # eg: {"annotations":[]}
        output_list = [v for v in output_dict.values()]
        return dict(annotations=output_list)

    def verify(self, data, optim_wrapper):
        self.train_step(data, optim_wrapper)