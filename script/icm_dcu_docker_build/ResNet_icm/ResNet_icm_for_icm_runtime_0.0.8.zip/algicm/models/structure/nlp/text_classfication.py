#!/usr/bin/env python
# -*- coding: utf-8 -*-

# File    :   text_classfication.py
# Time    :   2023/07/31 09:45:07
# Author  :   Tianqi

from algicm.registry.common import MODELS
from algicm.models.backend.core import BaseModel
from ...backend import stack, squeeze
from algicm.registry.common import LAYERS
import algicm.models.backend.functional as F


@MODELS.register_module()
class TextClassification(BaseModel):

    def __init__(self,
                 data_preprocessor,
                 backbone,
                 neck=None,
                 head=None,
                 init_cfg=None):
        super().__init__(
            init_cfg=init_cfg,
            data_preprocessor=data_preprocessor,
        )

        backbone = MODELS.build(backbone)
        if neck is not None:
            neck = MODELS.build(neck)
        if head is not None:
            head = MODELS.build(head)
        self.backbone = backbone
        self.neck = neck
        self.head = head

    @property
    def with_neck(self) -> bool:
        """Whether the classifier has a neck."""
        return hasattr(self, "neck") and self.neck is not None

    @property
    def with_head(self) -> bool:
        """Whether the classifier has a head."""
        return hasattr(self, "head") and self.head is not None

    def forward(self, data):
        """The unified entry for a forward process in both training and test.


        Args:
            inputs (torch.Tensor): The input tensor with shape
                (N, C, ...) in general.


        Returns:
            outputs (torch.Tensor): The output of runing forward impl
        """
        x = self.backbone(**data)
        if self.with_neck:
            x = self.neck(x)
        if self.with_head:
            x = self.head(x)  # get last latent
        return x

    def train_step(self, data, optim_wrapper):
        with optim_wrapper.optim_context(self):
            data = self.data_preprocessor(data, True)

            inputs = dict(
                inputs=data["text"],
                token_type_ids=data["token_type_ids"],
                attention_mask=data["attention_mask"],
            )
            output = self(inputs)
            losses = self.head.compute_loss(output,
                                            data["label"])  # type: ignore
        parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        optim_wrapper.update_params(parsed_losses)

        return log_vars

    def val_step(self, data):
        data = self.data_preprocessor(data, True)

        inputs = dict(
            inputs=data["text"],
            token_type_ids=data["token_type_ids"],
            attention_mask=data["attention_mask"],
        )
        output = self(inputs)
        result = dict(preds=F.convert_to_numpy(output),
                      labels=F.convert_to_numpy(data["label"]))
        return result

    def test_step(self, data, rescale=False):
        data = self.data_preprocessor(data, True)

        inputs = dict(
            inputs=data["text"],
            token_type_ids=data["token_type_ids"],
            attention_mask=data["attention_mask"],
        )
        output = self(inputs)
        if data.get('label') is not None:
            result = dict(preds=F.convert_to_numpy(output),
                          labels=F.convert_to_numpy(data["label"]))
        else:
            result = dict(preds=F.convert_to_numpy(output))
        return result

    def verify(self, data, optim_wrapper):
        self.train_step(data, optim_wrapper)
