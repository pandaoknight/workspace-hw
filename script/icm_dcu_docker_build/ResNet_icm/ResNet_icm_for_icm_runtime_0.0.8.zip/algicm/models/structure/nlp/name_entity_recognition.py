#!/usr/bin/env python
# -*- coding: utf-8 -*-

# File    :   text_classfication.py
# Time    :   2023/07/31 09:45:07
# Author  :   Tianqi

import numpy as np
from algicm.registry.common import MODELS
from algicm.models.backend.core import BaseModel
from ...backend import stack, squeeze
from algicm.models.layers import dropout
from algicm.models.backend import utils
import algicm.models.backend.functional as F


@MODELS.register_module()
class NER(BaseModel):

    def __init__(self, data_preprocessor, backbone, neck, head, init_cfg=None):
        super().__init__(
            init_cfg=init_cfg,
            data_preprocessor=data_preprocessor,
        )

        backbone = MODELS.build(backbone)
        neck = MODELS.build(neck)
        head = MODELS.build(head)
        self.backbone = backbone
        self.neck = neck
        self.head = head

    @property
    def with_neck(self) -> bool:
        """Whether the classifier has a neck."""
        return hasattr(self, "neck") and self.neck is not None

    @property
    def with_head(self) -> bool:
        """Whether the classifier has a head."""
        return hasattr(self, "head") and self.head is not None

    def forward(self, data):
        """The unified entry for a forward process in both training and test.


        Args:
            inputs (torch.Tensor): The input tensor with shape
                (N, C, ...) in general.


        Returns:
            outputs (torch.Tensor): The output of runing forward impl
        """
        x = self.backbone(**data)
        if self.with_neck:
            hidden = self.neck(x)
        if self.with_head:
            cls_score = self.head(hidden)  # get last latent
        return cls_score

    def train_step(self, data, optim_wrapper):
        with optim_wrapper.optim_context(self):
            data = self.data_preprocessor(data, True)

            inputs = dict(inputs=data["text"],
                          token_type_ids=data["token_type_ids"],
                          attention_mask=data["attention_mask"])
            cls_score = self(inputs)
            numerator, denominator = self.head.encode(
                cls_score, data["token_label"],
                F.cast(data["attention_mask"], utils.bool))
            losses = self.head.compute_loss(numerator, denominator)

        parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        optim_wrapper.update_params(parsed_losses)
        return log_vars

    def val_step(self, data):
        data = self.data_preprocessor(data, False)
        inputs = dict(inputs=data["text"],
                      token_type_ids=data["token_type_ids"],
                      attention_mask=data["attention_mask"])
        cls_score = self(inputs)  # 模型的输出
        # preds is a list of predicted token
        preds = self.head.decode(
            cls_score, F.conver_dtype(data["attention_mask"], utils.bool))

        token_label_np = F.convert_to_numpy(data["token_label"])
        attention_mask_np = F.convert_to_numpy(data["attention_mask"])

        label_list = []
        pred_list = []
        for mask, pred, label in zip(attention_mask_np, preds, token_label_np):
            mask_bool = mask.astype(np.bool_)
            label = label[mask_bool][1:-1].tolist()
            pred_list.append(pred[1:-1])
            label_list.append(label)

        return dict(preds=pred_list, labels=label_list)

    def test_step(self, data, rescale=False):
        data = self.data_preprocessor(data, False)
        inputs = dict(inputs=data["text"],
                      token_type_ids=data["token_type_ids"],
                      attention_mask=data["attention_mask"])
        cls_score = self(inputs)  # 模型的输出
        # preds is a list of predicted token
        preds = self.head.decode(
            cls_score, F.conver_dtype(data["attention_mask"], utils.bool))

        if "token_label" in data:
            token_label_np = F.convert_to_numpy(data["token_label"])
            attention_mask_np = F.convert_to_numpy(data["attention_mask"])

            label_list = []
            pred_list = []
            for mask, pred, label in zip(attention_mask_np, preds,
                                         token_label_np):
                mask_bool = mask.astype(np.bool_)
                label = label[mask_bool][1:-1].tolist()
                pred_list.append(pred[1:-1])
                label_list.append(label)
            return dict(preds=pred_list, labels=label_list)
        else:
            return dict(preds=[pred[1:-1] for pred in preds])

    def verify(self, data, optim_wrapper):
        self.train_step(data, optim_wrapper)
