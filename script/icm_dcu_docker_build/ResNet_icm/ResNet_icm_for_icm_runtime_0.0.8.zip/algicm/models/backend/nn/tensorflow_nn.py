import math
import warnings
import tensorflow as tf
import tensorflow_addons as tfa

from math import floor, ceil

from tensorflow.python.framework import ops
from tensorflow.python.ops import math_ops, array_ops
from tensorflow.python.training import moving_averages

from math import floor, ceil
from collections import abc
from ..functional.tensorflow_functional import (
    batch_normalization,
    group_normalization,
    instance_normalization,
    quantize_active,
    quantize_weight,
    quantize_active_overflow,
    quantize_weight_overflow,
    moments,
    mean_var_with_update,
    w_fold,
    bias_fold,
    compute_alpha,
    ternary_operation,
    get_tensor_shape,
)

from ..utils.tensorflow_utils import (
    channel_format,
    padding_format,
    preprocess_1d_format,
    preprocess_2d_format,
    preprocess_3d_format,
    preprocess_padding,
    nchw_to_nhwc,
    nhwc_to_nchw,
)


def is_seq_of(seq, expected_type, seq_type=None):
    """Check whether it is a sequence of some type.

    Args:
        seq (Sequence): The sequence to be checked.
        expected_type (type): Expected type of sequence items.
        seq_type (type, optional): Expected sequence type.

    Returns:
        bool: Whether the sequence is valid.
    """
    if seq_type is None:
        exp_seq_type = abc.Sequence
    else:
        assert isinstance(seq_type, type)
        exp_seq_type = seq_type
    if not isinstance(seq, exp_seq_type):
        return False
    for item in seq:
        if not isinstance(item, expected_type):
            return False
    return True


# loss function
sparse_softmax_cross_entropy_with_logits = (
    tf.nn.sparse_softmax_cross_entropy_with_logits
)


class RReLU(object):
    def __init__(
        self, lower: float = 0.125, upper: float = 1 / 3, inplace: bool = True, **kwargs
    ):
        self.lower = lower
        self.upper = upper

    def __call__(self, input, train):
        return tfa.activations.rrelu(input, self.lower, self.upper, training=train)


class ReLU(object):
    def __init__(self, inplace=False):
        self.inplace = inplace

    def __call__(self, x):
        return tf.nn.relu(x)


class ELU(object):
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def __call__(self, x):
        res = tf.nn.elu(x)
        if self.alpha == 1:
            return res
        else:
            return tf.where(x > 0, res, self.alpha * res)


class ReLU6(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return tf.nn.relu6(x)


class LeakyReLU(object):
    def __init__(self, negative_slope=0.2):
        self.negative_slope = negative_slope

    def __call__(self, x):
        return tf.nn.leaky_relu(x, alpha=self.negative_slope)


class Softplus(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return tf.nn.softplus(x)


class Tanh(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return tf.nn.tanh(x)


class Sigmoid(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return tf.nn.sigmoid(x)


class Softmax(object):
    def __init__(self, axis=-1):
        self.axis = axis

    def __call__(self, x):
        return tf.nn.softmax(x, axis=self.axis)


class GeLU(object):
    def __init__(self, approximate=False):
        self.approximate = approximate

    def __call__(self, x):
        return tf.nn.gelu(x, approximate=self.approximate)


class SiLU(object):
    def __init__(self):
        pass

    def __call__(self, inputs):
        return inputs * tf.nn.sigmoid(inputs)


class Dropout(object):
    def __init__(self, p, seed=0):
        self.p = p
        self.seed = seed

    def __call__(self, inputs, *args, **kwargs):
        outputs = tf.nn.dropout(inputs, rate=self.p, seed=self.seed)
        return outputs


def drop_path(x, drop_prob=0.0, training=False):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of
    residual blocks).
    We follow the implementation
    https://github.com/rwightman/pytorch-image-models/blob/a2727c1bf78ba0d7b5727f5f95e37fb7f8866b1f/timm/models/layers/drop.py  # noqa: E501
    """
    if drop_prob == 0.0 or not training:
        return x
    keep_prob = 1 - drop_prob
    # handle tensors with different dimensions, not just 4D tensors.
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)
    random_tensor = keep_prob + tf.random.uniform(shape, dtype=x.dtype)
    output = tf.divide(x, keep_prob) * tf.floor(random_tensor)
    return output


class Conv1D(object):
    def __init__(
        self,
        stride,
        padding,
        data_format="NWC",
        dilations=None,
        groups=None,
        out_channel=None,
        k_size=None,
    ):
        self.stride = stride
        self.dilations = dilations
        self.data_format, self.padding = preprocess_1d_format(data_format, padding)
        self.pad_value = None

        if isinstance(padding, int):
            self.pad_value = preprocess_padding(self.padding, "1d", self.data_format)
            self.padding = "VALID"

    def __call__(self, input, filters):
        if self.pad_value is not None:
            input = tf.pad(input, paddings=self.pad_value)

        outputs = tf.nn.conv1d(
            input=input,
            filters=filters,
            stride=self.stride,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
            # name=name
        )
        return outputs


class BiasAdd(object):
    """
    Adds bias to value.

    Parameters
    ----------
    x : tensor
        A Tensor with type float, double, int64, int32, uint8, int16, int8, complex64, or complex128.
    bias : tensor
        Must be the same type as value unless value is a quantized type,
        in which case a different quantized type may be used.
    Returns
    -------
        A Tensor with the same type as value.
    """

    def __init__(self, data_format="channels_first"):
        if data_format in ["channels_first", "NCL", "NCW", "NCHW", "NCDHW"]:
            self.data_format = "NCHW"
        elif data_format in ["channels_last", "NLC", "NWC", "NHWC", "NDHWC"]:
            self.data_format = "NHWC"

    def __call__(self, x, bias):
        return tf.nn.bias_add(x, bias, data_format=self.data_format)


class Conv2D(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NHWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        groups=None,
    ):
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)

        if isinstance(padding, int) or isinstance(padding, tuple):
            self.padding = preprocess_padding(self.padding, "2d", self.data_format)

    def __call__(self, input, filters):
        outputs = tf.nn.conv2d(
            input=input,
            filters=filters,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )
        return outputs


class Conv3D(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NDHWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        groups=None,
    ):
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.pad_value = None

        if isinstance(padding, int) or isinstance(padding, tuple):
            self.pad_value = preprocess_padding(self.padding, "3d", self.data_format)
            self.padding = "VALID"

    def __call__(self, input, filters):
        if self.pad_value is not None:
            input = tf.pad(input, paddings=self.pad_value)
        outputs = tf.nn.conv3d(
            input=input,
            filters=filters,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )
        return outputs


class MaxPool1d(object):
    def __init__(self, ksize, strides, padding, return_mask, data_format=None):
        self.data_format, self.padding = preprocess_1d_format(
            data_format=data_format, padding=padding
        )
        self.ksize = ksize
        self.strides = strides
        self.padding_value = None
        self.return_mask = return_mask
        if not isinstance(self.padding, str):
            self.padding_value = preprocess_padding(
                self.padding, "1d", self.data_format
            )
            self.padding = "VALID"

    def __call__(self, inputs):
        if self.padding_value is not None:
            inputs = tf.pad(inputs, self.padding_value)
        if self.return_mask:
            raise NotImplementedError
        else:
            outputs = tf.nn.max_pool(
                input=inputs,
                ksize=self.ksize,
                strides=self.strides,
                padding=self.padding,
                data_format=self.data_format,
            )
        return outputs


class MaxPool(object):
    def __init__(self, ksize, strides, padding, return_mask, data_format=None):
        self.ksize = ksize
        self.strides = strides
        self.data_format = data_format
        self.padding = padding
        self.return_mask = return_mask
        self.data_format, self.padding = preprocess_2d_format(
            data_format=self.data_format, padding=self.padding
        )
        self.padding_value = None
        if not isinstance(self.padding, str):
            self.padding_value = preprocess_padding(
                self.padding, "2d", self.data_format
            )
            self.padding = "VALID"

    def __call__(self, inputs):
        # if len(inputs.shape) == 3:
        #     self.data_format, self.padding = preprocess_1d_format(data_format=self.data_format, padding=self.padding)
        #     if not isinstance(self.padding, str):
        #         self.padding_value = preprocess_padding(self.padding, '1d', self.data_format)
        #         self.padding = "VALID"
        #         inputs = tf.pad(inputs, self.padding_value)
        # elif len(inputs.shape) == 4:
        if self.padding_value is not None:
            inputs = tf.pad(inputs, self.padding_value)
        # elif len(inputs.shape) == 5:
        #     self.data_format, self.padding = preprocess_3d_format(data_format=self.data_format, padding=self.padding)
        #     if not isinstance(self.padding, str):
        #         self.padding_value = preprocess_padding(self.padding, '3d', self.data_format)
        #         self.padding = "VALID"
        #         inputs = tf.pad(inputs, self.padding_value)

        if self.return_mask:
            outputs = tf.nn.max_pool_with_argmax(
                input=inputs,
                ksize=self.ksize,
                strides=self.strides,
                padding=self.padding,
                data_format=self.data_format,
                include_batch_in_index=True,
            )
        else:
            outputs = tf.nn.max_pool(
                input=inputs,
                ksize=self.ksize,
                strides=self.strides,
                padding=self.padding,
                data_format=self.data_format,
            )
        return outputs


class AvgPool1d(object):
    def __init__(self, ksize, strides, padding, data_format=None):
        self.data_format, self.padding = preprocess_1d_format(
            data_format=data_format, padding=padding
        )
        self.ksize = [
            ksize,
        ]
        self.strides = [
            strides,
        ]
        self.padding_value = None
        if not isinstance(self.padding, str):
            self.padding_value = preprocess_padding(
                self.padding, "1d", self.data_format
            )
            self.padding = "VALID"

    def __call__(self, inputs):
        if self.padding_value is not None:
            inputs = tf.pad(inputs, self.padding_value)
        outputs = tf.nn.pool(
            input=inputs,
            window_shape=self.ksize,
            pooling_type="AVG",
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
        )
        return outputs


class AvgPool(object):
    def __init__(self, ksize, strides, padding, data_format=None):
        self.ksize = ksize
        self.strides = strides
        self.data_format, self.padding = preprocess_2d_format(
            data_format=data_format, padding=padding
        )
        self.padding_value = None
        if not isinstance(self.padding, str):
            self.padding_value = preprocess_padding(
                self.padding, "2d", self.data_format
            )
            self.padding = "VALID"

    def __call__(self, inputs):
        data_format = channel_format(self.data_format, str(len(inputs.shape) - 2) + "d")
        if self.padding_value is not None:
            inputs = tf.pad(inputs, self.padding_value)
        outputs = tf.nn.avg_pool(
            input=inputs,
            ksize=self.ksize,
            strides=self.strides,
            padding=self.padding,
            data_format=data_format,
        )
        return outputs


class MaxPool3d(object):
    def __init__(self, ksize, strides, padding, return_mask, data_format=None):
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.ksize = ksize
        self.strides = strides
        self.padding_value = None
        self.return_mask = return_mask
        if not isinstance(self.padding, str):
            self.padding_value = preprocess_padding(
                self.padding, "3d", self.data_format
            )
            self.padding = "VALID"

    def __call__(self, inputs):
        if self.padding_value is not None:
            inputs = tf.pad(inputs, self.padding_value)
        if self.return_mask:
            raise NotImplementedError
        else:
            outputs = tf.nn.max_pool3d(
                input=inputs,
                ksize=self.ksize,
                strides=self.strides,
                padding=self.padding,
                data_format=self.data_format,
            )
        return outputs


class AvgPool3d(object):
    def __init__(self, ksize, strides, padding, data_format=None):
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.ksize = ksize
        self.strides = strides
        self.padding_value = None
        if not isinstance(self.padding, str):
            self.padding_value = preprocess_padding(
                self.padding, "3d", self.data_format
            )
            self.padding = "VALID"

    def __call__(self, inputs):
        if self.padding_value is not None:
            inputs = tf.pad(inputs, self.padding_value)
        outputs = tf.nn.avg_pool3d(
            input=inputs,
            ksize=self.ksize,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
        )
        return outputs


class DepthwiseConv2d(object):
    def __init__(
        self,
        strides,
        padding,
        data_format=None,
        dilations=None,
        ksize=None,
        channel_multiplier=1,
        in_channels=None,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        if isinstance(padding, int) or isinstance(padding, tuple):
            self.padding = preprocess_padding(self.padding, "2d", self.data_format)
        self.strides = strides
        self.dilations = dilations
        self.depthwise_conv = GroupConv2D(
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            out_channel=None,
            k_size=None,
            dilations=self.dilations,
            groups=in_channels,
        )

    def __call__(self, input, filter, point_filter=None):
        depthwise = self.depthwise_conv(input, filter)
        outputs = tf.nn.conv2d(
            depthwise,
            point_filter,
            strides=1,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )
        # outputs = tf.nn.depthwise_conv2d(
        #     input=input,
        #     filter=filter,
        #     strides=self.strides,
        #     padding=self.padding,
        #     data_format=self.data_format,
        #     dilations=self.dilations,
        # )
        return outputs


class Conv1d_transpose(object):
    def __init__(
        self,
        stride,
        padding,
        data_format="NWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        in_channels=None,
        groups=None,
    ):
        self.stride = stride
        self.groups = groups
        self.dilations = dilations
        self.k_size = k_size
        if isinstance(padding, int):
            self.padding_value = [padding, padding]
        else:
            raise TypeError(
                f"Padding in Conv1d only supports int but got type {type(padding)}"
            )
        self.data_format, self.padding = preprocess_1d_format(data_format, padding)

        if isinstance(padding, int):
            self.padding_value = [padding, padding]

    def __call__(self, input, filters):
        x_in_shape = int(input.shape[2])
        input = tf.pad(input, [[0, 0], [0, 0], self.padding_value])
        batch_size = input.shape[0]
        if self.data_format == "NWC":
            w_axis, c_axis = 1, 2
        else:
            w_axis, c_axis = 2, 1

        input_shape = input.shape.as_list()
        filters_shape = filters.shape.as_list()
        input_w = input_shape[w_axis]
        filters_w = filters_shape[0]
        output_channels = filters_shape[1]
        dilations_w = 1

        if isinstance(self.stride, int):
            strides_w = self.stride
        else:
            strides_list = list(self.stride)
            strides_w = strides_list[w_axis]

        if self.dilations is not None:
            if isinstance(self.dilations, int):
                dilations_w = self.dilations
            else:
                dilations_list = list(self.dilations)
                dilations_w = dilations_list[w_axis]

        filters_w = filters_w + (filters_w - 1) * (dilations_w - 1)
        self.padding = "VALID"
        assert self.padding in {"SAME", "VALID"}
        if self.padding == "VALID":
            output_w = (input_w - 1) * self.stride + self.k_size

        if self.data_format == "NCW":
            output_shape = (batch_size, output_channels, output_w)
        else:
            output_shape = (batch_size, output_w, output_channels)
        output_shape = tf.stack(output_shape)

        input_groups = tf.split(input, num_or_size_splits=self.groups, axis=1)
        filters_groups = tf.split(filters, num_or_size_splits=self.groups, axis=-1)

        output_groups = []
        for i in range(self.groups):
            outputs = tf.nn.conv1d_transpose(
                input=input_groups[i],
                filters=filters_groups[i],
                output_shape=output_shape,
                strides=self.stride,
                padding=self.padding,
                data_format=self.data_format,
                dilations=self.dilations,
            )
            output_groups.append(outputs)

        output_tensor = tf.concat(output_groups, axis=1)

        out_len = int(output_tensor.shape[2])
        # re-compute the length to match the shape of tensor in torch
        length = (
            (x_in_shape - 1) * int(self.stride)
            - 2 * self.padding_value[0]
            + int(self.dilations) * int(self.k_size - 1)
            + 1
        )
        pad_len = int((out_len - length) / 2)
        # what difference in torch is to cut off tensor edge
        output_tensor = output_tensor[:, :, pad_len:-pad_len]
        return output_tensor
        return outputs


class Conv2d_transpose(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NHWC",
        dilations=None,
        name=None,
        out_channels=None,
        k_size=None,
        in_channels=None,
        groups=1,
        output_padding=0,
    ):
        self.strides = strides
        self.dilations = dilations
        self.name = name
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self._padding = padding
        self.groups = groups
        self.output_padding = output_padding
        self.k_size = k_size
        self.in_channel = in_channels
        if isinstance(padding, int):
            self.padding_value = [[padding, padding], [padding, padding]]
        elif is_seq_of(padding, int):
            if len(padding) == 1:
                self.padding_value = [[padding, padding], [padding, padding]]
            elif len(padding) == 2:
                self.padding_value = [
                    [padding[0], padding[0]],
                    [padding[1], padding[1]],
                ]
            else:
                raise ValueError(
                    "Conv2d only support length of the padding less equal than 2"
                )
        else:
            raise TypeError(
                f"Padding in Conv2d should be int or sequence of int, but got {type(padding)}"
            )

    def _output_padding(self, output_shape, output_size):
        if len(output_size) != 2:
            raise ValueError(
                "ConvTranspose2D: for 4D input, output_size must have 2 elements (got {})".format(
                    len(output_size)
                )
            )
        res = []
        for i in range(2):
            if output_size[i] < output_shape[i]:
                ValueError("output size must greater than {}".format(output_shape))
            res.append(output_size[i] - output_shape[i])
        return tuple(res)

    def __call__(self, input, filters, output_size=None):
        x_in_shape_w, x_in_shape_h = int(input.shape[2]), int(input.shape[3])
        input = tf.pad(
            input, [[0, 0], [0, 0], self.padding_value[0], self.padding_value[1]]
        )
        if self.data_format == "NHWC":
            h_axis, w_axis = 1, 2
        else:
            h_axis, w_axis = 2, 3

        input_shape = input.shape.as_list()
        filters_shape = filters.shape.as_list()
        output_channels = filters_shape[2]
        batch_size = input.shape[0]
        input_h, input_w = input_shape[h_axis], input_shape[w_axis]
        kernel_h, kernel_w = filters_shape[0], filters_shape[1]
        dilations_h, dilations_w = 1, 1

        if isinstance(self.strides, int):
            strides_h = self.strides
            strides_w = self.strides
        else:
            strides_list = list(self.strides)
            if len(strides_list) == 2:
                strides_h = strides_list[0]
                strides_w = strides_list[1]
            elif len(strides_list) == 4:
                strides_h = strides_list[h_axis]
                strides_w = strides_list[w_axis]

        if self.dilations is not None:
            if isinstance(self.dilations, int):
                dilations_h = self.dilations
                dilations_w = self.dilations
            else:
                dilations_list = list(self.dilations)
                if len(dilations_list) == 2:
                    dilations_h = dilations_list[0]
                    dilations_w = dilations_list[1]
                elif len(dilations_list) == 4:
                    dilations_h = dilations_list[h_axis]
                    dilations_w = dilations_list[w_axis]

        kernel_h = kernel_h + (kernel_h - 1) * (dilations_h - 1)
        kernel_w = kernel_w + (kernel_w - 1) * (dilations_w - 1)
        self.padding = "VALID"
        if tf.__version__ < "2.4.0" and not isinstance(self.padding, str):
            assert self.padding in {"SAME", "VALID"}
        if self.padding == "VALID":
            output_h = (input_h - 1) * strides_h + kernel_h
            output_w = (input_w - 1) * strides_w + kernel_w

        else:
            if isinstance(self.padding, int):
                output_h = (
                    input_h * strides_h
                    + max(kernel_h - strides_h, 0)
                    - 2 * self._padding
                )
                output_w = (
                    input_w * strides_w
                    + max(kernel_w - strides_w, 0)
                    - 2 * self._padding
                )
                self.padding = [
                    [0, 0],
                    [self._padding, self._padding],
                    [self._padding, self._padding],
                    [0, 0],
                ]
            else:
                output_h = (
                    input_h * strides_h
                    + max(kernel_h - strides_h, 0)
                    - 2 * self._padding[0]
                )
                output_w = (
                    input_w * strides_w
                    + max(kernel_w - strides_w, 0)
                    - 2 * self._padding[1]
                )
                self.padding = [
                    [0, 0],
                    [self._padding[0], self._padding[0]],
                    [self._padding[1], self._padding[1]],
                    [0, 0],
                ]

        if self.data_format == "NCHW":
            out_shape = (batch_size, output_channels, output_h, output_w)
        else:
            out_shape = (batch_size, output_h, output_w, output_channels)

        out_shape = tf.stack(out_shape)
        output_padding = preprocess_padding(self.output_padding, "2d", self.data_format)
        if self.data_format == "NHWC":
            output_padding[1][1] = 0
            output_padding[2][1] = 0
        else:
            output_padding[2][1] = 0
            output_padding[3][1] = 0

        input_groups = tf.split(input, num_or_size_splits=self.groups, axis=1)
        filters_groups = tf.split(filters, num_or_size_splits=self.groups, axis=-1)

        output_groups = []
        for i in range(self.groups):
            outputs = tf.nn.conv2d_transpose(
                input=input_groups[i],
                filters=filters_groups[i],
                output_shape=out_shape,
                strides=self.strides,
                padding=self.padding,
                data_format=self.data_format,
                dilations=self.dilations,
            )

            output_groups.append(outputs)

        output_tensor = tf.concat(output_groups, axis=1)

        out_len_h = int(output_tensor.shape[2])
        out_len_w = int(output_tensor.shape[3])
        # re-compute the length to match the shape of tensor in torch
        length_h = (
            (x_in_shape_h - 1) * int(self.strides[0])
            - 2 * self.padding_value[0][0]
            + int(self.dilations[0]) * int(self.k_size[0] - 1)
            + 1
        )
        length_w = (
            (x_in_shape_w - 1) * int(self.strides[0])
            - 2 * self.padding_value[0][0]
            + int(self.dilations[0]) * int(self.k_size[0] - 1)
            + 1
        )
        pad_len_h = int((out_len_h - length_h) / 2)
        pad_len_w = int((out_len_w - length_w) / 2)
        # what difference in torch is to cut off tensor edge
        output_tensor = output_tensor[:, :, pad_len_h:-pad_len_h, pad_len_w:-pad_len_w]
        return output_tensor


def conv2d_transpose(
    input,
    filters,
    output_shape,
    strides,
    padding="SAME",
    data_format="NHWC",
    dilations=None,
    name=None,
):
    """
    The transpose of conv2d.

    Parameters
    ----------
    input : tensor
        A 4-D Tensor of type float and shape [batch, height, width, in_channels]
        for NHWC data format or [batch, in_channels, height, width] for NCHW data format.
    filters : tensor
        A 4-D Tensor with the same type as input and shape [height, width,
        output_channels, in_channels]. filter's in_channels dimension must match that of input.
    output_shape : tensor
        A 1-D Tensor representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1, 2 or 4. The stride of the sliding window for each dimension of input.
        If a single value is given it is replicated in the H and W dimension.
        By default the N and C dimensions are set to 0.
        The dimension order is determined by the value of data_format, see below for details.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
         'NHWC' and 'NCHW' are supported.
    dilations : list
        An int or list of ints that has length 1, 2 or 4, defaults to 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as input.
    """

    # data_format, padding = preprocess_2d_format(data_format, padding)
    # outputs = tf.nn.conv2d_transpose(
    #     input=input,
    #     filters=filters,
    #     output_shape=output_shape,
    #     strides=strides,
    #     padding=padding,
    #     data_format=data_format,
    #     dilations=dilations,
    #     name=name,
    # )
    # return outputs
    raise NotImplementedError


class Conv3d_transpose(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NDHWC",
        dilations=None,
        name=None,
        out_channel=None,
        k_size=None,
        in_channels=None,
        groups=None,
    ):
        self.strides = strides
        self.dilations = dilations
        self.name = name
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.k_size = k_size
        self.groups = groups
        if isinstance(padding, int):
            self.padding_value = [
                [padding, padding],
                [padding, padding],
                [padding, padding],
            ]
        elif is_seq_of(padding, int):
            if len(padding) == 1:
                self.padding_value = [
                    [padding, padding],
                    [padding, padding],
                    [padding, padding],
                ]
            elif len(padding) == 3:
                self.padding_value = [
                    [padding[0], padding[0]],
                    [padding[1], padding[1]],
                    [padding[2], padding[2]],
                ]
            raise TypeError(
                f"Padding in Conv3d supports int and sequnce of int, but got type {type(padding)}"
            )
        else:
            raise TypeError(
                f"Padding in Conv3d supports int and sequnce of int, but got type {type(padding)}"
            )

    def __call__(self, input, filters):
        x_in_shape_w, x_in_shape_h, x_in_shape_d = (
            int(input.shape[2]),
            int(input.shape[3]),
            int(input.shape[4]),
        )
        input = tf.pad(
            input,
            [
                [0, 0],
                [0, 0],
                self.padding_value[0],
                self.padding_value[1],
                self.padding_value[2],
            ],
        )
        if self.data_format == "NDHWC":
            d_axis, h_axis, w_axis = 1, 2, 3
        else:
            d_axis, h_axis, w_axis = 2, 3, 4

        input_shape = input.shape.as_list()
        filters_shape = filters.shape.as_list()
        output_channels = filters_shape[3]
        batch_size = input_shape[0]
        input_d, input_h, input_w = (
            input_shape[d_axis],
            input_shape[h_axis],
            input_shape[w_axis],
        )
        kernel_d, kernel_h, kernel_w = (
            filters_shape[0],
            filters_shape[1],
            filters_shape[2],
        )
        dilations_d, dilations_h, dilations_w = 1, 1, 1

        if isinstance(self.strides, int):
            strides_d, strides_h, strides_w = self.strides
        else:
            strides_list = list(self.strides)
            if len(strides_list) == 3:
                strides_d, strides_h, strides_w = (
                    strides_list[0],
                    strides_list[1],
                    strides_list[2],
                )
            elif len(strides_list) == 5:
                strides_d, strides_h, strides_w = (
                    strides_list[d_axis],
                    strides_list[h_axis],
                    strides_list[w_axis],
                )

        if self.dilations is not None:
            if isinstance(self.dilations, int):
                dilations_d, dilations_h, dilations_w = self.dilations
            else:
                dilations_list = list(self.dilations)
                if len(dilations_list) == 3:
                    dilations_d, dilations_h, dilations_w = (
                        dilations_list[0],
                        dilations_list[1],
                        dilations_list[2],
                    )
                elif len(dilations_list) == 5:
                    dilations_d, dilations_h, dilations_w = (
                        dilations_list[d_axis],
                        dilations_list[h_axis],
                        dilations_list[w_axis],
                    )

        kernel_d = kernel_d + (kernel_d - 1) * (dilations_d - 1)
        kernel_h = kernel_h + (kernel_h - 1) * (dilations_h - 1)
        kernel_w = kernel_w + (kernel_w - 1) * (dilations_w - 1)
        self.padding = "VALID"
        if self.padding == "VALID":
            output_d = (input_d - 1) * strides_d + kernel_d
            output_h = (input_h - 1) * strides_h + kernel_h
            output_w = (input_w - 1) * strides_w + kernel_w

        if self.data_format == "NDHWC":
            output_shape = (batch_size, output_d, output_h, output_w, output_channels)
        else:
            output_shape = (batch_size, output_channels, output_d, output_h, output_w)

        output_shape = tf.stack(output_shape)
        input_groups = tf.split(input, num_or_size_splits=self.groups, axis=1)
        filters_groups = tf.split(filters, num_or_size_splits=self.groups, axis=-1)

        output_groups = []
        for i in range(self.groups):
            outputs = tf.nn.conv3d_transpose(
                input=input_groups[i],
                filters=filters_groups[i],
                output_shape=output_shape,
                strides=self.strides,
                padding=self.padding,
                data_format=self.data_format,
                dilations=self.dilations,
            )
            output_groups.append(outputs)

        output_tensor = tf.concat(output_groups, axis=1)
        out_len_h = int(output_tensor.shape[2])
        out_len_w = int(output_tensor.shape[3])
        out_len_d = int(output_tensor.shape[4])
        # re-compute the length to match the shape of tensor in torch
        length_h = (
            (x_in_shape_h - 1) * int(self.strides[0])
            - 2 * self.padding_value[0][0]
            + int(self.dilations[0]) * int(self.k_size[0] - 1)
            + 1
        )
        length_w = (
            (x_in_shape_w - 1) * int(self.strides[0])
            - 2 * self.padding_value[0][0]
            + int(self.dilations[0]) * int(self.k_size[0] - 1)
            + 1
        )
        length_d = (
            (x_in_shape_d - 1) * int(self.strides[0])
            - 2 * self.padding_value[0][0]
            + int(self.dilations[0]) * int(self.k_size[0] - 1)
            + 1
        )
        pad_len_h = int((out_len_h - length_h) / 2)
        pad_len_w = int((out_len_w - length_w) / 2)
        pad_len_d = int((out_len_d - length_d) / 2)
        # what difference in torch is to cut off tensor edge
        output_tensor = output_tensor[
            :, :, pad_len_h:-pad_len_h, pad_len_w:-pad_len_w, pad_len_d:-pad_len_d
        ]

        return output_tensor


class BatchNorm(object):
    """
    The :class:`BatchNorm` is a batch normalization layer for both fully-connected and convolution outputs.
    See ``tf.nn.batch_normalization`` and ``tf.nn.moments``.

    Parameters
    ----------
    decay : float
        A decay factor for `ExponentialMovingAverage`.
        Suggest to use a large value for large dataset.
    epsilon : float
        Eplison.
    act : activation function
        The activation function of this layer.
    is_train : boolean
        Is being used for training or inference.
    beta_init : initializer or None
        The initializer for initializing beta, if None, skip beta.
        Usually you should not skip beta unless you know what happened.
    gamma_init : initializer or None
        The initializer for initializing gamma, if None, skip gamma.
        When the batch normalization layer is use instead of 'biases', or the next layer is linear, this can be
        disabled since the scaling can be done by the next layer. see `Inception-ResNet-v2 <https://github.com/tensorflow/models/blob/master/research/slim/nets/inception_resnet_v2.py>`__
    moving_mean_init : initializer or None
        The initializer for initializing moving mean, if None, skip moving mean.
    moving_var_init : initializer or None
        The initializer for initializing moving var, if None, skip moving var.
    num_features: int
        Number of features for input tensor. Useful to build layer if using BatchNorm1d, BatchNorm2d or BatchNorm3d,
        but should be left as None if using BatchNorm. Default None.
    data_format : str
        channels_last 'channel_last' (default) or channels_first.
    name : None or str
        A unique layer name.

    Examples
    ---------
    With TensorLayer

    >>> net = tlx.layers.Input([None, 50, 50, 32], name='input')
    >>> net = tlx.layers.BatchNorm()(net)

    Notes
    -----
    The :class:`BatchNorm` is universally suitable for 3D/4D/5D input in static model, but should not be used
    in dynamic model where layer is built upon class initialization. So the argument 'num_features' should only be used
    for subclasses :class:`BatchNorm1d`, :class:`BatchNorm2d` and :class:`BatchNorm3d`. All the three subclasses are
    suitable under all kinds of conditions.

    References
    ----------
    - `Source <https://github.com/ry/tensorflow-resnet/blob/master/resnet.py>`__
    - `stackoverflow <http://stackoverflow.com/questions/38312668/how-does-one-do-inference-with-batch-normalization-with-tensor-flow>`__

    """

    def __init__(
        self,
        decay=0.9,
        eps=0.00001,
        beta=None,
        gamma=None,
        moving_mean=None,
        moving_var=None,
        num_features=None,
        data_format="channels_first"
    ):
        self.decay = decay
        self.eps = eps
        self.data_format = data_format
        self.beta = beta
        self.gamma = gamma
        self.moving_mean = moving_mean
        self.moving_var = moving_var
        self.num_features = num_features
        self.axes = None

        if self.decay < 0.0 or 1.0 < self.decay:
            raise ValueError("decay should be between 0 to 1")

    def _get_param_shape(self, inputs_shape):
        if self.data_format == "channels_last":
            axis = -1
        elif self.data_format == "channels_first":
            axis = 1
        else:
            raise ValueError(
                "data_format should be either %s or %s"
                % ("channels_last", "channels_first")
            )

        channels = inputs_shape[axis]
        params_shape = [channels]

        return params_shape

    def _check_input_shape(self, inputs):
        if len(inputs.shape) <= 1:
            raise ValueError(
                "expected input at least 2D, but got {}D input".format(
                    len(inputs.shape)
                )
            )

    def __call__(self, inputs,is_train=False):
        self._check_input_shape(inputs)
        self.channel_axis = (
            len(inputs.shape) - 1 if self.data_format == "channels_last" else 1
        )
        if self.axes is None:
            self.axes = [i for i in range(len(inputs.shape)) if i != self.channel_axis]

        mean, var = tf.nn.moments(inputs, self.axes, keepdims=False)
        if is_train:
            # update moving_mean and moving_var
            self.moving_mean = moving_averages.assign_moving_average(
                self.moving_mean, mean, self.decay, zero_debias=False
            )
            self.moving_var = moving_averages.assign_moving_average(
                self.moving_var, var, self.decay, zero_debias=False
            )
            outputs = batch_normalization(
                inputs, mean, var, self.beta, self.gamma, self.eps, self.data_format
            )
        else:
            outputs = batch_normalization(
                inputs,
                self.moving_mean,
                self.moving_var,
                self.beta,
                self.gamma,
                self.eps,
                self.data_format,
            )

        return outputs

class GroupNorm(object):
    def __init__(
        self,
        num_groups,
        beta=None,
        gamma=None,
        eps=1e-5,
        data_format="channels_first",
    ) -> None:
        self.num_groups = num_groups
        self.beta = beta
        self.gamma = gamma
        self.eps = eps
        self.data_format = data_format
        if data_format == "channels_first":
            self.axis = 1
        elif data_format == "channels_last":
            self.aixs = -1
        else:
            raise ValueError("Data_format should be channels_first or channels_last")

    def __call__(self, inputs):
        input_shape = tf.keras.backend.int_shape(inputs)
        tensor_input_shape = tf.shape(inputs)

        reshaped_inputs, group_shape = self._reshape_into_groups(
            inputs, input_shape, tensor_input_shape
        )

        normalized_inputs = self._apply_normalization(reshaped_inputs, input_shape)

        is_instance_norm = (input_shape[self.axis] // self.num_groups) == 1
        if not is_instance_norm:
            outputs = tf.reshape(normalized_inputs, tensor_input_shape)
        else:
            outputs = normalized_inputs

        return outputs

    def _reshape_into_groups(self, inputs, input_shape, tensor_input_shape):
        group_shape = [tensor_input_shape[i] for i in range(len(input_shape))]
        is_instance_norm = (input_shape[self.axis] // self.num_groups) == 1
        if not is_instance_norm:
            group_shape[self.axis] = input_shape[self.axis] // self.num_groups
            group_shape.insert(self.axis, self.num_groups)
            group_shape = tf.stack(group_shape)
            reshaped_inputs = tf.reshape(inputs, group_shape)
            return reshaped_inputs, group_shape
        else:
            return inputs, group_shape

    def _apply_normalization(self, reshaped_inputs, input_shape):
        group_shape = tf.keras.backend.int_shape(reshaped_inputs)
        group_reduction_axes = list(range(1, len(group_shape)))
        is_instance_norm = (input_shape[self.axis] // self.num_groups) == 1
        if not is_instance_norm:
            axis = -2 if self.axis == -1 else self.axis - 1
        else:
            axis = -1 if self.axis == -1 else self.axis - 1
        group_reduction_axes.pop(axis)

        mean, variance = tf.nn.moments(
            reshaped_inputs, group_reduction_axes, keepdims=True
        )

        gamma, beta = self._get_reshaped_weights(input_shape)
        normalized_inputs = group_normalization(
            reshaped_inputs,
            mean=mean,
            variance=variance,
            offset=gamma,
            scale=beta,
            variance_epsilon=self.eps,
        )
        return normalized_inputs

    def _get_reshaped_weights(self, input_shape):
        broadcast_shape = self._create_broadcast_shape(input_shape)
        gamma = None
        beta = None
        if self.gamma is not None and self.beta is not None:
            gamma = tf.reshape(self.gamma, broadcast_shape)
            beta = tf.reshape(self.beta, broadcast_shape)
        return gamma, beta

    def _create_broadcast_shape(self, input_shape):
        broadcast_shape = [1] * len(input_shape)
        is_instance_norm = (input_shape[self.axis] // self.num_groups) == 1
        if not is_instance_norm:
            broadcast_shape[self.axis] = input_shape[self.axis] // self.num_groups
            broadcast_shape.insert(self.axis, self.num_groups)
        else:
            broadcast_shape[self.axis] = self.num_groups
        return broadcast_shape


class InstanceNorm(object):
    def __init__(
        self,
        num_features,
        beta=None,
        gamma=None,
        eps=1e-5,
        data_format="channels_first",
    ) -> None:
        self.num_features = num_features
        self.beta = beta
        self.gamma = gamma
        self.eps = eps
        self.data_format = data_format
        if data_format == "channels_first":
            self.axis = 1
        elif data_format == "channels_last":
            self.aixs = -1
        else:
            raise ValueError("Data_format should be channels_first or channels_last")

    def __call__(self, inputs):
        input_shape = tf.keras.backend.int_shape(inputs)
        tensor_input_shape = tf.shape(inputs)

        reshaped_inputs, group_shape = self._reshape_into_groups(
            inputs, input_shape, tensor_input_shape
        )

        normalized_inputs = self._apply_normalization(reshaped_inputs, input_shape)

        is_instance_norm = (input_shape[self.axis] // self.num_features) == 1
        if not is_instance_norm:
            outputs = tf.reshape(normalized_inputs, tensor_input_shape)
        else:
            outputs = normalized_inputs

        return outputs

    def _reshape_into_groups(self, inputs, input_shape, tensor_input_shape):
        group_shape = [tensor_input_shape[i] for i in range(len(input_shape))]
        is_instance_norm = (input_shape[self.axis] // self.num_features) == 1
        if not is_instance_norm:
            group_shape[self.axis] = input_shape[self.axis] // self.num_features
            group_shape.insert(self.axis, self.num_features)
            group_shape = tf.stack(group_shape)
            reshaped_inputs = tf.reshape(inputs, group_shape)
            return reshaped_inputs, group_shape
        else:
            return inputs, group_shape

    def _apply_normalization(self, reshaped_inputs, input_shape):
        group_shape = tf.keras.backend.int_shape(reshaped_inputs)
        group_reduction_axes = list(range(1, len(group_shape)))
        is_instance_norm = (input_shape[self.axis] // self.num_features) == 1
        if not is_instance_norm:
            axis = -2 if self.axis == -1 else self.axis - 1
        else:
            axis = -1 if self.axis == -1 else self.axis - 1

        group_reduction_axes.pop(axis)

        mean, var = tf.nn.moments(reshaped_inputs, group_reduction_axes, keepdims=True)
        normalized_inputs = instance_normalization(
            reshaped_inputs,
            mean,
            var,
            self.beta,
            self.gamma,
            self.eps,
            self.data_format,
        )

        return normalized_inputs

    def _get_reshaped_weights(self, input_shape):
        broadcast_shape = self._create_broadcast_shape(input_shape)
        gamma = None
        beta = None
        if self.gamma is not None and self.beta is not None:
            gamma = tf.reshape(self.gamma, broadcast_shape)
            beta = tf.reshape(self.beta, broadcast_shape)
        return gamma, beta

    def _create_broadcast_shape(self, input_shape):
        broadcast_shape = [1] * len(input_shape)
        is_instance_norm = (input_shape[self.axis] // self.num_features) == 1
        if not is_instance_norm:
            broadcast_shape[self.axis] = input_shape[self.axis] // self.num_features
            broadcast_shape.insert(self.axis, self.num_features)
        else:
            broadcast_shape[self.axis] = self.num_features
        return broadcast_shape


class GroupConv2D(object):
    def __init__(
        self, strides, padding, data_format, dilations, out_channel, k_size, groups
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.strides = strides
        self.dilations = dilations
        self.groups = groups
        if isinstance(padding, int) or isinstance(padding, tuple):
            self.padding = preprocess_padding(self.padding, "2d", self.data_format)

    def __call__(self, input, filters):
        outputs = tf.nn.conv2d(
            input=input,
            filters=filters,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )
        return outputs


class SeparableConv1D(object):
    def __init__(
        self,
        stride,
        padding,
        data_format,
        dilations,
        out_channel,
        k_size,
        in_channel,
        depth_multiplier,
    ):
        self.data_format, self.padding = preprocess_1d_format(data_format, padding)
        if self.data_format == "NWC":
            self.spatial_start_dim = 1
            self.strides = (1, stride, stride, 1)
            self.data_format = "NHWC"
        else:
            self.spatial_start_dim = 2
            self.strides = (1, 1, stride, stride)
            self.data_format = "NCHW"
        self.dilation_rate = (1, dilations)

    def __call__(self, inputs, depthwise_filters, pointwise_filters):
        inputs = tf.expand_dims(inputs, axis=self.spatial_start_dim)
        depthwise_filters = tf.expand_dims(depthwise_filters, 0)
        pointwise_filters = tf.expand_dims(pointwise_filters, 0)

        outputs = tf.nn.separable_conv2d(
            inputs,
            depthwise_filters,
            pointwise_filters,
            strides=self.strides,
            padding=self.padding,
            dilations=self.dilation_rate,
            data_format=self.data_format,
        )

        outputs = tf.squeeze(outputs, axis=self.spatial_start_dim)

        return outputs


class SeparableConv2D(object):
    def __init__(
        self,
        strides,
        padding,
        data_format,
        dilations,
        out_channel,
        k_size,
        in_channel,
        depth_multiplier,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        if isinstance(padding, int) or isinstance(padding, tuple):
            self.padding = preprocess_padding(self.padding, "2d", self.data_format)
        self.strides = strides
        self.dilations = (dilations[2], dilations[2])

    def __call__(self, inputs, depthwise_filters, pointwise_filters):
        outputs = tf.nn.separable_conv2d(
            inputs,
            depthwise_filters,
            pointwise_filters,
            strides=self.strides,
            padding=self.padding,
            dilations=self.dilations,
            data_format=self.data_format,
        )

        return outputs


class AdaptiveMeanPool1D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_1d_format(data_format, None)
        self.output_size = output_size

    def __call__(self, input):
        if self.data_format == "NWC":
            n, w, c = input.shape
        else:
            n, c, w = input.shape

        stride = floor(w / self.output_size)
        kernel = w - (self.output_size - 1) * stride
        output = tf.nn.avg_pool1d(
            input,
            ksize=kernel,
            strides=stride,
            data_format=self.data_format,
            padding="VALID",
        )

        return output


class AdaptiveMeanPool2D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_2d_format(data_format, None)
        self.output_size = output_size

    def __call__(self, inputs):
        if self.data_format == "NHWC":
            n, h, w, c = inputs.shape
        else:
            n, c, h, w = inputs.shape

        out_h, out_w = self.output_size
        stride_h = floor(h / out_h)
        kernel_h = h - (out_h - 1) * stride_h
        stride_w = floor(w / out_w)
        kernel_w = w - (out_w - 1) * stride_w

        outputs = tf.nn.avg_pool2d(
            inputs,
            ksize=(kernel_h, kernel_w),
            strides=(stride_h, stride_w),
            data_format=self.data_format,
            padding="VALID",
        )

        return outputs


class AdaptiveMeanPool3D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_3d_format(data_format, None)
        self.output_size = output_size

    def __call__(self, inputs):
        if self.data_format == "NDHWC":
            n, d, h, w, c = inputs.shape
        else:
            n, c, d, h, w = inputs.shape

        out_d, out_h, out_w = self.output_size
        stride_d = floor(d / out_d)
        kernel_d = d - (out_d - 1) * stride_d
        stride_h = floor(h / out_h)
        kernel_h = h - (out_h - 1) * stride_h
        stride_w = floor(w / out_w)
        kernel_w = w - (out_w - 1) * stride_w

        outputs = tf.nn.avg_pool3d(
            inputs,
            ksize=(kernel_d, kernel_h, kernel_w),
            strides=(stride_d, stride_h, stride_w),
            data_format=self.data_format,
            padding="VALID",
        )

        return outputs


class AdaptiveMaxPool1D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_1d_format(data_format, None)
        self.output_size = output_size

    def __call__(self, input):
        if self.data_format == "NWC":
            n, w, c = input.shape
        else:
            n, c, w = input.shape

        stride = floor(w / self.output_size)
        kernel = w - (self.output_size - 1) * stride
        output = tf.nn.max_pool1d(
            input,
            ksize=kernel,
            strides=stride,
            data_format=self.data_format,
            padding="VALID",
        )

        return output


class AdaptiveMaxPool2D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_2d_format(data_format, None)
        self.output_size = output_size

    def __call__(self, inputs):
        if self.data_format == "NHWC":
            n, h, w, c = inputs.shape
        else:
            n, c, h, w = inputs.shape

        out_h, out_w = self.output_size
        stride_h = floor(h / out_h)
        kernel_h = h - (out_h - 1) * stride_h
        stride_w = floor(w / out_w)
        kernel_w = w - (out_w - 1) * stride_w

        outputs = tf.nn.max_pool2d(
            inputs,
            ksize=(kernel_h, kernel_w),
            strides=(stride_h, stride_w),
            data_format=self.data_format,
            padding="VALID",
        )

        return outputs


class AdaptiveMaxPool3D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_3d_format(data_format, None)
        self.output_size = output_size

    def __call__(self, inputs):
        if self.data_format == "NDHWC":
            n, d, h, w, c = inputs.shape
        else:
            n, c, d, h, w = inputs.shape

        out_d, out_h, out_w = self.output_size
        stride_d = floor(d / out_d)
        kernel_d = d - (out_d - 1) * stride_d
        stride_h = floor(h / out_h)
        kernel_h = h - (out_h - 1) * stride_h
        stride_w = floor(w / out_w)
        kernel_w = w - (out_w - 1) * stride_w

        outputs = tf.nn.max_pool3d(
            inputs,
            ksize=(kernel_d, kernel_h, kernel_w),
            strides=(stride_d, stride_h, stride_w),
            data_format=self.data_format,
            padding="VALID",
        )

        return outputs


class BinaryConv2D(object):
    def __init__(
        self, strides, padding, data_format, dilations, out_channel, k_size, in_channel
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.strides = strides
        self.dilations = dilations

    # @tf.RegisterGradient("TL_Sign_QuantizeGrad")
    # def _quantize_grad(op, grad):
    #     """Clip and binarize tensor using the straight through estimator (STE) for the gradient."""
    #     return tf.clip_by_value(grad, -1, 1)

    def quantize(self, x):
        # ref: https://github.com/AngusG/tensorflow-xnor-bnn/blob/master/models/binary_net.py#L70
        #  https://github.com/itayhubara/BinaryNet.tf/blob/master/nnUtils.py
        with tf.compat.v1.get_default_graph().gradient_override_map(
            {"Sign": "TL_Sign_QuantizeGrad"}
        ):
            return tf.sign(x)

    def __call__(self, inputs, filters):
        filters = self.quantize(filters)

        outputs = tf.nn.conv2d(
            input=inputs,
            filters=filters,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )

        return outputs


class DorefaConv2D(object):
    def __init__(
        self,
        bitW,
        bitA,
        strides,
        padding,
        data_format,
        dilations,
        out_channel,
        k_size,
        in_channel,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.strides = strides
        self.dilations = dilations
        self.bitW = bitW
        self.bitA = bitA

    def _quantize_dorefa(self, x, k):
        G = tf.compat.v1.get_default_graph()
        n = float(2**k - 1)
        with G.gradient_override_map({"Round": "Identity"}):
            return tf.round(x * n) / n

    def cabs(self, x):
        return tf.minimum(1.0, tf.abs(x), name="cabs")

    def quantize_active(self, x, bitA):
        if bitA == 32:
            return x
        return self._quantize_dorefa(x, bitA)

    def quantize_weight(self, x, bitW, force_quantization=False):
        G = tf.compat.v1.get_default_graph()
        if bitW == 32 and not force_quantization:
            return x
        if bitW == 1:  # BWN
            with G.gradient_override_map({"Sign": "Identity"}):
                E = tf.stop_gradient(tf.reduce_mean(input_tensor=tf.abs(x)))
                return tf.sign(x / E) * E
        x = tf.clip_by_value(
            x * 0.5 + 0.5, 0.0, 1.0
        )  # it seems as though most weights are within -1 to 1 region anyways
        return 2 * self._quantize_dorefa(x, bitW) - 1

    def __call__(self, inputs, filters):
        inputs = self.quantize_active(self.cabs(inputs), self.bitA)

        filters = self.quantize_weight(filters, self.bitW)

        outputs = tf.nn.conv2d(
            input=inputs,
            filters=filters,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )

        return outputs


class rnncell(object):
    def __init__(self, weight_ih, weight_hh, bias_ih, bias_hh, act):
        self.weight_ih = weight_ih
        self.weight_hh = weight_hh
        self.bias_ih = bias_ih
        self.bias_hh = bias_hh
        self.act_fn = tf.nn.relu if act == "relu" else tf.nn.tanh

    def __call__(self, input, h):
        i2h = tf.matmul(input, self.weight_ih, transpose_b=True)
        if self.bias_ih is not None:
            i2h += self.bias_ih
        h2h = tf.matmul(h, self.weight_hh, transpose_b=True)
        if self.bias_hh is not None:
            h2h += self.bias_hh
        h = self.act_fn(i2h + h2h)
        return h, h


class lstmcell(object):
    def __init__(self, weight_ih, weight_hh, bias_ih, bias_hh, act=None):
        self.weight_ih = weight_ih
        self.weight_hh = weight_hh
        self.bias_ih = bias_ih
        self.bias_hh = bias_hh
        self.gate_act_fn = tf.sigmoid
        self.act_fn = tf.tanh

    def __call__(self, input, h, c):
        gates = tf.matmul(input, self.weight_ih, transpose_b=True)
        if self.bias_ih is not None:
            gates = gates + self.bias_ih
        gates += tf.matmul(h, self.weight_hh, transpose_b=True)
        if self.bias_hh is not None:
            gates += self.bias_hh

        gate_slices = tf.split(gates, num_or_size_splits=4, axis=-1)
        i = self.gate_act_fn(gate_slices[0])
        f = self.gate_act_fn(gate_slices[1])
        o = self.gate_act_fn(gate_slices[3])
        c = f * c + i * self.act_fn(gate_slices[2])
        h = o * self.act_fn(c)

        return h, h, c


class grucell(object):
    def __init__(self, weight_ih, weight_hh, bias_ih, bias_hh, act=None):
        self.weight_ih = weight_ih
        self.weight_hh = weight_hh
        self.bias_ih = bias_ih
        self.bias_hh = bias_hh
        self.gate_act_fn = tf.sigmoid
        self.act_fn = tf.tanh

    def __call__(self, input, h):
        x_gates = tf.matmul(input, self.weight_ih, transpose_b=True)
        if self.bias_ih is not None:
            x_gates = x_gates + self.bias_ih
        h_gates = tf.matmul(h, self.weight_hh, transpose_b=True)
        if self.bias_hh is not None:
            h_gates = h_gates + self.bias_hh

        x_r, x_z, x_c = tf.split(x_gates, num_or_size_splits=3, axis=-1)
        h_r, h_z, h_c = tf.split(h_gates, num_or_size_splits=3, axis=-1)

        r = self.gate_act_fn(x_r + h_r)
        z = self.gate_act_fn(x_z + h_z)
        c = self.act_fn(x_c + r * h_c)
        h = (h - c) * z + c

        return h, h


class rnnbase(object):
    def __init__(
        self,
        mode,
        input_size,
        hidden_size,
        num_layers,
        bias,
        batch_first,
        dropout,
        bidirectional,
        is_train,
        w_ih,
        w_hh,
        b_ih,
        b_hh,
    ):
        self.mode = mode
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bias = bias
        self.batch_first = batch_first
        self.dropout = float(dropout)
        self.train = is_train
        if not 0 <= dropout < 1:
            raise ValueError("dropout should be a number in range [0, 1).")
        if dropout > 0 and num_layers == 1:
            raise ValueError(
                "dropout option adds dropout after all but last "
                "recurrent layer, so non-zero dropout expects "
                "num_layers greater than 1, but got dropout={} and "
                "num_layers={}".format(dropout, num_layers)
            )
        self.bidirect = 2 if bidirectional else 1

        self.w_ih = w_ih
        self.w_hh = w_hh
        self.b_ih = b_ih
        self.b_hh = b_hh
        self.act_fn = None
        if mode == "LSTM":
            # gate_size = 4 * hidden_size
            self.rnn_cell = lstmcell
        elif mode == "GRU":
            # gate_size = 3 * hidden_size
            self.rnn_cell = grucell
        elif mode == "RNN_TANH":
            # gate_size = hidden_size
            self.rnn_cell = rnncell
            self.act_fn = "tanh"
        elif mode == "RNN_RELU":
            # gate_size = hidden_size
            self.rnn_cell = rnncell
            self.act_fn = "relu"

    def _bi_rnn_forward(self, x, h, c=None):
        time_step, batch_size, input_size = x.shape
        h_out = []
        c_out = []
        y = []
        pre_layer = x
        for i in range(self.num_layers):
            weight_ih_fw = self.w_ih[2 * i]
            weight_hh_fw = self.w_hh[2 * i]
            weight_ih_bw = self.w_ih[2 * i + 1]
            weight_hh_bw = self.w_hh[2 * i + 1]
            if self.bias:
                bias_ih_fw = self.b_ih[2 * i]
                bias_hh_fw = self.b_hh[2 * i]
                bias_ih_bw = self.b_ih[2 * i + 1]
                bias_hh_bw = self.b_hh[2 * i + 1]
            else:
                bias_ih_fw = None
                bias_hh_fw = None
                bias_ih_bw = None
                bias_hh_bw = None
            h_i_fw = h[i, :, :]
            h_i_bw = h[i + 1, :, :]
            if i != 0 and self.train:
                pre_layer = tf.nn.dropout(pre_layer, rate=self.dropout)
            if c is not None:
                c_i_fw = c[i, :, :]
                c_i_bw = c[i + 1, :, :]
                for j in range(time_step):
                    input = pre_layer[j, :, :]
                    cell_fw = self.rnn_cell(
                        weight_ih_fw, weight_hh_fw, bias_ih_fw, bias_hh_fw, self.act_fn
                    )
                    cell_bw = self.rnn_cell(
                        weight_ih_bw, weight_hh_bw, bias_ih_bw, bias_hh_bw, self.act_fn
                    )
                    bw_input = tf.reverse(input, axis=[0])
                    step_out_fw, h_i_fw, c_i_fw = cell_fw(input, h_i_fw, c_i_fw)
                    step_out_bw, h_i_bw, c_i_bw = cell_bw(bw_input, h_i_bw, c_i_bw)
                    step_out_bw = tf.reverse(step_out_bw, axis=[0])
                    step_out = tf.concat([step_out_fw, step_out_bw], axis=-1)
                    y.append(step_out)
                h_out.append(h_i_fw)
                h_out.append(h_i_bw)
                c_out.append(c_i_fw)
                c_out.append(c_i_bw)
                pre_layer = tf.stack(y)
                y = []
            else:
                for j in range(time_step):
                    input = pre_layer[j, :, :]
                    cell_fw = self.rnn_cell(
                        weight_ih_fw, weight_hh_fw, bias_ih_fw, bias_hh_fw, self.act_fn
                    )
                    cell_bw = self.rnn_cell(
                        weight_ih_bw, weight_hh_bw, bias_ih_bw, bias_hh_bw, self.act_fn
                    )
                    bw_input = tf.reverse(input, axis=[0])
                    step_out_fw, h_i_fw = cell_fw(input, h_i_fw)
                    step_out_bw, h_i_bw = cell_bw(bw_input, h_i_bw)
                    step_out_bw = tf.reverse(step_out_bw, axis=[0])
                    step_out = tf.concat([step_out_fw, step_out_bw], axis=-1)
                    y.append(step_out)
                h_out.append(h_i_fw)
                h_out.append(h_i_bw)
                pre_layer = tf.stack(y)
                y = []
        h_out = tf.stack(h_out)
        c_out = tf.stack(c_out) if c is not None else None

        return pre_layer, h_out, c_out

    def _rnn_forward(self, x, h, c=None):
        pre_layer = x
        h_out = []
        c_out = []
        y = []
        time_step, batch_size, input_size = x.shape
        for i in range(self.num_layers):
            weight_ih = self.w_ih[i]
            weight_hh = self.w_hh[i]
            if self.bias:
                bias_ih = self.b_ih[i]
                bias_hh = self.b_hh[i]
            else:
                bias_ih = None
                bias_hh = None
            h_i = h[i, :, :]
            if i != 0 and self.train:
                pre_layer = tf.nn.dropout(pre_layer, rate=self.dropout)
            if c is not None:
                c_i = c[i, :, :]
                for j in range(time_step):
                    input = pre_layer[j, :, :]
                    cell = self.rnn_cell(
                        weight_ih, weight_hh, bias_ih, bias_hh, self.act_fn
                    )
                    step_out, h_i, c_i = cell(input, h_i, c_i)
                    y.append(step_out)
                h_out.append(h_i)
                c_out.append(c_i)
                pre_layer = tf.stack(y)
                y = []
            else:
                for j in range(time_step):
                    input = pre_layer[j, :, :]
                    cell = self.rnn_cell(
                        weight_ih, weight_hh, bias_ih, bias_hh, self.act_fn
                    )
                    step_out, h_i = cell(input, h_i)
                    y.append(step_out)
                h_out.append(h_i)
                pre_layer = tf.stack(y)
                y = []
        h_out = tf.stack(h_out)
        c_out = tf.stack(c_out) if c is not None else None

        return pre_layer, h_out, c_out

    def check_input(self, input_shape):
        if len(input_shape) != 3:
            raise ValueError(
                "input must have 3 dimensions. But got {}.".format(len(input_shape))
            )
        if self.input_size != input_shape[-1]:
            raise ValueError(
                "The last dimension of input should be equal to input_size {}.But got {}".format(
                    self.input_size, input_shape[-1]
                )
            )

    def check_hidden(self, h, batch_size):
        expected_hidden_size = (
            self.num_layers * self.bidirect,
            batch_size,
            self.hidden_size,
        )
        if h.shape != expected_hidden_size:
            raise ValueError(
                "Expected hidden size {}, got {}.".format(expected_hidden_size, h.shape)
            )

    def __call__(self, input, initial_states=None):
        if self.batch_first:
            input = tf.transpose(input, perm=(1, 0, 2))
        input_dtype = input.dtype
        input_shape = input.shape
        time_step, batch_size, input_size = input_shape
        self.check_input(input_shape)
        if self.mode == "LSTM":
            if initial_states is not None:
                h, c = initial_states
                self.check_hidden(h, batch_size)
                self.check_hidden(c, batch_size)
            else:
                h = tf.zeros(
                    shape=(
                        self.num_layers * self.bidirect,
                        batch_size,
                        self.hidden_size,
                    ),
                    dtype=input_dtype,
                )
                c = tf.zeros(
                    shape=(
                        self.num_layers * self.bidirect,
                        batch_size,
                        self.hidden_size,
                    ),
                    dtype=input_dtype,
                )
            if self.bidirect == 1:
                y, new_h, new_c = self._rnn_forward(input, h, c)
            else:
                y, new_h, new_c = self._bi_rnn_forward(input, h, c)
            new_states = (new_h, new_c)
        else:
            if initial_states is not None:
                h = initial_states
                self.check_hidden(h, batch_size)
            else:
                h = tf.zeros(
                    shape=(
                        self.num_layers * self.bidirect,
                        batch_size,
                        self.hidden_size,
                    ),
                    dtype=input_dtype,
                )
            if self.bidirect == 1:
                y, new_h, _ = self._rnn_forward(input, h)
            else:
                y, new_h, _ = self._bi_rnn_forward(input, h)
            new_states = new_h
        if self.batch_first:
            y = tf.transpose(y, perm=(1, 0, 2))
        return y, new_states


class layernorm(object):
    def __init__(self, normalized_shape, gamma, beta, eps, input_shape):
        self.normalized_shape = normalized_shape
        self.gamma = gamma
        self.beta = beta
        self.eps = eps
        self.input_shape = input_shape
        self.axis = list(
            range((len(input_shape) - len(normalized_shape)), len(input_shape))
        )
        self.ndims = len(input_shape)
        self.broadcast_shape = [1] * self.ndims
        for dim in self.axis:
            self.broadcast_shape[dim] = input_shape[dim]

    def _broadcast(self, v):
        if (
            v is not None
            and len(v.shape) != self.ndims
            and self.axis != [self.ndims - 1]
        ):
            return array_ops.reshape(v, self.broadcast_shape)
        return v

    def __call__(self, input):
        input_dtype = input.dtype
        if input_dtype in ("float16", "bfloat16"):
            # If mixed precision is used, cast inputs to float32 so that this is at
            # least as numerically stable as the fused version.
            input = math_ops.cast(input, "float32")
        mean, var = tf.nn.moments(input, self.axis, keepdims=True)
        scale, offset = self._broadcast(self.gamma), self._broadcast(self.beta)
        with ops.name_scope(None, "layernorm", [input, mean, var, scale, offset]):
            inv = math_ops.rsqrt(var + self.eps)
            if scale is not None:
                inv *= scale

            a = math_ops.cast(inv, input.dtype)
            b = math_ops.cast(
                offset - mean * inv if offset is not None else -mean * inv, input.dtype
            )

            output = a * input + b
        output = math_ops.cast(output, input_dtype)
        return output


class multiheadattention(object):
    def __init__(
        self,
        embed_dim,
        num_heads,
        dropout,
        batch_first,
        need_weights,
        q_weight,
        k_weight,
        v_weight,
        out_weight,
        q_bias,
        k_bias,
        v_bias,
        out_bias,
        train,
    ):
        self.embed_dim_check = embed_dim
        self.num_heads = num_heads
        self.dropout = dropout
        self.batch_first = batch_first
        self.need_weights = need_weights
        self.q_weight = q_weight
        self.k_weight = k_weight
        self.v_weight = v_weight
        self.out_weight = out_weight
        self.q_bias = q_bias
        self.k_bias = k_bias
        self.v_bias = v_bias
        self.out_bias = out_bias
        self.train = train

    def __call__(self, q, k, v, attn_mask, key_padding_mask):
        k = q if k is None else k
        v = q if v is None else v
        if self.batch_first:
            q = tf.transpose(q, perm=(1, 0, 2))
            k = tf.transpose(k, perm=(1, 0, 2))
            v = tf.transpose(v, perm=(1, 0, 2))

        # check tensor shape
        tgt_len, batch_size, embed_dim = q.shape
        src_len, _, _ = k.shape

        if embed_dim != self.embed_dim_check:
            raise ValueError(
                "Expecting embedding dimension is {}, but got {}".format(
                    self.embed_dim_check, embed_dim
                )
            )

        head_dim = embed_dim // self.num_heads
        if head_dim * self.num_heads != embed_dim:
            raise ValueError(
                "embedding dimension {} not divisible by num_heads {}".format(
                    embed_dim, self.num_heads
                )
            )
        if k.shape[:2] != v.shape[:2]:
            raise ValueError(
                "key's sequence length and batch size {} do not match value's {}".format(
                    k.shape[:2], v.shape[:2]
                )
            )

        # compute q k v linear projection
        q = tf.matmul(q, self.q_weight)
        if self.q_bias is not None:
            q = tf.nn.bias_add(q, self.q_bias)
        k = tf.matmul(k, self.k_weight)
        if self.k_bias is not None:
            k = tf.nn.bias_add(k, self.k_bias)
        v = tf.matmul(v, self.v_weight)
        if self.v_bias is not None:
            v = tf.nn.bias_add(v, self.v_bias)

        # check and prep attention mask
        if attn_mask is not None:
            if attn_mask.dtype == tf.uint8:
                warnings.warn("attn_mask tensor dtype should better be bool.")
                attn_mask = tf.cast(attn_mask, dtype=tf.bool)
            elif attn_mask.dtype not in (tf.float32, tf.float64, tf.bool):
                raise TypeError(
                    "attn_mask tensor dtype should be in ('float32', 'float64', 'bool', 'uint8'),"
                    "but got {}".format(attn_mask.dtype)
                )
            if attn_mask._rank() == 2:
                if attn_mask.shape != (tgt_len, src_len):
                    raise ValueError(
                        "The shape of 2D attn_mask should be {}, but got {}.".format(
                            (tgt_len, src_len), attn_mask.shape
                        )
                    )
                attn_mask = tf.expand_dims(attn_mask, axis=0)
                attn_mask = tf.broadcast_to(
                    attn_mask, (batch_size * self.num_heads, tgt_len, src_len)
                )
            elif attn_mask._rank() == 3:
                size_3d = (batch_size * self.num_heads, tgt_len, src_len)
                if attn_mask.shape != size_3d:
                    raise ValueError(
                        "The shape of 3D attn_mask should be {}, but got {}.".format(
                            size_3d, attn_mask.shape
                        )
                    )
            else:
                raise ValueError(
                    "attn_mask's dimension {} is not supported.".format(attn_mask.dim())
                )

        # prep mulithead q k v

        q = tf.transpose(
            tf.reshape(q, shape=(tgt_len, batch_size * self.num_heads, head_dim)),
            perm=(1, 0, 2),
        )
        k = tf.transpose(
            tf.reshape(k, shape=(src_len, batch_size * self.num_heads, head_dim)),
            perm=(1, 0, 2),
        )
        v = tf.transpose(
            tf.reshape(v, shape=(src_len, batch_size * self.num_heads, head_dim)),
            perm=(1, 0, 2),
        )

        # check and prep key padding mask
        if key_padding_mask is not None:
            if key_padding_mask.shape != (batch_size, src_len):
                raise ValueError(
                    "Expecting key_padding_mask shape is {}, but got {}.".format(
                        (batch_size, src_len), key_padding_mask.shape
                    )
                )

            if key_padding_mask.dtype == tf.uint8:
                warnings.warn("key_padding_mask tensor dtype should better be bool.")
                key_padding_mask = tf.cast(key_padding_mask, dtype=tf.bool)
            elif key_padding_mask.dtype != tf.bool:
                raise TypeError(
                    "key_padding_mask tensor dtype should be 'bool' or 'uint8', but got {}.".format(
                        key_padding_mask.dtype
                    )
                )

            key_padding_mask = tf.reshape(key_padding_mask, (batch_size, 1, 1, src_len))
            key_padding_mask = tf.broadcast_to(
                key_padding_mask, (1, self.num_heads, 1, 1)
            )
            key_padding_mask = tf.reshape(
                key_padding_mask, (batch_size * self.num_heads, 1, src_len)
            )

            if attn_mask is None:
                attn_mask = key_padding_mask
            elif attn_mask.dtype == tf.bool:
                attn_mask = tf.logical_or(attn_mask, key_padding_mask)
            else:
                key_padding_mask_inf = tf.fill(key_padding_mask.shape, float("-inf"))
                attn_mask = tf.where(key_padding_mask, key_padding_mask_inf, attn_mask)

        # convert bool mask to float
        if attn_mask is not None and attn_mask.dtype == tf.bool:
            new_attn_mask_zero = tf.zeros_like(attn_mask, dtype=tf.float32)
            new_attn_mask_inf = tf.fill(attn_mask.shape, float("-inf"))
            attn_mask = tf.where(attn_mask, new_attn_mask_inf, new_attn_mask_zero)

        q = q / math.sqrt(embed_dim)
        k = tf.transpose(k, perm=(0, 2, 1))
        attn = tf.matmul(q, k)
        if attn_mask is not None:
            attn += attn_mask
        attn = tf.nn.softmax(attn)
        if self.train:
            attn = tf.nn.dropout(attn, self.dropout)
        output = tf.matmul(attn, v)

        output = tf.reshape(
            tf.transpose(output, perm=(1, 0, 2)), shape=(tgt_len, batch_size, embed_dim)
        )
        output = tf.matmul(output, self.out_weight)
        if self.out_bias is not None:
            output = tf.nn.bias_add(output, self.out_bias)

        if self.batch_first:
            output = tf.transpose(output, perm=(1, 0, 2))

        if self.need_weights:
            attn = tf.reshape(
                attn, shape=(batch_size, self.num_heads, tgt_len, src_len)
            )
            attn = tf.reduce_sum(attn, axis=1) / self.num_heads
            return output, attn
        else:
            return output, None


class BinaryDense(object):
    def __init__(self, weights, bias):
        self.weights = weights
        self.bias = bias

    def __call__(self, inputs):
        self.weights = quantize(self.weights)
        outputs = tf.matmul(inputs, self.weights)

        if self.bias is not None:
            outputs = tf.nn.bias_add(outputs, self.bias)

        return outputs


class DorefaDense(object):
    def __init__(self, weights, bias, bitW, bitA):
        self.weights = weights
        self.bias = bias
        self.bitW = bitW
        self.bitA = bitA

    def __call__(self, inputs):
        inputs = quantize_active(cabs(inputs), self.bitA)
        self.W = quantize_weight(self.weights, self.bitW)
        outputs = tf.matmul(inputs, self.W)
        if self.bias is not None:
            outputs = tf.nn.bias_add(outputs, self.bias)

        return outputs


class TernaryDense(object):
    def __init__(self, weights, bias):
        self.weights = weights
        self.bias = bias

    def __call__(self, inputs):
        alpha = compute_alpha(self.weights)
        W_ = ternary_operation(self.weights)
        W_ = tf.math.multiply(alpha, W_)
        outputs = tf.matmul(inputs, W_)

        if self.bias is not None:
            outputs = tf.nn.bias_add(outputs, self.bias)

        return outputs


class QuanDense(object):
    def __init__(self, weights, bias, bitW, bitA):
        self.weights = weights
        self.bias = bias
        self.bitW = bitW
        self.bitA = bitA

    def __call__(self, inputs):
        inputs = quantize_active_overflow(inputs, self.bitA)
        W_ = quantize_weight_overflow(self.weights, self.bitW)
        outputs = tf.matmul(inputs, W_)
        if self.bias is not None:
            outputs = tf.nn.bias_add(outputs, self.bias)
        return outputs


class QuanDenseBn(object):
    def __init__(
        self,
        weights,
        scale_para,
        offset_para,
        moving_mean,
        moving_variance,
        decay,
        bitW,
        bitA,
        epsilon,
        is_train,
    ):
        self.weights = weights
        self.scale_para = scale_para
        self.offset_para = offset_para
        self.moving_mean = moving_mean
        self.moving_variance = moving_variance
        self.decay = decay
        self.bitW = bitW
        self.bitA = bitA
        self.epsilon = epsilon
        self.is_train = is_train

    def __call__(self, inputs):
        x = inputs
        inputs = quantize_active_overflow(inputs, self.bitA)
        mid_out = tf.matmul(x, self.weights)
        mean, variance = moments(
            x=mid_out, axes=list(range(len(mid_out.get_shape()) - 1))
        )
        update_moving_mean = moving_averages.assign_moving_average(
            self.moving_mean, mean, self.decay, zero_debias=False
        )
        update_moving_variance = moving_averages.assign_moving_average(
            self.moving_variance, variance, self.decay, zero_debias=False
        )

        if self.is_train:
            mean, var = mean_var_with_update(
                update_moving_mean, update_moving_variance, mean, variance
            )
        else:
            mean, var = self.moving_mean, self.moving_variance

        _w_fold = w_fold(self.weights, self.scale_para, var, self.epsilon)
        W = quantize_weight_overflow(_w_fold, self.bitW)
        outputs = tf.matmul(inputs, W)

        if self.offset_para is not None:
            _bias_fold = bias_fold(
                self.offset_para, self.scale_para, mean, var, self.epsilon
            )
            outputs = tf.nn.bias_add(outputs, _bias_fold)

        return outputs


class TernaryConv(object):
    def __init__(self, weights, strides, padding, data_format, dilations):
        self.weights = weights
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)

    def __call__(self, inputs):
        alpha = compute_alpha(self.weights)
        W_ = ternary_operation(self.weights)
        W_ = tf.multiply(alpha, W_)
        outputs = tf.nn.conv2d(
            input=inputs,
            filters=W_,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )
        return outputs


class QuanConv(object):
    def __init__(self, weights, strides, padding, data_format, dilations, bitW, bitA):
        self.weights = weights
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.bitW = bitW
        self.bitA = bitA

    def __call__(self, inputs):
        inputs = quantize_active_overflow(inputs, self.bitA)
        W_ = quantize_weight_overflow(self.weights, self.bitW)
        outputs = tf.nn.conv2d(
            input=inputs,
            filters=W_,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )

        return outputs


class QuanConvBn(object):
    def __init__(
        self,
        weights,
        scale_para,
        offset_para,
        moving_mean,
        moving_variance,
        strides,
        padding,
        data_format,
        dilations,
        bitW,
        bitA,
        decay,
        epsilon,
        is_train,
    ):
        self.weights = weights
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.bitW = bitW
        self.bitA = bitA
        self.scale_para = scale_para
        self.offset_para = offset_para
        self.moving_mean = moving_mean
        self.moving_variance = moving_variance
        self.decay = decay
        self.epsilon = epsilon
        self.is_train = is_train

    def __call__(self, inputs):
        x = inputs
        inputs = quantize_active_overflow(inputs, self.bitA)
        outputs = tf.nn.conv2d(
            input=x,
            filters=self.weights,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
        )
        mean, variance = tf.nn.moments(
            outputs, axes=list(range(len(outputs.get_shape()) - 1))
        )
        update_moving_mean = moving_averages.assign_moving_average(
            self.moving_mean, mean, self.decay, zero_debias=False
        )
        update_moving_variance = moving_averages.assign_moving_average(
            self.moving_variance, variance, self.decay, zero_debias=False
        )

        if self.is_train:
            mean, var = mean_var_with_update(
                update_moving_mean, update_moving_variance, mean, variance
            )
        else:
            mean, var = self.moving_mean, self.moving_variance

        _w_fold = w_fold(self.weights, self.scale_para, var, self.epsilon)

        W_ = quantize_weight_overflow(_w_fold, self.bitW)

        conv_fold = tf.nn.conv2d(
            inputs,
            W_,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
        )

        if self.offset_para is not None:
            _bias_fold = bias_fold(
                self.offset_para, self.scale_para, mean, var, self.epsilon
            )
            conv_fold = tf.nn.bias_add(conv_fold, _bias_fold, name="bn_bias_add")

        return conv_fold


class PReLU(object):
    def __init__(self, data_format):
        self.data_format = data_format

    def __call__(self, input, weight):
        if self.data_format == "channels_first":
            input = nchw_to_nhwc(input)
        pos = tf.nn.relu(input)
        neg = -weight * tf.nn.relu(-input)
        output = pos + neg
        if self.data_format == "channels_first":
            output = nhwc_to_nchw(output)
        return output


class MatMul(object):
    def __init__(self, transpose_a=False, transpose_b=False):
        self.transpose_a = transpose_a
        self.transpose_b = transpose_b

    def __call__(self, a, b):
        return tf.matmul(
            a, b, transpose_a=self.transpose_a, transpose_b=self.transpose_b
        )


class Maximum(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return tf.maximum(x=x, y=y)


class Minimum(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return tf.minimum(x=x, y=y)


class FlattenReshape(object):
    def __init__(self):
        pass

    def __call__(self, inputs):
        dim = 1
        for d in get_tensor_shape(inputs)[1:]:
            dim *= d
        return tf.reshape(inputs, [-1, dim])


class Reshape(object):
    def __init__(self, shape):
        self.shape = shape

    def __call__(self, tensor):
        return tf.reshape(tensor, self.shape)


class Concat(object):
    def __init__(self, axis):
        super(Concat, self).__init__()
        self.axis = axis

    def __call__(self, values):
        return tf.concat(values=values, axis=self.axis)


class ReduceSum(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, input):
        return tf.reduce_sum(input, axis=self.axis, keepdims=self.keepdims)


class Maximum(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return tf.maximum(x=x, y=y)


class Minimum(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return tf.minimum(x=x, y=y)


class FlattenReshape(object):
    def __init__(self):
        pass

    def __call__(self, inputs):
        dim = 1
        for d in get_tensor_shape(inputs)[1:]:
            dim *= d
        return tf.reshape(inputs, [-1, dim])


class Reshape(object):
    def __init__(self, shape):
        self.shape = shape

    def __call__(self, tensor):
        return tf.reshape(tensor, self.shape)


class Concat(object):
    def __init__(self, axis):
        super(Concat, self).__init__()
        self.axis = axis

    def __call__(self, values):
        return tf.concat(values=values, axis=self.axis)


class ReduceSum(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, input):
        return tf.reduce_sum(input, axis=self.axis, keepdims=self.keepdims)


class ReduceMean(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, inputs):
        output = tf.reduce_mean(inputs, self.axis, keepdims=self.keepdims)
        return output


class ReduceMax(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, inputs):
        output = tf.reduce_max(inputs, axis=self.axis, keepdims=self.keepdims)
        return output


class Pad2d(object):
    def __init__(
        self, padding, mode="constant", value=0.0, data_format="NCHW", name=None
    ):
        self.padding = [
            [0, 0],
            [padding[0], padding[1]],
            [padding[2], padding[3]],
            [0, 0],
        ]
        self._mode = mode
        self._value = value
        self._data_format = data_format
        self._name = name

    def __call__(self, x):
        if self._data_format == "NCHW":
            x = nchw_to_nhwc(x)
        outputs = tf.pad(x, self.padding, mode=self._mode, constant_values=self._value)
        if self._data_format == "NCHW":
            outputs = nhwc_to_nchw(outputs)
        return outputs


class Pad(object):
    def __init__(self, paddings, mode="REFLECT", constant_values=0):
        if mode not in ["CONSTANT", "REFLECT", "SYMMETRIC"]:
            raise Exception("Unsupported mode: {}".format(mode))
        self.paddings = paddings
        self.mode = mode
        self.constant_values = constant_values

    def __call__(self, x):
        outputs = tf.pad(
            x, self.paddings, mode=self.mode, constant_values=self.constant_values
        )
        return outputs


class Unstack(object):
    def __init__(self, axis, num=None):
        self.axis = axis
        self.num = num

    def __call__(self, values):
        return tf.unstack(values, num=self.num, axis=self.axis)


class Stack(object):
    def __init__(self, axis=0):
        self.axis = axis

    def __call__(self, values):
        return tf.stack(values, axis=self.axis)


class Meshgrid(object):
    def __init__(self, indexing="xy"):
        super(Meshgrid, self).__init__()
        self.index = indexing

    def __call__(self, inputs):
        return tf.meshgrid(inputs)


class ExpandDims(object):
    def __init__(self, axis):
        self.axis = axis

    def __call__(self, x):
        return tf.expand_dims(x, axis=self.axis)


class Tile(object):
    def __init__(self):
        pass

    def __call__(self, x, multiples):
        return tile(x, multiples)


class Cast(object):
    def __init__(self, dtype):
        self.dtype = dtype

    def __call__(self, x):
        return tf.cast(x, dtype=self.dtype)


class Transpose(object):
    def __init__(self, perm, conjugate=False):
        self.perm = perm
        self.conjugate = conjugate

    def __call__(self, a):
        return tf.transpose(a, self.perm, self.conjugate)


class ClipGradByValue(object):
    def __init__(self, clip_min=-1, clip_max=1):
        self.min = clip_min
        self.max = clip_max

    def __call__(self, inputs):
        return tf.clip_by_value(inputs, self.min, self.max)


class ClipGradByNorm(object):
    def __init__(self, clip_norm=0.1):
        self.clip_norm = clip_norm

    def __call__(self, inputs):
        return tf.clip_by_norm(inputs, clip_norm=self.clip_norm)


class ClipByGlobalNorm(object):
    def __init__(self, clip_norm):
        self.clip_norm = clip_norm

    def __call__(self, inputs):
        return tf.clip_by_global_norm(inputs, clip_norm=self.clip_norm)


class Floor(object):
    def __call__(self, x):
        return tf.floor(x)


class OneHot(object):
    def __init__(self, depth, on_value=None, off_value=None, axis=None, dtype=None):
        self.depth = depth
        self.on_value = on_value
        self.off_value = off_value
        self.axis = axis
        self.dtype = dtype

    def __call__(self, inputs):
        outputs = tf.one_hot(
            inputs,
            self.depth,
            on_value=self.on_value,
            off_value=self.off_value,
            axis=self.axis,
            dtype=self.dtype,
        )
        return outputs


class L2Normalize(object):
    def __init__(self, axis=None, epsilon=1e-12):
        self.axis = axis
        self.epsilon = epsilon

    def __call__(self, input, *args, **kwargs):
        outputs = tf.math.l2_normalize(input, axis=self.axis, epsilon=self.epsilon)
        return outputs


class EmbeddingLookup(object):
    def __init__(self, max_norm=None):
        self.max_norm = max_norm

    def __call__(self, params, ids):
        outputs = tf.nn.embedding_lookup(params=params, ids=ids, max_norm=self.max_norm)
        return outputs


class NCELoss(object):
    def __init__(self, num_true=1, sampled_values=None, remove_accidental_hits=False):
        self.num_true = num_true
        self.sampled_values = sampled_values
        self.remove_accidental_hits = remove_accidental_hits

    def __call__(self, weights, biases, labels, inputs, num_sampled, num_classes):
        outputs = tf.nn.nce_loss(
            weights=weights,
            biases=biases,
            inputs=inputs,
            labels=labels,
            num_sampled=num_sampled,
            num_classes=num_classes,
        )
        return outputs


class NotEqual(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return tf.not_equal(x, y)


class CountNonzero(object):
    def __init__(self, keepdims=None, dtype=tf.int64):
        self.keepdims = keepdims
        self.dtype = dtype

    def __call__(self, input, axis=None):
        return tf.math.count_nonzero(
            input, axis=axis, keepdims=self.keepdims, dtype=self.dtype
        )


class Resize:
    def __init__(
        self,
        size=None,
        scale_factor=None,
        mode="bilinear",
        align_corners=False,
        data_format="channels_first",
    ):
        self.mode = mode
        self.align_corners = align_corners
        self.size = size
        self.data_format = data_format
        self.scale_factor = scale_factor

    def __call__(self, inputs):
        if self.data_format == "channels_first":
            inputs = nchw_to_nhwc(inputs)

        if self.size is not None:
            output_size = self.size
        elif self.scale_factor is not None:
            output_size = [
                int(inputs.shape[1] * self.scale_factor[0]),
                int(inputs.shape[2] * self.scale_factor[1]),
            ]
        else:
            raise TypeError("Expect either size or scale is not None.")

        if len(get_tensor_shape(inputs)) != 4:
            raise ("The inputs shape must be 4-D Tensor.")

        if self.align_corners:
            outputs = tf.compat.v1.image.resize(
                inputs,
                size=output_size,
                method=self.mode,
                align_corners=True,
            )
        else:
            outputs = tf.image.resize(inputs, size=output_size, method=self.mode)
        if self.data_format == "channels_first":
            outputs = nhwc_to_nchw(outputs)
        return outputs


class ZeroPadding1D(object):
    def __init__(self, padding, data_format):
        if data_format == "channels_first":
            padding = ((0, 0), (0, 0), padding)
        elif data_format == "channels_last":
            padding = ((0, 0), padding, (0, 0))
        else:
            raise ValueError("data_format must be channels_first or channels_last.")
        self.pad = Pad(paddings=padding)

    def __call__(self, inputs):
        return self.pad(inputs)


class ZeroPadding2D(object):
    def __init__(self, padding, data_format):
        if data_format == "channels_first":
            padding = ((0, 0), (0, 0), padding[0], padding[1])
        elif data_format == "channels_last":
            padding = ((0, 0), padding[0], padding[1], (0, 0))
        else:
            raise ValueError("data_format must be channels_first or channels_last.")
        self.pad = Pad(paddings=padding)

    def __call__(self, inputs):
        return self.pad(inputs)


class ZeroPadding3D(object):
    def __init__(self, padding, data_format):
        if data_format == "channels_first":
            padding = ((0, 0), (0, 0), padding[0], padding[1], padding[2])
        elif data_format == "channels_last":
            padding = ((0, 0), padding[0], padding[1], padding[2], (0, 0))
        else:
            raise ValueError("data_format must be channels_first or channels_last.")
        self.pad = Pad(paddings=padding)

    def __call__(self, inputs):
        return self.pad(inputs)


class Sign(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return tf.sign(x)


class Ceil(object):
    def __call__(self, x):
        return tf.math.ceil(x)


class BatchToSpace(object):
    def __init__(self, block_size, crops):
        self.bolock_size = block_size
        self.crops = crops

    def __call__(self, input_x):
        return tf.batch_to_space(
            input=input_x, block_shape=self.bolock_size, crops=self.crops
        )


class DepthToSpace(object):
    def __init__(self, block_size, data_format="NHWC"):
        data_format, _ = preprocess_2d_format(data_format, None)
        self.block_size = block_size
        self.data_format = data_format

    def __call__(self, input):
        return tf.nn.depth_to_space(
            input, block_size=self.block_size, data_format=self.data_format
        )


class Einsum(object):
    def __init__(self, equation):
        super(Einsum, self).__init__()
        self.equation = equation

    def __call__(self, *args):
        return tf.einsum(self.equation, *args)


class Swish(object):
    def __init__(self):
        pass

    def __call__(self, x):
        raise NotImplementedError
