#! /usr/bin/python
# -*- coding: utf-8 -*-

import torch
import torch.nn.functional as F
from torch import _VF
from torch.nn import Module

from ..utils.torch_utils import (
    preprocess_1d_format,
    preprocess_2d_format,
    preprocess_3d_format,
    nchw_to_nhwc,
    nhwc_to_nchw,
)
from ..functional.torch_functional import (
    _single,
    get_tensor_shape,
    transpose,
    cast,
    same_padding,
    same_padding_deconvolution,
)


class MatMul(object):
    def __init__(self, transpose_a=False, transpose_b=False):
        self.transpose_a = transpose_a
        self.transpose_b = transpose_b

    def __call__(self, a, b):
        return torch.matmul(a, b)


class Maximum(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return torch.maximum(x, y)


class Minimum(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return torch.minimum(x, y)


class FlattenReshape(object):
    def __init__(self):
        pass

    def __call__(self, inputs):
        dim = 1
        for d in get_tensor_shape(inputs)[1:]:
            dim *= d
        return torch.reshape(inputs, [-1, dim])


class Reshape(object):
    def __init__(self, shape):
        self.shape = shape

    def __call__(self, tensor):
        return torch.reshape(tensor, self.shape)


class Concat(object):
    def __init__(self, axis=0):
        super(Concat, self).__init__()
        self.axis = axis

    def __call__(self, values):
        return torch.cat(tensors=values, dim=self.axis)


class ReduceSum(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, input):
        if self.axis is not None:
            return torch.sum(input=input, dim=self.axis)
        else:
            return torch.sum(input=input)


class ReduceMean(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, inputs):
        if self.axis is not None:
            return torch.mean(input=inputs, dim=self.axis, keepdim=self.keepdims)
        else:
            return torch.mean(inputs)


class ReduceMax(object):
    def __init__(self, axis=None, keepdims=False):
        self.axis = axis
        self.keepdims = keepdims

    def __call__(self, inputs):
        if self.axis is not None:
            if isinstance(self.axis, (list, tuple)):
                out = inputs
                for dim in self.axis[::-1]:
                    out = torch.max(out, dim=dim, keepdim=self.keepdims).values
                return out
            else:
                return torch.max(inputs, dim=self.axis, keepdim=self.keepdims).values
        else:
            return torch.max(inputs)


class Pad2d(object):
    def __init__(
        self, padding, mode="constant", value=0.0, data_format="NCHW", name=None
    ):
        self.padding = padding
        self._mode = mode
        self._value = value
        self._data_format = data_format
        self._name = name

    def __call__(self, x):
        if self._data_format == "NHWC":
            x = nhwc_to_nchw(x)
        output = torch.nn.functional.pad(x, self.padding, self._mode, value=self._value)
        if self._data_format == "NHWC":
            output = nchw_to_nhwc(output)
        return output


class Pad(object):
    def __init__(self, paddings, mode="REFLECT", constant_values=0.0):
        if mode not in ["CONSTANT", "REFLECT", "SYMMETRIC"]:
            raise Exception("Unsupported mode: {}".format(mode))
        self.paddings = self.correct_paddings(paddings)
        self.mode = mode.lower()
        self.constant_values = constant_values

    def __call__(self, x):
        if self.mode in ["symmetric", "reflect"]:
            if len(x.shape) == 3 and self.paddings[0:2] + self.paddings[4:] == (
                0,
                0,
                0,
                0,
            ):
                self.paddings = (self.paddings[2], self.paddings[3])
                x = torch.transpose(x, 1, 2)
            elif len(x.shape) == 4 and self.paddings[0:2] + self.paddings[6:] == (
                0,
                0,
                0,
                0,
            ):
                self.paddings = (self.paddings[2:6])[::-1]
                x = torch.transpose(x, 1, 3)
            elif len(x.shape) == 5 and self.paddings[0:2] + self.paddings[8:] == (
                0,
                0,
                0,
                0,
            ):
                self.paddings = (self.paddings[2:8])[::-1]
                x = torch.transpose(x, 1, 4)
            else:
                raise NotImplementedError(
                    "Only constant padding is implemented for arbitrary dimensions."
                )

        out = torch.nn.functional.pad(
            x, self.paddings, mode=self.mode, value=self.constant_values
        )

        if self.mode in ["symmetric", "reflect"]:
            if len(x.shape) == 3:
                out = torch.transpose(out, 1, 2)
            if len(x.shape) == 4:
                out = torch.transpose(out, 1, 3)
            if len(x.shape) == 5:
                out = torch.transpose(out, 1, 4)
        return out

    def correct_paddings(self, paddings):
        paddings = paddings[::-1]
        _padding = []
        for p_i in paddings:
            for pj in p_i:
                _padding.append(pj)
        return tuple(_padding)

    def __call__(self, x):
        if self.mode in ["symmetric", "reflect"]:
            if len(x.shape) == 3 and self.paddings[0:2] + self.paddings[4:] == (
                0,
                0,
                0,
                0,
            ):
                self.paddings = (self.paddings[2], self.paddings[3])
                x = torch.transpose(x, 1, 2)
            elif len(x.shape) == 4 and self.paddings[0:2] + self.paddings[6:] == (
                0,
                0,
                0,
                0,
            ):
                self.paddings = (self.paddings[2:6])[::-1]
                x = torch.transpose(x, 1, 3)
            elif len(x.shape) == 5 and self.paddings[0:2] + self.paddings[8:] == (
                0,
                0,
                0,
                0,
            ):
                self.paddings = (self.paddings[2:8])[::-1]
                x = torch.transpose(x, 1, 4)
            else:
                raise NotImplementedError(
                    "Only constant padding is implemented for arbitrary dimensions."
                )

        out = torch.nn.functional.pad(
            x, self.paddings, mode=self.mode, value=self.constant_values
        )

        if self.mode in ["symmetric", "reflect"]:
            if len(x.shape) == 3:
                out = torch.transpose(out, 1, 2)
            if len(x.shape) == 4:
                out = torch.transpose(out, 1, 3)
            if len(x.shape) == 5:
                out = torch.transpose(out, 1, 4)
        return out

    def correct_paddings(self, paddings):
        paddings = paddings[::-1]
        _padding = []
        for p_i in paddings:
            for pj in p_i:
                _padding.append(pj)
        return tuple(_padding)


class Unstack(object):
    def __init__(self, axis, num=None):
        self.axis = axis
        self.num = num

    def __call__(self, values):
        out = []
        for o in torch.chunk(values, chunks=self.num, dim=self.axis):
            out.append(torch.squeeze(o))
        return out


class Stack(object):
    def __init__(self, axis=0):
        self.axis = axis

    def __call__(self, values):
        return torch.stack(values, dim=self.axis)


class Meshgrid(object):
    def __init__(self, indexing="xy"):
        super(Meshgrid, self).__init__()
        self.index = indexing

    def __call__(self, *inputs):
        return torch.meshgrid(*inputs, indexing=self.index)


class ExpandDims(object):
    def __init__(self, axis=0):
        self.axis = axis

    def __call__(self, input):
        return torch.unsqueeze(input=input, dim=self.axis)


class Tile(object):
    def __init__(self):
        pass

    def __call__(self, input, multiples):
        return torch.tile(input, dims=multiples)


class Cast(object):
    def __init__(self, dtype=None):
        self.dtype = dtype

    def __call__(self, x):
        return x.type(self.dtype)


class Transpose(object):
    def __init__(self, perm, conjugate=False):
        self.perm = perm
        self.conjugate = conjugate

    def __call__(self, a):
        return transpose(a, self.perm, self.conjugate)


class ClipGradByValue(object):
    def __init__(self, clip_min=-1, clip_max=1):
        self.min = clip_min
        self.max = clip_max

    def __call__(self, inputs):
        torch.nn.utils.clip_grad_value_(inputs, clip_value=self.max)


class ClipGradByNorm(object):
    def __init__(self, clip_norm=0.1):
        self.clip_norm = clip_norm

    def __call__(self, inputs):
        torch.nn.utils.clip_grad_norm_(inputs, max_norm=self.clip_norm, norm_type=2)


class ClipByGlobalNorm(object):
    def __init__(self, clip_norm):
        self.clip_norm = clip_norm

    def __call__(self, inputs):
        raise NotImplementedError


class Floor(object):
    def __call__(self, x):
        return torch.floor(x)


class OneHot(object):
    def __init__(self, depth=-1, on_value=None, off_value=None, axis=None, dtype=None):
        self.depth = depth
        self.on_value = on_value
        self.off_value = off_value
        self.axis = axis
        self.dtype = dtype

    def __call__(self, inputs):
        if [self.on_value, self.off_value] == [None, None]:
            return torch.nn.functional.one_hot(inputs, self.depth)
        else:
            out = torch.nn.functional.one_hot(inputs, self.depth)
            out = cast(out, torch.float64)
            out = torch.where(out == 1, self.on_value, out)
            out = torch.where(out == 0, self.off_value, out)
            out = cast(out, torch.int)
            return out


class L2Normalize(object):
    def __init__(self, axis=None, epsilon=1e-12):
        self.axis = axis
        self.epsilon = epsilon

    def __call__(self, input, *args, **kwargs):
        return torch.nn.functional.normalize(
            input, p=2, dim=self.axis, eps=self.epsilon
        )


class EmbeddingLookup(object):
    def __init__(self, max_norm=None):
        self.max_norm = max_norm
        self.padding_idx = None
        self.norm_type = 2.0
        self.scale_grad_by_freq = False
        self.sparse = False

    def __call__(self, params, ids):
        return F.embedding(
            ids,
            params,
            self.padding_idx,
            self.max_norm,
            self.norm_type,
            self.scale_grad_by_freq,
            self.sparse,
        )


class NCELoss(object):
    def __init__(self, num_true=1, sampled_values=None, remove_accidental_hits=False):
        self.num_true = num_true
        self.sampled_values = sampled_values
        self.remove_accidental_hits = remove_accidental_hits

    def __call__(self, weights, biases, labels, inputs, num_sampled, num_classes):
        raise NotImplementedError


class NotEqual(object):
    def __init__(self):
        pass

    def __call__(self, x, y):
        return torch.ne(x, y)


class CountNonzero(object):
    def __init__(self, keepdims=None, dtype=None):
        self.keepdims = keepdims
        self.dtype = dtype

    def __call__(self, input, axis=None):
        return torch.count_nonzero(input, dim=axis)


class Resize:
    def __init__(self, size=None, scale_factor=None, mode='bilinear', align_corners=False, data_format="channels_first"):
        self.mode = mode
        self.align_corners = align_corners
        self.size = size
        self.data_format = data_format
        self.scale_factor = scale_factor

    def __call__(self, inputs):
        if self.data_format == "channels_last":
            inputs = nhwc_to_nchw(inputs)
            
        outputs = F.interpolate(
            inputs,
            size=self.size,
            scale_factor=self.scale_factor,
            mode=self.mode,
            align_corners=self.align_corners,
        )
        if self.data_format == "channels_last":
            outputs = nchw_to_nhwc(outputs)
            
        return outputs


class ZeroPadding1D(object):
    def __init__(self, padding, data_format):
        if data_format == "channels_first":
            padding = ((0, 0), (0, 0), padding)
        elif data_format == "channels_last":
            padding = ((0, 0), padding, (0, 0))
        else:
            raise ValueError("data_format must be channels_first or channels_last.")
        self.pad = Pad(paddings=padding)

    def __call__(self, inputs):
        return self.pad(inputs)


class ZeroPadding2D(object):
    def __init__(self, padding, data_format):
        if data_format == "channels_first":
            padding = ((0, 0), (0, 0), padding[0], padding[1])
        elif data_format == "channels_last":
            padding = ((0, 0), padding[0], padding[1], (0, 0))
        else:
            raise ValueError("data_format must be channels_first or channels_last.")
        self.pad = Pad(paddings=padding)

    def __call__(self, inputs):
        return self.pad(inputs)


class ZeroPadding3D(object):
    def __init__(self, padding, data_format):
        if data_format == "channels_first":
            padding = ((0, 0), (0, 0), padding[0], padding[1], padding[2])
        elif data_format == "channels_last":
            padding = ((0, 0), padding[0], padding[2], padding[1], (0, 0))
        else:
            raise ValueError("data_format must be channels_first or channels_last.")
        self.pad = Pad(paddings=padding)

    def __call__(self, inputs):
        return self.pad(inputs)


class Sign(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return torch.sign(x)


class Ceil(object):
    def __call__(self, x):
        return torch.ceil(x)


class BatchToSpace(object):
    def __init__(self, block_size, crops):
        self.bolock_size = block_size
        self.crops = crops

    def __call__(self, input_x):
        raise NotImplementedError


class DepthToSpace(object):
    def __init__(self, block_size, data_format):
        self.block_size = block_size
        self.data_format = data_format

    def __call__(self, input):
        if self.data_format == "channels_last":
            input = nhwc_to_nchw(input)
        output = torch.nn.functional.pixel_shuffle(
            input, upscale_factor=self.block_size
        )
        if self.data_format == "channels_last":
            output = nchw_to_nhwc(output)
        return output


class Einsum(object):
    def __init__(self, equation):
        super(Einsum, self).__init__()
        self.equation = equation

    def __call__(self, *args):
        return torch.einsum(self.equation, *args)


class Swish(object):
    def __init__(self):
        pass

    def __call__(self, x):
        raise NotImplementedError


class ReLU(object):
    def __init__(self, inplace=False):
        self.inplace = inplace

    def __call__(self, x):
        return F.relu(x, self.inplace)


class ELU(object):
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def __call__(self, x):
        return F.elu(x, alpha=self.alpha)


class ReLU6(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return F.relu6(x)


class LeakyReLU(object):
    def __init__(self, negative_slope=0.01):
        self.negative_slope = negative_slope

    def __call__(self, x):
        return F.leaky_relu(x, negative_slope=self.negative_slope)


class Softplus(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return F.softplus(x)


class Tanh(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return F.tanh(x)


class Sigmoid(object):
    def __init__(self):
        pass

    def __call__(self, x):
        return torch.sigmoid(x)


class Softmax(object):
    def __init__(self, axis=None):
        self.axis = axis

    def __call__(self, x):
        return F.softmax(x, dim=self.axis)


class GeLU(object):
    def __init__(self, approximate=False):
        self.approximate = approximate

    def __call__(self, x):
        return F.gelu(x)


class SiLU(object):
    def __init__(self):
        pass

    def __call__(self, inputs):
        return inputs * torch.sigmoid(inputs)


class Dropout(object):
    def __init__(self, p, seed=0):
        self.p = p
        self.seed = seed

    def __call__(self, inputs):
        return F.dropout(inputs, p=self.p)


def drop_path(x, drop_prob=0.0, training=False):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of
    residual blocks).

    We follow the implementation
    https://github.com/rwightman/pytorch-image-models/blob/a2727c1bf78ba0d7b5727f5f95e37fb7f8866b1f/timm/models/layers/drop.py  # noqa: E501
    """
    if drop_prob == 0.0 or not training:
        return x
    keep_prob = 1 - drop_prob
    # handle tensors with different dimensions, not just 4D tensors.
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    output = x.div(keep_prob) * random_tensor.floor()
    return output


class BiasAdd(object):
    """
    Adds bias to value.

    Parameters
    ----------
    x : tensor
        A Tensor with type float, double, int64, int32, uint8, int16, int8, complex64, or complex128.
    bias : tensor
        Must be the same type as value unless value is a quantized type,
        in which case a different quantized type may be used.
    Returns
    -------
        A Tensor with the same type as value.
    """

    def __init__(self, data_format="channels_first"):
        super(BiasAdd, self).__init__()
        if data_format in ["channels_first", "NCL", "NCW", "NCHW", "NCDHW"]:
            self.data_format = "channels_first"
        elif data_format in ["channels_last", "NLC", "NWC", "NHWC", "NDHWC"]:
            self.data_format = "channels_last"
        else:
            raise ("Unsupported data format: " + str(data_format))

    def __call__(self, x, bias):
        if len(x.shape) > 2 and self.data_format == "channels_first":
            x = nchw_to_nhwc(x)
        outputs = torch.add(x, bias)
        if len(x.shape) > 2 and self.data_format == "channels_first":
            outputs = nhwc_to_nchw(outputs)
        return outputs


class Conv1D(object):
    def __init__(
        self,
        stride,
        padding,
        data_format="NWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        groups=1,
    ):
        self.stride = stride
        self.dilations = dilations
        self.groups = groups
        self.data_format, self.padding = preprocess_1d_format(data_format, padding)

    def __call__(self, input, filters):
        if self.data_format == "NLC":
            input = nhwc_to_nchw(input)
        if self.padding == "same":
            out = self.conv1d_same_padding(input, filters)
        else:
            out = F.conv1d(
                input,
                filters,
                stride=self.stride,
                padding=self.padding,
                dilation=self.dilations,
                groups=self.groups,
            )
        if self.data_format == "NLC":
            out = nchw_to_nhwc(out)

        return out

    def conv1d_same_padding(self, input, filters):
        rows_odd, padding_rows = same_padding(input, filters, self.stride, 1)
        if rows_odd:
            input = F.pad(input, [0, int(rows_odd)], "replicate")
        return F.conv1d(
            input,
            filters,
            stride=self.stride,
            padding=(padding_rows // 2),
            groups=self.groups,
        )


class Conv2D(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NHWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        groups=1,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        if self.data_format == "NHWC":
            self.strides = (strides[1], strides[2])
            self.dilations = (dilations[1], dilations[2])
        elif self.data_format == "NCHW":
            self.strides = (strides[2], strides[3])
            self.dilations = (dilations[2], dilations[3])
        self.groups = groups

    def __call__(self, input, filters):
        if self.data_format == "NHWC":
            input = nhwc_to_nchw(input)

        if self.padding == "same":
            output = self.conv2d_same_padding(input, filters)
        else:
            output = F.conv2d(
                input,
                filters,
                stride=self.strides,
                padding=self.padding,
                dilation=self.dilations,
                groups=self.groups,
            )

        if self.data_format == "NHWC":
            output = nchw_to_nhwc(output)
        return output

    def conv2d_same_padding(self, input, weight, bias=None):
        rows_odd, cols_odd, padding_rows, padding_cols = same_padding(
            input, weight, self.strides, self.dilations
        )
        if rows_odd or cols_odd:
            input = F.pad(input, [0, int(cols_odd), 0, int(rows_odd)])

        return F.conv2d(
            input,
            weight,
            bias,
            self.strides,
            padding=(padding_rows // 2, padding_cols // 2),
            dilation=self.dilations,
            groups=self.groups,
        )


class Conv3D(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NDHWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        groups=1,
    ):
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        if self.data_format == "NDHWC":
            self._strides = (strides[1], strides[2], strides[3])
            self._dilations = (dilations[1], dilations[2], dilations[3])
        elif self.data_format == "NCDHW":
            self._strides = (strides[2], strides[3], strides[4])
            self._dilations = (dilations[2], dilations[3], dilations[4])
        self.groups = groups

    def __call__(self, input, filters):
        if self.data_format == "NDHWC":
            input = nhwc_to_nchw(input)

        if self.padding == "same":
            out = self.conv3d_same_padding(input, weight=filters)
        else:
            out = F.conv3d(
                input,
                weight=filters,
                stride=self._strides,
                padding=self.padding,
                dilation=self._dilations,
                groups=self.groups,
            )

        if self.data_format == "NDHWC":
            out = nchw_to_nhwc(out)

        return out

    def conv3d_same_padding(self, input, weight, bias=None, groups=1):
        (
            rows_odd,
            cols_odd,
            depth_odd,
            padding_rows,
            padding_cols,
            padding_depth,
        ) = same_padding(input, weight, self._strides, self._dilations)
        if rows_odd or cols_odd or depth_odd:
            input = F.pad(
                input, [0, int(cols_odd), 0, int(rows_odd), 0, int(depth_odd)]
            )

        return F.conv3d(
            input,
            weight,
            bias,
            self._strides,
            padding=(padding_rows // 2, padding_cols // 2, padding_depth // 2),
            dilation=self._dilations,
            groups=groups,
        )


class MaxPool1d(object):
    def __init__(self, ksize, strides, padding, return_mask, data_format=None):
        self.data_format, self.padding = preprocess_1d_format(
            data_format=data_format, padding=padding
        )
        self.max_pool1d = MaxPool(
            [
                ksize,
            ],
            strides,
            padding,
            return_mask,
            data_format,
        )

    def __call__(self, inputs):
        return self.max_pool1d(inputs)


class MaxPool(object):
    def __init__(self, ksize, strides, padding, return_mask=False, data_format=None):
        self.ksize = ksize
        self.strides = strides
        self.return_mask = return_mask
        if data_format in ["channels_last", "NLC", "NWC", "NHWC", "NDHWC"]:
            self.data_format = "channels_last"
        elif data_format in ["channels_first", "NCL", "NCW", "NCHW", "NCDHW"]:
            self.data_format = "channels_first"
        self.padding = padding
        if self.padding in ["VALID", "valid"]:
            self.padding = 0

    def __call__(self, inputs):
        if self.data_format == "channels_last":
            inputs = nhwc_to_nchw(inputs)
        if len(inputs.shape) == 2 or len(inputs.shape) == 3:
            if self.padding in ["SAME", "same"]:
                out = self.maxpool1d_same_padding(inputs)
            else:
                out = F.max_pool1d(
                    inputs,
                    self.ksize,
                    self.strides,
                    padding=self.padding,
                    return_indices=self.return_mask,
                )
        if len(inputs.shape) == 4:
            if self.padding in ["SAME", "same"]:
                out = self.maxpool2d_same_padding(inputs)
            else:
                out = F.max_pool2d(
                    inputs,
                    self.ksize,
                    self.strides,
                    padding=self.padding,
                    return_indices=self.return_mask,
                )
        if len(inputs.shape) == 5:
            if self.padding in ["SAME", "same"]:
                out = self.maxpool3d_same_padding(inputs)
            else:
                out = F.max_pool3d(
                    inputs,
                    self.ksize,
                    self.strides,
                    padding=self.padding,
                    return_indices=self.return_mask,
                )

        if self.data_format == "channels_last":
            if self.return_mask:
                outputs = [None, None]
                outputs[0] = nchw_to_nhwc(out[0])
                outputs[1] = nchw_to_nhwc(out[1])
                return outputs
            else:
                return nchw_to_nhwc(out)
        else:
            return out

    def maxpool1d_same_padding(self, input):
        rows_odd, padding_rows = same_padding(input, self.ksize, self.strides, 1)
        if rows_odd:
            input = F.pad(input, [0, int(rows_odd)], "constant", float("-inf"))
        return F.max_pool1d(
            input,
            self.ksize,
            self.strides,
            padding=(padding_rows // 2),
            return_indices=self.return_mask,
        )

    def maxpool2d_same_padding(self, input):
        rows_odd, cols_odd, padding_rows, padding_cols = same_padding(
            input, self.ksize, self.strides, (1, 1)
        )
        if rows_odd or cols_odd:
            # TODO The fill value for maxpool is -INF.
            input = F.pad(
                input, [0, int(rows_odd), 0, int(cols_odd)], "constant", float("-inf")
            )

        return F.max_pool2d(
            input,
            self.ksize,
            self.strides,
            padding=(padding_rows // 2, padding_cols // 2),
            return_indices=self.return_mask,
        )

    def maxpool3d_same_padding(self, input):
        (
            rows_odd,
            cols_odd,
            depth_odd,
            padding_rows,
            padding_cols,
            padding_depth,
        ) = same_padding(input, self.ksize, self.strides, (1, 1, 1))
        if rows_odd or cols_odd or depth_odd:
            input = F.pad(
                input,
                [0, int(cols_odd), 0, int(rows_odd), 0, int(depth_odd)],
                "constant",
                float("-inf"),
            )
        return F.max_pool3d(
            input,
            self.ksize,
            self.strides,
            padding=(padding_rows // 2, padding_cols // 2, padding_depth // 2),
            return_indices=self.return_mask,
        )


class AvgPool1d(object):
    def __init__(self, ksize, strides, padding, data_format=None):
        self.data_format, self.padding = preprocess_1d_format(
            data_format=data_format, padding=padding
        )
        self.avg_poo1d = AvgPool(
            [
                ksize,
            ],
            strides,
            padding,
            data_format,
        )

    def __call__(self, inputs):
        return self.avg_poo1d(inputs)


class AvgPool(object):
    def __init__(self, ksize, strides, padding, data_format=None):
        self.ksize = ksize
        self.strides = strides
        if data_format in ["channels_last", "NLC", "NWC", "NHWC", "NDHWC"]:
            self.data_format = "channels_last"
        elif data_format in ["channels_first", "NCL", "NCW", "NCHW", "NCDHW"]:
            self.data_format = "channels_first"
        self.padding = padding
        if self.padding in ["VALID", "valid"]:
            self.padding = 0

    def __call__(self, inputs):
        if self.data_format == "channels_last":
            inputs = nhwc_to_nchw(inputs)
        if len(inputs.shape) == 2 or len(inputs.shape) == 3:
            if self.padding in ["SAME", "same"]:
                out = self.avgpool1d_same_padding(inputs)
            else:
                out = F.avg_pool1d(
                    inputs, self.ksize, self.strides, padding=self.padding
                )
        if len(inputs.shape) == 4:
            if self.padding in ["SAME", "same"]:
                out = self.avgpool2d_same_padding(inputs)
            else:
                out = F.avg_pool2d(
                    inputs, self.ksize, self.strides, padding=self.padding
                )
        if len(inputs.shape) == 5:
            if self.padding in ["SAME", "same"]:
                out = self.avgpool3d_same_padding(inputs)
            else:
                out = F.avg_pool3d(
                    inputs, self.ksize, self.strides, padding=self.padding
                )

        if self.data_format == "channels_last":
            return nchw_to_nhwc(out)
        else:
            return out

    def avgpool1d_same_padding(self, input):
        rows_odd, padding_rows = same_padding(input, self.ksize, self.strides, 1)
        if rows_odd:
            input = F.pad(input, [0, int(rows_odd)], "replicate")
        return F.avg_pool1d(
            input, self.ksize, self.strides, padding=(padding_rows // 2)
        )

    def avgpool2d_same_padding(self, input):
        rows_odd, cols_odd, padding_rows, padding_cols = same_padding(
            input, self.ksize, self.strides, (1, 1)
        )
        if rows_odd or cols_odd:
            # TODO The fill value for maxpool is -INF.
            input = F.pad(input, [0, int(rows_odd), 0, int(cols_odd)], mode="replicate")

        return F.avg_pool2d(
            input,
            self.ksize,
            self.strides,
            padding=(padding_rows // 2, padding_cols // 2),
        )

    def avgpool3d_same_padding(self, input):
        (
            rows_odd,
            cols_odd,
            depth_odd,
            padding_rows,
            padding_cols,
            padding_depth,
        ) = same_padding(input, self.ksize, self.strides, (1, 1, 1))
        if rows_odd or cols_odd or depth_odd:
            input = F.pad(
                input,
                [0, int(cols_odd), 0, int(rows_odd), 0, int(depth_odd)],
                mode="replicate",
            )
        return F.avg_pool3d(
            input,
            self.ksize,
            self.strides,
            padding=(padding_rows // 2, padding_cols // 2, padding_depth // 2),
        )


class MaxPool3d(object):
    def __init__(self, ksize, strides, padding, return_mask, data_format=None):
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.max_pool3d = MaxPool(ksize, strides, padding, return_mask, data_format)

    def __call__(self, inputs):
        return self.max_pool3d(inputs)


# def max_pool3d(input, ksize, strides, padding, data_format=None):
#     """
#     Performs the max pooling on the input.
#
#     Parameters
#     ----------
#     input : tensor
#          A 5-D Tensor of the format specified by data_format.
#     ksize : int or list of ints
#         An int or list of ints that has length 1, 3 or 5.
#         The size of the window for each dimension of the input tensor.
#     strides : int or list of ints
#         An int or list of ints that has length 1, 3 or 5.
#         The stride of the sliding window for each dimension of the input tensor.
#     padding : string
#         'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
#     data_format : string
#          "NDHWC", "NCDHW". Defaults to "NDHWC". The data format of the input and output data.
#          With the default format "NDHWC", the data is stored in the order of: [batch, in_depth, in_height, in_width, in_channels].
#          Alternatively, the format could be "NCDHW", the data storage order is: [batch, in_channels, in_depth, in_height, in_width].
#     name : string
#          A name for the operation (optional).
#
#     Returns
#     -------
#         A Tensor of format specified by data_format. The max pooled output tensor.
#     """
#
#     data_format, padding = preprocess_3d_format(data_format, padding)
#     max_pool3d_obj = MaxPool(ksize, strides, padding, data_format)
#     return max_pool3d_obj(input)


class AvgPool3d(object):
    def __init__(self, ksize, strides, padding, data_format=None):
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.avg_pool3d_obj = AvgPool(ksize, strides, self.padding, self.data_format)

    def __call__(self, inputs):
        return self.avg_pool3d_obj(inputs)


# def avg_pool3d(input, ksize, strides, padding, data_format=None):
#     """
#     Performs the average pooling on the input.
#
#     Parameters
#     ----------
#     input : tensor
#         A 5-D Tensor of shape [batch, height, width, channels] and type float32, float64, qint8, quint8, or qint32.
#     ksize : int or list of ints
#         An int or list of ints that has length 1, 3 or 5. The size of the window for each dimension of the input tensor.
#     strides : int or list of ints
#         An int or list of ints that has length 1, 3 or 5.
#         The stride of the sliding window for each dimension of the input tensor.
#     padding : string
#         'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
#     data_format : string
#         'NDHWC' and 'NCDHW' are supported.
#     name : string
#         Optional name for the operation.
#
#     Returns
#     -------
#         A Tensor with the same type as value. The average pooled output tensor.
#     """
#
#     avg_pool_obj = AvgPool(ksize, strides, padding, data_format)
#     return avg_pool_obj(input)


class DepthwiseConv2d(object):
    def __init__(
        self,
        strides,
        padding,
        data_format=None,
        dilations=None,
        ksize=None,
        channel_multiplier=1,
        in_channels=None,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        if self.data_format == "NHWC":
            self.strides = (1, strides[0], strides[1], 1)
            self.dilations = (1, dilations[0], dilations[1], 1)
        elif self.data_format == "NCHW":
            self.strides = (1, 1, strides[0], strides[1])
            self.dilations = (1, 1, dilations[0], dilations[1])
        self.depthwise = Conv2D(
            padding=self.padding,
            strides=self.strides,
            data_format=self.data_format,
            dilations=self.dilations,
            groups=in_channels,
        )
        self.pointwise = Conv2D(
            strides=(1, 1, 1, 1),
            padding=self.padding,
            data_format=self.data_format,
            dilations=self.dilations,
            k_size=1,
        )

    def __call__(self, input, filter, point_filter=None):
        depthwise_conv = self.depthwise(input, filter)
        pointwise_conv = self.pointwise(depthwise_conv, point_filter)

        return pointwise_conv


class Conv1d_transpose(object):
    def __init__(
        self,
        stride,
        padding,
        data_format="NWC",
        dilations=None,
        out_channel=None,
        k_size=None,
        in_channels=None,
        groups=None,
    ):
        self.stride = stride
        self.dilations = dilations
        self.data_format, self.padding = preprocess_1d_format(data_format, padding)
        self.groups = groups

    def __call__(self, input, filters):
        if self.data_format == "NLC":
            input = nhwc_to_nchw(input)
        if self.padding == "same":
            out = self.conv1d_transpose_same_padding(input, filters)
        else:
            out = F.conv_transpose1d(
                input,
                weight=filters,
                padding=(0 if isinstance(self.padding, str) else self.padding),
                stride=self.stride,
                dilation=self.dilations,
                groups=self.groups,
            )
        if self.data_format == "NLC":
            out = nchw_to_nhwc(out)
        return out

    def conv1d_transpose_same_padding(self, input, filters):
        rows_odd, padding_rows = same_padding_deconvolution(
            input, filters, self.stride, 1
        )
        if rows_odd:
            input = F.pad(input, [0, int(rows_odd)])
            out_padding = 0
        else:
            out_padding = 1
        return F.conv_transpose1d(
            input,
            weight=filters,
            padding=(padding_rows // 2),
            stride=self.stride,
            dilation=self.dilations,
            output_padding=out_padding,
        )


class Conv2d_transpose(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NHWC",
        dilations=None,
        name=None,
        out_channels=None,
        k_size=None,
        in_channels=None,
        groups=1,
        output_padding=0,
    ):
        self.strides = strides
        self.dilations = dilations
        self.name = name
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.groups = groups
        self.output_padding = output_padding

    def _output_padding(
        self,
        input,
        output_size,
        stride,
        padding,
        kernel_size,
        num_spatial_dims,
        dilation=None,
    ):
        if output_size is None:
            ret = _single(self.output_padding)  # converting to list if was not already
        else:
            has_batch_dim = input.dim() == num_spatial_dims + 2
            num_non_spatial_dims = 2 if has_batch_dim else 1
            if len(output_size) == num_non_spatial_dims + num_spatial_dims:
                output_size = output_size[num_non_spatial_dims:]
            if len(output_size) != num_spatial_dims:
                raise ValueError(
                    "ConvTranspose{}D: for {}D input, output_size must have {} or {} elements (got {})".format(
                        num_spatial_dims,
                        input.dim(),
                        num_spatial_dims,
                        num_non_spatial_dims + num_spatial_dims,
                        len(output_size),
                    )
                )

            min_sizes = []
            max_sizes = []
            for d in range(num_spatial_dims):
                dim_size = (
                    (input.size(d + num_non_spatial_dims) - 1) * stride[d]
                    - 2 * padding[d]
                    + (dilation[d] if dilation is not None else 1)
                    * (kernel_size[d] - 1)
                    + 1
                )
                min_sizes.append(dim_size)
                max_sizes.append(min_sizes[d] + stride[d] - 1)

            for i in range(len(output_size)):
                size = output_size[i]
                min_size = min_sizes[i]
                max_size = max_sizes[i]
                if size < min_size or size > max_size:
                    raise ValueError(
                        (
                            "requested an output size of {}, but valid sizes range "
                            "from {} to {} (for an input of {})"
                        ).format(output_size, min_sizes, max_sizes, input.size()[2:])
                    )

            res = []
            for d in range(num_spatial_dims):
                res.append(output_size[d] - min_sizes[d])

            ret = res
        return ret

    def __call__(self, input, filters, output_size):
        if self.data_format == "NHWC":
            input = nhwc_to_nchw(input)
        if self.padding == "same":
            out = self.conv2d_transpore_same(input, filters)
        else:
            out_padding = self._output_padding(
                input,
                output_size,
                self.strides,
                (0 if isinstance(self.padding, str) else self.padding),
                filters.shape,
                2,
                self.dilations,
            )
            out = F.conv_transpose2d(
                input,
                weight=filters,
                padding=(0 if isinstance(self.padding, str) else self.padding),
                stride=self.strides,
                dilation=self.dilations,
                output_padding=out_padding,
                groups=self.groups,
            )
        if self.data_format == "NHWC":
            out = nchw_to_nhwc(out)
        return out

    def conv2d_transpore_same(self, input, filters):
        rows_odd, cols_odd, padding_rows, padding_cols = same_padding_deconvolution(
            input, filters, self.strides, (1, 1)
        )
        if rows_odd or cols_odd:
            input = F.pad(input, [0, int(rows_odd), 0, int(cols_odd)])
            out_padding = 0
        else:
            out_padding = 1
        out = F.conv_transpose2d(
            input,
            weight=filters,
            padding=(padding_rows // 2, padding_cols // 2),
            stride=self.strides,
            dilation=self.dilations,
            output_padding=out_padding,
            groups=self.groups,
        )
        return out


class Conv3d_transpose(object):
    def __init__(
        self,
        strides,
        padding,
        data_format="NDHWC",
        dilations=None,
        name=None,
        out_channel=None,
        k_size=None,
        in_channels=None,
        groups=None,
    ):
        self.strides = strides
        self.dilations = dilations
        self.name = name
        self.out_channel = out_channel
        self.data_format, self.padding = preprocess_3d_format(data_format, padding)
        self.groups = groups

    def __call__(self, input, filters):
        if self.data_format == "NDHWC":
            input = nhwc_to_nchw(input)
        if self.padding == "same":
            out = self.conv3d_transpore_same(input, filters)
        else:
            out = F.conv_transpose3d(
                input,
                weight=filters,
                padding=(0 if isinstance(self.padding, str) else self.padding),
                stride=self.strides,
                dilation=self.dilations,
                groups=self.groups,
            )
        if self.data_format == "NDHWC":
            out = nchw_to_nhwc(out)
        return out

    def conv3d_transpore_same(self, input, filters):
        (
            rows_odd,
            cols_odd,
            depth_odd,
            padding_rows,
            padding_cols,
            padding_depth,
        ) = same_padding_deconvolution(input, filters, self.strides, (1, 1, 1))
        if rows_odd or cols_odd or depth_odd:
            input = F.pad(
                input, [0, int(rows_odd), 0, int(cols_odd), 0, int(depth_odd)]
            )
            out_padding = 0
        else:
            out_padding = 1
        out = F.conv_transpose3d(
            input,
            weight=filters,
            padding=(padding_rows // 2, padding_cols // 2, padding_depth // 2),
            stride=self.strides,
            dilation=self.dilations,
            output_padding=out_padding,
        )
        return out


class BatchNorm(object):
    """
    The :class:`BatchNorm` is a batch normalization layer for both fully-connected and convolution outputs.
    See ``tf.nn.batch_normalization`` and ``tf.nn.moments``.

    Parameters
    ----------
    decay : float
        A decay factor for `ExponentialMovingAverage`.
        Suggest to use a large value for large dataset.
    epsilon : float
        Eplison.
    act : activation function
        The activation function of this layer.
    is_train : boolean
        Is being used for training or inference.
    beta_init : initializer or None
        The initializer for initializing beta, if None, skip beta.
        Usually you should not skip beta unless you know what happened.
    gamma_init : initializer or None
        The initializer for initializing gamma, if None, skip gamma.
        When the batch normalization layer is use instead of 'biases', or the next layer is linear, this can be
        disabled since the scaling can be done by the next layer. see `Inception-ResNet-v2 <https://github.com/tensorflow/models/blob/master/research/slim/nets/inception_resnet_v2.py>`__
    moving_mean_init : initializer or None
        The initializer for initializing moving mean, if None, skip moving mean.
    moving_var_init : initializer or None
        The initializer for initializing moving var, if None, skip moving var.
    num_features: int
        Number of features for input tensor. Useful to build layer if using BatchNorm1d, BatchNorm2d or BatchNorm3d,
        but should be left as None if using BatchNorm. Default None.
    data_format : str
        channels_last 'channel_last' (default) or channels_first.
    name : None or str
        A unique layer name.

    Examples
    ---------
    With TensorLayer

    >>> net = tlx.layers.Input([None, 50, 50, 32], name='input')
    >>> net = tlx.layers.BatchNorm()(net)

    Notes
    -----
    The :class:`BatchNorm` is universally suitable for 3D/4D/5D input in static model, but should not be used
    in dynamic model where layer is built upon class initialization. So the argument 'num_features' should only be used
    for subclasses :class:`BatchNorm1d`, :class:`BatchNorm2d` and :class:`BatchNorm3d`. All the three subclasses are
    suitable under all kinds of conditions.

    References
    ----------
    - `Source <https://github.com/ry/tensorflow-resnet/blob/master/resnet.py>`__
    - `stackoverflow <http://stackoverflow.com/questions/38312668/how-does-one-do-inference-with-batch-normalization-with-tensor-flow>`__

    """

    def __init__(
        self,
        decay=0.9,
        eps=0.00001,
        gamma=None,
        beta=None,
        moving_mean=None,
        moving_var=None,
        num_features=None,
        data_format="channels_first"
    ):
        self.decay = decay
        self.eps = eps
        self.data_format = data_format
        self.beta = beta
        self.gamma = gamma
        self.moving_mean = moving_mean
        self.moving_var = moving_var
        self.num_features = num_features,
        self.axes = None

        if self.decay < 0.0 or 1.0 < self.decay:
            raise ValueError("decay should be between 0 to 1")

    def __call__(self, inputs,is_train = False):
        if self.data_format == "channels_last":
            inputs = nhwc_to_nchw(inputs)

        out = torch.nn.functional.batch_norm(
            inputs,
            running_mean=self.moving_mean,
            running_var=self.moving_var,
            weight=self.gamma,
            bias=self.beta,
            training=is_train,
            momentum=self.decay,
            eps=self.eps,
        )
        if self.data_format == "channels_last":
            out = nchw_to_nhwc(out)
        return out



class GroupNorm(object):
    def __init__(
        self,
        num_groups,
        beta=None,
        gamma=None,
        data_format="channels_first",
        eps=1e-5,
    ):
        self.num_groups = num_groups
        self.eps = eps
        self.data_format = data_format
        self.bata = beta
        self.gamma = gamma

    def __call__(self, inputs):
        if self.data_format == "channels_last":
            inputs = nhwc_to_nchw(inputs)

        out = torch.nn.functional.group_norm(
            input, self.num_groups, self.beta, self.gamma, self.eps
        )
        if self.data_format == "channels_last":
            out = nchw_to_nhwc(out)
        return out


class InstanceNorm(object):
    def __init__(
        self,
        num_features,
        beta=None,
        gamma=None,
        eps=1e-5,
        data_format="channels_first",
    ) -> None:
        self.num_features = num_features
        self.eps = eps
        self.data_format = data_format
        self.beta = beta
        self.gamma = gamma

    def __call__(self, inputs):
        if self.data_format == "channels_last":
            inputs = nhwc_to_nchw(inputs)

        out = torch.nn.functional.instance_norm(
            inputs,
            running_mean=None,
            running_var=None,
            weight=self.beta,
            bias=self.gamma,
            use_input_stats=True,
            eps=self.eps,
        )
        if self.data_format == "channels_last":
            out = nchw_to_nhwc(out)
        return out


class GroupConv2D(object):
    def __init__(
        self, strides, padding, data_format, dilations, out_channel, k_size, groups=1
    ):
        self.groups = groups
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.conv2d = Conv2D(
            strides, self.padding, self.data_format, dilations, groups=self.groups
        )

    def __call__(self, input, filters):
        return self.conv2d(input, filters)


class SeparableConv1D(object):
    def __init__(
        self,
        stride,
        padding,
        data_format,
        dilations,
        out_channel,
        k_size,
        in_channel,
        depth_multiplier,
    ):
        self.data_format, self.padding = preprocess_1d_format(data_format, padding)
        self.depthwise_conv = Conv1D(
            stride, self.padding, self.data_format, dilations, groups=in_channel
        )
        self.pointwise_conv = Conv1D(1, self.padding, self.data_format, 1)

    def __call__(self, inputs, depthwise_filters, pointwise_filters):
        depthwise_conv = self.depthwise_conv(inputs, depthwise_filters)
        pointwise_conv = self.pointwise_conv(depthwise_conv, pointwise_filters)
        return pointwise_conv


class SeparableConv2D(object):
    def __init__(
        self,
        strides,
        padding,
        data_format,
        dilations,
        out_channel,
        k_size,
        in_channel,
        depth_multiplier,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.depthwise_conv = Conv2D(
            strides, self.padding, self.data_format, dilations, groups=in_channel
        )
        self.pointwise_conv = Conv2D((1, 1), self.padding, self.data_format, (1, 1))

    def __call__(self, input, filter, point_filter=None):
        depthwise_conv = self.depthwise_conv(input, filter)
        pointwise_conv = self.pointwise_conv(depthwise_conv, point_filter)
        return pointwise_conv


class AdaptiveMeanPool1D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_1d_format(data_format, None)
        self.op = torch.nn.AdaptiveAvgPool1d(output_size=output_size)

    def __call__(self, input):
        if self.data_format == "NLC":
            input = nhwc_to_nchw(input)
        output = self.op(input)
        if self.data_format == "NLC":
            output = nchw_to_nhwc(output)
        return output


class AdaptiveMeanPool2D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_2d_format(data_format, None)
        self.op = torch.nn.AdaptiveAvgPool2d(output_size=output_size)

    def __call__(self, inputs):
        if self.data_format == "NHWC":
            inputs = nhwc_to_nchw(inputs)
        output = self.op(inputs)
        if self.data_format == "NHWC":
            output = nchw_to_nhwc(output)
        return output


class AdaptiveMeanPool3D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_3d_format(data_format, None)
        self.op = torch.nn.AdaptiveAvgPool3d(output_size=output_size)

    def __call__(self, inputs):
        if self.data_format == "NDHWC":
            inputs = nhwc_to_nchw(inputs)
        output = self.op(inputs)
        if self.data_format == "NDHWC":
            output = nchw_to_nhwc(output)
        return output


class AdaptiveMaxPool1D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_1d_format(data_format, None)
        self.op = torch.nn.AdaptiveMaxPool1d(output_size=output_size)

    def __call__(self, input):
        if self.data_format == "NLC":
            input = nhwc_to_nchw(input)
        output = self.op(input)
        if self.data_format == "NLC":
            output = nchw_to_nhwc(output)
        return output


class AdaptiveMaxPool2D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_2d_format(data_format, None)
        self.op = torch.nn.AdaptiveMaxPool2d(output_size=output_size)

    def __call__(self, inputs):
        if self.data_format == "NHWC":
            inputs = nhwc_to_nchw(inputs)
        output = self.op(inputs)
        if self.data_format == "NHWC":
            output = nchw_to_nhwc(output)
        return output


class AdaptiveMaxPool3D(object):
    def __init__(self, output_size, data_format):
        self.data_format, _ = preprocess_3d_format(data_format, None)
        self.op = torch.nn.AdaptiveMaxPool3d(output_size=output_size)

    def __call__(self, inputs):
        if self.data_format == "NDHWC":
            inputs = nhwc_to_nchw(inputs)
        output = self.op(inputs)
        if self.data_format == "NDHWC":
            output = nchw_to_nhwc(output)
        return output


class BinaryConv2D(object):
    def __init__(
        self, strides, padding, data_format, dilations, out_channel, k_size, in_channel
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.strides = strides
        self.dilations = dilations

    def quantize(self, x):
        raise NotImplementedError

    def __call__(self, inputs, filters):
        raise NotImplementedError


class DorefaConv2D(object):
    def __init__(
        self,
        bitW,
        bitA,
        strides,
        padding,
        data_format,
        dilations,
        out_channel,
        k_size,
        in_channel,
    ):
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.strides = strides
        self.dilations = dilations
        self.bitW = bitW
        self.bitA = bitA

    def _quantize_dorefa(self, x, k):
        raise NotImplementedError

    def cabs(self, x):
        raise NotImplementedError

    def quantize_active(self, x, bitA):
        raise NotImplementedError

    def quantize_weight(self, x, bitW, force_quantization=False):
        raise NotImplementedError

    def __call__(self, inputs, filters):
        raise NotImplementedError


class rnncell(object):
    def __init__(self, weight_ih, weight_hh, bias_ih, bias_hh, act):
        self.weight_ih = weight_ih
        self.weight_hh = weight_hh
        self.bias_ih = bias_ih
        self.bias_hh = bias_hh
        self.act = act

    def __call__(self, input, h):
        if self.act == "tanh":
            h = _VF.rnn_tanh_cell(
                input,
                h,
                self.weight_ih,
                self.weight_hh,
                self.bias_ih,
                self.bias_hh,
            )
        else:
            h = _VF.rnn_relu_cell(
                input,
                h,
                self.weight_ih,
                self.weight_hh,
                self.bias_ih,
                self.bias_hh,
            )
        return h, h


class lstmcell(object):
    def __init__(self, weight_ih, weight_hh, bias_ih, bias_hh, act=None):
        self.weight_ih = weight_ih
        self.weight_hh = weight_hh
        self.bias_ih = bias_ih
        self.bias_hh = bias_hh

    def __call__(self, input, h, c):
        h = (h, c)
        h, c = _VF.lstm_cell(
            input,
            h,
            self.weight_ih,
            self.weight_hh,
            self.bias_ih,
            self.bias_hh,
        )
        return h, h, c


class grucell(object):
    def __init__(self, weight_ih, weight_hh, bias_ih, bias_hh, act=None):
        self.weight_ih = weight_ih
        self.weight_hh = weight_hh
        self.bias_ih = bias_ih
        self.bias_hh = bias_hh

    def __call__(self, input, h):
        h = _VF.gru_cell(
            input,
            h,
            self.weight_ih,
            self.weight_hh,
            self.bias_ih,
            self.bias_hh,
        )
        return h, h


class rnnbase(Module):
    def __init__(
        self,
        mode,
        input_size,
        hidden_size,
        num_layers,
        bias,
        batch_first,
        dropout,
        bidirectional,
        is_train,
        w_ih,
        w_hh,
        b_ih,
        b_hh,
    ):
        super(rnnbase, self).__init__()
        self.mode = mode
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bias = bias
        self.batch_first = batch_first
        self.dropout = float(dropout)
        self.train = is_train
        if not 0 <= dropout < 1:
            raise ValueError("dropout should be a number in range [0, 1).")
        if dropout > 0 and num_layers == 1:
            raise ValueError(
                "dropout option adds dropout after all but last "
                "recurrent layer, so non-zero dropout expects "
                "num_layers greater than 1, but got dropout={} and "
                "num_layers={}".format(dropout, num_layers)
            )
        self.bidirectional = bidirectional
        self.num_directions = 2 if bidirectional else 1
        self.rnn_impls = {
            "RNN_TANH": _VF.rnn_tanh,
            "RNN_RELU": _VF.rnn_relu,
            "GRU": _VF.gru,
        }
        self.w_ih = w_ih
        self.w_hh = w_hh
        self.b_ih = b_ih
        self.b_hh = b_hh

        # stdv = 1.0 / np.sqrt(self.hidden_size)
        # _init = tf.random_uniform_initializer(minval=-stdv, maxval=stdv)
        self.proj_size = 0
        self.act_fn = None
        self._flat_weights_names = []
        self._all_weights = []
        cur = 0
        for layer in range(num_layers):
            for direction in range(self.num_directions):
                if bias:
                    layer_params = (w_ih[cur], w_hh[cur], b_ih[cur], b_hh[cur])
                else:
                    layer_params = (w_ih[cur], w_hh[cur])

                suffix = "_reverse" if direction == 1 else ""
                param_names = ["weight_ih_l{}{}", "weight_hh_l{}{}"]
                if bias:
                    param_names += ["bias_ih_l{}{}", "bias_hh_l{}{}"]
                param_names = [x.format(layer, suffix) for x in param_names]

                for name, param in zip(param_names, layer_params):
                    setattr(self, name, param)
                self._flat_weights_names.extend(param_names)
                self._all_weights.append(param_names)
                cur += 1
        self._flat_weights = [
            (lambda wn: getattr(self, wn) if hasattr(self, wn) else None)(wn)
            for wn in self._flat_weights_names
        ]
        self.flatten_parameters()

    def flatten_parameters(self):
        if len(self._flat_weights) != len(self._flat_weights_names):
            return

        for w in self._flat_weights:
            if not isinstance(w, torch.Tensor):
                return
        first_fw = self._flat_weights[0]
        dtype = first_fw.dtype
        for fw in self._flat_weights:
            if (
                not isinstance(fw.data, torch.Tensor)
                or not (fw.data.dtype == dtype)
                or not fw.data.is_cuda
                or not torch.backends.cudnn.is_acceptable(fw.data)
            ):
                return
        unique_data_ptrs = set(p.data_ptr() for p in self._flat_weights)
        if len(unique_data_ptrs) != len(self._flat_weights):
            return

        with torch.cuda.device_of(first_fw):
            import torch.backends.cudnn.rnn as rnn

            with torch.no_grad():
                if torch._use_cudnn_rnn_flatten_weight():
                    num_weights = 4 if self.bias else 2
                    if self.proj_size > 0:
                        num_weights += 1
                    torch._cudnn_rnn_flatten_weight(
                        self._flat_weights,
                        num_weights,
                        self.input_size,
                        rnn.get_cudnn_mode(self.mode),
                        self.hidden_size,
                        self.proj_size,
                        self.num_layers,
                        self.batch_first,
                        bool(self.bidirectional),
                    )

    def _apply(self, fn):
        ret = super(rnnbase, self)._apply(fn)
        self._flat_weights = [
            (lambda wn: getattr(self, wn) if hasattr(self, wn) else None)(wn)
            for wn in self._flat_weights_names
        ]
        self.flatten_parameters()
        return ret

    def check_input(self, input_shape):
        if len(input_shape) != 3:
            raise ValueError(
                "input must have 3 dimensions. But got {}.".format(len(input_shape))
            )
        if self.input_size != input_shape[-1]:
            raise ValueError(
                "The last dimension of input should be equal to input_size {}.But got {}".format(
                    self.input_size, input_shape[-1]
                )
            )

    def check_hidden(self, h, batch_size):
        expected_hidden_size = (
            self.num_layers * self.num_directions,
            batch_size,
            self.hidden_size,
        )
        if h.shape != expected_hidden_size:
            raise ValueError(
                "Expected hidden size {}, got {}.".format(expected_hidden_size, h.shape)
            )

    def forward(self, input, states):
        batch_size = input.shape[0] if self.batch_first else input.shape[1]
        input_shape = input.shape
        self.check_input(input_shape)
        if self.mode == "LSTM":
            if states is None:
                h = torch.zeros(
                    self.num_layers * self.num_directions,
                    batch_size,
                    self.hidden_size,
                    dtype=input.dtype,
                    device=input.device,
                )
                c = torch.zeros(
                    self.num_layers * self.num_directions,
                    batch_size,
                    self.hidden_size,
                    dtype=input.dtype,
                    device=input.device,
                )
                states = (h, c)
            else:
                h, c = states
                self.check_hidden(h, batch_size)
                self.check_hidden(c, batch_size)
            result = _VF.lstm(
                input,
                states,
                self._flat_weights,
                self.bias,
                self.num_layers,
                self.dropout,
                self.training,
                self.bidirectional,
                self.batch_first,
            )
            return result[0], result[1:]
        else:
            if states is None:
                h = torch.zeros(
                    self.num_layers * self.num_directions,
                    batch_size,
                    self.hidden_size,
                    dtype=input.dtype,
                    device=input.device,
                )
                states = h
            else:
                self.check_hidden(states, batch_size)
            impl = self.rnn_impls[self.mode]
            result = impl(
                input,
                states,
                self._flat_weights,
                self.bias,
                self.num_layers,
                self.dropout,
                self.training,
                self.bidirectional,
                self.batch_first,
            )
            return result[0], result[1]


class layernorm(object):
    def __init__(self, normalized_shape, gamma, beta, eps, input_shape):
        self.normalized_shape = normalized_shape
        self.gamma = gamma
        self.beta = beta
        self.eps = eps
        self.input_shape = input_shape
        self.axis = list(
            range((len(input_shape) - len(normalized_shape)), len(input_shape))
        )
        self.ndims = len(input_shape)
        self.broadcast_shape = [1] * self.ndims
        for dim in self.axis:
            self.broadcast_shape[dim] = input_shape[dim]

    def __call__(self, input):
        return F.layer_norm(
            input, self.normalized_shape, self.gamma, self.beta, self.eps
        )


class multiheadattention(Module):
    def __init__(
        self,
        embed_dim,
        num_heads,
        dropout,
        batch_first,
        need_weights,
        q_weight,
        k_weight,
        v_weight,
        out_weight,
        q_bias,
        k_bias,
        v_bias,
        out_bias,
        train,
    ):
        super(multiheadattention, self).__init__()
        self.embed_dim_check = embed_dim
        self.num_heads = num_heads
        self.dropout = dropout
        self.batch_first = batch_first
        self.need_weights = need_weights
        self.q_weight = q_weight
        self.k_weight = k_weight
        self.v_weight = v_weight
        self.out_weight = out_weight
        self.q_bias = q_bias
        self.k_bias = k_bias
        self.v_bias = v_bias
        self.out_bias = out_bias
        self.train = train
        self.head_dim = embed_dim // num_heads
        assert (
            self.head_dim * num_heads == self.embed_dim_check
        ), "embed_dim must be divisible by num_heads"
        self.register_parameter("in_proj_weight", None)

        if q_bias is not None:
            self.in_proj_bias = torch.cat((self.q_bias, self.k_bias, self.v_bias))
        else:
            self.register_parameter("in_proj_bias", None)

        self.bias_k = self.bias_v = None
        self.add_zero_attn = False

    def forward(self, q, k, v, attn_mask, key_padding_mask):
        k = q if k is None else k
        v = q if v is None else v
        if self.batch_first:
            q, k, v = [x.transpose(1, 0) for x in (q, k, v)]
        attn_output, attn_output_weights = F.multi_head_attention_forward(
            q,
            k,
            v,
            self.embed_dim_check,
            self.num_heads,
            self.in_proj_weight,
            self.in_proj_bias,
            self.bias_k,
            self.bias_v,
            self.add_zero_attn,
            self.dropout,
            self.out_weight,
            self.out_bias,
            training=self.training,
            key_padding_mask=key_padding_mask,
            need_weights=self.need_weights,
            attn_mask=attn_mask,
            use_separate_proj_weight=True,
            q_proj_weight=self.q_weight,
            k_proj_weight=self.k_weight,
            v_proj_weight=self.v_weight,
        )
        if self.batch_first:
            return attn_output.transpose(1, 0), attn_output_weights
        else:
            return attn_output, attn_output_weights


class BinaryDense(object):
    def __init__(self, weights, bias):
        self.weights = weights
        self.bias = bias

    def __call__(self, inputs):
        raise NotImplementedError


class DorefaDense(object):
    def __init__(self, weights, bias, bitW, bitA):
        self.weights = weights
        self.bias = bias
        self.bitW = bitW
        self.bitA = bitA

    def __call__(self, inputs):
        raise NotImplementedError


class TernaryDense(object):
    def __init__(self, weights, bias):
        self.weights = weights
        self.bias = bias

    def __call__(self, inputs):
        raise NotImplementedError


class QuanDense(object):
    def __init__(self, weights, bias, bitW, bitA):
        self.weights = weights
        self.bias = bias
        self.bitW = bitW
        self.bitA = bitA

    def __call__(self, inputs):
        raise NotImplementedError


class QuanDenseBn(object):
    def __init__(
        self,
        weights,
        scale_para,
        offset_para,
        moving_mean,
        moving_variance,
        decay,
        bitW,
        bitA,
        epsilon,
        is_train,
    ):
        self.weights = weights
        self.scale_para = scale_para
        self.offset_para = offset_para
        self.moving_mean = moving_mean
        self.moving_variance = moving_variance
        self.decay = decay
        self.bitW = bitW
        self.bitA = bitA
        self.epsilon = epsilon
        self.is_train = is_train

    def __call__(self, inputs):
        raise NotImplementedError


class TernaryConv(object):
    def __init__(self, weights, strides, padding, data_format, dilations):
        self.weights = weights
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)

    def __call__(self, inputs):
        raise NotImplementedError


class QuanConv(object):
    def __init__(self, weights, strides, padding, data_format, dilations, bitW, bitA):
        self.weights = weights
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.bitW = bitW
        self.bitA = bitA

    def __call__(self, inputs):
        raise NotImplementedError


class QuanConvBn(object):
    def __init__(
        self,
        weights,
        scale_para,
        offset_para,
        moving_mean,
        moving_variance,
        strides,
        padding,
        data_format,
        dilations,
        bitW,
        bitA,
        decay,
        epsilon,
        is_train,
    ):
        self.weights = weights
        self.strides = strides
        self.dilations = dilations
        self.data_format, self.padding = preprocess_2d_format(data_format, padding)
        self.bitW = bitW
        self.bitA = bitA
        self.scale_para = scale_para
        self.offset_para = offset_para
        self.moving_mean = moving_mean
        self.moving_variance = moving_variance
        self.decay = decay
        self.epsilon = epsilon
        self.is_train = is_train

    def __call__(self, inputs):
        raise NotImplementedError


class RReLU(object):
    r"""Applies the randomized leaky rectified liner unit function, element-wise,
    as described in the paper:

<<<<<<< Updated upstream:algicm/models/backend/nn/torch_nn.py
    `Empirical Evaluation of Rectified Activations in Convolutional Network`_.

    The function is defined as:

    .. math::
        \text{RReLU}(x) =
        \begin{cases}
            x & \text{if } x \geq 0 \\
            ax & \text{ otherwise }
        \end{cases}

    where :math:`a` is randomly sampled from uniform distribution
    :math:`\mathcal{U}(\text{lower}, \text{upper})`.

     See: https://arxiv.org/pdf/1505.00853.pdf

    Args:
        lower (float): lower bound of the uniform distribution. Default: :math:`\frac{1}{8}`
        upper (float): upper bound of the uniform distribution. Default: :math:`\frac{1}{3}`
        inplace (bool): can optionally do the operation in-place. Default: ``False``

    Shape:
        - Input: :math:`(*)`, where :math:`*` means any number of dimensions.
        - Output: :math:`(*)`, same shape as the input.

    Examples::

        >>> m = RReLU(0.1, 0.3)
        >>> input = torch.randn(2)
        >>> output = m(input)

    .. _`Empirical Evaluation of Rectified Activations in Convolutional Network`:
        https://arxiv.org/abs/1505.00853
    """

    def __init__(
        self, lower: float = 0.125, upper: float = 1 / 3, inplace: bool = True, **kwargs
    ):
        self.lower = lower
        self.upper = upper

    def __call__(self, input, train):
        return torch.rrelu(input, lower=self.lower, upper=self.upper, training=train)


class PReLU(object):
    def __init__(self, data_format):
        self.data_format = data_format

    def __call__(self, input, weight):
        if self.data_format == "channels_last":
            input = nhwc_to_nchw(input)
        output = torch.prelu(input, weight)
        if self.data_format == "channels_last":
            output = nchw_to_nhwc(output)
        return output
