from algicm import BACKEND

if BACKEND == "tensorflow":
    from .tensorflow_nn import *
elif BACKEND == "torch":
    from .torch_nn import *
else:
    raise NotImplementedError("This backend is not supported")
