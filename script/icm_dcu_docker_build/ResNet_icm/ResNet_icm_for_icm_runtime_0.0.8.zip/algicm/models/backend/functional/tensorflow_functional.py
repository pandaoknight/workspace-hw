import random
import numpy as np
import math
import tensorflow as tf
from tensorflow.python.framework import ops
from tensorflow.python.ops import math_ops, nn_ops
from tensorflow.python.keras import backend
from contextlib import contextmanager

from ..utils.tensorflow_utils import (
    nchw_to_nhwc,
    nhwc_to_nchw,
    padding_format,
    preprocess_1d_format,
    preprocess_2d_format,
    preprocess_3d_format,
    preprocess_padding,
    _RandomGenerator,
    _dtypeDict,
)


def dtype_str(x):
    if isinstance(x, str):
        if x in list(_dtypeDict.keys()):
            return _dtypeDict[x]
        else:
            raise NotImplementedError("The input data type is incorrect.")
    else:
        return x


def set_context(**kwargs):
    raise Exception("Using TenosrFlow backend,You don't need to set context")


def get_tensor_shape(x):
    """
    Get the shape of tensor

    Parameters
    ----------
    x : tensor
         type float16, float32, float64, int32, complex64, complex128.

    Returns
    -------
        list.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x_in = tlx.layers.Input((32, 3, 3, 32))
    >>> x_shape = tlx.ops.get_tensor_shape(x_in)

    """

    return x.get_shape().as_list()


# initializers


def zeros(shape, dtype="float32", device=None):
    """
    Creates a tensor with all elements set to zero.

    Parameters
    ----------
    shape : A list of integers
        a tuple of integers, or a 1-D Tensor of type int32.
    dtype : tensor or str
        The DType of an element in the resulting Tensor
    device : str or None
        create a tensor on 'cpu' or 'gpu', defautl is None.

    Returns
    -------
        A Tensor with all elements set to zero.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.zeros((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.zeros((10, 25, 25, 10), dtype='float32')

    """

    return tf.zeros(shape=shape, dtype=dtype_str(dtype))


def ones(shape, dtype="float32", device=None):
    """
    Creates a tensor with all elements set to ones.

    Parameters
    ----------
    shape : A list of integers
        a tuple of integers, or a 1-D Tensor of type int32.
    dtype : tensor or str
        The DType of an element in the resulting Tensor
    device : str or None
        create a tensor on 'cpu' or 'gpu', defautl is None.

    Returns
    -------
        A Tensor with all elements set to zero.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.ones((10, 25, 25, 10), dtype='float32')

    """

    return tf.ones(shape=shape, dtype=dtype_str(dtype))


def constant(value=None, dtype="float32", shape=None, device=None):
    """
    Creates a constant tensor from a tensor-like object.

    Parameters
    ----------
    value : list
        A constant value (or list) of output type dtype.
    dtype : tensor or str
         The type of the elements of the resulting tensor.
    shape : tuple
        Optional dimensions of resulting tensor.
    device : str or None
        create a tensor on 'cpu' or 'gpu', defautl is None.

    Returns
    -------
        A Constant Tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(0.5, (32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.constant(0.5, (10, 25, 25, 10), dtype='float32')

    """

    return tf.constant(value=value, dtype=dtype_str(dtype), shape=shape)


def random_uniform(shape, minval=0, maxval=1, dtype="float32", seed=None):
    """
    Outputs random values from a uniform distribution.

    Parameters
    ----------
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    minval : float
        The lower bound on the range of random values to generate (inclusive). Defaults to 0.
    maxval : float
        The upper bound on the range of random values to generate (exclusive). Defaults to 1 if dtype is floating point.
    dtype : tensor or str
        The type of the output: float16, float32, float64, int32, or int64.
    seed : int
         Used in combination with tf.random.set_seed to create a reproducible sequence of tensors across multiple calls.
    Returns
    -------
        A tensor of the specified shape filled with random uniform values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.random_uniform((32, 3, 3, 32), maxval=1.0, dtype=tlx.int32)
    >>> y = tlx.ops.random_uniform((10, 25, 25, 10), maxval=1.0, dtype='float32')

    """

    outputs = tf.random.uniform(shape=shape,
                                minval=minval,
                                maxval=maxval,
                                dtype=dtype_str(dtype),
                                seed=seed)
    return outputs


def random_normal(shape, mean=0.0, stddev=1.0, dtype="float32", seed=None):
    """
    Outputs random values from a normal distribution.

    Parameters
    ----------
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    mean : float
        The mean of the normal distribution
    stddev : float
        The standard deviation of the normal distribution.
    dtype : tensor or str
        The type of the output.
    seed : A Python integer
         Used to create a random seed for the distribution

    Returns
    -------
        A tensor of the specified shape filled with random normal values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.random_normal((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.random_normal((10, 25, 25, 10), dtype='float32')

    """

    outputs = tf.random.normal(shape=shape,
                               mean=mean,
                               stddev=stddev,
                               dtype=dtype_str(dtype),
                               seed=seed)
    return outputs


def truncated_normal(shape, mean=0.0, stddev=1.0, dtype="float32", seed=None):
    """
    Outputs random values from a truncated normal distribution.

    Parameters
    ----------
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    mean : float
        The mean of the normal distribution
    stddev : float
        The standard deviation of the normal distribution.
    dtype : tensor or str
        The type of the output.
    seed : A Python integer
         Used to create a random seed for the distribution

    Returns
    -------
        A tensor of the specified shape filled with random truncated normal values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.truncated_normal((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.truncated_normal((10, 25, 25, 10), dtype='float32')

    """

    outputs = tf.random.truncated_normal(shape=shape,
                                         mean=mean,
                                         stddev=stddev,
                                         dtype=dtype_str(dtype),
                                         seed=seed)
    return outputs


def _get_dtype(dtype):
    if dtype is None:
        dtype = backend.floatx()
    return dtype


def _assert_float_dtype(dtype):
    if not dtype.is_floating:
        raise ValueError("Expected floating point type, got %s." % dtype)
    return dtype


def compute_fans(shape):
    if len(shape) < 1:  # Just to avoid errors for constants.
        fan_in = fan_out = 1
    elif len(shape) == 1:
        fan_in = fan_out = shape[0]
    elif len(shape) == 2:
        fan_in = shape[0]
        fan_out = shape[1]
    else:
        receptive_field_size = 1
        for dim in shape[:-2]:
            receptive_field_size *= dim
        fan_in = shape[-2] * receptive_field_size
        fan_out = shape[-1] * receptive_field_size
    return int(fan_in), int(fan_out)


def calculate_gain(nonlinearity, param=None):
    linear_fns = [
        "linear",
        "conv1d",
        "conv2d",
        "conv3d",
        "conv_transpose1d",
        "conv_transpose2d",
        "conv_transpose3d",
    ]
    if nonlinearity in linear_fns or nonlinearity == "sigmoid":
        return 1
    elif nonlinearity == "tanh":
        return 5.0 / 3
    elif nonlinearity == "relu":
        return math.sqrt(2.0)
    elif nonlinearity == "leaky_relu":
        if param is None:
            negative_slope = 0.01
        elif isinstance(param, int) or isinstance(param, float):
            negative_slope = param
        else:
            raise ValueError(
                "negative_slope {} not a valid number".format(param))
        return math.sqrt(2.0 / (1 + negative_slope**2))
    elif nonlinearity == "selu":
        return 3.0 / 4
    else:
        raise ValueError("Unsupported nonlinearity {}".format(nonlinearity))


def kaiming_normal(shape,
                   a=0,
                   mode="fan_in",
                   nonlinearity="leaky_relu",
                   dtype="float32",
                   seed=None):
    """
    He normal initializer.

    Parameters
    ----------
    seed : A Python integer.
        Used to seed the random generator.
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    dtype : tensor or str
        The type of the output.

    Returns
    -------
        A tensor of the specified shape filled with he normal values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.he_normal((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.he_normal((10, 25, 25, 10), dtype='float32')

    """
    fan_in, fan_out = compute_fans(shape)
    correct_fan = fan_in if mode == "fan_in" else fan_out
    gain = calculate_gain(nonlinearity, a)
    std = gain / math.sqrt(correct_fan)
    dtype = _assert_float_dtype(_get_dtype(dtype))
    return _RandomGenerator(seed).random_normal(shape, 0.0, std, dtype)


def kaiming_uniform(shape,
                    a=0,
                    mode="fan_in",
                    nonlinearity="leaky_relu",
                    dtype="float32",
                    seed=None):
    """

    Parameters
    ----------
    shape
    a
    mode
    nonlinearity
    dtype
    seed

    Returns
    -------

    """
    fan_in, fan_out = compute_fans(shape)
    correct_fan = fan_in if mode == "fan_in" else fan_out
    gain = calculate_gain(nonlinearity, a)
    std = gain / math.sqrt(correct_fan)
    bound = math.sqrt(3.0) * std
    dtype = _assert_float_dtype(_get_dtype(dtype))
    return _RandomGenerator(seed).random_uniform(shape, -bound, bound, dtype)


def xavier_normal(shape, gain=1.0, dtype="float32", seed=None):
    """
    Xavier normal.

    Parameters
    ----------
    seed : A Python integer.
        Used to seed the random generator.
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    dtype : tensor or str
        The type of the output.

    Returns
    -------
        A tensor of the specified shape filled with xavier normal values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.xavier_normal((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.xavier_normal((10, 25, 25, 10), dtype='float32')

    """
    fan_in, fan_out = compute_fans(shape)
    std = gain * math.sqrt(2.0 / float(fan_in + fan_out))
    dtype = _assert_float_dtype(_get_dtype(dtype))
    return _RandomGenerator(seed).random_normal(shape, 0.0, std, dtype)


def xavier_uniform(shape, gain=1.0, dtype="float32", seed=None):
    """
    Xavier uniform.

    Parameters
    ----------
    seed : A Python integer.
        Used to seed the random generator.
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    dtype : tensor or str
        The type of the output.

    Returns
    -------
        A tensor of the specified shape filled with xavier uniform values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.xavier_uniform((32, 3, 3, 32), dtype=tlx.int32)
    >>> y = tlx.ops.xavier_uniform((10, 25, 25, 10), dtype='float32')

    """
    fan_in, fan_out = compute_fans(shape)
    std = gain * math.sqrt(2.0 / float(fan_in + fan_out))
    bound = math.sqrt(3.0) * std
    dtype = _assert_float_dtype(_get_dtype(dtype))
    return _RandomGenerator(seed).random_uniform(shape, -bound, bound, dtype)


def Variable(initial_value, name, trainable=True, device=None):
    """
    Creates a new variable with value initial_value.

    Parameters
    ----------
    initial_value : tensor
        A Tensor, or Python object convertible to a Tensor
    name : str
        Optional name for the variable. Defaults to 'Variable' and gets uniquified automatically.
    device : str or None
        create a tensor on 'cpu' or 'gpu', defautl is None.
    Returns
    -------
        Variable

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.Variable(tlx.ops.ones(shape=(10, 20)), name='w')

    """

    var = tf.Variable(initial_value=initial_value,
                      name=name,
                      trainable=trainable)
    return var


def matmul(a, b, transpose_a=False, transpose_b=False):
    """
    Multiplies matrix a by matrix b, producing a * b.

    Parameters
    ----------
    a : tensor
         type float16, float32, float64, int32, complex64, complex128 and rank > 1.
    b : tensor
        with same type and rank as a.
    transpose_a : boolean
        If True, a is transposed before multiplication.
    transpose_b : boolean
        If True, b is transposed before multiplication.

    Returns
    -------
        A Tensor of the same type as a and b

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.convert_to_tensor(np.random.random([2,3,2]), dtype="float32")
    >>> y = tlx.convert_to_tensor(np.random.random([2,2,3]), dtype="float32")
    >>> z = tlx.ops.matmul(x, y)
    >>> print(z.shape)
    >>> [2,3,3]
    """

    outputs = tf.matmul(a, b, transpose_a=transpose_a, transpose_b=transpose_b)
    return outputs


def add(value, bias):
    """
    Returns x + y element-wise.

    Parameters
    ----------
    value :  tensor.
        Must be one of the following types: bfloat16, half, float32, float64,
        uint8, int8, int16, int32, int64, complex64, complex128, string.
    bias : tensor
        Must have the same type as a

    Returns
    -------
        A Tensor. Has the same type as a.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> value = tlx.ones(shape=(10, 20))
    >>> bias = tlx.ones(shape=(20))
    >>> x = tlx.ops.add(value, bias)

    """

    outputs = tf.add(value, bias)
    return outputs


def dtypes(dt):
    """
    Data dtypes.

    Parameters
    ----------
    dt : string
         It could be 'uint8', 'uint16', 'uint32', 'uint64', 'int8', 'int16',
         'int32', 'int64', 'float16', 'float32', 'float64', 'DType'.

    Returns
    -------
    Data dtypes

    """

    if dt not in _dtypeDict.keys():
        raise Exception("Unsupported dtype: {}".format(dt))
    return _dtypeDict[dt]


def minimum(x, y):
    """
    Returns the min of x and y (i.e. x < y ? x : y) element-wise.

    Parameters
    ----------
    x : tensor.
        Must be one of the following types: bfloat16, half, float32, float64, int32, int64.
    y : A Tensor.
        Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([0., 0., 0., 0.])
    >>> y = tlx.ops.constant([-5., -2., 0., 3.])
    >>> z = tlx.ops.minimum(x, y)

    """

    return tf.minimum(x=x, y=y)


def reshape(tensor, shape):
    """
    Reshapes a tensor.

    Parameters
    ----------
    tensor : tensor
        A Tensor.
    shape : tensor
         Defines the shape of the output tensor.
    Returns
    -------
        A Tensor. Has the same type as tensor

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([0., 1., 2., 3.])
    >>> z = tlx.ops.reshape(x, [2, 2])

    """

    return tf.reshape(tensor, shape)


def concat(values, axis=0):
    """
    Concatenates tensors along one dimension.

    Parameters
    ----------
    values : list
         A list of Tensor objects or a single Tensor
    axis : int
        0-D int32 Tensor. Dimension along which to concatenate
    Returns
    -------
        A Tensor resulting from concatenation of the input tensors.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([0., 0., 0., 0.])
    >>> y = tlx.ops.constant([-5., -2., 0., 3.])
    >>> z = tlx.ops.concat([x, y], 0)

    """

    return tf.concat(values, axis)


def convert_to_tensor(value, dtype=None, device=None):
    """
    Converts the given value to a Tensor.

    Parameters
    ----------
    value : object
        An object whose type has a registered Tensor conversion function.
    dtype : optional
        Optional element type for the returned tensor. If missing, the type is inferred from the type of value.
    device : str or None
        create a tensor on 'cpu' or 'gpu', defautl is None.

    Returns
    -------
        A Tensor based on value.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = np.ones(shape=(10, 10))
    >>> y = tlx.ops.convert_to_tensor(x)

    """
    if isinstance(value, tf.Variable):
        return value
    return tf.convert_to_tensor(value, dtype)


def convert_to_numpy(value):
    """
    Converts the given Tensor to a numpy.

    Parameters
    ----------
    value : object
        An object whose type has a registered Tensor conversion function.

    Returns
    -------
        A value based on tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones(shape=(10, 10))
    >>> y = tlx.ops.convert_to_numpy(x)

    """

    return value.numpy()


def sqrt(x):
    """
    Computes square root of a tensor element-wise.

    Parameters
    ----------
    x : tensor
         Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.


    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([0.0, 1.0, 4.0]), dtype=tlx.float32)
    >>> x = tlx.ops.sqrt(x)
    >>> print(x)
    >>> [0.0, 1.0, 2.0]

    """
    return tf.sqrt(x)


def reduce_mean(input_tensor, axis=None, keepdims=False):
    """
    Computes the mean of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have numeric type.
    axis : list
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_mean(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_mean(x, axis=1, keepdims=True)

    """

    return tf.reduce_mean(input_tensor, axis=axis, keepdims=keepdims)


def reduce_max(x, axis=None, keepdims=False):
    """
    Computes the maximum of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.


    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_max(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_max(x, axis=1, keepdims=True)


    """

    return tf.reduce_max(x, axis=axis, keepdims=keepdims)


def reduce_min(x, axis=None, keepdims=False):
    """
    Computes the minimum of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_min(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_min(x, axis=1, keepdims=True)

    """

    return tf.reduce_min(x, axis=axis, keepdims=keepdims)


def pad(tensor, paddings, mode="CONSTANT", constant_values=0):
    """
    Pads a tensor.

    Parameters
    ----------
    tensor : tensor
        A Tensor.
    paddings : list or tuple
         paddings is an list or tuple with size [n, 2], where n is the rank of tensor.
         For each dimension D of input, paddings[D, :] indicates how many values to add before the contents of tensor in that dimension,
    mode : str
        One of "CONSTANT", "REFLECT", or "SYMMETRIC" (case-insensitive), default is "CONSTANT".
    constant_values : int
        In "CONSTANT" mode, the scalar pad value to use. Must be same type as tensor.

    Returns
    -------
        A Tensor. Has the same type as tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([[1, 2, 3], [4, 5, 6]])
    >>> paddings = [[1,1], [2, 2]]
    >>> res = tlx.ops.pad(x, paddings)
    >>> [[0, 0, 0, 0, 0, 0, 0],
    >>> [0, 0, 1, 2, 3, 0, 0],
    >>> [0, 0, 4, 5, 6, 0, 0],
    >>> [0, 0, 0, 0, 0, 0, 0]]
    """

    if mode not in ["CONSTANT", "REFLECT", "SYMMETRIC"]:
        raise Exception("Unsupported mode: {}".format(mode))
    outputs = tf.pad(tensor,
                     paddings,
                     mode=mode,
                     constant_values=constant_values)
    return outputs


def stack(values, axis=0):
    """
    Stacks a list of rank-R tensors into one rank-(R+1) tensor.

    Parameters
    ----------
    values : list
        A list of Tensor objects with the same shape and type.
    axis : int
        An int. The axis to stack along. Defaults to the first dimension.
        Negative values wrap around, so the valid range is [-(R+1), R+1).

    Returns
    -------
        A stacked Tensor with the same type as values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([1,2,3])
    >>> y = tlx.ops.constant([1,2,3])
    >>> res = tlx.ops.stack([x, y])
    >>> [[1, 2, 3],
    >>>  [1, 2, 3]]

    """

    return tf.stack(values, axis=axis)


def meshgrid(*args, **kwargs):
    """
    Broadcasts parameters for evaluation on an N-D grid.

    Parameters
    ----------
    x : tensor
        Tensors with rank 1.
    y : tensor
        Tensors with rank 1.

    Returns
    -------
        A list of N Tensors with rank N.
    """

    return tf.meshgrid(*args, **kwargs)


def arange(start, limit=None, delta=1, dtype=None, device=None):
    """
    Creates a sequence of numbers.

    Parameters
    ----------
    start : tensor
        A 0-D Tensor (scalar). Acts as first entry in the range if limit is not None;
        otherwise, acts as range limit and first entry defaults to 0.
    limit : tensor
         A 0-D Tensor (scalar). Upper limit of sequence, exclusive. If None,
         defaults to the value of start while the first entry of the range defaults to 0.
    delta : tensor
        A 0-D Tensor (scalar). Number that increments start. Defaults to 1.
    dtype : type
        The type of the elements of the resulting tensor.

    Returns
    -------
        An 1-D Tensor of type dtype.
    """

    if limit is None:
        outputs = tf.range(start, delta=delta, dtype=dtype)
    else:
        outputs = tf.range(start, limit, delta=delta, dtype=dtype)
    return outputs


def expand_dims(input, axis):
    """
    Inserts a dimension of 1 into a tensor's shape.

    Parameters
    ----------
    input : tensor
        A Tensor.
    axis : int
        0-D (scalar). Specifies the dimension index at which to expand the shape of input.
        Must be in the range [-rank(input) - 1, rank(input)].

    Returns
    -------
        A Tensor with the same data as input, but its shape has an additional dimension of size 1 added.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones([1,2,3])
    >>> res = tlx.ops.expand_dims(x, axis=0)
    >>> print(res.shape)
    >>>  [1, 1, 2, 3]

    """

    return tf.expand_dims(input, axis)


def tile(input, multiples):
    """
    Constructs a tensor by tiling a given tensor.

    Parameters
    ----------
    input : tensor
        A Tensor. 1-D or higher.
    multiples : tensor or tuple or list
        The number of repeating times.
        If repeat_times is a list or tuple, all its elements should be integers or 1-D Tensors with the data type int32.
        If repeat_times is a Tensor, it should be an 1-D Tensor with the data type int32.
        Length must be the same as the number of dimensions in input.
    Returns
    -------
        A Tensor. Has the same type as input.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([[1,2,3],[1,2,3]])
    >>> y = tlx.ops.tile(x, [2, 1])
    >>> [[1, 2, 3],
    >>>  [1, 2, 3],
    >>>  [1, 2, 3],
    >>>  [1, 2, 3]]

    """

    multiples = tf.convert_to_tensor(multiples, tf.int32)
    if len(multiples.shape) == 0:
        return tf.tile(input, (multiples, ))

    else:
        return tf.tile(input, multiples)


def cast(x, dtype):
    """
    Casts a tensor to a new type.

    Parameters
    ----------
    x : tensor
        A Tensor or SparseTensor or IndexedSlices of numeric type.
        It could be uint8, uint16, uint32, uint64, int8, int16, int32, int64, float16, float32, float64.
    dtype : dtpye
         The destination type. The list of supported dtypes is the same as x

    Returns
    -------
        A Tensor or SparseTensor or IndexedSlices with same shape as x and same type as dtype.
    """

    return tf.cast(x, dtype=dtype)


def transpose(a, perm=None, conjugate=False):
    """
    Transposes a.

    Parameters
    ----------
    a : tensor
        A Tensor.
    perm : list / int
        A permutation of the dimensions of a.
    conjugate : bool
        Setting it to True is mathematically equivalent to tf.math.conj(tf.transpose(input)).

    Returns
    -------
        A transposed Tensor.
    """

    return tf.transpose(a, perm, conjugate)


def gather_nd(params, indices, batch_dims=0):
    """
    Gather slices from params into a Tensor with shape specified by indices.

    Parameters
    ----------
    params : tensor
        The tensor from which to gather values.
    indices : tensor
        Must be one of the following types: int32, int64. Index tensor.
    batch_dims : int
        An integer or a scalar 'Tensor'. The number of batch dimensions.

    Returns
    -------
        A Tensor. Has the same type as params.
    """

    return tf.gather_nd(params, indices, batch_dims)


def scatter_nd(indices, updates, shape):
    return tf.scatter_nd(indices, updates, shape)


def clip_by_value(t, clip_value_min, clip_value_max):
    """
    Clips tensor values to a specified min and max.

    Parameters
    ----------
    t : tensor
        A Tensor or IndexedSlices
    clip_value_min : tensor
        A 0-D (scalar) Tensor, or a Tensor with the same shape as t. The minimum value to clip by
    clip_value_max : tensor
        A 0-D (scalar) Tensor, or a Tensor with the same shape as t. The minimum value to clip by

    Returns
    -------
        A clipped Tensor or IndexedSlices.
    """

    return tf.clip_by_value(t, clip_value_min, clip_value_max)


def split(value, num_or_size_splits, axis=0):
    """
    Splits a tensor into sub tensors.

    Parameters
    ----------
    value : tensor
        The Tensor to split.
    num_or_size_splits : int or list
        Either an integer indicating the number of splits along split_dim or a 1-D integer Tensor or
        Python list containing the sizes of each output tensor along split_dim.
    axis : int
        The dimension along which to split. Must be in the range [-rank(value), rank(value)). Defaults to 0.


    Returns
    -------
        Tensor objects resulting from splitting value.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones([3, 9, 5])
    >>> y1, y2, y3 = tlx.ops.split(x, 3, axis=1)
    >>> y1, y2, y3 = tlx.ops.split(x, [1,3,5], axis=1)

    """

    return tf.split(value=value,
                    num_or_size_splits=num_or_size_splits,
                    axis=axis)


def floor(x):
    """
    Returns element-wise largest integer not greater than x.

    Parameters
    ----------
    x : tensor
        A Tensor. Must be one of the following types: bfloat16, half, float32, float64.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1.23, 2.56, 3.589])
    >>> y = tlx.ops.floor(x)

    """

    return tf.floor(x)


def gather(params, indices, axis=None):
    """Gather slices from params axis axis according to indices.

    Parameters
    ----------
    params : tensor
        The Tensor from which to gather values. Must be at least rank axis + 1.
    indices : indices
        The index Tensor. Must be one of the following types: int32, int64. The values must be in range [0, params.shape[axis]).
    axis : tensor.
        Must be one of the following types: int32, int64. The axis in params to gather indices from. The default value is None, if None, the axis is 0.

    Returns
    -------
        A Tensor. Has the same type as params.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[[0, 1.0, 2.0],
    >>>                  [10.0, 11.0, 12.0],
    >>>                  [20.0, 21.0, 22.0],
    >>>                  [30.0, 31.0, 32.0]])
    >>> y = tlx.ops.gather(x, indices=[3,1])


    """
    return tf.gather(params, indices, axis=axis)


def linspace(start, stop, num):
    return tf.linspace(start, stop, num)


def slice(inputs, starts, sizes):
    return tf.slice(inputs, starts, sizes)


def add_n(inputs):
    return tf.add_n(inputs)


def resize(inputs,
           size=None,
           scale_factor=None,
           mode="bilinear",
           align_corners=False,
           data_format="channels_first"):
    if data_format == "channels_first":
        inputs = nchw_to_nhwc(inputs)

    if size is not None:
        output_size = size
    elif scale_factor is not None:
        output_size = [
            int(inputs.shape[1] * scale_factor[0]),
            int(inputs.shape[2] * scale_factor[1]),
        ]
    else:
        raise TypeError("Expect either size or scale is not None.")

    if len(get_tensor_shape(inputs)) != 4:
        raise ("The inputs shape must be 4-D Tensor.")

    if align_corners:
        outputs = tf.compat.v1.image.resize(
            inputs,
            size=output_size,
            method=mode,
            align_corners=True,
        )
    else:
        outputs = tf.image.resize(inputs, size=output_size, method=mode)
    if data_format == "channels_first":
        outputs = nhwc_to_nchw(outputs)
    return outputs


def ceil(x):
    """
    Return the ceiling of the input, element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64. int32

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.ceil(x)

    """

    return tf.math.ceil(x)


def multiply(x, y):
    """
    Returns an element-wise x * y.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64,
        uint8, int8, uint16, int16, int32, int64, complex64, complex128.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.multiply(x, x)

    """

    return tf.multiply(x, y)


def divide(x, y):
    """
    Computes Python style division of x by y.

    Parameters
    ----------
    x : tensor
        A Tensor
    y : tensor
        A Tensor

    Returns
    -------
        A Tensor with same shape as input

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.divide(x, x)

    """

    return tf.divide(x, y)


def identity(x):
    return tf.identity(x)


def triu(x, diagonal=0):
    """
    This op returns the upper triangular part of a matrix (2-D tensor) or batch of matrices x,
    the other elements of the result tensor are set to 0.
    The upper triangular part of the matrix is defined as the elements on and above the diagonal.

    Parameters
    ----------
    x : tensor
        The tensor to triu.
    diagonal : int
        The diagonal to consider, default value is 0. If diagonal = 0, all elements on and above the main diagonal are retained.
        A positive value excludes just as many diagonals above the main diagonal, and similarly a negative value includes just as many diagonals below the main diagonal.

    Returns
    -------
        Results of upper triangular operation by the specified diagonal of input tensor x, it’s data type is the same as x’s Tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.convert_to_tensor(np.arange(1, 10, dtype="int32").reshape(3,-1))
    >>> y = tlx.ops.triu(x, diagonal=1)
    >>> print(y)
    >>> [[0, 2, 3],
    >>> [ 0, 0, 6],
    >>> [ 0, 0, 0]]

    """

    return tf.experimental.numpy.triu(x, k=diagonal)


def tril(x, diagonal=0):
    """
    This op returns the lower triangular part of a matrix (2-D tensor) or batch of matrices x, the other elements of the result tensor are set to 0.
    The lower triangular part of the matrix is defined as the elements on and below the diagonal.

    Parameters
    ----------
    x : tensor
        The tensor to tril.
    diagonal : int
        The diagonal to consider, default value is 0. If diagonal = 0, all elements on and below the main diagonal are retained.
        A positive value includes just as many diagonals above the main diagonal, and similarly a negative value excludes just as many diagonals below the main diagonal.

    Returns
    -------
        Results of lower triangular operation by the specified diagonal of input tensor x, it’s data type is the same as x’s Tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.convert_to_tensor(np.arange(1, 10, dtype="int32").reshape(3,-1))
    >>> y = tlx.ops.tril(x, diagonal=1)
    >>> print(y)
    >>> [[0, 0, 0],
    >>> [ 4, 0, 0],
    >>> [ 7, 8, 0]]

    """

    return tf.experimental.numpy.tril(x, k=diagonal)


def abs(x):
    """
    Computes the absolute value of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor or SparseTensor of type float16, float32, float64, int32, int64, complex64 or complex128.

    Returns
    -------
        A Tensor or SparseTensor of the same size, type and sparsity as x, with absolute values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.layers.Input((32, 3, 3, 32))
    >>> y = tlx.ops.abs(x)

    """

    return tf.math.abs(x)


def acos(x):
    """
    Computes acos of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, uint8, int8, int16, int32, int64, complex64, complex128, string.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.layers.Input((32, 3, 3, 32))
    >>> y = tlx.ops.acos(x)

    """

    return tf.math.acos(x)


def acosh(x):
    """
    Computes inverse hyperbolic cosine of x element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor. Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.layers.Input((32, 3, 3, 32))
    >>> y = tlx.ops.acosh(x)

    """

    return tf.math.acosh(x)


def angle(x):
    """
    Returns the element-wise argument of a complex (or real) tensor.

    Parameters
    ----------
    x : tensor
        A Tensor. Must be one of the following types: float, double, complex64, complex128.

    Returns
    -------
        A Tensor of type float32 or float64.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[2.15 + 3.57j, 3.89 + 6.54j])
    >>> y = tlx.ops.angle(x)

    """

    return tf.math.angle(x)


def argmax(x, axis=None, keepdim=False, dtype="int64"):
    """
    Returns the index with the largest value across axes of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor
    axis : int
        An integer, the axis to reduce across. Default to 0.
    dtype : tensor or str
        An optional output dtype (nt32 or int64). Defaults to int64.

    Returns
    -------
        A Tensor of type output_type.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[10, 20, 5, 6, 15])
    >>> y = tlx.ops.argmax(x)

    """
    if keepdim == True:
        argmax = tf.math.argmax(x, axis=axis, output_type=dtype_str(dtype))
        return tf.expand_dims(argmax, axis=axis)
    else:
        return tf.math.argmax(x, axis=axis, output_type=dtype_str(dtype))


def argmin(x, axis=None, dtype="int64"):
    """
    Returns the index with the smallest value across axes of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor
    axis : int
        An integer, the axis to reduce across. Default to 0.
    dtype : tensor or str
        An optional output dtype (nt32 or int64). Defaults to int64.

    Returns
    -------
        A Tensor of type output_type.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[10, 20, 5, 6, 15])
    >>> y = tlx.ops.argmin(x)

    """

    return tf.math.argmin(x, axis=axis, output_type=dtype_str(dtype))


def asin(x):
    """
    Returns the index with the smallest value across axes of a tensor.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, int8, int16, int32, int64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[10, 20, 5, 6, 15])
    >>> y = tlx.ops.asin(x)

    """

    return tf.math.asin(x)


def asinh(x):
    """
    Computes inverse hyperbolic sine of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.asinh(x)

    """

    return tf.math.asinh(x)


def atan(x):
    """
    Computes the trignometric inverse tangent of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, int8, int16, int32, int64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.atan(x)

    """

    return tf.math.atan(x)


def atanh(x):
    """
    Computes inverse hyperbolic tangent of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.atanh(x)

    """

    return tf.math.atanh(x)


def cos(x):
    """
    Computes cos of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.cos(x)

    """

    return tf.math.cos(x)


def cosh(x):
    """
    Computes hyperbolic cosine of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[0.9142202  0.72091234])
    >>> y = tlx.ops.cosh(x)

    """

    return tf.math.cosh(x)


def count_nonzero(x, axis=None, keepdims=None, dtype="int64"):
    """
    Computes number of nonzero elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should be of numeric type, bool, or string.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions. Must be in the range [-rank(input), rank(input)).
    keepdims : bool
        If true, retains reduced dimensions with length 1.
    dtype : tensor or str
        The output dtype; defaults to tf.int64.

    Returns
    -------
        The reduced tensor (number of nonzero values).

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=["", "a", "c", "b", " "])
    >>> y = tlx.ops.count_nonzero(x)

    """

    return tf.math.count_nonzero(x,
                                 axis=axis,
                                 keepdims=keepdims,
                                 dtype=dtype_str(dtype))


def cumprod(x, axis=0, exclusive=False, reverse=False):
    """
    Compute the cumulative product of the tensor x along axis.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int64, int32, uint8, uint16, int16, int8,
         complex64, complex128, qint8, quint8, qint32, half.
    axis : int
        A Tensor of type int32 (default: 0). Must be in the range [-rank(x), rank(x)).
    exclusive : bool
        If True, perform exclusive cumprod.
    reverse : bool
        A bool (default: False).

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[3, 2, 1])
    >>> y = tlx.ops.cumprod(x)
    >>> y = tlx.ops.cumprod(x, exclusive=True, reverse=True)

    """

    return tf.math.cumprod(x, axis=axis, exclusive=exclusive, reverse=reverse)


def cumsum(x, axis=0, exclusive=False, reverse=False):
    """
    Compute the cumulative sum of the tensor x along axis.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int64, int32, uint8, uint16, int16, int8,
         complex64, complex128, qint8, quint8, qint32, half.
    axis : int
        A Tensor of type int32 (default: 0). Must be in the range [-rank(x), rank(x)).
    exclusive : bool
        If True, perform exclusive cumprod.
    reverse : bool
        A bool (default: False).

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.cumsum(x)
    >>> y = tlx.ops.cumsum(x, exclusive=True, reverse=True)

    """

    return tf.math.cumsum(x, axis=axis, exclusive=exclusive, reverse=reverse)


def equal(x, y):
    """
    Returns the truth value of (x == y) element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor or SparseTensor or IndexedSlices.
    y : tensor
        A Tensor or SparseTensor or IndexedSlices.

    Returns
    -------
        A Tensor of type bool with the same size as that of x or y.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.equal(x, x)

    """

    return tf.math.equal(x, y)


def exp(x):
    """
    Computes exponential of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.exp(x)

    """

    return tf.exp(x)


def floordiv(x, y):
    """
    Divides x / y elementwise, rounding toward the most negative integer.

    Parameters
    ----------
    x : tensor
        Tensor numerator of real numeric type.
    y : tensor
        Tensor denominator of real numeric type.

    Returns
    -------
        x / y rounded toward -infinity.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.floordiv(x, x)

    """

    return tf.math.floordiv(x, y)


def floormod(x, y):
    """
    Returns element-wise remainder of division.
    When x < 0 xor y < 0 is true, this follows Python semantics in that the result
    here is consistent with a flooring divide. E.g. floor(x / y) * y + mod(x, y) = x.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: int8, int16, int32, int64, uint8,
        uint16, uint32, uint64, bfloat16, half, float32, float64.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.floormod(x, x)

    """

    return tf.math.floormod(x, y)


def greater(x, y):
    """
    Returns the truth value of (x >= y) element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8, int16,
        int8, int64, bfloat16, uint16, half, uint32, uint64.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.greater(x, x)

    """

    return tf.math.greater(x, y)


def greater_equal(x, y):
    """
    Returns the truth value of (x >= y) element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8,
        int16, int8, int64, bfloat16, uint16, half, uint32, uint64.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.greater_equal(x, x)

    """

    return tf.math.greater_equal(x, y)


def is_inf(x):
    """
    Returns which elements of x are Inf.

    Parameters
    ----------
    x : tensor
        A Tensor. Must be one of the following types: bfloat16, half, float32, float64.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.constant(value=[1, 2, 3, np.inf])
    >>> y = tlx.ops.is_inf(x)

    """

    return tf.math.is_inf(x)


def is_nan(x):
    """
    Returns which elements of x are NaN.

    Parameters
    ----------
    x : tensor
        A Tensor. Must be one of the following types: bfloat16, half, float32, float64.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.constant(value=[1, 2, 3, np.nan])
    >>> y = tlx.ops.is_nan(x)

    """

    return tf.math.is_nan(x)


def l2_normalize(x, axis=None, eps=1e-12):
    """
    Normalizes along dimension axis using an L2 norm.
    For a 1-D tensor with axis = 0, computes output = x / sqrt(max(sum(x**2), epsilon))

    Parameters
    ----------
    x : tensor
        A Tensor
    axis : int
        Dimension along which to normalize. A scalar or a vector of integers.
    eps : float
        A lower bound value for the norm. Will use sqrt(epsilon) as the divisor if norm < sqrt(epsilon).

    Returns
    -------
        A Tensor with the same shape as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.constant(value=[1, 2, 3, np.nan])
    >>> y = tlx.ops.l2_normalize(x)

    """

    return tf.math.l2_normalize(x, axis=axis, epsilon=eps)


def less(x, y):
    """
    Returns the truth value of (x < y) element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8,
        int16, int8, int64, bfloat16, uint16, half, uint32, uint64.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.less(x, x)

    """
    return tf.math.less(x, y)


def less_equal(x, y):
    """
    Returns the truth value of (x <= y) element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8,
        int16, int8, int64, bfloat16, uint16, half, uint32, uint64.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.less_equal(x, x)

    """
    return tf.math.less_equal(x, y)


def log(x):
    """
    Computes natural logarithm of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.log(x)

    """

    return tf.math.log(x)


def log_sigmoid(x):
    """
    Computes log sigmoid of x element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor with type float32 or float64.

    Returns
    -------
        A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.log_sigmoid(x)

    """

    return tf.math.log_sigmoid(x)


def maximum(x, y):
    """
    Returns the max of x and y (i.e. x > y ? x : y) element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8,
        int16, int8, int64, bfloat16, uint16, half, uint32, uint64.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.maximum(x, x)

    """

    return tf.math.maximum(x, y)


def negative(x):
    """
    Computes numerical negative value element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, int8,
        int16, int32, int64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.
        If x is a SparseTensor, returns SparseTensor(x.indices, tf.math.negative(x.values, ...), x.dense_shape)

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.negative(x)

    """

    return tf.math.negative(x)


def not_equal(x, y):
    """
    Returns the truth value of (x != y) element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor or SparseTensor or IndexedSlices.
    y : tensor
        A Tensor or SparseTensor or IndexedSlices.

    Returns
    -------
        A Tensor of type bool with the same size as that of x or y.


    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.constant(value=[1, 3, 5])
    >>> x = tlx.ops.not_equal(x, y)

    """

    return tf.math.not_equal(x, y)


def pow(x, y):
    """
    Computes the power of one value to another.

    Parameters
    ----------
    x : tensor
        A Tensor of type float16, float32, float64, int32, int64, complex64, or complex128.
    y : tensor
        A Tensor of type float16, float32, float64, int32, int64, complex64, or complex128.

    Returns
    -------
        A Tensor.


    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[1, 2, 3])
    >>> y = tlx.ops.constant(value=[1, 3, 5])
    >>> x = tlx.ops.pow(x, y)

    """

    return tf.math.pow(x, y)


def real(x):
    """
    Computes numerical negative value element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor. Must have numeric type.

    Returns
    -------
        A Tensor of type float32 or float64.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[-2.25 + 4.75j, 3.25 + 5.75j])
    >>> y = tlx.ops.real(x)

    """

    return tf.math.real(x)


def reciprocal(x):
    """
    Computes the reciprocal of x element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor. Must be one of the following types: bfloat16, half, float32, float64,
        int8, int16, int32, int64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant(value=[-2.25, 3.25])
    >>> y = tlx.ops.reciprocal(x)

    """

    return tf.math.reciprocal(x)


def reduce_prod(x, axis=None, keepdims=False):
    """
    Computes the multiply of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_prod(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_prod(x, axis=1, keepdims=True)

    """

    return tf.reduce_prod(x, axis=axis, keepdims=keepdims)


def reduce_std(x, axis=None, keepdims=False):
    """
    Computes the standard deviation of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_std(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_std(x, axis=1, keepdims=True)

    """

    return tf.math.reduce_std(x, axis=axis, keepdims=keepdims)


def reduce_sum(x, axis=None, keepdims=False):
    """
    Computes the standard deviation of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_sum(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_sum(x, axis=1, keepdims=True)

    """

    return tf.reduce_sum(x, axis=axis, keepdims=keepdims)


def reduce_variance(x, axis=None, keepdims=False):
    """
    Computes the variance of elements across dimensions of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x), rank(x)).
    keepdims : boolean
        If true, keep these reduced dimensions and the length is 1. If false, don’t keep these dimensions.
        Default : False, don’t keep these reduced dimensions.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.randn(3, 4))
    >>> x1 = tlx.ops.reduce_variance(x, axis=1, keepdims=False)
    >>> x2 = tlx.ops.reduce_variance(x, axis=1, keepdims=True)

    """
    return tf.math.reduce_variance(x, axis=axis, keepdims=keepdims)


def round(x):
    """
    Rounds the values of a tensor to the nearest integer, element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to round. Should have real numeric type.

    Returns
    -------
        A Tensor of same shape and type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([0.9, 2.5, 2.3, 1.5, -4.5]))
    >>> x = tlx.ops.round(x)

    """
    return tf.round(x)


def rsqrt(x):
    """
    Computes reciprocal of square root of x element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to rsqrt. Should have real numeric type.

    Returns
    -------
        A Tensor of same shape and type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([0.9, 2.5, 2.3, 1.5]))
    >>> x = tlx.ops.rsqrt(x)

    """
    return tf.math.rsqrt(x)


def segment_max(x, segment_ids):
    """
    Computes the maximum along segments of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to segment_max. Should have real numeric type.
    segment_ids : tensor
        A 1-D tensor whose size is equal to the size of data's first dimension. Values should be sorted and can be repeated.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1,2,3,4], [4, 3, 2, 1], [5,6,7,8]]))
    >>> id = tlx.ops.convert_to_tensor([0, 0, 1])
    >>> x = tlx.ops.segment_max(x, id)
    >>> print(x)
    >>> [[4, 3, 3, 4],
    >>> [5, 6, 7, 8]]

    """

    return tf.math.segment_max(x, segment_ids)


def segment_mean(x, segment_ids):
    """
    Computes the mean along segments of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to segment_mean. Should have real numeric type.
    segment_ids : tensor
        A 1-D tensor whose size is equal to the size of data's first dimension. Values should be sorted and can be repeated.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1.0 , 2, 3, 4], [4, 3, 2, 1], [5, 6, 7, 8]]))
    >>> id = tlx.ops.convert_to_tensor([0, 0, 1])
    >>> x = tlx.ops.segment_mean(x, id)
    >>> print(x)
    >>> [[2.5, 2.5, 2.5, 2.5],
    >>> [5, 6, 7, 8]]

    """

    return tf.math.segment_mean(x, segment_ids)


def segment_min(x, segment_ids):
    """
    Computes the minimum along segments of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to segment_minimum. Should have real numeric type.
    segment_ids : tensor
        A 1-D tensor whose size is equal to the size of data's first dimension. Values should be sorted and can be repeated.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1, 2, 3, 4], [4, 3, 2, 1], [5, 6, 7, 8]]))
    >>> id = tlx.ops.convert_to_tensor([0, 0, 1])
    >>> x = tlx.ops.segment_minimum(x, id)
    >>> print(x)
    >>> [[1, 2, 2, 1],
    >>> [5, 6, 7, 8]]

    """

    return tf.math.segment_minimum(x, segment_ids)


def segment_prod(x, segment_ids):
    """
    Computes the product along segments of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to segment_prod. Should have real numeric type.
    segment_ids : tensor
        A 1-D tensor whose size is equal to the size of data's first dimension. Values should be sorted and can be repeated.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1, 2, 3, 4], [4, 3, 2, 1], [5, 6, 7, 8]]))
    >>> id = tlx.ops.convert_to_tensor([0, 0, 1])
    >>> x = tlx.ops.segment_prod(x, id)
    >>> print(x)
    >>> [[4, 6, 6, 4],
    >>> [5, 6, 7, 8]]

    """

    return tf.math.segment_prod(x, segment_ids)


def segment_sum(x, segment_ids):
    """
    Computes the sum along segments of a tensor.

    Parameters
    ----------
    x : tensor
        The tensor to segment_sum. Should have real numeric type.
    segment_ids : tensor
        A 1-D tensor whose size is equal to the size of data's first dimension. Values should be sorted and can be repeated.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1, 2, 3, 4], [4, 3, 2, 1], [5, 6, 7, 8]]))
    >>> id = tlx.ops.convert_to_tensor([0, 0, 1])
    >>> x = tlx.ops.segment_sum(x, id)
    >>> print(x)
    >>> [[5, 5, 5, 5],
    >>> [5, 6, 7, 8]]

    """

    return tf.math.segment_sum(x, segment_ids)


def sigmoid(x):
    """
    Computes sigmoid of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to sigmoid.


    Returns
    -------
        A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([-128.0, 0.0, 128.0]), dtype='float32')
    >>> x = tlx.ops.sigmoid(x)
    >>> print(x)
    >>> [0., 0.5, 1.]

    """
    return tf.sigmoid(x)


def sign(x):
    """
    Computes sign of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to sign. y = sign(x) = -1 if x < 0; 0 if x == 0; 1 if x > 0.

    Returns
    -------
        A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([-128.0, 0.0, 128.0]), dtype='float32')
    >>> x = tlx.ops.sign(x)
    >>> print(x)
    >>> [-1., 0., 1.]

    """
    return tf.sign(x)


def sin(x):
    """
    Computes sine of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to sin. Input range is (-inf, inf) and output range is [-1,1].

    Returns
    -------
         A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([-1.0, 0.0, 1.0]), dtype='float32')
    >>> x = tlx.ops.sin(x)
    >>> print(x)
    >>> [-0.84147096, 0., 0.84147096]

    """
    return tf.math.sin(x)


def sinh(x):
    """
    Computes hyperbolic sine of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to hyperbolic sin. Input range is (-inf, inf) and output range is [-inf,inf].

    Returns
    -------
         A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([-1.0, 0.0, 1.0]), dtype='float32')
    >>> x = tlx.ops.sinh(x)
    >>> print(x)
    >>> [-1.1752012, 0., 1.1752012]

    """
    return tf.math.sinh(x)


def softplus(x):
    """
    Computes softplus of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to softplus. softplus(x) = log(exp(x) + 1).

    Returns
    -------
        A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([-1.0, 0.0, 1.0]), dtype='float32')
    >>> x = tlx.ops.softplus(x)
    >>> print(x)
    >>> [0.3132617, 0.6931472, 1.3132616]
    """

    return tf.math.softplus(x)


def square(x):
    """
    Computes square of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to square.

    Returns
    -------
        A Tensor with the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([-1.0, 0.0, 1.0]), dtype='float32')
    >>> x = tlx.ops.square(x)
    >>> print(x)
    >>> [1.0, 0.0, 1.0]
    """
    return tf.math.square(x)


def squared_difference(x, y):
    """
    Computes difference and square between tensor x and tensor y. return square(x - y)

    Parameters
    ----------
    x : tensor
        A Tensor.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1,0,1], [2,3,4]]), dtype='float32')
    >>> y = tlx.ops.convert_to_tensor(np.array([[-1,0,1], [2,3,4]]), dtype='float32')
    >>> res = tlx.ops.squared_difference(x, y)
    >>> print(res)
    >>> [[4.0, 0.0, 0.0],
    >>> [0.0, 0.0, 0.0]]
    """

    return tf.math.squared_difference(x, y)


def subtract(x, y):
    """
    Returns x - y element-wise.

    Parameters
    ----------
    x : tensor
        A tensor.
    y : tensor
        A Tensor. Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([[1,0,1], [2,3,4]]), dtype='float32')
    >>> y = tlx.ops.convert_to_tensor(np.array([[-1,0,1], [2,3,4]]), dtype='float32')
    >>> res = tlx.ops.subtract(x, y)
    >>> print(res)
    >>> [[-2.0, 0.0, 0.0],
    >>> [0.0, 0.0, 0.0]]

    """
    return tf.math.subtract(x, y)


def tan(x):
    """
    Computes tan of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to tan.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([1,0,1]), dtype='float32')
    >>> res = tlx.ops.tan(x)
    >>> print(res)
    >>> [-1.5574077, 0.0, 1.5574077]

    """

    return tf.math.tan(x)


def tanh(x):
    """
    Computes hyperbolic tangent of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The tensor to tanh.

    Returns
    -------
        A Tensor. Has the same type as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([1,0,1]), dtype="float32")
    >>> res = tlx.ops.tanh(x)
    >>> print(res)
    >>> [-0.7615942, 0.0, 0.7615942]
    """

    return tf.math.tanh(x)


def any(x, axis=None, keepdims=False):
    """
    Computes logical_or of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The boolean tensor to reduce.
    axis : int or None
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x),rank(x)).
    keepdims : boolean
        If true, retains reduced dimensions with length 1.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([1,0,1]), dtype='bool')
    >>> res = tlx.ops.any(x, axis = None, keepdims = False)
    >>> print(res)
    >>> True
    """

    return tf.math.reduce_any(x, axis=axis, keepdims=keepdims)


def all(x, axis=None, keepdims=False):
    """
    Computes logical_and of a tensor element-wise.

    Parameters
    ----------
    x : tensor
        The boolean tensor to reduce.
    axis : int or None
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(x),rank(x)).
    keepdims : boolean
        If true, retains reduced dimensions with length 1.

    Returns
    -------
        The reduced tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.array([1,0,1]), dtype='bool')
    >>> res = tlx.ops.all(x, axis = None, keepdims = False)
    >>> print(res)
    >>> False
    """

    return tf.math.reduce_all(x, axis=axis, keepdims=keepdims)


def logical_and(x, y):
    """
    Returns the truth value of x AND y element-wise.

    Parameters
    ----------
    x : tensor
        A tf.Tensor of type bool.
    y : tensor
        A tf.Tensor of type bool.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.constant([False, False, True, True])
    >>> y = tlx.constant([False, True, False, True])
    >>> res = tlx.ops.logical_and(x, y)
    >>> print(res)
    >>> [False, False, False, True]

    """

    return tf.math.logical_and(x, y)


def logical_or(x, y):
    """
    Returns the truth value of x OR y element-wise.

    Parameters
    ----------
    x : tensor
        A tf.Tensor of type bool.
    y : tensor
        A tf.Tensor of type bool.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.constant([False, False, True, True])
    >>> y = tlx.constant([False, True, False, True])
    >>> res = tlx.ops.logical_or(x, y)
    >>> print(res)
    >>> [False, True, True, True]

    """

    return tf.math.logical_or(x, y)


def logical_not(x):
    """
    Returns the truth value of NOT x element-wise.

    Parameters
    ----------
    x : tensor
        A tf.Tensor of type bool.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.constant([False, False, True, True])
    >>> res = tlx.ops.logical_not(x, y)
    >>> print(res)
    >>> [True, True, False, False]

    """

    return tf.math.logical_not(x)


def logical_xor(x, y):
    """
    Returns the truth value of NOT x element-wise. x ^ y = (x | y) & ~(x & y)

    Parameters
    ----------
    x : tensor
        A tf.Tensor of type bool.

    Returns
    -------
        A Tensor of type bool.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.constant([False, False, True, True])
    >>> y = tlx.constant([False, True, False, True])
    >>> res = tlx.ops.logical_xor(x, y)
    >>> print(res)
    >>> [False, True, True, False]

    """

    return tf.math.logical_xor(x, y)


def argsort(x, axis=-1, descending=False):
    """
    Returns the indices of a tensor that give its sorted order along an axis.

    Parameters
    ----------
    x : tensor
        An input N-D Tensor
    axis : int or None
        The axis along which to sort. The default is -1, which sorts the last axis.
    descending : boolean
        Descending is a flag, if set to true, algorithm will sort by descending order, else sort by ascending order. Default is false.

    Returns
    -------
        A Tensor with the same shape as values.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = [1, 10, 26.9, 2.8, 166.32, 62.3]
    >>> y = tlx.ops.argsort(x, descending = False)
    >>> print(y)
    >>> [0, 3, 1, 2, 5, 4]

    """
    direction = "ASCENDING"
    if descending:
        direction = "DESCENDING"
    return tf.argsort(x, axis=axis, direction=direction)


def bmm(x, y):
    """
    Applies batched matrix multiplication to two tensors.
    Both of the two input tensors must be three-dementional and share the same batch size.
    if x is a (b, m, k) tensor, y is a (b, k, n) tensor, the output will be a (b, m, n) tensor.

    Parameters
    ----------
    x : tensor
        The input Tensor.
    y : tensor
        The input Tensor.

    Returns
    -------
        The product Tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.convert_to_tensor([[[1.0, 1.0, 1.0],[2.0, 2.0, 2.0]],[[3.0, 3.0, 3.0],[4.0, 4.0, 4.0]]])
    >>> y = tlx.convert_to_tensor([[[1.0, 1.0],[2.0, 2.0],[3.0, 3.0]],[[4.0, 4.0],[5.0, 5.0],[6.0, 6.0]]])
    >>> res = tlx.ops.bmm(x, y)
    >>> print(res)
    >>> [[[6. , 6. ],
    >>> [12., 12.]],
    >>> [[45., 45.],
    >>> [60., 60.]]]

    """
    x_shape = x.shape
    y_shape = y.shape
    if not len(x_shape) == len(y_shape) == 3:
        raise ValueError(
            "x and y should be 3-dimensional. But received x's dimention: {}, y's dimention: {}"
            .format(x_shape, y_shape))
    if x_shape[2] != y_shape[1]:
        raise ValueError(
            "x's width must be equal with y's height. But received x's shape: {}, y's shape: {}"
            .format(x_shape, y_shape))
    if x_shape[0] != y_shape[0]:
        raise ValueError(
            "x's batch (shape[0]) must be equal with y's batch (shape[0]). But received x's shape: {}, y's shape: {}"
            .format(x_shape, y_shape))

    return tf.matmul(x, y)


def where(condition, x, y):
    """
    Return a tensor of elements selected from either x or y, depending on condition.

    Parameters
    ----------
    condition : tensor of bool
        When True (nonzero), yield x, otherwise yield y
    x : tensor
        values selected at indices where condition is True
    y : tensor
        values selected at indices where condition is False

    Returns
    -------
        A tensor of shape equal to the broadcasted shape of condition, x, y

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.convert_to_tensor([0.9, 0.1, 3.2, 1.2])
    >>> y = tlx.convert_to_tensor([1.0, 1.0, 1.0, 1.0])
    >>> res = tlx.ops.where(x>1, x, y)
    >>> print(res)
    >>> [1.0, 1.0, 3.2, 1.2]

    """

    return tf.where(condition=condition, x=x, y=y)


def ones_like(x, dtype=None):
    """
    This OP returns a Tensor filled with the value 1, with the same shape and data type (use dtype if dtype is not None) as x.

    Parameters
    ----------
    x : tensor
        The input tensor which specifies shape and dtype.
    dtype : str
        A type for the returned Tensor.If dtype is None, the data type is the same as x. Default is None.

    Returns
    -------
        A Tensor filled with the value 1, with the same shape and data type (use dtype if dtype is not None) as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.convert_to_tensor([0.9, 0.1, 3.2, 1.2])
    >>> res = tlx.ops.ones_like(x, dtype="int32")
    >>> print(res)
    >>> [1, 1, 1, 1]

    """

    return tf.ones_like(x, dtype=dtype)


def zeros_like(x, dtype=None, requires_grad=False):
    """
    This OP returns a Tensor filled with the value 0, with the same shape and data type (use dtype if dtype is not None) as x.

    Parameters
    ----------
    x : tensor
        The input tensor which specifies shape and dtype.
    dtype : str
        A type for the returned Tensor.If dtype is None, the data type is the same as x. Default is None.

    Returns
    -------
        A Tensor filled with the value 0, with the same shape and data type (use dtype if dtype is not None) as x.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.convert_to_tensor([0.9, 0.1, 3.2, 1.2])
    >>> res = tlx.ops.zeros_like(x, dtype="int32")
    >>> print(res)
    >>> [0, 0, 0, 0]

    """

    return tf.zeros_like(x, dtype=dtype)


def squeeze(x, axis=None):
    """
    Removes dimensions of size 1 from the shape of a tensor.

    Parameters
    ----------
    x : tensor
        The input Tensor.
    axis : int or list or tuple
        An integer or list/tuple of integers, indicating the dimensions to be squeezed. Default is None.
        The range of axis is [−ndim(x),ndim(x)). If axis is negative, axis=axis+ndim(x).
        If axis is None, all the dimensions of x of size 1 will be removed.

    Returns
    -------
        Squeezed Tensor with the same data type as input Tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones(shape=[1,2,3])
    >>> res = tlx.ops.squeeze(x, axis=0)
    >>> print(res.shape)
    >>> [2, 3]

    """

    return tf.squeeze(x, axis)


def unsorted_segment_sum(x, segment_ids, num_segments):
    """Computes the sum along segments of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor.
    segment_ids : Tensor or list or tuple
        Must be one of the following types: int32, int64.
    num_segments : int or tensor
        should equal the number of distinct segment IDs.

    Returns
    -------
        A Tensor. Has the same type as data.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([1,2,3])
    >>> res = tlx.ops.unsorted_segment_sum(x, (0, 0, 1), num_segments=2)
    >>> print(res)
    >>> [2, 3]

    """

    return tf.math.unsorted_segment_sum(x, segment_ids, num_segments)


def unsorted_segment_mean(x, segment_ids, num_segments):
    """Computes the mean along segments of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor.
    segment_ids : Tensor or list or tuple
        Must be one of the following types: int32, int64.
    num_segments : int or tensor
        should equal the number of distinct segment IDs.

    Returns
    -------
        A Tensor. Has the same type as data.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([1.,2.,3.])
    >>> res = tlx.ops.unsorted_segment_mean(x, (0, 0, 1), num_segments=2)
    >>> print(res)
    >>> [1.5, 3]

    """

    return tf.math.unsorted_segment_mean(x, segment_ids, num_segments)


def unsorted_segment_min(x, segment_ids, num_segments):
    """Computes the min along segments of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor.
    segment_ids : Tensor or list or tuple
        Must be one of the following types: int32, int64.
    num_segments : int or tensor
        should equal the number of distinct segment IDs.

    Returns
    -------
        A Tensor. Has the same type as data.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([1.,2.,3.])
    >>> res = tlx.ops.unsorted_segment_min(x, (0, 0, 1), num_segments=2)
    >>> print(res)
    >>> [1, 3]

    """

    return tf.math.unsorted_segment_min(x, segment_ids, num_segments)


def unsorted_segment_max(x, segment_ids, num_segments):
    """Computes the max along segments of a tensor.

    Parameters
    ----------
    x : tensor
        A Tensor.
    segment_ids : Tensor or list or tuple
        Must be one of the following types: int32, int64.
    num_segments : int or tensor
        should equal the number of distinct segment IDs.

    Returns
    -------
        A Tensor. Has the same type as data.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.constant([1.,2.,3.])
    >>> res = tlx.ops.unsorted_segment_max(x, (0, 0, 1), num_segments=2)
    >>> print(res)
    >>> [2, 3]

    """

    return tf.math.unsorted_segment_max(x, segment_ids, num_segments)


def set_seed(seed):
    """

    Parameters
    ----------
    seed : int
        The random seed to set.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> tlx.ops.set_seed(42)
    """
    tf.random.set_seed(seed)
    random.seed(seed)
    np.random.seed(seed)


def is_tensor(x):
    """

    Parameters
    ----------
    x : input
        A python object to check.

    Returns
    -------
        a bool Value. if x is tensor return True, else return False.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> tlx.ops.is_tensor(a)
    """

    return tf.is_tensor(x)


def tensor_scatter_nd_update(tensor, indices, updates, cls_loss=False):
    """

    Parameters
    ----------
    tensor : Tensor
        tensor to update.
    indices : list
        indices to update.
    updates : Tensor
        value to apply at the indices

    Returns
    -------
        updated Tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> tensor = tlx.ops.ones(shape=(5,3))
    >>> indices = [[0],[ 4],[ 2]]
    >>> updates = tlx.ops.convert_to_tensor([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    >>> new_tensor = tlx.ops.tensor_scatter_nd_update(tensor, indices, updates)
    >>>  [[1. 2. 3.]
    >>>  [1. 1. 1.]
    >>>  [7. 8. 9.]
    >>>  [1. 1. 1.]
    >>>  [4. 5. 6.]]
    """

    return tf.tensor_scatter_nd_update(tensor, indices, updates)


def diag(input, diagonal=0):
    """

    Parameters
    ----------
    input : Tensor
        the input tensor.
    diagonal : int
         the diagonal to consider. Defualt is 0.

    Returns
    -------
        the output tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> tensor = tlx.ops.convert_to_tensor([[1,2,3],[4,5,6],[7,8,9]]))
    >>> new_tensor = tlx.ops.diag(tensor)
    >>> [1, 5, 9]
    """
    return tf.experimental.numpy.diag(input, diagonal)


def mask_select(x, mask, axis=0):
    """

    Parameters
    ----------
    x : Tensor
        N-D Tensor.
    mask : Tensor
        N-D boolean Tensor or 1-D boolean Tensor
    axis :
        the axis in tensor to mask from. By default, axis is 0.

    Returns
    -------
        the output tensor.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> tensor = tlx.ops.convert_to_tensor([[1,2,3],[4,5,6],[7,8,9]]))
    >>> mask = tlx.ops.convert_to_tensor(np.array([True, False, True]), dtype=tlx.bool)
    >>> new_tensor = tlx.ops.mask_select(tensor, mask)
    >>> [[1, 2, 3],[7, 8, 9]]
    """

    return tf.boolean_mask(x, mask, axis=axis)


def eye(n, m=None, dtype=None):
    """

    Parameters
    ----------
    n : int
        the number of rows
    m : int or None
        the number of columns with default being n
    dtype : str or None
        the desired data type of returned tensor. Default: if None, use float32

    Returns
    -------
        A 2-D tensor with ones on the diagonal and zeros elsewhere

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> tlx.ops.eye(2)
    >>> [[1,0],
    >>> [0,1]]
    """
    if dtype is None:
        dtype = tf.dtypes.float32
    return tf.eye(n, m, dtype=dtype)


def einsum(equation, *operands):
    """
    Sums the product of the elements of the input operands along dimensions specified
    using a notation based on the Einstein summation convention.

    Parameters
    ----------
    equation : An attribute
        represent the operation you want to do.
        the value can contain only letters([a-z][A-Z]), commas(,), ellipsis(…), and arrow(->).
        the letters represent inputs’s tensor dimension, commas(,)represent separate tensors, ellipsis(…) indicates
        the tensor dimension that you do not care about, the left of the arrow(->) indicates the input tensors,
        and the right of it indicates the desired output dimension.

    operands : list
        input tensor used for calculation. the data type of the tensor must be the same.

    Returns
    -------
        Tensor, the shape of it can be obtained from the equation, and the data type is the same as input tensors.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.nn.Input((5,))
    >>> y = tlx.nn.Input((4,))
    >>> out = tlx.ops.einsum('i,j->ij', x, y)
    >>> cal_enisum = tlx.ops.Einsum('i,j->ij')
    >>> out = cal_enisum(x, y)
    """
    return tf.einsum(equation, *operands)


def set_device(device="GPU", id=0):
    """This function can specify the global device which the OP will run.

    Parameters
    ----------
    device : str
        Specific running device. It can be 'CPU', 'GPU' and 'Ascend'(In mindspore backend).
    id : int
        Device id.

    """
    if device not in ["GPU", "CPU"]:
        raise ValueError("Only support 'CPU', 'GPU'.")
    if device == "GPU":
        gpus = tf.config.experimental.list_physical_devices("GPU")
        if gpus:
            try:
                for gpu in gpus:
                    tf.config.experimental.set_memory_growth(gpu, True)
                tf.config.experimental.set_visible_devices(gpus[id], "GPU")
            except RuntimeError as e:
                print(e)


def scatter_update(tensor, indices, updates):
    """Applies sparse updates to a variable

    Parameters
    ----------
    tensor : Tensor
        A Tensor. The dim of tensor must be 1.
    indices : Tensor
        Indices into the tensor.
    updates : Tensor
        Updated values

    Returns
    -------
        Tensor after updated.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones((5,))
    >>> indices = tlx.ops.convert_to_tensor([0,  4,  2])
    >>> updates = tlx.ops.convert_to_tensor([1., 4., 7.])
    >>> res = tlx.ops.scatter_update(x, indices, updates)
    >>> [1. 1. 7. 1. 4.]
    """
    shape = indices.shape
    indices = tf.reshape(indices, shape=(shape[0], 1))
    return tf.tensor_scatter_nd_update(tensor, indices, updates)


def get_device():
    """This function can get the specified global device.

    Returns
    -------
        The global device.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.get_device()
    >>> "CPU"
    """
    device = tf.config.experimental.get_visible_devices("GPU")
    if len(device) == 0:
        device = tf.config.experimental.get_visible_devices("CPU")
    return device


def to_device(tensor, device="GPU", id=0):
    """Returns a copy of Tensor in specified device.

    Parameters
    ----------
    tensor : Tensor
        A tensor.
    device : str
        The specified device. Support 'GPU' and 'CPU'. Default is 'GPU'.
    id : int
        The id of specified device. Default is 0.


    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones((5,))
    >>> x = tlx.ops.to_device(x, device="GPU", id=0)
    """
    if device is None:
        return tensor
    with tf.device("/" + device.upper() + ":" + str(id)):
        return tf.identity(tensor)


def roll(input, shifts, dims=None):
    """Roll the tensor input along the given dimension(s).
    Elements that are shifted beyond the last position are re-introduced at the first position.
    If dims is None, the tensor will be flattened before rolling and then restored to the original shape.

    Parameters
    ----------
    input : tensor
        the input tensor.
    shifts : int or tuple
        The number of places by which the elements of the tensor are shifted.
        If shifts is a tuple, dims must be a tuple of the same size, and each dimension will be rolled by the corresponding value
    dims : int or tuple
        Axis along which to roll

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> x = tlx.ops.ones((5,6))
    >>> x = tlx.ops.roll(x, shifts=2)

    """
    if dims is None:
        raw_shape = input.shape
        shape = 1
        for d in input.shape:
            shape *= d
        input = tf.reshape(input, [1, shape])
        output = tf.roll(input, shifts, 1)
        output = tf.reshape(output, raw_shape)
        return output
    return tf.roll(input, shifts, dims)


def logsoftmax(input, dim=None):
    """Applies a softmax followed by a logarithm.

    Parameters
    ----------
    input : Tensor
        the input tensor.
    dim : int
        A dimension along which LogSoftmax will be computed.


    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.random((3,4)))
    >>> x = tlx.ops.logsoftmax(x, dim=1)

    """

    return tf.nn.log_softmax(input, dim)


def topk(input, k, dim=None, largest=True, sorted=True):
    """
    Returns the k largest elements of the given input tensor along a given dimension.

    A namedtuple of (values, indices) is returned, where the indices are the indices of the elements in the original input tensor.

    Parameters
    ----------
    input : Tensor
        the input tensor.
    k : int
        the k in “top-k”
    dim : int
        the dimension to sort along. If dim is not given, the last dimension of the input is chosen.
    largest : bool
        controls whether to return largest or smallest elements
    sorted : bool
        controls whether to return the elements in sorted order

    Returns
    -------
    out : tuple
        return the values and indices.

    Examples
    ---------
    >>> import tensorlayerx as tlx
    >>> import numpy as np
    >>> x = tlx.ops.convert_to_tensor(np.random.random((3,4)))
    >>> x = tlx.ops.topk(x, 2)

    """

    dims = len(input.shape) - 1
    if dim is not None:
        if dim < 0:
            dim = len(input.shape) + dim
        input = tf.experimental.numpy.swapaxes(input, dim, dims)
    if not largest:
        input = tf.negative(input)

    values, indices = tf.math.top_k(input, k=k, sorted=sorted)

    if dim is not None:
        values = tf.experimental.numpy.swapaxes(values, dim, dims)

    if not largest:
        values = tf.negative(values)

    return (values, indices)


def numel(input):
    """Returns the total number of elements in the input tensor.

    Parameters
    ----------
    input : tensor
        the input tensor.

    """
    if isinstance(input, tf.TensorShape):
        return tf.reduce_prod(input)
    else:
        return tf.size(input)


def histogram(input, bins=100, min=0, max=0, name=None):
    raise NotImplementedError


def flatten(x, start_axis=0, stop_axis=-1, name=None):
    raise NotImplementedError


def interpolate(
    x,
    size=None,
    scale_factor=None,
    mode="bilinear",
    align_corners=False,
    align_mode=0,
    data_format="NCHW",
    name=None,
):

    x = tf.transpose(x, [0, 2, 3, 1])
    x = tf.image.resize(x, size, method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)
    x = tf.transpose(x, [0, 3, 1, 2])
    return x


def index_select(x, index, axis=0, name=None):
    raise NotImplementedError


def dot(x, y, name=None):
    raise NotImplementedError


def expand(x, shape):
    """

    Parameters
    ----------
    x : Tensor
         The input Tensor, its data type is bool, float32, float64, int32 or int64.
    shape : list|tuple|Tensor
        The result shape after expanding.

    """

    raise NotImplementedError


def expand_as(x, y):
    """

    Parameters
    ----------
    x : Tensor
         The input Tensor, its data type is bool, float32, float64, int32 or int64.
    shape : list|tuple|Tensor
        The result shape after expanding.

    """

    return tf.broadcast_to(x, y.shape)


def unique(Tensor):

    return tf.unique(Tensor)[0]


def flip(x, axis):
    """

    Parameters
    ----------
    x : Tensor
        The input tensor
    axis : list|tuple|int
        The axis(axes) to flip on.

    """
    raise NotImplementedError


def mv(x, vec):
    """

    Parameters
    ----------
    x : Tensor
        A tensor with shape [M,N] , The data type of the input Tensor x should be one of float32, float64.
    vec : Tensor
        A tensor with shape [N] , The data type of the input Tensor x should be one of float32, float64.


    """
    pass


# loss function
sparse_softmax_cross_entropy_with_logits = tf.nn.sparse_softmax_cross_entropy_with_logits
sigmoid_cross_entropy_with_logits = tf.nn.sigmoid_cross_entropy_with_logits


def relu(x):
    """
    Computes rectified linear: max(features, 0).

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8, int16,
        int8, int64, bfloat16, uint16, half, uint32, uint64, qint8.

    Returns
    -------
        A Tensor. Has the same type as features.
    """

    return tf.nn.relu(x)


def elu(x, alpha=1.0):
    """
    Computes exponential linear: `exp(features) - 1` if < 0, `features` otherwise.

    See [Fast and Accurate Deep Network Learning by Exponential Linear Units (ELUs)
    ](http://arxiv.org/abs/1511.07289)

    Parameters
    ----------
    x : tensor
        Must be one of the following types: half, bfloat16, float32, float64.

    Returns
    -------
        A Tensor with the same type as features.
    """

    return tf.nn.elu(x * alpha)


def relu6(x):
    """
    Computes Rectified Linear 6: min(max(features, 0), 6).

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8, int16,
        int8, int64, bfloat16, uint16, half, uint32, uint64, qint8.

    Returns
    -------
        A Tensor with the same type as features.
    """

    return tf.nn.relu6(x)


def leaky_relu(x, negative_slope=0.2):
    """
    Compute the Leaky ReLU activation function.

    Parameters
    ----------
    x : tensor
        representing preactivation values. Must be one of the following types:
        float16, float32, float64, int32, int64.

    Returns
    -------
        The activation value.
    """

    return tf.nn.leaky_relu(x, alpha=negative_slope)


def sigmoid(x):
    """
    Computes sigmoid of x element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor with type float16, float32, float64, complex64, or complex128.

    Returns
    -------
        A Tensor with the same type as x.
    """

    return tf.nn.sigmoid(x)


def softmax(logits, axis=-1):
    """
    Computes softmax activations.

    Parameters
    ----------
    logits : tensor
        Must be one of the following types: half, float32, float64.
    axis : int
        The dimension softmax would be performed on. The default is -1 which indicates the last dimension.

    Returns
    -------
        A Tensor. Has the same type and shape as logits.
    """

    return tf.nn.softmax(logits, axis)


def gelu(x, approximate=False):
    return tf.nn.gelu(x, approximate=approximate)


def bias_add(x, bias, data_format=None, name=None):
    """
    Adds bias to value.

    Parameters
    ----------
    x : tensor
        A Tensor with type float, double, int64, int32, uint8, int16, int8, complex64, or complex128.
    bias : tensor
        Must be the same type as value unless value is a quantized type,
        in which case a different quantized type may be used.
    data_format : A string.
        'N...C' and 'NC...' are supported.
    name : str
        A name for the operation (optional).
    Returns
    -------
        A Tensor with the same type as value.
    """
    data_format, _ = preprocess_2d_format(data_format, None)
    x = tf.nn.bias_add(x, bias, data_format=data_format, name=name)
    return x


def conv1d(input, filters, stride, padding, data_format="NWC", dilations=None):
    """
    Computes a 1-D convolution given 3-D input and filter tensors.

    Parameters
    ----------
    input : tensor
        A 3D Tensor. Must be of type float16, float32, or float64
    filters : tensor
        A 3D Tensor. Must have the same type as input.
    stride : int of list
         An int or list of ints that has length 1 or 3. The number of entries by which the filter is moved right at each step.
    padding : string
         'SAME' or 'VALID'
    data_format : string
        An optional string from "NWC", "NCW". Defaults to "NWC", the data is stored in the order of
        [batch, in_width, in_channels]. The "NCW" format stores data as [batch, in_channels, in_width].
    dilations : int or list
        An int or list of ints that has length 1 or 3 which defaults to 1.
        The dilation factor for each dimension of input. If set to k > 1,
        there will be k-1 skipped cells between each filter element on that dimension.
        Dilations in the batch and depth dimensions must be 1.
    name : string
        A name for the operation (optional).
    Returns
    -------
        A Tensor. Has the same type as input.
    """

    data_format, padding = preprocess_1d_format(data_format, padding)
    outputs = tf.nn.conv1d(
        input=input,
        filters=filters,
        stride=stride,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
        # name=name
    )
    return outputs


def conv2d(input,
           filters,
           strides,
           padding,
           data_format="NHWC",
           dilations=None):
    """
    Computes a 2-D convolution given 4-D input and filters tensors.

    Parameters
    ----------
    input : tensor
        Must be one of the following types: half, bfloat16, float32, float64. A 4-D tensor.
        The dimension order is interpreted according to the value of data_format, see below for details.
    filters : tensor
         Must have the same type as input. A 4-D tensor of shape [filter_height, filter_width, in_channels, out_channels]
    strides : int of list
        The stride of the sliding window for each dimension of input. If a single value is given it is replicated in the H and W dimension.
        By default the N and C dimensions are set to 1. The dimension order is determined by the value of data_format, see below for details.
    padding : string
        "SAME" or "VALID"
    data_format : string
        "NHWC", "NCHW". Defaults to "NHWC".
    dilations : list or ints
        list of ints that has length 1, 2 or 4, defaults to 1. The dilation factor for each dimension ofinput.
    name : string
         A name for the operation (optional).

    Returns
    -------
        A Tensor. Has the same type as input.
    """

    data_format, padding = preprocess_2d_format(data_format, padding)
    outputs = tf.nn.conv2d(
        input=input,
        filters=filters,
        strides=strides,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
    )
    return outputs


def conv3d(input,
           filters,
           strides,
           padding,
           data_format="NDHWC",
           dilations=None):
    """
    Computes a 3-D convolution given 5-D input and filters tensors.

    Parameters
    ----------
    input : tensor
        Must be one of the following types: half, bfloat16, float32, float64.
        Shape [batch, in_depth, in_height, in_width, in_channels].
    filters : tensor
        Must have the same type as input. Shape [filter_depth, filter_height, filter_width, in_channels, out_channels].
        in_channels must match between input and filters.
    strides : list of ints
        A list of ints that has length >= 5. 1-D tensor of length 5.
        The stride of the sliding window for each dimension of input.
        Must have strides[0] = strides[4] = 1.
    padding : string
        A string from: "SAME", "VALID". The type of padding algorithm to use.
    data_format : string
        An optional string from: "NDHWC", "NCDHW". Defaults to "NDHWC". The data format of the input and output data.
        With the default format "NDHWC", the data is stored in the order of: [batch, in_depth, in_height, in_width, in_channels].
        Alternatively, the format could be "NCDHW", the data storage order is: [batch, in_channels, in_depth, in_height, in_width].
    dilations : list of ints
        Defaults to [1, 1, 1, 1, 1]. 1-D tensor of length 5. The dilation factor for each dimension of input.
        If set to k > 1, there will be k-1 skipped cells between each filter element on that dimension.
        The dimension order is determined by the value of data_format, see above for details.
        Dilations in the batch and depth dimensions must be 1.
    name : string
        A name for the operation (optional).

    Returns
    -------
        A Tensor. Has the same type as input.
    """

    data_format, padding = preprocess_3d_format(data_format, padding)
    outputs = tf.nn.conv3d(
        input=input,
        filters=filters,
        strides=strides,
        padding=padding,
        data_format=data_format,  # 'NDHWC',
        dilations=dilations,  # [1, 1, 1, 1, 1],
        # name=name,
    )
    return outputs


def lrn(inputs, depth_radius, bias, alpha, beta):
    """
    Local Response Normalization.

    Parameters
    ----------
    inputs : tensor
        Must be one of the following types: half, bfloat16, float32. 4-D.
    depth_radius : int
        Defaults to 5. 0-D. Half-width of the 1-D normalization window.
    bias : float
        Defaults to 1. An offset (usually positive to avoid dividing by 0).
    alpha : float
        Defaults to 1. A scale factor, usually positive.
    beta : float
         Defaults to 0.5. An exponent.

    Returns
    -------
        A Tensor. Has the same type as input.
    """

    outputs = tf.nn.lrn(inputs,
                        depth_radius=depth_radius,
                        bias=bias,
                        alpha=alpha,
                        beta=beta)
    return outputs


def moments(x, axes, shift=None, keepdims=False):
    """
    Calculates the mean and variance of x.

    Parameters
    ----------
    x : tensor
        A Tensor
    axes : list or ints
        Axes along which to compute mean and variance.
    shift : int
        Not used in the current implementation.
    keepdims : bool
        produce moments with the same dimensionality as the input.

    Returns
    -------
        Two Tensor objects: mean and variance.
    """

    outputs = tf.nn.moments(x, axes, shift, keepdims)
    return outputs


def max_pool(input, ksize, strides, padding, data_format=None):
    """
    Performs the max pooling on the input.

    Parameters
    ----------
    input : tensor
        Tensor of rank N+2, of shape [batch_size] + input_spatial_shape + [num_channels] if data_format does not start
        with "NC" (default), or [batch_size, num_channels] + input_spatial_shape if data_format starts with "NC".
        Pooling happens over the spatial dimensions only.
    ksize : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The size of the window for each dimension of the input tensor.
    strides : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The stride of the sliding window for each dimension of the input tensor.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    name : string
        A name for the operation (optional).

    Returns
    -------
        A Tensor of format specified by data_format. The max pooled output tensor.
    """

    if len(input.shape) == 3:
        data_format, padding = preprocess_1d_format(data_format=data_format,
                                                    padding=padding)
    elif len(input.shape) == 4:
        data_format, padding = preprocess_2d_format(data_format=data_format,
                                                    padding=padding)
    elif len(input.shape) == 5:
        data_format, padding = preprocess_3d_format(data_format=data_format,
                                                    padding=padding)

    outputs = tf.nn.max_pool(
        input=input,
        ksize=ksize,
        strides=strides,
        padding=padding,
        data_format=data_format,
    )
    return outputs


def max_pool1d(input,
               kernel_size,
               stride=None,
               padding=0,
               return_mask=False,
               data_format="NCL"):
    data_format, padding = preprocess_1d_format(data_format=data_format,
                                                padding=padding)
    padding_value = None
    if not isinstance(padding, str):
        padding_value = preprocess_padding(padding, "1d", data_format)
        padding = "VALID"
    if padding_value is not None:
        input = tf.pad(input, padding_value)
    if return_mask:
        raise NotImplementedError
    else:
        outputs = tf.nn.max_pool(
            input=input,
            ksize=kernel_size,
            strides=stride,
            padding=padding,
            data_format=data_format,
        )
    return outputs


def max_pool2d(input,
               kernel_size,
               stride=None,
               padding=0,
               return_mask=False,
               data_format="NCHW"):
    data_format, padding = preprocess_2d_format(data_format=data_format,
                                                padding=padding)
    padding_value = None
    if not isinstance(padding, str):
        padding_value = preprocess_padding(padding, "2d", data_format)
        padding = "VALID"
    if padding_value is not None:
        input = tf.pad(input, padding_value)
    if return_mask:
        outputs = tf.nn.max_pool_with_argmax(
            input=input,
            ksize=kernel_size,
            strides=stride,
            padding=padding,
            data_format=data_format,
            include_batch_in_index=True,
        )
    else:
        outputs = tf.nn.max_pool(
            input=input,
            ksize=kernel_size,
            strides=stride,
            padding=padding,
            data_format=data_format,
        )
    return outputs


def max_pool3d(input,
               kernel_size,
               stride=None,
               padding=0,
               return_mask=False,
               data_format="NCDHW"):
    data_format, padding = preprocess_3d_format(data_format=data_format,
                                                padding=padding)
    padding_value = None
    if not isinstance(padding, str):
        padding_value = preprocess_padding(padding, "3d", data_format)
        padding = "VALID"
    if padding_value is not None:
        input = tf.pad(input, padding_value)
    if return_mask:
        raise NotImplementedError
    else:
        outputs = tf.nn.max_pool(
            input=input,
            ksize=kernel_size,
            strides=stride,
            padding=padding,
            data_format=data_format,
        )
    return outputs


def avg_pool(input, ksize, strides, padding):
    """
    Performs the avg pooling on the input.

    Parameters
    ----------
    input : tensor
        Tensor of rank N+2, of shape [batch_size] + input_spatial_shape + [num_channels]
        if data_format does not start with "NC" (default), or [batch_size, num_channels] + input_spatial_shape
        if data_format starts with "NC". Pooling happens over the spatial dimensions only.
    ksize : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The size of the window for each dimension of the input tensor.
    strides : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The stride of the sliding window for each dimension of the input tensor.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    name : string
        Optional name for the operation.

    Returns
    -------
        A Tensor of format specified by data_format. The average pooled output tensor.
    """

    padding = padding_format(padding)
    outputs = tf.nn.avg_pool(
        input=input,
        ksize=ksize,
        strides=strides,
        padding=padding,
    )
    return outputs


def avg_pool1d(input, kernel_size, stride=None, padding=0, data_format="NCL"):
    data_format, padding = preprocess_1d_format(data_format=data_format,
                                                padding=padding)
    padding_value = None
    if not isinstance(padding, str):
        padding_value = preprocess_padding(padding, "1d", data_format)
        padding = "VALID"
    if padding_value is not None:
        input = tf.pad(input, padding_value)
    output = tf.nn.pool(
        input=input,
        window_shape=kernel_size,
        pooling_type="AVG",
        strides=stride,
        padding=padding,
        data_format=data_format,
    )
    return output


def avg_pool2d(input, kernel_size, stride=None, padding=0, data_format="NCHW"):
    data_format, padding = preprocess_2d_format(data_format=data_format,
                                                padding=padding)
    if isinstance(kernel_size, int):
        kernel_size = [kernel_size, kernel_size]
    if isinstance(stride, int):
        stride = [stride, stride]
    padding_value = None
    if not isinstance(padding, str):
        padding_value = preprocess_padding(padding, "2d", data_format)
        padding = "VALID"
    if padding_value is not None:
        input = tf.pad(input, padding_value)
    output = tf.nn.pool(
        input=input,
        window_shape=kernel_size,
        pooling_type="AVG",
        strides=stride,
        padding=padding,
        data_format=data_format,
    )
    return output


def avg_pool3d(input,
               kernel_size,
               stride=None,
               padding=0,
               data_format="NCDHW"):
    data_format, padding = preprocess_3d_format(data_format=data_format,
                                                padding=padding)
    if isinstance(kernel_size, int):
        kernel_size = [kernel_size, kernel_size, kernel_size]
    if isinstance(stride, int):
        stride = [stride, stride, stride]
    padding_value = None
    if not isinstance(padding, str):
        padding_value = preprocess_padding(padding, "3d", data_format)
        padding = "VALID"
    if padding_value is not None:
        input = tf.pad(input, padding_value)
    output = tf.nn.pool(
        input=input,
        window_shape=kernel_size,
        pooling_type="AVG",
        strides=stride,
        padding=padding,
        data_format=data_format,
    )
    return output


# def max_pool3d(input, ksize, strides, padding, data_format=None):
#     """
#     Performs the max pooling on the input.
#
#     Parameters
#     ----------
#     input : tensor
#          A 5-D Tensor of the format specified by data_format.
#     ksize : int or list of ints
#         An int or list of ints that has length 1, 3 or 5.
#         The size of the window for each dimension of the input tensor.
#     strides : int or list of ints
#         An int or list of ints that has length 1, 3 or 5.
#         The stride of the sliding window for each dimension of the input tensor.
#     padding : string
#         'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
#     data_format : string
#          "NDHWC", "NCDHW". Defaults to "NDHWC". The data format of the input and output data.
#          With the default format "NDHWC", the data is stored in the order of: [batch, in_depth, in_height, in_width, in_channels].
#          Alternatively, the format could be "NCDHW", the data storage order is: [batch, in_channels, in_depth, in_height, in_width].
#     name : string
#          A name for the operation (optional).
#
#     Returns
#     -------
#         A Tensor of format specified by data_format. The max pooled output tensor.
#     """
#
#     data_format, padding = preprocess_3d_format(data_format, padding)
#     outputs = tf.nn.max_pool3d(
#         input=input,
#         ksize=ksize,
#         strides=strides,
#         padding=padding,
#         data_format=data_format,
#     )
#     return outputs

# def avg_pool3d(input, ksize, strides, padding, data_format=None):
#     """
#     Performs the average pooling on the input.
#
#     Parameters
#     ----------
#     input : tensor
#         A 5-D Tensor of shape [batch, height, width, channels] and type float32, float64, qint8, quint8, or qint32.
#     ksize : int or list of ints
#         An int or list of ints that has length 1, 3 or 5. The size of the window for each dimension of the input tensor.
#     strides : int or list of ints
#         An int or list of ints that has length 1, 3 or 5.
#         The stride of the sliding window for each dimension of the input tensor.
#     padding : string
#         'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
#     data_format : string
#         'NDHWC' and 'NCDHW' are supported.
#     name : string
#         Optional name for the operation.
#
#     Returns
#     -------
#         A Tensor with the same type as value. The average pooled output tensor.
#     """
#
#     data_format, padding = preprocess_3d_format(data_format, padding)
#     outputs = tf.nn.avg_pool3d(
#         input=input,
#         ksize=ksize,
#         strides=strides,
#         padding=padding,
#         data_format=data_format,
#     )
#     return outputs


def pool(
    input,
    window_shape,
    pooling_type,
    strides=None,
    padding="VALID",
    data_format=None,
    dilations=None,
    name=None,
):
    """
    Performs an N-D pooling operation.

    Parameters
    ----------
    input : tensor
        Tensor of rank N+2, of shape [batch_size] + input_spatial_shape + [num_channels]
        if data_format does not start with "NC" (default), or [batch_size, num_channels] + input_spatial_shape
        if data_format starts with "NC". Pooling happens over the spatial dimensions only.
    window_shape : int
        Sequence of N ints >= 1.
    pooling_type : string
        Specifies pooling operation, must be "AVG" or "MAX".
    strides : ints
        Sequence of N ints >= 1. Defaults to [1]*N. If any value of strides is > 1, then all values of dilation_rate must be 1.
    padding : string
        The padding algorithm, must be "SAME" or "VALID". Defaults to "SAME".
        See the "returns" section of tf.ops.convolution for details.
    data_format : string
        Specifies whether the channel dimension of the input and output is the last dimension (default, or if data_format does not start with "NC"),
        or the second dimension (if data_format starts with "NC").
        For N=1, the valid values are "NWC" (default) and "NCW". For N=2, the valid values are "NHWC" (default) and "NCHW".
        For N=3, the valid values are "NDHWC" (default) and "NCDHW".
    dilations : list of ints
        Dilation rate. List of N ints >= 1. Defaults to [1]*N. If any value of dilation_rate is > 1, then all values of strides must be 1.
    name : string
        Optional. Name of the op.

    Returns
    -------
        Tensor of rank N+2, of shape [batch_size] + output_spatial_shape + [num_channels]
    """
    if pooling_type in ["MAX", "max"]:
        pooling_type = "MAX"
    elif pooling_type in ["AVG", "avg"]:
        pooling_type = "AVG"
    else:
        raise ValueError("Unsupported pool_mode: " + str(pooling_type))
    padding = padding_format(padding)
    outputs = tf.nn.pool(
        input=input,
        window_shape=window_shape,
        pooling_type=pooling_type,
        strides=strides,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
        name=name,
    )
    return outputs


def depthwise_conv2d(input,
                     filter,
                     strides,
                     padding,
                     data_format=None,
                     dilations=None,
                     name=None):
    """
    Depthwise 2-D convolution.

    Parameters
    ----------
    input : tensor
        4-D with shape according to data_format.
    filter : tensor
        4-D with shape [filter_height, filter_width, in_channels, channel_multiplier].
    strides : list
        1-D of size 4. The stride of the sliding window for each dimension of input.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
        The data format for input. Either "NHWC" (default) or "NCHW".
    dilations : list
        1-D of size 2. The dilation rate in which we sample input values across the height and width dimensions in atrous convolution.
        If it is greater than 1, then all values of strides must be 1.
    name : string
        A name for this operation (optional).

    Returns
    -------
        A 4-D Tensor with shape according to data_format.
        E.g., for "NHWC" format, shape is [batch, out_height, out_width, in_channels * channel_multiplier].
    """

    data_format, padding = preprocess_2d_format(data_format, padding)
    outputs = tf.nn.depthwise_conv2d(
        input=input,
        filter=filter,
        strides=strides,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
        name=name,
    )
    return outputs


def conv1d_transpose(
    input,
    filters,
    output_shape,
    strides,
    padding="SAME",
    data_format="NWC",
    dilations=None,
    name=None,
):
    """
    The transpose of conv1d.

    Parameters
    ----------
    input : tensor
        A 3-D Tensor of type float and shape [batch, in_width, in_channels]
        for NWC data format or [batch, in_channels, in_width] for NCW data format.
    filters : tensor
        A 3-D Tensor with the same type as value and shape [filter_width, output_channels, in_channels].
        filter's in_channels dimension must match that of value.
    output_shape : tensor
        A 1-D Tensor, containing three elements, representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1 or 3. The number of entries by which the filter is moved right at each step.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
        'NWC' and 'NCW' are supported.
    dilations : list
         An int or list of ints that has length 1 or 3 which defaults to 1.
         The dilation factor for each dimension of input. If set to k > 1,
         there will be k-1 skipped cells between each filter element on that dimension.
         Dilations in the batch and depth dimensions must be 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as value.
    """

    data_format, padding = preprocess_1d_format(data_format, padding)
    outputs = tf.nn.conv1d_transpose(
        input=input,
        filters=filters,
        output_shape=output_shape,
        strides=strides,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
        name=name,
    )
    return outputs


def conv2d_transpose(
    input,
    filters,
    output_shape,
    strides,
    padding="SAME",
    data_format="NHWC",
    dilations=None,
    name=None,
):
    """
    The transpose of conv2d.

    Parameters
    ----------
    input : tensor
        A 4-D Tensor of type float and shape [batch, height, width, in_channels]
        for NHWC data format or [batch, in_channels, height, width] for NCHW data format.
    filters : tensor
        A 4-D Tensor with the same type as input and shape [height, width,
        output_channels, in_channels]. filter's in_channels dimension must match that of input.
    output_shape : tensor
        A 1-D Tensor representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1, 2 or 4. The stride of the sliding window for each dimension of input.
        If a single value is given it is replicated in the H and W dimension.
        By default the N and C dimensions are set to 0.
        The dimension order is determined by the value of data_format, see below for details.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
         'NHWC' and 'NCHW' are supported.
    dilations : list
        An int or list of ints that has length 1, 2 or 4, defaults to 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as input.
    """

    # data_format, padding = preprocess_2d_format(data_format, padding)
    # outputs = tf.nn.conv2d_transpose(
    #     input=input,
    #     filters=filters,
    #     output_shape=output_shape,
    #     strides=strides,
    #     padding=padding,
    #     data_format=data_format,
    #     dilations=dilations,
    #     name=name,
    # )
    # return outputs
    raise NotImplementedError


def conv3d_transpose(
    input,
    filters,
    output_shape,
    strides,
    padding="SAME",
    data_format="NDHWC",
    dilations=None,
    name=None,
):
    """
    The transpose of conv3d.

    Parameters
    ----------
    input : tensor
         A 5-D Tensor of type float and shape [batch, height, width, in_channels] for
         NHWC data format or [batch, in_channels, height, width] for NCHW data format.
    filters : tensor
        A 5-D Tensor with the same type as value and shape [height, width, output_channels, in_channels].
        filter's in_channels dimension must match that of value.
    output_shape : tensor
        A 1-D Tensor representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1, 3 or 5.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
        'NDHWC' and 'NCDHW' are supported.
    dilations : list of ints
        An int or list of ints that has length 1, 3 or 5, defaults to 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as value.
    """

    data_format, padding = preprocess_3d_format(data_format, padding)
    outputs = tf.nn.conv3d_transpose(
        input=input,
        filters=filters,
        output_shape=output_shape,
        strides=strides,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
        name=name,
    )
    return outputs


def depthwise_conv2d(
    input,
    filters,
    strides,
    padding="SAME",
    data_format="NHWC",
    dilations=None,
    name=None,
):
    """
    Depthwise 2-D convolution.

    Parameters
    ----------
    input : tensor
        4-D with shape according to data_format.
    filters : tensor
        4-D with shape [filter_height, filter_width, in_channels, channel_multiplier].
    strides : tuple
        1-D of size 4. The stride of the sliding window for each dimension of input.
    padding : string
        'VALID' or 'SAME'
    data_format : string
        "NHWC" (default) or "NCHW".
    dilations : tuple
        The dilation rate in which we sample input values across the height and width dimensions in atrous convolution.
        If it is greater than 1, then all values of strides must be 1.
    name : string
        A name for this operation (optional).

    Returns
    -------
        A 4-D Tensor with shape according to data_format.
    """

    data_format, padding = preprocess_2d_format(data_format, padding)
    outputs = tf.nn.depthwise_conv2d(
        input=input,
        filter=filters,
        strides=strides,
        padding=padding,
        data_format=data_format,
        dilations=dilations,
        name=name,
    )
    return outputs


def _to_channel_first_bias(b):
    """Reshape [c] to [c, 1, 1]."""
    channel_size = int(b.shape[0])
    new_shape = (channel_size, 1, 1)
    return tf.reshape(b, new_shape)


def _bias_scale(x, b, data_format):
    """The multiplication counter part of tf.nn.bias_add."""
    if data_format == "NHWC":
        return x * b
    elif data_format == "NCHW":
        return x * _to_channel_first_bias(b)
    else:
        raise ValueError("invalid data_format: %s" % data_format)


def _bias_add(x, b, data_format):
    """Alternative implementation of tf.nn.bias_add which is compatiable with tensorRT."""
    if data_format == "NHWC":
        return tf.add(x, b)
    elif data_format == "NCHW":
        return tf.add(x, _to_channel_first_bias(b))
    else:
        raise ValueError("invalid data_format: %s" % data_format)


def batch_normalization(x,
                        mean,
                        variance,
                        offset,
                        scale,
                        variance_epsilon,
                        data_format,
                        name=None):
    """Data Format aware version of tf.nn.batch_normalization."""
    if data_format == "channels_last":
        mean = tf.reshape(mean, [1] * (len(x.shape) - 1) + [-1])
        variance = tf.reshape(variance, [1] * (len(x.shape) - 1) + [-1])
        offset = tf.reshape(offset, [1] * (len(x.shape) - 1) + [-1])
        scale = tf.reshape(scale, [1] * (len(x.shape) - 1) + [-1])
    elif data_format == "channels_first":
        mean = tf.reshape(mean, [1] + [-1] + [1] * (len(x.shape) - 2))
        variance = tf.reshape(variance, [1] + [-1] + [1] * (len(x.shape) - 2))
        offset = tf.reshape(offset, [1] + [-1] + [1] * (len(x.shape) - 2))
        scale = tf.reshape(scale, [1] + [-1] + [1] * (len(x.shape) - 2))
    else:
        raise ValueError("invalid data_format: %s" % data_format)

    with ops.name_scope(name, "batchnorm", [x, mean, variance, scale, offset]):
        inv = math_ops.rsqrt(variance + variance_epsilon)
        if scale is not None:
            inv *= scale

        a = math_ops.cast(inv, x.dtype)
        b = math_ops.cast(
            offset - mean * inv if offset is not None else -mean * inv,
            x.dtype)
        # Return a * x + b with customized data_format.
        # Currently TF doesn't have bias_scale, and tensorRT has bug in converting tf.nn.bias_add
        # So we reimplemted them to allow make the model work with tensorRT.
        # See https://github.com/tensorlayer/openpose-plus/issues/75 for more details.
        # df = {'channels_first': 'NCHW', 'channels_last': 'NHWC'}
        # return _bias_add(_bias_scale(x, a, df[data_format]), b, df[data_format])
        return a * x + b


def group_normalization(x,
                        mean,
                        variance,
                        scale,
                        offset,
                        variance_epsilon,
                        name=None):
    with ops.name_scope(name, "groupnorm", [x, mean, variance, scale, offset]):
        inv = math_ops.rsqrt(variance + variance_epsilon)
    if scale is not None:
        inv *= scale
    return x * math_ops.cast(inv, x.dtype) + math_ops.cast(
        offset - mean * inv if offset is not None else -mean * inv, x.dtype)


def instance_normalization(x,
                           mean,
                           variance,
                           scale,
                           offset,
                           variance_epsilon,
                           name=None):
    with ops.name_scope(name, "instance_norm",
                        [x, mean, variance, scale, offset]):
        inv = math_ops.rsqrt(variance + variance_epsilon)
    if scale is not None:
        inv *= scale
    return x * math_ops.cast(inv, x.dtype) + math_ops.cast(
        offset - mean * inv if offset is not None else -mean * inv, x.dtype)


def adaptive_avg_pool1d(input, output_size):
    raise NotImplementedError


def adaptive_avg_pool2d(input, output_size):
    raise NotImplementedError


def adaptive_avg_pool3d(input, output_size):
    raise NotImplementedError


def adaptive_max_pool1d(input, output_size, return_indices=False):
    raise NotImplementedError


def adaptive_max_pool2d(input, output_size, return_indices=False):
    raise NotImplementedError


def adaptive_max_pool3d(input, output_size, return_indices=False):
    raise NotImplementedError


def quantize(x):
    # ref: https://github.com/AngusG/tensorflow-xnor-bnn/blob/master/models/binary_net.py#L70
    #  https://github.com/itayhubara/BinaryNet.tf/blob/master/nnUtils.py
    with tf.compat.v1.get_default_graph().gradient_override_map(
        {"Sign": "TL_Sign_QuantizeGrad"}):
        return tf.sign(x)


def _quantize_dorefa(x, k):
    G = tf.compat.v1.get_default_graph()
    n = float(2**k - 1)
    with G.gradient_override_map({"Round": "Identity"}):
        return tf.round(x * n) / n


def quantize_active(x, bitA):
    if bitA == 32:
        return x
    return _quantize_dorefa(x, bitA)


def quantize_weight(x, bitW, force_quantization=False):
    G = tf.compat.v1.get_default_graph()
    if bitW == 32 and not force_quantization:
        return x
    if bitW == 1:  # BWN
        with G.gradient_override_map({"Sign": "Identity"}):
            E = tf.stop_gradient(tf.reduce_mean(input_tensor=tf.abs(x)))
            return tf.sign(x / E) * E
    x = tf.clip_by_value(
        x * 0.5 + 0.5, 0.0, 1.0
    )  # it seems as though most weights are within -1 to 1 region anyways
    return 2 * _quantize_dorefa(x, bitW) - 1


def cabs(x):
    return tf.minimum(1.0, tf.abs(x), name="cabs")


def _compute_threshold(x):
    """
    ref: https://github.com/XJTUWYD/TWN
    Computing the threshold.
    """
    x_sum = tf.reduce_sum(input_tensor=tf.abs(x),
                          axis=None,
                          keepdims=False,
                          name=None)
    # threshold = tf.compat.v1.div(x_sum, tf.cast(tf.size(input=x), tf.float32), name=None)
    threshold = tf.math.divide(x_sum,
                               tf.cast(tf.size(input=x), tf.float32),
                               name=None)
    threshold = tf.multiply(0.7, threshold, name=None)
    return threshold


def compute_alpha(x):
    """Computing the scale parameter."""
    threshold = _compute_threshold(x)
    alpha1_temp1 = tf.where(tf.greater(x, threshold), x,
                            tf.zeros_like(x, tf.float32))
    alpha1_temp2 = tf.where(tf.less(x, -threshold), x,
                            tf.zeros_like(x, tf.float32))
    alpha_array = tf.add(alpha1_temp1, alpha1_temp2, name=None)
    alpha_array_abs = tf.abs(alpha_array)
    alpha_array_abs1 = tf.where(
        tf.greater(alpha_array_abs, 0),
        tf.ones_like(alpha_array_abs, tf.float32),
        tf.zeros_like(alpha_array_abs, tf.float32),
    )
    alpha_sum = tf.reduce_sum(input_tensor=alpha_array_abs)
    n = tf.reduce_sum(input_tensor=alpha_array_abs1)
    # alpha = tf.compat.v1.div(alpha_sum, n)
    alpha = tf.math.divide(alpha_sum, n)
    return alpha


def _quantize_overflow(x, k):
    G = tf.compat.v1.get_default_graph()
    n = float(2**k - 1)
    max_value = tf.reduce_max(input_tensor=x)
    min_value = tf.reduce_min(input_tensor=x)
    with G.gradient_override_map({"Round": "Identity"}):
        step = tf.stop_gradient((max_value - min_value) / n)
        return tf.round(
            (tf.maximum(tf.minimum(x, max_value), min_value) - min_value) /
            step) * step + min_value


def quantize_active_overflow(x, bitA):
    if bitA == 32:
        return x
    return _quantize_overflow(x, bitA)


def quantize_weight_overflow(x, bitW):
    if bitW == 32:
        return x
    return _quantize_overflow(x, bitW)


def ternary_operation(x):
    """Ternary operation use threshold computed with weights."""
    g = tf.compat.v1.get_default_graph()
    with g.gradient_override_map({"Sign": "Identity"}):
        threshold = _compute_threshold(x)
        x = tf.sign(
            tf.add(tf.sign(tf.add(x, threshold)),
                   tf.sign(tf.add(x, -threshold))))
        return x


def mean_var_with_update(update_moving_mean, update_moving_variance, mean,
                         variance):
    with tf.control_dependencies([update_moving_mean, update_moving_variance]):
        return tf.identity(mean), tf.identity(variance)


def w_fold(w, gama, var, epsilon):
    return tf.compat.v1.div(tf.multiply(gama, w), tf.sqrt(var + epsilon))


def bias_fold(beta, gama, mean, var, epsilon):
    return tf.subtract(
        beta, tf.compat.v1.div(tf.multiply(gama, mean),
                               tf.sqrt(var + epsilon)))


def prelu(input, weight, data_format):
    if data_format == "channels_first":
        input = nchw_to_nhwc(input)
    pos = tf.nn.relu(input)
    neg = -weight * tf.nn.relu(-input)
    output = pos + neg
    if data_format == "channels_first":
        output = nhwc_to_nchw(output)
    return output


def hardsigmoid(input):
    point_two = tf.convert_to_tensor(1 / 6, input.dtype.base_dtype)
    point_five = tf.convert_to_tensor(0.5, input.dtype.base_dtype)
    x = math_ops.multiply(input, point_two)
    x = math_ops.add(x, point_five)
    x = tf.clip_by_value(x, 0.0, 1.0)
    return x


def hardswish(input):
    point_two = tf.convert_to_tensor(1 / 6, input.dtype.base_dtype)
    point_five = tf.convert_to_tensor(0.5, input.dtype.base_dtype)
    x_sqrt = math_ops.multiply(input, input)
    x_1 = math_ops.multiply(x_sqrt, point_two)
    x_2 = math_ops.multiply(input, point_five)
    x = math_ops.add(x_1, x_2)
    x = tf.clip_by_value(x, 0.0, input)
    return x


def swish(input):
    return tf.sigmoid(input) * input


def linear(input, weight, bias=None):
    output = tf.matmul(input, weight, transpose_b=True)
    if bias is not None:
        output = output + bias
    return output


def unfold(input, kernel_size, dilation=1, padding=0, stride=1):
    input = tf.transpose(input, perm=[0, 2, 3, 1])
    kernel_size = ([
        1,
    ] + list(kernel_size) + [1])
    stride = ([
        1,
    ] + list(stride) + [1])
    dilation = ([
        1,
    ] + list(dilation) + [1])
    padding = [[0, 0], [padding[0], padding[0]], [padding[1], padding[1]],
               [0, 0]]
    input = tf.pad(input, paddings=padding, mode="CONSTANT", constant_values=0)
    output = tf.image.extract_patches(input,
                                      sizes=kernel_size,
                                      strides=stride,
                                      padding="VALID",
                                      rates=dilation)
    output = tf.transpose(output, perm=[0, 3, 1, 2])
    output = tf.reshape(
        output,
        shape=[
            output.shape[0], output.shape[1], output.shape[2] * output.shape[3]
        ],
    )
    return output


REDUCTION_ENUM = {"none": 0, "mean": 1, "sum": 2}


def _expand_onehot_labels(labels, label_weights, label_channels, ignore_index):
    """Expand onehot labels to match the size of prediction."""
    bin_labels = tf.cast(tf.fill((labels.shape[0], label_channels), 0),
                         tf.int64)
    valid_mask = (labels >= 0) & (labels != ignore_index)
    inds = tf.where(tf.not_equal(valid_mask & (labels < label_channels),
                                 False))
    gather_label = tf.gather(labels, inds)
    indices = tf.concat([inds, gather_label], axis=-1)
    updates = tf.ones_like(indices[:, 0])
    if inds.shape[0] > 0:
        bin_labels = tf.tensor_scatter_nd_update(bin_labels, indices, updates)
    valid_mask = tf.cast(
        tf.broadcast_to(tf.reshape(valid_mask, (-1, 1)),
                        (labels.shape[0], label_channels)),
        tf.float32,
    )
    if label_weights is None:
        bin_label_weights = valid_mask
    else:
        bin_label_weights = tf.tile(tf.reshape(label_weights, (-1, 1)),
                                    (1, label_channels))
        bin_label_weights *= valid_mask

    return bin_labels, bin_label_weights


def weight_reduce_loss(loss, weight=None, reduction="mean", avg_factor=None):
    """Apply element-wise weight and reduce loss.
    Args:
        loss (Tensor): Element-wise loss.
        weight (Tensor): Element-wise weights.
        reduction (str): Same as built-in losses of PyTorch.
        avg_factor (float): Avarage factor when computing the mean of losses.
    Returns:
        Tensor: Processed loss values.
    """
    # if weight is specified, apply element-wise weight
    #     print('before weight',tf.math.reduce_sum(loss),"weigh :", weight , tf.math.reduce_sum(tf.where(weight > 1, 1,0)))
    # print(reduction)
    if weight is not None:
        loss = loss * tf.cast(weight, loss.dtype)
    #     print('affter weight',tf.math.reduce_sum(loss))
    # if avg_factor is not specified, just reduce the loss
    if avg_factor is None:
        loss = reduce_loss(loss, reduction)
    else:
        # if reduction is mean, then average the loss by avg_factor
        if reduction == "mean":
            avg_factor = tf.cast(avg_factor, loss.dtype)
            loss = tf.math.reduce_sum(loss) / (avg_factor + 1e-6)
        # if reduction is 'none', then do nothing, otherwise raise an error
        elif reduction != "none":
            raise ValueError('avg_factor can not be used with reduction="sum"')
    return loss


def reduce_loss(loss, reduction):
    """Reduce loss as specified.
    Args:
        loss (Tensor): Elementwise loss tensor.
        reduction (str): Options are "none", "mean" and "sum".
    Return:
        Tensor: Reduced loss tensor.
    """

    reduction = reduction.lower()
    reduction_enum = REDUCTION_ENUM[reduction]
    # reduction_enum = F._Reduction.get_enum(reduction)
    # none: 0, elementwise_mean:1, sum: 2
    if reduction_enum == 0:
        return loss
    elif reduction_enum == 1:
        return tf.math.reduce_mean(loss)
    elif reduction_enum == 2:
        return tf.math.reduce_sum(loss)


def binary_cross_entropy(
    pred,
    label,
    weight=None,
    reduction="mean",
    avg_factor=None,
    class_weight=None,
    ignore_index=-100,
    avg_non_ignore=False,
):
    """Calculate the binary CrossEntropy loss.

    Args:
        pred (tf.Tensor): The prediction with shape (N, 1) or (N, ).
            When the shape of pred is (N, 1), label will be expanded to
            one-hot format, and when the shape of pred is (N, ), label
            will not be expanded to one-hot format.
        label (tf.Tensor): The learning label of the prediction,
            with shape (N, ).
        weight (tf.Tensor, optional): Sample-wise loss weight.
        reduction (str, optional): The method used to reduce the loss.
            Options are "none", "mean" and "sum".
        avg_factor (int, optional): Average factor that is used to average
            the loss. Defaults to None.
        class_weight (list[float], optional): The weight for each class.
        ignore_index (int | None): The label index to be ignored.
            If None, it will be set to default value. Default: -100.
        avg_non_ignore (bool): The flag decides to whether the loss is
            only averaged over non-ignored targets. Default: False.

    Returns:
        tf.Tensor: The calculated loss.
    """
    # The default value of ignore_index is the same as F.cross_entropy
    ignore_index = -100 if ignore_index is None else ignore_index
    if pred.shape != label.shape:
        label, weight = _expand_onehot_labels(label, weight, pred.shape[-1],
                                              ignore_index)
        # pred = tf.squeeze(pred)
        # label = tf.cast(label, pred.dtype)
        # weight = tf.cast(weight, pred.dtype)
    else:
        # should mask out the ignored elements
        valid_mask = tf.cast((label >= 0) & (label != ignore_index),
                             pred.dtype)
        if weight is not None:
            # The inplace writing method will have a mismatched broadcast
            # shape error if the weight and valid_mask dimensions
            # are inconsistent such as (B,N,1) and (B,N,C).
            weight = weight * valid_mask
        else:
            weight = valid_mask

    if (avg_factor is None) and avg_non_ignore and reduction == "mean":
        avg_factor = tf.reduce_sum(valid_mask)

    if class_weight is not None:
        log_weight = 1 + (class_weight - 1) * label
    else:
        # loss = backend.binary_crossentropy(label, pred, from_logits=True)
        log_weight = 1
    loss = math_ops.add(
        (tf.cast(1, pred.dtype) - tf.cast(label, pred.dtype)) * pred,
        tf.cast(log_weight, pred.dtype) *
        (math_ops.log1p(math_ops.exp(-math_ops.abs(pred))) +
         nn_ops.relu(-pred)),
    )
    loss = weight_reduce_loss(loss,
                              weight,
                              reduction=reduction,
                              avg_factor=avg_factor)
    return loss


def mask_cross_entropy(
    pred,
    target,
    label,
    reduction="mean",
    avg_factor=None,
    class_weight=None,
    ignore_index=None,
    **kwargs,
):
    """Calculate the CrossEntropy loss for masks.

    Args:
        pred (tf.Tensor): The prediction with shape (N, C, *), C is the
            number of classes. The trailing * indicates arbitrary shape.
        target (tf.Tensor): The learning label of the prediction.
        label (tf.Tensor): ``label`` indicates the class label of the mask
            corresponding object. This will be used to select the mask in the
            of the class which the object belongs to when the mask prediction
            if not class-agnostic.
        reduction (str, optional): The method used to reduce the loss.
            Options are "none", "mean" and "sum".
        avg_factor (int, optional): Average factor that is used to average
            the loss. Defaults to None.
        class_weight (list[float], optional): The weight for each class.
        ignore_index (None): Placeholder, to be consistent with other loss.
            Default: None.

    Returns:
        tf.Tensor: The calculated loss

    Example:
        >>> N, C = 3, 11
        >>> H, W = 2, 2
        >>> pred = torch.randn(N, C, H, W) * 1000
        >>> target = torch.rand(N, H, W)
        >>> label = torch.randint(0, C, size=(N,))
        >>> reduction = 'mean'
        >>> avg_factor = None
        >>> class_weights = None
        >>> loss = mask_cross_entropy(pred, target, label, reduction,
        >>>                           avg_factor, class_weights)
        >>> assert loss.shape == (1,)
    """
    assert ignore_index is None, "BCE loss does not support ignore_index"
    # TODO: handle these two reserved arguments
    assert reduction == "mean" and avg_factor is None
    num_rois = pred.shape.as_list()[0]
    inds = backend.arange(0, num_rois, dtype=tf.int64)
    if tf.size(label) == 1 and num_rois > 1:
        label = tf.tile(label, num_rois)
    assert len(label) == len(inds)
    indices = tf.transpose(tf.stack([inds, label], axis=0))
    pred_slice = tf.gather_nd(pred, indices)
    if class_weight is None:
        class_weight = 1
    return tf.math.reduce_mean(
        tf.nn.weighted_cross_entropy_with_logits(target, pred_slice,
                                                 class_weight))


def cross_entropy(
    pred,
    label,
    weight=None,
    reduction="mean",
    avg_factor=None,
    class_weight=None,
    ignore_index=-100,
    avg_non_ignore=False,
):
    """Calculate the binary CrossEntropy loss.


    Args:
        pred (tf.Tensor): The prediction with shape (N, C), C is the number
            of classes.
        label (tf.Tensor): The learning label of the prediction.
        weight (tf.Tensor, optional): Sample-wise loss weight.
        reduction (str, optional): The method used to reduce the loss.
        avg_factor (int, optional): Average factor that is used to average
            the loss. Defaults to None.
        class_weight (list[float], optional): The weight for each class.
        ignore_index (int | None): The label index to be ignored.
            If None, it will be set to default value. Default: -100.
        avg_non_ignore (bool): The flag decides to whether the loss is
            only averaged over non-ignored targets. Default: False.

    Returns:
        tf.Tensor: The calculated loss.
    """
    # The default value of ignore_index is the same as F.cross_entropy
    ignore_index = None if ignore_index is None else ignore_index

    # should mask out the ignored elements
    valid_mask = tf.cast((label >= 0) & (label != ignore_index), pred.dtype)
    if weight is not None:
        # The inplace writing method will have a mismatched broadcast
        # shape error if the weight and valid_mask dimensions
        # are inconsistent such as (B,N,1) and (B,N,C).
        weight = weight * valid_mask
    else:
        weight = valid_mask

    if pred.shape != label.shape:
        if len(pred.shape) == 2:
            loss = tf.losses.sparse_categorical_crossentropy(
                label, pred, ignore_class=ignore_index, from_logits=True)
        else:
            # need to transpose pred (N,C,d1,d2...) to (N,d1,d2,...,C)
            pred = tf.einsum("ij...k->ik...j", pred)
            loss = tf.losses.sparse_categorical_crossentropy(
                label, pred, ignore_class=ignore_index, from_logits=True)
    else:
        if ignore_index is not None:
            raise RuntimeError(
                "ignore_index is not supported for floating point target")
        loss = tf.nn.softmax_cross_entropy_with_logits(label, pred)

    if class_weight is None:
        class_weight = 1

    if len(weight.shape):
        weight = weight[:, None]
    if len(loss.shape) == 1:
        loss = loss[:, None]
        loss = tf.math.divide_no_nan(tf.reduce_sum(loss * weight),
                                     tf.reduce_sum(weight))
    else:
        loss = tf.math.divide_no_nan(tf.reduce_sum(loss * weight),
                                     tf.reduce_sum(weight))
    if (avg_factor is None) and avg_non_ignore and reduction == "mean":
        avg_factor = tf.reduce_sum(valid_mask)

    loss = weight_reduce_loss(loss,
                              weight,
                              reduction=reduction,
                              avg_factor=avg_factor)
    return loss


def L1_Loss(pred, label, weight=None, reduction='mean', avg_factor=None):

    loss = tf.abs(pred - label)
    loss = weight_reduce_loss(loss,
                              weight,
                              reduction=reduction,
                              avg_factor=avg_factor)
    return loss


@contextmanager
def no_grad():
    yield


def new_full(input, size, fill_value, dtype=None):
    return tf.fill(size, fill_value)


def conver_dtype(input, dtype):
    return tf.dtypes.cast(input, dtype=dtype)


def detach(input):
    return tf.stop_gradient(input)


def repeat(input, repeats, axis=None):
    return tf.repeat(input, repeats, axis=axis)


def nonzero(input):
    return tf.where(input)


def sort(input, descending=None):
    if descending == True:
        descending = "DESCENDING"
    else:
        descending = "ASCENDING"
    return tf.sort(input,
                   direction=descending), tf.argsort(input,
                                                     direction=descending)


def freeze_stages(m):
    for param in m.trainable_variables:
        param.trainable = False


def move_to_device(model, device=None):
    return model


def convert_to_numpy(value):
    """Convert a value to numpy, handle cases of tensor.
    Args:
        value(any): Any type of value.

    Returns:
        np.ndarry type of value

    """
    if isinstance(value, np.ndarray):
        return value
    elif isinstance(value, (tf.Variable, tf.Tensor)):
        return value.numpy()
    else:
        try:
            return np.array(value)
        except Exception:
            raise TypeError(
                f"Expected type tf.Variable or tf.Tensor, but got type of {type(value)}"
            )


def fill_(tensor, value):
    fill_value = tf.constant(value=value,
                             shape=tensor.shape,
                             dtype=tensor.dtype)
    tensor.assign(fill_value)


def logsumexp(tensor, axis=None, keep_dims=False):
    return tf.reduce_logsumexp(tensor, axis=axis, keepdims=keep_dims)


def item(Tensor):

    return Tensor.numpy()


def tolist(Tensor):
    numpy_tensor = Tensor.numpy()
    list_tensor = numpy_tensor.tolist()
    return list_tensor


def log2(Tensor):
    return tf.math.log(Tensor) / tf.math.log(2.0)


def contiguous(Tensor):
    return Tensor


def randperm(num):
    range = tf.range(num)
    return tf.random.shuffle(range)


def empty_like(Tensor):
    return tf.Variable(tf.random.uniform(Tensor.shape, dtype=tf.float32),
                       trainable=False)


def roi_align(features,
              rois,
              output_size=7,
              spatial_scale=0.5,
              sampling_ratio=None,
              img_metas=None,
              aligned=None):

    batch_ids = tf.cast(rois[:, 0], tf.int32)
    rois = rois[:, 1:]
    img_w = features.shape[3]
    img_h = features.shape[2]
    x1 = (rois[:, 0] * spatial_scale) / img_w
    y1 = (rois[:, 1] * spatial_scale) / img_h
    x2 = (rois[:, 2] * spatial_scale) / img_w
    y2 = (rois[:, 3] * spatial_scale) / img_h

    boxes = tf.stack([y1, x1, y2, x2], axis=1)
    features = tf.transpose(features, [0, 2, 3, 1])
    crops = tf.image.crop_and_resize(features,
                                     boxes,
                                     box_indices=batch_ids,
                                     crop_size=output_size,
                                     method='bilinear')

    return tf.transpose(crops, [0, 3, 1, 2])


def get_type(Tensor):
    return Tensor.dtype


def count_nonzero(Tensor):
    return tf.math.count_nonzero(Tensor)