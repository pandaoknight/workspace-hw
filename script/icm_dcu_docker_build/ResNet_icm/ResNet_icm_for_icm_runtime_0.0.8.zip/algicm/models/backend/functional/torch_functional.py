import collections
import itertools
import numpy as np
import random
import torch
import torchvision
import torch.nn.functional as F
from contextlib import contextmanager
from ..utils.torch_utils import (
    _dtypeDict,
    preprocess_1d_format,
    preprocess_2d_format,
    preprocess_3d_format,
    nchw_to_nhwc,
    nhwc_to_nchw,
)
from itertools import repeat


def set_context(**kwargs):
    raise Exception("Using PyTorch backend,You don't need to set context")


def get_tensor_shape(x):
    return list(x.size())


# initializers
def zeros(shape, dtype=None, device=None):
    """
    Creates a tensor with all elements set to zero.

    Parameters
    ----------
    shape : A list of integers
        a tuple of integers, or a 1-D Tensor of type int32.
    dtype : tensor
        The DType of an element in the resulting Tensor

    Returns
    -------
        A Tensor with all elements set to zero.

    """
    # if device == "cpu":
    #     device = torch.device("cpu")
    # elif device == "gpu":
    #     device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    return torch.zeros(shape, dtype=dtype, device=device)


def ones(shape, dtype=None, device=None):
    """
    Creates a tensor with all elements set to ones.

    Parameters
    ----------
    shape : A list of integers
        a tuple of integers, or a 1-D Tensor of type int32.
    dtype : tensor
        The DType of an element in the resulting Tensor

    Returns
    -------
        A Tensor with all elements set to zero.

    """
    if device == "cpu":
        device = torch.device("cpu")
    elif device == "gpu":
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    return torch.ones(shape, dtype=dtype, device=device)


def constant(value, dtype=None, shape=None, device=None):
    """
    Creates a constant tensor from a tensor-like object.

    Parameters
    ----------
    value : int
        A constant value (or list) of output type dtype.
    dtype : tensor
         The type of the elements of the resulting tensor.
    shape : tuple
        Optional dimensions of resulting tensor.

    Returns
    -------
        A Constant Tensor.

    """
    # if device == 'cpu':
    #     device = torch.device('cpu')
    # elif device == 'gpu':
    #     device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    if isinstance(value, list):
        return torch.tensor(value, dtype=dtype, device=device)
    else:
        if shape == None:
            shape = 1
        w = torch.empty(shape, dtype=dtype, device=device)
        return torch.nn.init.constant_(w, value)


def compute_fans(shape):
    if len(shape) < 1:  # Just to avoid errors for constants.
        fan_in = fan_out = 1
    elif len(shape) == 1:
        fan_in = fan_out = shape[0]
    elif len(shape) == 2:
        fan_in = shape[0]
        fan_out = shape[1]
    else:
        receptive_field_size = 1
        for dim in shape[:-2]:
            receptive_field_size *= dim
        fan_in = shape[-2] * receptive_field_size
        fan_out = shape[-1] * receptive_field_size
    return int(fan_in), int(fan_out)


def random_uniform(shape, minval=0, maxval=1, dtype=None, seed=None):
    """
    Outputs random values from a uniform distribution.

    Parameters
    ----------
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    minval : int
        The lower bound on the range of random values to generate (inclusive). Defaults to 0.
    maxval : int
        The upper bound on the range of random values to generate (exclusive). Defaults to 1 if dtype is floating point.
    dtype : tensor
        The type of the output: float16, float32, float64, int32, or int64.
    seed : int
         Used in combination with tf.random.set_seed to create a reproducible sequence of tensors across multiple calls.
    Returns
    -------
        A tensor of the specified shape filled with random uniform values.

    """

    if seed is None:
        torch.random.seed()
    else:
        torch.random.manual_seed(seed)
    w = torch.randn(size=shape, dtype=dtype)
    out = w.uniform_(minval, maxval)
    return out


def random_normal(shape, mean=0.0, stddev=1.0, dtype=None, seed=None):
    """
    Outputs random values from a normal distribution.

    Parameters
    ----------
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    mean : float
        The mean of the normal distribution
    stddev : float
        The standard deviation of the normal distribution.
    dtype : tensor
        The type of the output.
    seed : A Python integer
         Used to create a random seed for the distribution

    Returns
    -------
        A tensor of the specified shape filled with random normal values.

    """

    if seed is None:
        torch.random.seed()
    else:
        torch.random.manual_seed(seed)
    w = torch.randn(size=shape, dtype=dtype)
    out = w.normal_(mean=mean, std=stddev)
    return out


def truncated_normal(shape, mean=0.0, stddev=1.0, dtype=None, seed=None):
    """
    Outputs random values from a truncated normal distribution.

    Parameters
    ----------
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    mean : float
        The mean of the normal distribution
    stddev : float
        The standard deviation of the normal distribution.
    dtype : tensor
        The type of the output.
    seed : A Python integer
         Used to create a random seed for the distribution

    Returns
    -------
        A tensor of the specified shape filled with random truncated normal values.

    """

    tensor = torch.empty(size=shape, dtype=dtype)
    out = torch.nn.init.trunc_normal_(tensor, mean=mean, std=stddev)
    return out


def kaiming_normal(shape,
                   a=0,
                   mode="fan_in",
                   nonlinearity="leaky_relu",
                   dtype=None,
                   seed=None):
    """
    He normal initializer.

    Parameters
    ----------
    seed : A Python integer.
        Used to seed the random generator.
    shape : tuple
        A 1-D integer Tensor or Python array. The shape of the output tensor.
    dtype : tensor
        The type of the output.

    Returns
    -------
        A tensor of the specified shape filled with he normal values.
    """

    tensor = torch.empty(size=shape, dtype=dtype)
    out = torch.nn.init.kaiming_normal_(tensor,
                                        a=a,
                                        mode=mode,
                                        nonlinearity=nonlinearity)
    return out


def kaiming_uniform(shape,
                    a=0,
                    mode="fan_in",
                    nonlinearity="leaky_relu",
                    dtype=None,
                    seed=None):
    tensor = torch.empty(size=shape, dtype=dtype)
    out = torch.nn.init.kaiming_uniform_(tensor,
                                         a=a,
                                         mode=mode,
                                         nonlinearity=nonlinearity)
    return out


def xavier_normal(shape, gain=1.0, dtype=None, seed=None):
    _tensor = torch.empty(size=shape, dtype=dtype)
    return torch.nn.init.xavier_normal_(_tensor, gain)


def xavier_uniform(shape, gain=1.0, dtype=None, seed=None):
    _tensor = torch.empty(size=shape, dtype=dtype)
    return torch.nn.init.xavier_uniform_(_tensor, gain)


def Variable(initial_value, name=None, trainable=True):
    """
    Creates a new variable with value initial_value.

    Parameters
    ----------
    initial_value : tensor
        A Tensor, or Python object convertible to a Tensor
    name : str
        Optional name for the variable. Defaults to 'Variable' and gets uniquified automatically.
    Returns
    -------
        Variable
    """
    return torch.nn.Parameter(data=initial_value, requires_grad=trainable)


def matmul(a, b, transpose_a=False, transpose_b=False):
    """
    Multiplies matrix a by matrix b, producing a * b.

    Parameters
    ----------
    a : tensor
         type float16, float32, float64, int32, complex64, complex128 and rank > 1.
    b : tensor
        with same type and rank as a.

    Returns
    -------
        A Tensor of the same type as a and b
    """
    if transpose_b:
        b = b.transpose(-1, -2)
    if transpose_a:
        a = a.transpose(-1, -2)
    return torch.matmul(a, b)


def add(value, bias):
    """
    Returns x + y element-wise.

    Parameters
    ----------
    value :  tensor.
        Must be one of the following types: bfloat16, half, float32, float64,
        uint8, int8, int16, int32, int64, complex64, complex128, string.
    bias : tensor
        Must have the same type as a

    Returns
    -------
        A Tensor. Has the same type as a.
    """
    return torch.add(value, bias)


def dtypes(dt):
    """
    Data dtypes.

    Parameters
    ----------
    dt : string
         It could be 'uint8', 'uint16', 'uint32', 'uint64', 'int8', 'int16',
         'int32', 'int64', 'float16', 'float32', 'float64', 'DType'.

    Returns
    -------
        Data dtypes
    """
    if dt not in _dtypeDict.keys():
        raise Exception("Unsupported dtype: {}".format(dt))
    return _dtypeDict[dt]


def minimum(x, y):
    """
    Returns the min of x and y (i.e. x < y ? x : y) element-wise.

    Parameters
    ----------
    x : tensor.
        Must be one of the following types: bfloat16, half, float32, float64, int32, int64.
    y : A Tensor.
        Must have the same type as x.

    Returns
    -------
        A Tensor. Has the same type as x
    """

    return torch.minimum(x, y)


def reshape(tensor, shape):
    """
    Reshapes a tensor.

    Parameters
    ----------
    tensor : tensor
        A Tensor.
    shape : tensor
         Defines the shape of the output tensor.
    Returns
    -------
        A Tensor. Has the same type as tensor
    """
    if isinstance(shape, int):
        shape = [shape]
    return torch.reshape(tensor, shape)


def concat(values, axis=0):
    """
    Concatenates tensors along one dimension.

    Parameters
    ----------
    values : list
         A list of Tensor objects or a single Tensor
    axis : int
        0-D int32 Tensor. Dimension along which to concatenate
    Returns
    -------
        A Tensor resulting from concatenation of the input tensors.
    """

    return torch.cat(values, axis)


def convert_to_tensor(value, dtype=None, device=None):
    """
    Converts the given value to a Tensor.

    Parameters
    ----------
    value : object
        An object whose type has a registered Tensor conversion function.
    dtype : optional
        Optional element type for the returned tensor. If missing, the type is inferred from the type of value.

    Returns
    -------
        A Tensor based on value.
    """
    if isinstance(dtype, str):
        dtype = _dtypeDict[dtype]
    if device == "cpu":
        device = torch.device("cpu")
    elif device == "gpu":
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if isinstance(value, torch.Tensor):
        return value.clone()
    else:
        return torch.tensor(value, dtype=dtype, device=device)


def convert_to_numpy(value):
    try:
        return value.numpy()
    except:
        return value.cpu().detach().numpy()


def sqrt(x):
    """
    Computes square root of x element-wise.

    Parameters
    ----------
    x : tensor
         Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.
    """
    return torch.sqrt(x)


def reduce_mean(input_tensor, axis=None, keepdims=False):
    """
    Computes the mean of elements across dimensions of a tensor.

    Parameters
    ----------
    input_tensor : tensor
        The tensor to reduce. Should have numeric type.
    axis : list
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(input_tensor), rank(input_tensor)).
    name : str
        A name for the operation (optional).

    Returns
    -------
        The reduced tensor.
    """

    if axis is not None:
        return torch.mean(input_tensor, dim=axis, keepdim=keepdims)
    else:
        return torch.mean(input_tensor)


def reduce_max(input_tensor, axis=None, keepdims=False):
    """
    Computes the maximum of elements across dimensions of a tensor.

    Parameters
    ----------
    input_tensor : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(input_tensor), rank(input_tensor)).
    name : str
        A name for the operation (optional).

    Returns
    -------
        The reduced tensor.
    """

    if axis is not None:
        return torch.max(input_tensor, dim=axis, keepdim=keepdims).values
    else:
        return torch.max(input_tensor)


def reduce_min(input_tensor, axis=None, keepdims=False):
    """
    Computes the minimum of elements across dimensions of a tensor.

    Parameters
    ----------
    input_tensor : tensor
        The tensor to reduce. Should have real numeric type.
    axis : int
        The dimensions to reduce. If None (the default), reduces all dimensions.
        Must be in the range [-rank(input_tensor), rank(input_tensor)).
    name : str
        A name for the operation (optional).

    Returns
    -------
        The reduced tensor.
    """

    if axis is not None:
        return torch.min(input_tensor, dim=axis, keepdim=keepdims).values
    else:
        return torch.min(input_tensor)


def pad(tensor, paddings, mode="CONSTANT", constant_values=0):
    """
    Pads a tensor.

    Parameters
    ----------
    tensor : tensor
        A Tensor.
    paddings : tensor
        A Tensor of type int32.
    mode : str
        One of "CONSTANT", "REFLECT", or "SYMMETRIC" (case-insensitive)
    constant_values : int
        In "CONSTANT" mode, the scalar pad value to use. Must be same type as tensor.

    Returns
    -------
        A Tensor. Has the same type as tensor.
    """

    if mode not in ["CONSTANT", "REFLECT", "SYMMETRIC"]:
        raise ValueError("Unsupported mode: {}".format(mode))
    outputs = F.pad(
        tensor,
        list(itertools.chain.from_iterable(paddings)),
        mode=mode,
        constant_values=constant_values,
    )
    return outputs


def stack(values, axis=0):
    """
    Stacks a list of rank-R tensors into one rank-(R+1) tensor.

    Parameters
    ----------
    values : list
        A list of Tensor objects with the same shape and type.
    axis : int
        An int. The axis to stack along. Defaults to the first dimension.
        Negative values wrap around, so the valid range is [-(R+1), R+1).

    Returns
    -------
        A stacked Tensor with the same type as values.
    """

    return torch.stack(values, dim=axis)


def meshgrid(*args, **kwargs):
    """
    Broadcasts parameters for evaluation on an N-D grid.

    Parameters
    ----------
    x : tensor
        Tensors with rank 1.
    y : tensor
        Tensors with rank 1.

    Returns
    -------
        A list of N Tensors with rank N.
    """

    return torch.meshgrid(*args)


def arange(start, limit=None, delta=1, dtype=None, device=None):
    """
    Creates a sequence of numbers.

    Parameters
    ----------
    start : tensor
        A 0-D Tensor (scalar). Acts as first entry in the range if limit is not None;
        otherwise, acts as range limit and first entry defaults to 0.
    limit : tensor
         A 0-D Tensor (scalar). Upper limit of sequence, exclusive. If None,
         defaults to the value of start while the first entry of the range defaults to 0.
    delta : tensor
        A 0-D Tensor (scalar). Number that increments start. Defaults to 1.
    dtype : None or dtype
        The type of the elements of the resulting tensor.

    Returns
    -------
        An 1-D Tensor of type dtype.
    """
    if limit == None and delta == 1 and dtype == None:
        return torch.arange(start, device=device)
    else:
        return torch.arange(start=start,
                            end=limit,
                            step=delta,
                            dtype=dtype,
                            device=device)


def expand_dims(input, axis):
    """
    Inserts a dimension of 1 into a tensor's shape.

    Parameters
    ----------
    input : tensor
        A Tensor.
    axis : int
        0-D (scalar). Specifies the dimension index at which to expand the shape of input.
        Must be in the range [-rank(input) - 1, rank(input)].

    Returns
    -------
        A Tensor with the same data as input, but its shape has an additional dimension of size 1 added.
    """

    return torch.unsqueeze(input, axis)


def tile(input, multiples):
    """
    Constructs a tensor by tiling a given tensor.

    Parameters
    ----------
    input : tensor
        A Tensor. 1-D or higher.
    multiples : tensor
        Must be one of the following types: int32, int64. 1-D.
        Length must be the same as the number of dimensions in input

    Returns
    -------
        A Tensor. Has the same type as input.
    """
    if type(multiples) == int:
        return torch.tile(input, (multiples, ))
    else:
        return torch.tile(input, multiples)


def cast(x, dtype=None):
    """
    Casts a tensor to a new type.

    Parameters
    ----------
    x : tensor
        A Tensor or SparseTensor or IndexedSlices of numeric type.
        It could be uint8, uint16, uint32, uint64, int8, int16, int32, int64, float16, float32, float64.
    dtype : dtpye
         The destination type. The list of supported dtypes is the same as x

    Returns
    -------
        A Tensor or SparseTensor or IndexedSlices with same shape as x and same type as dtype.
    """

    return x.type(dtype)


def transpose(a, perm=None, conjugate=False):
    """
    Transposes a.

    Parameters
    ----------
    a : tensor
        A Tensor.
    perm : list / int
        A permutation of the dimensions of a.
    conjugate : bool
        Setting it to True is mathematically equivalent to tf.math.conj(tf.transpose(input)).

    Returns
    -------
        A transposed Tensor.
    """
    if perm == None:
        if len(a.shape) <= 2:
            return torch.t(a)
        if len(a.shape) == 3:
            perm = [2, 1, 0]
        if len(a.shape) == 4:
            perm = [3, 2, 1, 0]
        if len(a.shape) == 5:
            perm = [4, 3, 2, 1, 0]
    out = torch.permute(a, perm)
    if conjugate:
        out = torch.conj_physical(out)
    return out


def gather_nd(params, indices, batch_dims=0):
    """
    Gather slices from params into a Tensor with shape specified by indices.

    Parameters
    ----------
    params : tensor
        The tensor from which to gather values.
    indices : tensor
        Must be one of the following types: int32, int64. Index tensor.
    batch_dims : int
        An integer or a scalar 'Tensor'. The number of batch dimensions.

    Returns
    -------
        A Tensor. Has the same type as params.
    """

    out_shape = indices.shape[:-1]
    indices = indices.unsqueeze(0).transpose(0, -1)
    ndim = indices.shape[0]
    indices = indices.long().to(params.device)
    idx = torch.zeros_like(indices[0], device=params.device).long()
    m = 1

    for i in range(ndim)[::-1]:
        idx += indices[i] * m
        m *= params.size(i)
    out = torch.take(params, idx)
    return out.view(out_shape)


def scatter_nd(indices, updates, shape):
    raise NotImplementedError


def clip_by_value(t, clip_value_min, clip_value_max):
    """
    Clips tensor values to a specified min and max.

    Parameters
    ----------
    t : tensor
        A Tensor or IndexedSlices
    clip_value_min : tensor
        A 0-D (scalar) Tensor, or a Tensor with the same shape as t. The minimum value to clip by
    clip_value_max : tensor
        A 0-D (scalar) Tensor, or a Tensor with the same shape as t. The minimum value to clip by

    Returns
    -------
        A clipped Tensor or IndexedSlices.
    """

    t_min = clip_value_min
    t_max = clip_value_max

    result = (t >= t_min) * t + (t < t_min) * t_min
    result = (result <= t_max) * result + (result > t_max) * t_max
    return result


def split(value, num_or_size_splits, axis=0):
    """
    Splits a tensor into sub tensors.

    Parameters
    ----------
    value : tensor
        The Tensor to split.
    num_or_size_splits : list
        Either an integer indicating the number of splits along split_dim or a 1-D integer Tensor or
        Python list containing the sizes of each output tensor along split_dim.
    axis : int
        The dimension along which to split. Must be in the range [-rank(value), rank(value)). Defaults to 0.
    num : int
        used to specify the number of outputs when it cannot be inferred from the shape of size_splits.

    Returns
    -------
        Tensor objects resulting from splitting value.
    """
    if isinstance(num_or_size_splits, int):
        nums = value.size(axis)
        if nums % num_or_size_splits != 0:
            raise ValueError(
                "Expected input_axis_nums % num_or_size_splits == 0, but received input_axis_nums % num_or_size_splits = 0"
            )
        else:
            num_or_size_splits = int(nums / num_or_size_splits)
    return torch.split(value, num_or_size_splits, dim=axis)


def floor(x):
    return torch.floor(x)


def gather(params, indices, axis=None):
    if not isinstance(indices, list):
        indices = indices.tolist()
    if axis is None:
        axis = 0
    if axis < 0:
        axis = len(params.shape) + axis
    if axis == 0:
        return params[indices]
    elif axis == 1:
        return params[:, indices]
    elif axis == 2:
        return params[:, :, indices]
    elif axis == 3:
        return params[:, :, :, indices]


def linspace(start, stop, num):
    return torch.linspace(start=start, end=stop, steps=num)


def slice(inputs, starts, sizes):
    ends = [starts[i] + sizes[i] for i in range(len(starts))]

    if len(inputs.shape) == 1:
        return inputs[starts[0]:ends[0]]
    if len(inputs.shape) == 2:
        return inputs[starts[0]:ends[0], starts[1]:ends[1]]
    if len(inputs.shape) == 3:
        return inputs[starts[0]:ends[0], starts[1]:ends[1], starts[2]:ends[2]]
    if len(inputs.shape) == 4:
        return inputs[starts[0]:ends[0], starts[1]:ends[1], starts[2]:ends[2],
                      starts[3]:ends[3], ]
    if len(inputs.shape) == 5:
        return inputs[starts[0]:ends[0], starts[1]:ends[1], starts[2]:ends[2],
                      starts[3]:ends[3], starts[4]:ends[4], ]


def add_n(inputs):
    a = inputs[0]
    for b in inputs[1:]:
        a += b
    return a


def resize(inputs,
           size=None,
           scale_factor=None,
           mode="bilinear",
           align_corners=False,
           data_format="channels_first"):
    if data_format == "channels_last":
        inputs = nhwc_to_nchw(inputs)

    outputs = F.interpolate(
        inputs,
        size=size,
        scale_factor=scale_factor,
        mode=mode,
        align_corners=align_corners,
    )
    if data_format == "channels_last":
        outputs = nchw_to_nhwc(outputs)
    return outputs


def ceil(x):
    return torch.ceil(x)


def multiply(x, y):
    return torch.multiply(x, y)


def divide(x, y):
    return torch.divide(x, y)


def identity(x):
    return torch.nn.Identity()(x)


def triu(data, diagonal=0):
    return torch.triu(data, diagonal)


def tril(data, diagonal=0):
    return torch.tril(data, diagonal)


def abs(x):
    return torch.abs(x)


def acos(x):
    return torch.acos(x)


def acosh(x):
    return torch.acosh(x)


def angle(x):
    return torch.angle(x)


def argmax(x, axis=None, keepdim=False, dtype="int64"):
    return torch.argmax(x, dim=axis, keepdim=keepdim)


def argmin(x, axis=None, dtype="int64"):
    return torch.argmin(x, dim=axis)


def asin(x):
    return torch.asin(x)


def asinh(x):
    return torch.asinh(x)


def atan(x):
    return torch.atan(x)


def atanh(x):
    return torch.atanh(x)


def cos(x):
    return torch.cos(x)


def cosh(x):
    return torch.cosh(x)


def count_nonzero(x, axis=None, keepdims=None, dtype="int64"):
    return torch.count_nonzero(x, dim=axis)


def cumprod(x, axis=0, exclusive=False, reverse=False):
    return torch.cumprod(x, dim=axis)


def cumsum(x, axis=0, exclusive=False, reverse=False):
    return torch.cumsum(x, dim=axis)


def equal(x, y):
    return torch.eq(x, y)


def exp(x):
    return torch.exp(x)


def floordiv(x, y):
    return torch.floor_divide(x, y)


def floormod(x, y):
    return torch.fmod(x, y)


def greater(x, y):
    return torch.greater(x, y)


def greater_equal(x, y):
    return torch.greater_equal(x, y)


def is_inf(x):
    return torch.isinf(x)


def is_nan(x):
    return torch.isnan(x)


def l2_normalize(x, axis=None, eps=1e-12):
    axis = 0 if axis is None else axis
    return F.normalize(x, p=2.0, dim=axis, eps=eps)


def less(x, y):
    return torch.less(x, y)


def less_equal(x, y):
    return torch.less_equal(x, y)


def log(x):
    return torch.log(x)


def log_sigmoid(x):
    return torch.log(1 / (1 + torch.exp(-x)))


def maximum(x, y):
    return torch.maximum(x, y)


def negative(x):
    return torch.negative(x)


def not_equal(x, y):
    return torch.not_equal(x, y)


def pow(x, y):
    return torch.pow(x, y)


def real(x):
    return torch.real(x)


def reciprocal(x):
    return torch.reciprocal(x)


def reduce_prod(x, axis=None, keepdims=False):
    if axis is not None:
        return torch.prod(x, dim=axis, keepdim=keepdims)
    else:
        return torch.prod(x)


def reduce_std(x, axis=None, keepdims=False):
    if axis is not None:
        return torch.std(x, dim=axis, keepdim=keepdims)
    else:
        return torch.std(x)


def reduce_sum(x, axis=None, keepdims=False):
    if axis is not None:
        return torch.sum(x, dim=axis, keepdim=keepdims)
    else:
        return torch.sum(x)


def reduce_variance(x, axis=None, keepdims=False):
    if axis is not None:
        return torch.var(x, dim=axis, keepdim=keepdims)
    else:
        return torch.var(x)


def round(x):
    return torch.round(x)


def rsqrt(x):
    return torch.rsqrt(x)


def segment_max(x, segment_ids):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    num_segments = len(torch.unique(segment_ids))
    return unsorted_segment_max(x, segment_ids, num_segments)


def segment_mean(x, segment_ids):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    num_segments = len(torch.unique(segment_ids))
    return unsorted_segment_mean(x, segment_ids, num_segments)


def segment_min(x, segment_ids):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    num_segments = len(torch.unique(segment_ids))
    return unsorted_segment_min(x, segment_ids, num_segments)


def segment_prod(x, segment_ids):
    raise NotImplementedError


def segment_sum(x, segment_ids):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    num_segments = len(torch.unique(segment_ids))
    return unsorted_segment_sum(x, segment_ids, num_segments)


def sigmoid(x):
    return torch.sigmoid(x)


def sign(x):
    return torch.sign(x)


def sin(x):
    return torch.sin(x)


def sinh(x):
    return torch.sinh(x)


def softplus(x):
    """
    Computes softplus: log(exp(features) + 1).

    Parameters
    ----------
    x : tensor
        Must be one of the following types: half, bfloat16, float32, float64.

    Returns
    -------
        A Tensor. Has the same type as features.
    """

    # Computes softplus: (1/b) * log(1 + exp(features*b)) ; b=1
    return F.softplus(x)


def square(x):
    return torch.square(x)


def squared_difference(x, y):
    return torch.square(x - y)


def subtract(x, y):
    return torch.subtract(x, y)


def tan(x):
    return torch.tan(x)


def tanh(x):
    """
    Computes hyperbolic tangent of x element-wise.

    Parameters
    ----------
    x : tensor
        Must be one of the following types: bfloat16, half, float32, float64, complex64, complex128.

    Returns
    -------
        A Tensor. Has the same type as x.
    """

    return torch.tanh(x)


def any(x, axis=None, keepdims=False):
    if axis is not None:
        return torch.any(x, dim=axis, keepdim=keepdims)
    else:
        return torch.any(x)


def all(x, axis=None, keepdims=False):
    if axis is not None:
        return torch.all(x, dim=axis, keepdim=keepdims)
    else:
        return torch.all(x)


def logical_and(x, y):
    return torch.logical_and(x, y)


def logical_or(x, y):
    return torch.logical_or(x, y)


def logical_not(x):
    return torch.logical_not(x)


def logical_xor(x, y):
    return torch.logical_xor(x, y)


def argsort(x, axis=-1, descending=False):
    return torch.argsort(x, dim=axis, descending=descending)


def bmm(x, y):
    return torch.bmm(x, y)


def where(condition, x, y):
    return torch.where(condition, x, y)


def ones_like(x, dtype=None):
    return torch.ones_like(x, dtype=dtype)


def zeros_like(x, dtype=None, requires_grad=False):
    return torch.zeros_like(x, dtype=dtype, requires_grad=requires_grad)


def squeeze(x, axis=None):
    return torch.squeeze(x, dim=axis)


def unsorted_segment_sum(x, segment_ids, num_segments):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    assert x.shape[0] == segment_ids.shape[
        0], "the length of segment_ids should be equal to data.shape[0]."
    if len(segment_ids.shape) == 1:
        s = torch.prod(torch.tensor(x.shape[1:])).to(torch.int32)
        segment_ids = segment_ids.repeat_interleave(s).view(
            segment_ids.shape[0], *x.shape[1:])

    assert x.shape == segment_ids.shape, "data.shape and segment_ids.shape should be equal"

    shape = [num_segments] + list(x.shape[1:])
    tensor = torch.zeros(*shape).to(x.dtype).scatter_add(0, segment_ids, x)
    return tensor


def unsorted_segment_mean(x, segment_ids, num_segments):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    assert x.shape[0] == segment_ids.shape[
        0], "the length of segment_ids should be equal to data.shape[0]."
    res = []
    for i in range(num_segments):
        mask_index = segment_ids == i
        if torch.any(mask_index):
            a = torch.mean(x[mask_index], 0)
            res.append(a)
        else:
            a = torch.zeros_like(x[0])
            res.append(a)
    if res[0].shape == [1]:
        return torch.concat(res, 0)
    else:
        return torch.stack(res, 0)


def unsorted_segment_min(x, segment_ids, num_segments):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    assert x.shape[0] == segment_ids.shape[
        0], "the length of segment_ids should be equal to data.shape[0]."
    res = []
    for i in range(num_segments):
        mask_index = segment_ids == i
        if torch.any(mask_index):
            res.append(torch.min(x[mask_index], 0)[0])
        else:
            a = torch.zeros_like(x[0])
            a.fill_(torch.tensor(float("inf")).to(a.dtype))
            res.append(a)
    if res[0].shape == [1]:
        return torch.concat(res, 0)
    else:
        return torch.stack(res, 0)


def unsorted_segment_max(x, segment_ids, num_segments):
    segment_ids = torch.tensor(segment_ids, dtype=torch.int64)
    assert x.shape[0] == segment_ids.shape[
        0], "the length of segment_ids should be equal to data.shape[0]."
    res = []
    for i in range(num_segments):
        mask_index = segment_ids == i
        if torch.any(mask_index):
            res.append(torch.max(x[mask_index], 0)[0])
        else:
            a = torch.zeros_like(x[0])
            a.fill_(torch.tensor(float("-inf")).to(a.dtype))
            res.append(a)
    if res[0].shape == [1]:
        return torch.concat(res, 0)
    else:
        return torch.stack(res, 0)


def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def is_tensor(x):
    return isinstance(x, torch.Tensor)


def tensor_scatter_nd_update(tensor, indices, updates, cls_loss=False):
    if len(indices[0]) == 1:
        tensor = tensor.clone()
        indices = torch.tensor(indices, dtype=torch.long)
        updates = updates.clone()
        indices = torch.flatten(indices)
        tensor[indices] = updates
    elif len(indices[0]) == 4:
        a, b, c, d = indices.T.type(torch.long)
        tensor[a, b, c, d] = updates
    elif cls_loss:
        a, b = indices.T.type(torch.long)
        tensor[a, b] = updates
    else:
        tensor = tensor.clone()
        indices = torch.tensor(indices, dtype=torch.long)
        updates = updates.clone()
        indices = indices[:, 1].unique()
        tensor[:, [indices[0], indices[1]]] = updates.reshape([-1, 2])
    return tensor


def diag(input, diagonal=0):
    return torch.diag(input, diagonal)


def mask_select(x, mask, axis=0):
    if axis is None:
        axis = 0
    if axis < 0:
        axis = len(x.shape) + axis
    if x.shape == mask.shape:
        return torch.masked_select(x, mask)
    if axis == 0:
        return x[mask]
    elif axis == 1:
        return x[:, mask]
    elif axis == 2:
        return x[:, :, mask]
    elif axis == 3:
        return x[:, :, :, mask]


def eye(n, m=None, dtype=None):
    if m is None:
        m = n
    return torch.eye(n=n, m=m, dtype=dtype)


def einsum(equation, *operands):
    return torch.einsum(equation, *operands)


def set_device(device="GPU", id=0):
    if device == "GPU":
        torch.set_default_tensor_type("torch.cuda.FloatTensor")
        torch.cuda.set_device(id)


def scatter_update(tensor, indices, updates):
    tensor = torch.tensor(tensor)
    indices = torch.tensor(indices, dtype=torch.long)
    updates = torch.tensor(updates)
    tensor[indices] = updates
    return tensor


def get_device():
    try:
        id = torch.cuda.current_device()
        device = "GPU:" + str(id)
        return device
    except:
        device = "CPU"
        return device


def to_device(tensor, device="cpu", id=0):
    # device = device.lower()
    if device == "GPU":
        device = "cuda" + ":" + str(id)
    tensor = tensor.detach().to(device)
    return tensor


def roll(input, shifts, dims=None):
    return torch.roll(input, shifts, dims)


def logsoftmax(input, dim=None):
    return F.log_softmax(input, dim)


def topk(input, k, dim=-1, largest=True, sorted=True):
    return torch.topk(input, k, dim, largest, sorted)


def numel(input):
    if isinstance(input, torch.Size):
        return torch.Size.numel(input)
    else:
        return torch.numel(input)


def histogram(input, bins=100, min=0, max=0, name=None):
    raise NotImplementedError


def flatten(x, start_axis=0, stop_axis=-1, name=None):
    raise NotImplementedError


def interpolate(
    x,
    size=None,
    scale_factor=None,
    mode="bilinear",
    align_corners=False,
    align_mode=0,
    data_format="NCHW",
    name=None,
):
    return F.interpolate(x, size=size, scale_factor=scale_factor, mode=mode)


def index_select(x, index, axis=0, name=None):
    raise NotImplementedError


def dot(x, y, name=None):
    raise NotImplementedError


def expand(x, shape):
    return x.expand(shape)


def expand_as(x, y):
    return torch.Tensor.expand_as(x, y)


def unique(Tensor):

    return torch.unique(Tensor)


def flip(x, axis):
    return torch.flip(x, axis)


def mv(x, vec):
    return torch.mv(x, vec)


def relu(x):
    """
    Computes rectified linear: max(features, 0).

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8, int16,
        int8, int64, bfloat16, uint16, half, uint32, uint64, qint8.

    Returns
    -------
        A Tensor. Has the same type as features.
    """

    return F.relu(x)


def elu(x, alpha=1.0):
    """
    Computes exponential linear: `exp(features) - 1` if < 0, `features` otherwise.

    See [Fast and Accurate Deep Network Learning by Exponential Linear Units (ELUs)
    ](http://arxiv.org/abs/1511.07289)

    Parameters
    ----------
    x : tensor
        Must be one of the following types: half, bfloat16, float32, float64.

    Returns
    -------
        A Tensor with the same type as features.
    """

    return F.elu(x, alpha=alpha)


def relu6(x):
    """
    Computes Rectified Linear 6: min(max(features, 0), 6).

    Parameters
    ----------
    x : tensor
        Must be one of the following types: float32, float64, int32, uint8, int16,
        int8, int64, bfloat16, uint16, half, uint32, uint64, qint8.

    Returns
    -------
        A Tensor with the same type as features.
    """

    return F.relu6(x)


def leaky_relu(x, negative_slope=0.01):
    """
    Compute the Leaky ReLU activation function.

    Parameters
    ----------
    x : tensor
        representing preactivation values. Must be one of the following types:
        float16, float32, float64, int32, int64.

    Returns
    -------
        The activation value.
    """

    return F.leaky_relu(x, negative_slope=negative_slope)


def sigmoid(x):
    """
    Computes sigmoid of x element-wise.

    Parameters
    ----------
    x : tensor
        A Tensor with type float16, float32, float64, complex64, or complex128.

    Returns
    -------
        A Tensor with the same type as x.
    """

    return torch.sigmoid(x)


def softmax(logits, axis=None):
    """
    Computes softmax activations.

    Parameters
    ----------
    logits : tensor
        Must be one of the following types: half, float32, float64.
    axis : int
        The dimension softmax would be performed on. The default is -1 which indicates the last dimension.

    Returns
    -------
        A Tensor. Has the same type and shape as logits.
    """

    return F.softmax(logits, axis)


def gelu(x, approximate=False):
    return F.gelu(x)


def bias_add(x, bias, data_format=None):
    """
    Adds bias to value.

    Parameters
    ----------
    x : tensor
        A Tensor with type float, double, int64, int32, uint8, int16, int8, complex64, or complex128.
    bias : tensor
        Must be the same type as value unless value is a quantized type,
        in which case a different quantized type may be used.
    data_format : A string.
        'N...C' and 'NC...' are supported.
    name : str
        A name for the operation (optional).
    Returns
    -------
        A Tensor with the same type as value.
    """

    # add_obj = BiasAdd(data_format=data_format)
    # return add_obj(x, bias)
    raise NotImplementedError


def conv1d(input, filters, stride, padding, data_format="NWC", dilations=None):
    """
    Computes a 1-D convolution given 3-D input and filter tensors.

    Parameters
    ----------
    input : tensor
        A 3D Tensor. Must be of type float16, float32, or float64
    filters : tensor
        A 3D Tensor. Must have the same type as input.
    stride : int of list
         An int or list of ints that has length 1 or 3. The number of entries by which the filter is moved right at each step.
    padding : string
         'SAME' or 'VALID'
    data_format : string
        An optional string from "NWC", "NCW". Defaults to "NWC", the data is stored in the order of
        [batch, in_width, in_channels]. The "NCW" format stores data as [batch, in_channels, in_width].
    dilations : int or list
        An int or list of ints that has length 1 or 3 which defaults to 1.
        The dilation factor for each dimension of input. If set to k > 1,
        there will be k-1 skipped cells between each filter element on that dimension.
        Dilations in the batch and depth dimensions must be 1.
    name : string
        A name for the operation (optional).
    Returns
    -------
        A Tensor. Has the same type as input.
    """
    raise NotImplementedError
    # return Conv1D(
    #     stride=stride, padding=padding, data_format=data_format, dilations=dilations
    # )(input, filters)


def same_padding(input, weight, strides, dilations):
    #                     H(in) + 2* padding[0] - dilation[0] * (Ksize[0] - 1) - 1
    # H(out) = = floor( --------------------------------------------------------------   + 1 )
    #                                        stride[0]
    if isinstance(weight, torch.Tensor):
        if len(input.shape) == 3:
            filter_rows = weight.size(2)
        if len(input.shape) == 4:
            filter_rows = weight.size(2)
            filter_cols = weight.size(3)
        elif len(input.shape) == 5:
            filter_rows = weight.size(2)
            filter_cols = weight.size(3)
            filter_depth = weight.size(4)
    else:
        if len(input.shape) == 3:
            filter_rows = weight[0]
        elif len(input.shape) == 4:
            filter_rows = weight[0]
            filter_cols = weight[1]
        elif len(input.shape) == 5:
            filter_rows = weight[0]
            filter_cols = weight[1]
            filter_depth = weight[2]

    if len(input.shape) == 3:
        input_rows = input.size(2)
        out_rows = (input_rows + strides - 1) // strides
        padding_rows = max(0, (out_rows - 1) * strides +
                           (filter_rows - 1) * dilations + 1 - input_rows)
        rows_odd = padding_rows % 2 != 0
        return rows_odd, padding_rows

    if len(input.shape) == 4:
        input_rows = input.size(2)
        input_cols = input.size(3)

        # filter_rows = weight.size(2)
        # filter_cols = weight.size(3)

        out_rows = (input_rows + strides[0] - 1) // strides[0]
        out_cols = (input_cols + strides[1] - 1) // strides[1]

        padding_rows = max(
            0,
            (out_rows - 1) * strides[0] + (filter_rows - 1) * dilations[0] +
            1 - input_rows,
        )
        padding_cols = max(
            0,
            (out_cols - 1) * strides[1] + (filter_cols - 1) * dilations[1] +
            1 - input_cols,
        )

        rows_odd = padding_rows % 2 != 0
        cols_odd = padding_cols % 2 != 0
        return rows_odd, cols_odd, padding_rows, padding_cols

    if len(input.shape) == 5:
        input_rows = input.size(2)
        input_cols = input.size(3)
        input_depth = input.size(4)

        # filter_rows = weight.size(2)
        # filter_cols = weight.size(3)
        # filter_depth = weight.size(4)

        out_rows = (input_rows + strides[0] - 1) // strides[0]
        out_cols = (input_cols + strides[1] - 1) // strides[1]
        out_depth = (input_depth + strides[2] - 1) // strides[2]

        padding_rows = max(
            0,
            (out_rows - 1) * strides[0] + (filter_rows - 1) * dilations[0] +
            1 - input_rows,
        )
        padding_cols = max(
            0,
            (out_cols - 1) * strides[1] + (filter_cols - 1) * dilations[1] +
            1 - input_cols,
        )
        padding_depth = max(
            0,
            (out_depth - 1) * strides[2] + (filter_depth - 1) * dilations[2] +
            1 - input_depth,
        )

        rows_odd = padding_rows % 2 != 0
        cols_odd = padding_cols % 2 != 0
        depth_odd = padding_depth % 2 != 0
        return rows_odd, cols_odd, depth_odd, padding_rows, padding_cols, padding_depth


def conv2d(input,
           filters,
           strides,
           padding,
           data_format="NHWC",
           dilations=None):
    """
    Computes a 2-D convolution given 4-D input and filters tensors.

    Parameters
    ----------
    input : tensor
        Must be one of the following types: half, bfloat16, float32, float64. A 4-D tensor.
        The dimension order is interpreted according to the value of data_format, see below for details.
    filters : tensor
         Must have the same type as input. A 4-D tensor of shape [filter_height, filter_width, in_channels, out_channels]
    strides : int of list
        The stride of the sliding window for each dimension of input. If a single value is given it is replicated in the H and W dimension.
        By default the N and C dimensions are set to 1. The dimension order is determined by the value of data_format, see below for details.
    padding : string
        "SAME" or "VALID"
    data_format : string
        "NHWC", "NCHW". Defaults to "NHWC".
    dilations : list or ints
        list of ints that has length 1, 2 or 4, defaults to 1. The dilation factor for each dimension ofinput.
    name : string
         A name for the operation (optional).

    Returns
    -------
        A Tensor. Has the same type as input.
    """

    if data_format == "NHWC":
        input = nhwc_to_nchw(input)

    output = F.conv2d(input,
                      filters,
                      stride=strides,
                      padding=padding,
                      dilation=dilations)

    if data_format == "NHWC":
        output = nchw_to_nhwc(output)
    return output


def conv3d(input,
           filters,
           strides,
           padding,
           data_format="NDHWC",
           dilations=None):
    """
    Computes a 3-D convolution given 5-D input and filters tensors.

    Parameters
    ----------
    input : tensor
        Must be one of the following types: half, bfloat16, float32, float64.
        Shape [batch, in_depth, in_height, in_width, in_channels].
    filters : tensor
        Must have the same type as input. Shape [filter_depth, filter_height, filter_width, in_channels, out_channels].
        in_channels must match between input and filters.
    strides : list of ints
        A list of ints that has length >= 5. 1-D tensor of length 5.
        The stride of the sliding window for each dimension of input.
        Must have strides[0] = strides[4] = 1.
    padding : string
        A string from: "SAME", "VALID". The type of padding algorithm to use.
    data_format : string
        An optional string from: "NDHWC", "NCDHW". Defaults to "NDHWC". The data format of the input and output data.
        With the default format "NDHWC", the data is stored in the order of: [batch, in_depth, in_height, in_width, in_channels].
        Alternatively, the format could be "NCDHW", the data storage order is: [batch, in_channels, in_depth, in_height, in_width].
    dilations : list of ints
        Defaults to [1, 1, 1, 1, 1]. 1-D tensor of length 5. The dilation factor for each dimension of input.
        If set to k > 1, there will be k-1 skipped cells between each filter element on that dimension.
        The dimension order is determined by the value of data_format, see above for details.
        Dilations in the batch and depth dimensions must be 1.
    name : string
        A name for the operation (optional).

    Returns
    -------
        A Tensor. Has the same type as input.
    """
    raise NotImplementedError
    # return Conv3D(
    #     strides=strides, padding=padding, data_format=data_format, dilations=dilations
    # )(input, filters)


def lrn(inputs, depth_radius, bias, alpha, beta):
    """
    Local Response Normalization.

    Parameters
    ----------
    inputs : tensor
        Must be one of the following types: half, bfloat16, float32. 4-D.
    depth_radius : int
        Defaults to 5. 0-D. Half-width of the 1-D normalization window.
    bias : float
        Defaults to 1. An offset (usually positive to avoid dividing by 0).
    alpha : float
        Defaults to 1. A scale factor, usually positive.
    beta : float
         Defaults to 0.5. An exponent.

    Returns
    -------
        A Tensor. Has the same type as input.
    """

    lrn_obj = torch.nn.LocalResponseNorm(size=depth_radius,
                                         alpha=alpha,
                                         beta=beta,
                                         k=bias)
    return lrn_obj(inputs)


def moments(x, axes, shift=None, keepdims=False):
    """
    Calculates the mean and variance of x.

    Parameters
    ----------
    x : tensor
        A Tensor
    axes : list or ints
        Axes along which to compute mean and variance.
    shift : int
        Not used in the current implementation.
    keepdims : bool
        produce moments with the same dimensionality as the input.

    Returns
    -------
        Two Tensor objects: mean and variance.
    """

    raise NotImplementedError


def max_pool(input, ksize, strides, padding, return_mask, data_format=None):
    """
    Performs the max pooling on the input.

    Parameters
    ----------
    input : tensor
        Tensor of rank N+2, of shape [batch_size] + input_spatial_shape + [num_channels] if data_format does not start
        with "NC" (default), or [batch_size, num_channels] + input_spatial_shape if data_format starts with "NC".
        Pooling happens over the spatial dimensions only.
    ksize : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The size of the window for each dimension of the input tensor.
    strides : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The stride of the sliding window for each dimension of the input tensor.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    name : string
        A name for the operation (optional).

    Returns
    -------
        A Tensor of format specified by data_format. The max pooled output tensor.
    """
    raise NotImplementedError
    # maxpool_obj = MaxPool(ksize, strides, padding, return_mask, data_format)
    # return maxpool_obj(input)


def max_pool1d(input,
               kernel_size,
               stride=None,
               padding=0,
               return_mask=False,
               data_format="NCL"):
    raise NotImplementedError
    # maxpool_obj = MaxPool(kernel_size, stride, padding, return_mask, data_format)
    # return maxpool_obj(input)


def max_pool2d(input,
               kernel_size,
               stride=None,
               padding=0,
               return_mask=False,
               data_format="NCHW"):
    return F.max_pool2d(input, kernel_size, stride)
    # maxpool_obj = MaxPool(kernel_size, stride, padding, return_mask, data_format)
    # return maxpool_obj(input)


def max_pool3d(input,
               kernel_size,
               stride=None,
               padding=0,
               return_mask=False,
               data_format="NCDHW"):
    raise NotImplementedError
    # maxpool_obj = MaxPool(kernel_size, stride, padding, return_mask, data_format)
    # return maxpool_obj(input)


def avg_pool(input, ksize, strides, padding):
    """
    Performs the avg pooling on the input.

    Parameters
    ----------
    input : tensor
        Tensor of rank N+2, of shape [batch_size] + input_spatial_shape + [num_channels]
        if data_format does not start with "NC" (default), or [batch_size, num_channels] + input_spatial_shape
        if data_format starts with "NC". Pooling happens over the spatial dimensions only.
    ksize : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The size of the window for each dimension of the input tensor.
    strides : int or list of ints
        An int or list of ints that has length 1, N or N+2.
        The stride of the sliding window for each dimension of the input tensor.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    name : string
        Optional name for the operation.

    Returns
    -------
        A Tensor of format specified by data_format. The average pooled output tensor.
    """
    raise NotImplementedError
    # avg_pool_obj = AvgPool(ksize, strides, padding)
    # return avg_pool_obj(input)


def avg_pool1d(input, kernel_size, stride=None, padding=0, data_format="NCL"):
    raise NotImplementedError
    # data_format, padding = preprocess_1d_format(data_format, padding)
    # avg_pool_obj = AvgPool(kernel_size, stride, padding, data_format)
    # return avg_pool_obj(input)


def avg_pool2d(input, kernel_size, stride=None, padding=0, data_format="NCHW"):
    raise NotImplementedError
    # data_format, padding = preprocess_2d_format(data_format, padding)
    # avg_pool_obj = AvgPool(kernel_size, stride, padding, data_format)
    # return avg_pool_obj(input)


def avg_pool3d(input,
               kernel_size,
               stride=None,
               padding=0,
               data_format="NCDHW"):
    raise NotImplementedError
    # data_format, padding = preprocess_3d_format(data_format, padding)
    # avg_pool_obj = AvgPool(kernel_size, stride, padding, data_format)
    # return avg_pool_obj(input)


def pool(
    input,
    window_shape,
    pooling_type,
    strides=None,
    padding="VALID",
    data_format=None,
    dilations=None,
    name=None,
):
    """
    Performs an N-D pooling operation.

    Parameters
    ----------
    input : tensor
        Tensor of rank N+2, of shape [batch_size] + input_spatial_shape + [num_channels]
        if data_format does not start with "NC" (default), or [batch_size, num_channels] + input_spatial_shape
        if data_format starts with "NC". Pooling happens over the spatial dimensions only.
    window_shape : int
        Sequence of N ints >= 1.
    pooling_type : string
        Specifies pooling operation, must be "AVG" or "MAX".
    strides : ints
        Sequence of N ints >= 1. Defaults to [1]*N. If any value of strides is > 1, then all values of dilation_rate must be 1.
    padding : string
        The padding algorithm, must be "SAME" or "VALID". Defaults to "SAME".
        See the "returns" section of tf.ops.convolution for details.
    data_format : string
        Specifies whether the channel dimension of the input and output is the last dimension (default, or if data_format does not start with "NC"),
        or the second dimension (if data_format starts with "NC").
        For N=1, the valid values are "NWC" (default) and "NCW". For N=2, the valid values are "NHWC" (default) and "NCHW".
        For N=3, the valid values are "NDHWC" (default) and "NCDHW".
    dilations : list of ints
        Dilation rate. List of N ints >= 1. Defaults to [1]*N. If any value of dilation_rate is > 1, then all values of strides must be 1.
    name : string
        Optional. Name of the op.

    Returns
    -------
        Tensor of rank N+2, of shape [batch_size] + output_spatial_shape + [num_channels]
    """
    raise NotImplementedError
    # if pooling_type in ["MAX", "max"]:
    #     pool_obj = MaxPool(window_shape, strides, padding, data_format)
    # elif pooling_type in ["AVG", "avg"]:
    #     pool_obj = AvgPool(window_shape, strides, padding, data_format)
    # else:
    #     raise ValueError("Unsupported pool_mode: " + str(pooling_type))

    # return pool_obj(input)


def depthwise_conv2d(input,
                     filter,
                     strides,
                     padding,
                     data_format=None,
                     dilations=None,
                     name=None):
    """
    Depthwise 2-D convolution.

    Parameters
    ----------
    input : tensor
        4-D with shape according to data_format.
    filter : tensor
        4-D with shape [filter_height, filter_width, in_channels, channel_multiplier].
    strides : list
        1-D of size 4. The stride of the sliding window for each dimension of input.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
        The data format for input. Either "NHWC" (default) or "NCHW".
    dilations : list
        1-D of size 2. The dilation rate in which we sample input values across the height and width dimensions in atrous convolution.
        If it is greater than 1, then all values of strides must be 1.
    name : string
        A name for this operation (optional).

    Returns
    -------
        A 4-D Tensor with shape according to data_format.
        E.g., for "NHWC" format, shape is [batch, out_height, out_width, in_channels * channel_multiplier].
    """
    raise NotImplementedError
    # depthwise_conv2d_obj = DepthwiseConv2d(strides, padding, data_format, dilations)
    # return depthwise_conv2d_obj(input, filter)


def same_padding_deconvolution(input, weight, strides, dilations):
    # H(out) = floor((H(in) - 1)*stride[0] - 2* padding[0] + dilation[0] * (ksize[0]-1) + 1)

    if isinstance(weight, torch.Tensor):
        if len(input.shape) == 3:
            filter_rows = weight.size(2)
        if len(input.shape) == 4:
            filter_rows = weight.size(2)
            filter_cols = weight.size(3)
        elif len(input.shape) == 5:
            filter_rows = weight.size(2)
            filter_cols = weight.size(3)
            filter_depth = weight.size(4)
    else:
        if len(input.shape) == 3:
            filter_rows = weight[0]
        elif len(input.shape) == 4:
            filter_rows = weight[0]
            filter_cols = weight[1]
        elif len(input.shape) == 5:
            filter_rows = weight[0]
            filter_cols = weight[1]
            filter_depth = weight[2]

    if len(input.shape) == 3:
        input_rows = input.size(2)
        out_rows = input_rows * strides - strides + 1
        padding_rows = max(0, (input_rows - 1) * strides +
                           (filter_rows - 1) * dilations + 1 - out_rows)
        rows_odd = padding_rows % 2 != 0
        return rows_odd, padding_rows

    if len(input.shape) == 4:
        input_rows = input.size(2)
        input_cols = input.size(3)

        out_rows = input_rows * strides[0] - strides[0] + 1
        out_cols = input_cols * strides[1] - strides[1] + 1

        padding_rows = max(
            0,
            (input_rows - 1) * strides[0] + (filter_rows - 1) * dilations[0] +
            1 - out_rows,
        )
        padding_cols = max(
            0,
            (input_cols - 1) * strides[1] + (filter_cols - 1) * dilations[1] +
            1 - out_cols,
        )

        rows_odd = padding_rows % 2 != 0
        cols_odd = padding_cols % 2 != 0
        return rows_odd, cols_odd, padding_rows, padding_cols

    if len(input.shape) == 5:
        input_rows = input.size(2)
        input_cols = input.size(3)
        input_depth = input.size(4)

        out_rows = input_rows * strides[0] - strides[0] + 1
        out_cols = input_cols * strides[1] - strides[1] + 1
        out_depth = input_depth * strides[2] - strides[2] + 1

        padding_rows = max(
            0,
            (input_rows - 1) * strides[0] + (filter_rows - 1) * dilations[0] +
            1 - out_rows,
        )
        padding_cols = max(
            0,
            (input_cols - 1) * strides[1] + (filter_cols - 1) * dilations[1] +
            1 - out_cols,
        )
        padding_depth = max(
            0,
            (input_depth - 1) * strides[2] +
            (filter_depth - 1) * dilations[2] + 1 - out_depth,
        )

        rows_odd = padding_rows % 2 != 0
        cols_odd = padding_cols % 2 != 0
        depth_odd = padding_depth % 2 != 0
        return rows_odd, cols_odd, depth_odd, padding_rows, padding_cols, padding_depth


def conv1d_transpose(
    input,
    filters,
    output_shape,
    strides,
    padding="SAME",
    data_format="NWC",
    dilations=None,
    name=None,
):
    """
    The transpose of conv1d.

    Parameters
    ----------
    input : tensor
        A 3-D Tensor of type float and shape [batch, in_width, in_channels]
        for NWC data format or [batch, in_channels, in_width] for NCW data format.
    filters : tensor
        A 3-D Tensor with the same type as value and shape [filter_width, output_channels, in_channels].
        filter's in_channels dimension must match that of value.
    output_shape : tensor
        A 1-D Tensor, containing three elements, representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1 or 3. The number of entries by which the filter is moved right at each step.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
        'NWC' and 'NCW' are supported.
    dilations : list
         An int or list of ints that has length 1 or 3 which defaults to 1.
         The dilation factor for each dimension of input. If set to k > 1,
         there will be k-1 skipped cells between each filter element on that dimension.
         Dilations in the batch and depth dimensions must be 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as value.
    """
    raise NotImplementedError
    # conv1d_transpose_obj = Conv1d_transpose(strides, padding, data_format, dilations)
    # return conv1d_transpose_obj(input, filters)


def _ntuple(n, name="parse"):

    def parse(x):
        if isinstance(x, collections.abc.Iterable):
            return tuple(x)
        return tuple(repeat(x, n))

    parse.__name__ = name
    return parse


_single = _ntuple(1, "_single")


def conv2d_transpose(
    x,
    weight,
    bias=None,
    stride=1,
    padding=0,
    output_padding=0,
    groups=1,
    dilation=1,
    data_format="NCHW",
    output_size=None,
):
    """
    The transpose of conv2d.

    Parameters
    ----------
    input : tensor
        A 4-D Tensor of type float and shape [batch, height, width, in_channels]
        for NHWC data format or [batch, in_channels, height, width] for NCHW data format.
    filters : tensor
        A 4-D Tensor with the same type as input and shape [height, width,
        output_channels, in_channels]. filter's in_channels dimension must match that of input.
    output_shape : tensor
        A 1-D Tensor representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1, 2 or 4. The stride of the sliding window for each dimension of input.
        If a single value is given it is replicated in the H and W dimension.
        By default the N and C dimensions are set to 0.
        The dimension order is determined by the value of data_format, see below for details.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
         'NHWC' and 'NCHW' are supported.
    dilations : list
        An int or list of ints that has length 1, 2 or 4, defaults to 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as input.
    """
    data_format, padding = preprocess_2d_format(data_format, padding)
    if isinstance(padding, str):
        raise ValueError("padding should be int or tuple of int.")

    def _output_padding(
        input,
        output_size,
        stride,
        padding,
        kernel_size,
        num_spatial_dims,
        dilation=None,
    ):
        if output_size is None:
            ret = _single(
                output_padding)  # converting to list if was not already
        else:
            has_batch_dim = input.dim() == num_spatial_dims + 2
            num_non_spatial_dims = 2 if has_batch_dim else 1
            if len(output_size) == num_non_spatial_dims + num_spatial_dims:
                output_size = output_size[num_non_spatial_dims:]
            if len(output_size) != num_spatial_dims:
                raise ValueError(
                    "ConvTranspose{}D: for {}D input, output_size must have {} or {} elements (got {})"
                    .format(
                        num_spatial_dims,
                        input.dim(),
                        num_spatial_dims,
                        num_non_spatial_dims + num_spatial_dims,
                        len(output_size),
                    ))

            min_sizes = []
            max_sizes = []
            for d in range(num_spatial_dims):
                dim_size = (
                    (input.size(d + num_non_spatial_dims) - 1) * stride[d] -
                    2 * padding[d] +
                    (dilation[d] if dilation is not None else 1) *
                    (kernel_size[d] - 1) + 1)
                min_sizes.append(dim_size)
                max_sizes.append(min_sizes[d] + stride[d] - 1)

            for i in range(len(output_size)):
                size = output_size[i]
                min_size = min_sizes[i]
                max_size = max_sizes[i]
                if size < min_size or size > max_size:
                    raise ValueError((
                        "requested an output size of {}, but valid sizes range "
                        "from {} to {} (for an input of {})").format(
                            output_size, min_sizes, max_sizes,
                            input.size()[2:]))

            res = []
            for d in range(num_spatial_dims):
                res.append(output_size[d] - min_sizes[d])

            ret = res
        return ret

    if data_format == "NHWC":
        x = nhwc_to_nchw(x)

    out_padding = _output_padding(x, output_size, stride, padding,
                                  weight.shape[2:], 2, dilation)
    out = F.conv_transpose2d(
        x,
        weight=weight,
        bias=bias,
        padding=padding,
        stride=stride,
        dilation=dilation,
        output_padding=out_padding,
        groups=groups,
    )
    if data_format == "NHWC":
        out = nchw_to_nhwc(out)
    return out


def conv3d_transpose(
    input,
    filters,
    output_shape,
    strides,
    padding="SAME",
    data_format="NDHWC",
    dilations=None,
    name=None,
):
    """
    The transpose of conv3d.

    Parameters
    ----------
    input : tensor
         A 5-D Tensor of type float and shape [batch, height, width, in_channels] for
         NHWC data format or [batch, in_channels, height, width] for NCHW data format.
    filters : tensor
        A 5-D Tensor with the same type as value and shape [height, width, output_channels, in_channels].
        filter's in_channels dimension must match that of value.
    output_shape : tensor
        A 1-D Tensor representing the output shape of the deconvolution op.
    strides : list
        An int or list of ints that has length 1, 3 or 5.
    padding : string
        'VALID' or 'SAME'. The padding algorithm. See the "returns" section of tf.ops.convolution for details.
    data_format : string
        'NDHWC' and 'NCDHW' are supported.
    dilations : list of ints
        An int or list of ints that has length 1, 3 or 5, defaults to 1.
    name : string
        Optional name for the returned tensor.

    Returns
    -------
        A Tensor with the same type as value.
    """
    raise NotImplementedError
    # data_format, padding = preprocess_3d_format(data_format, padding)
    # conv3d_transpose_obj = Conv3d_transpose(strides, padding, data_format, dilations)
    # return conv3d_transpose_obj(input, filters)


def _to_channel_first_bias(b):
    """Reshape [c] to [c, 1, 1]."""
    raise NotImplementedError


def _bias_scale(x, b, data_format):
    """The multiplication counter part of tf.nn.bias_add."""
    raise NotImplementedError


def _bias_add(x, b, data_format):
    """Alternative implementation of tf.nn.bias_add which is compatiable with tensorRT."""
    raise NotImplementedError


def batch_normalization(x,
                        mean,
                        variance,
                        offset,
                        scale,
                        variance_epsilon,
                        data_format,
                        name=None):
    """Data Format aware version of tf.nn.batch_normalization."""
    raise NotImplementedError


def adaptive_avg_pool1d(input, output_size):
    return F.adaptive_avg_pool1d(input, output_size)


def adaptive_avg_pool2d(input, output_size):
    return F.adaptive_avg_pool2d(input, output_size)


def adaptive_avg_pool3d(input, output_size):
    return F.adaptive_avg_pool3d(input, output_size)


def adaptive_max_pool1d(input, output_size, return_indices=False):
    return F.adaptive_max_pool1d(input, output_size, return_indices)


def adaptive_max_pool2d(input, output_size, return_indices=False):
    return F.adaptive_max_pool2d(input, output_size, return_indices)


def adaptive_max_pool3d(input, output_size, return_indices=False):
    return F.adaptive_max_pool3d(input, output_size, return_indices)


def prelu(input, weight, data_format):
    if data_format == "channels_last":
        input = nhwc_to_nchw(input)
    output = torch.prelu(input, weight)
    if data_format == "channels_last":
        output = nchw_to_nhwc(output)
    return output


def hardsigmoid(input):
    return torch.nn.functional.hardsigmoid(input)


def hardswish(input):
    return torch.nn.functional.hardswish(input)


def swish(input):
    return torch.sigmoid(input) * input


def linear(input, weight, bias=None):
    return torch.nn.functional.linear(input, weight, bias)


def unfold(input, kernel_size, dilation=1, padding=0, stride=1):
    return torch.nn.functional.unfold(input,
                                      kernel_size,
                                      stride=stride,
                                      padding=padding,
                                      dilation=dilation)


def reduce_loss(loss, reduction):
    """Reduce loss as specified.

    Args:
        loss (Tensor): Elementwise loss tensor.
        reduction (str): Options are "none", "mean" and "sum".

    Return:
        Tensor: Reduced loss tensor.
    """
    reduction_enum = F._Reduction.get_enum(reduction)
    # none: 0, elementwise_mean:1, sum: 2
    if reduction_enum == 0:
        return loss
    elif reduction_enum == 1:
        return loss.mean()
    elif reduction_enum == 2:
        return loss.sum()


def weight_reduce_loss(loss, weight=None, reduction="mean", avg_factor=None):
    """Apply element-wise weight and reduce loss.

    Args:
        loss (Tensor): Element-wise loss.
        weight (Tensor): Element-wise weights.
        reduction (str): Same as built-in losses of PyTorch.
        avg_factor (float): Average factor when computing the mean of losses.

    Returns:
        Tensor: Processed loss values.
    """
    # if weight is specified, apply element-wise weight
    if weight is not None:
        loss = loss * weight.float()

    # if avg_factor is not specified, just reduce the loss
    if avg_factor is None:
        loss = reduce_loss(loss, reduction)
    else:
        # if reduction is mean, then average the loss by avg_factor
        if reduction == "mean":
            eps = torch.finfo(torch.float32).eps
            loss = loss.sum() / (avg_factor + eps)
        # if reduction is 'none', then do nothing, otherwise raise an error
        elif reduction != "none":
            raise ValueError('avg_factor can not be used with reduction="sum"')
    return loss


def _expand_onehot_labels(labels, label_weights, label_channels, ignore_index):
    """Expand onehot labels to match the size of prediction."""
    bin_labels = labels.new_full((labels.size(0), label_channels), 0)
    valid_mask = (labels >= 0) & (labels != ignore_index)
    inds = torch.nonzero(valid_mask & (labels < label_channels),
                         as_tuple=False)

    if inds.numel() > 0:
        bin_labels[inds, labels[inds]] = 1

    valid_mask = valid_mask.view(-1, 1).expand(labels.size(0),
                                               label_channels).float()
    if label_weights is None:
        bin_label_weights = valid_mask
    else:
        bin_label_weights = label_weights.view(-1, 1).repeat(1, label_channels)
        bin_label_weights *= valid_mask

    return bin_labels, bin_label_weights, valid_mask


def binary_cross_entropy(
    pred,
    label,
    weight=None,
    reduction="mean",
    avg_factor=None,
    class_weight=None,
    ignore_index=-100,
    avg_non_ignore=False,
):
    """Calculate the binary CrossEntropy loss.

    Args:
        pred (torch.Tensor): The prediction with shape (N, 1) or (N, ).
            When the shape of pred is (N, 1), label will be expanded to
            one-hot format, and when the shape of pred is (N, ), label
            will not be expanded to one-hot format.
        label (torch.Tensor): The learning label of the prediction,
            with shape (N, ).
        weight (torch.Tensor, optional): Sample-wise loss weight.
        reduction (str, optional): The method used to reduce the loss.
            Options are "none", "mean" and "sum".
        avg_factor (int, optional): Average factor that is used to average
            the loss. Defaults to None.
        class_weight (list[float], optional): The weight for each class.
        ignore_index (int | None): The label index to be ignored.
            If None, it will be set to default value. Default: -100.
        avg_non_ignore (bool): The flag decides to whether the loss is
            only averaged over non-ignored targets. Default: False.

    Returns:
        torch.Tensor: The calculated loss.
    """
    # The default value of ignore_index is the same as F.cross_entropy
    ignore_index = -100 if ignore_index is None else ignore_index

    if pred.dim() != label.dim():
        label, weight, valid_mask = _expand_onehot_labels(
            label, weight, pred.size(-1), ignore_index)
    else:
        # should mask out the ignored elements
        valid_mask = ((label >= 0) & (label != ignore_index)).float()
        if weight is not None:
            # The inplace writing method will have a mismatched broadcast
            # shape error if the weight and valid_mask dimensions
            # are inconsistent such as (B,N,1) and (B,N,C).
            weight = weight * valid_mask
        else:
            weight = valid_mask

    # average loss over non-ignored elements
    if (avg_factor is None) and avg_non_ignore and reduction == "mean":
        avg_factor = valid_mask.sum().item()

    # weighted element-wise losses
    weight = weight.float()
    loss = F.binary_cross_entropy_with_logits(pred,
                                              label.float(),
                                              pos_weight=class_weight,
                                              reduction="none")
    # do the reduction for the weighted loss
    loss = weight_reduce_loss(loss,
                              weight,
                              reduction=reduction,
                              avg_factor=avg_factor)

    return loss


def mask_cross_entropy(
    pred,
    target,
    label,
    reduction="mean",
    avg_factor=None,
    class_weight=None,
    ignore_index=None,
    **kwargs,
):
    """Calculate the CrossEntropy loss for masks.

    Args:
        pred (torch.Tensor): The prediction with shape (N, C, *), C is the
            number of classes. The trailing * indicates arbitrary shape.
        target (torch.Tensor): The learning label of the prediction.
        label (torch.Tensor): ``label`` indicates the class label of the mask
            corresponding object. This will be used to select the mask in the
            of the class which the object belongs to when the mask prediction
            if not class-agnostic.
        reduction (str, optional): The method used to reduce the loss.
            Options are "none", "mean" and "sum".
        avg_factor (int, optional): Average factor that is used to average
            the loss. Defaults to None.
        class_weight (list[float], optional): The weight for each class.
        ignore_index (None): Placeholder, to be consistent with other loss.
            Default: None.

    Returns:
        torch.Tensor: The calculated loss

    Example:
        >>> N, C = 3, 11
        >>> H, W = 2, 2
        >>> pred = torch.randn(N, C, H, W) * 1000
        >>> target = torch.rand(N, H, W)
        >>> label = torch.randint(0, C, size=(N,))
        >>> reduction = 'mean'
        >>> avg_factor = None
        >>> class_weights = None
        >>> loss = mask_cross_entropy(pred, target, label, reduction,
        >>>                           avg_factor, class_weights)
        >>> assert loss.shape == (1,)
    """
    assert ignore_index is None, "BCE loss does not support ignore_index"
    # TODO: handle these two reserved arguments
    assert reduction == "mean" and avg_factor is None
    num_rois = pred.size()[0]
    inds = torch.arange(0, num_rois, dtype=torch.long, device=pred.device)
    pred_slice = pred[inds, label].squeeze(1)
    return F.binary_cross_entropy_with_logits(pred_slice,
                                              target,
                                              weight=class_weight,
                                              reduction="mean")[None]


def cross_entropy(
    pred,
    label,
    weight=None,
    reduction="mean",
    avg_factor=None,
    class_weight=None,
    ignore_index=-100,
    avg_non_ignore=False,
):
    """Calculate the CrossEntropy loss.

    Args:
        pred (torch.Tensor): The prediction with shape (N, C), C is the number
            of classes.
        label (torch.Tensor): The learning label of the prediction.
        weight (torch.Tensor, optional): Sample-wise loss weight.
        reduction (str, optional): The method used to reduce the loss.
        avg_factor (int, optional): Average factor that is used to average
            the loss. Defaults to None.
        class_weight (list[float], optional): The weight for each class.
        ignore_index (int | None): The label index to be ignored.
            If None, it will be set to default value. Default: -100.
        avg_non_ignore (bool): The flag decides to whether the loss is
            only averaged over non-ignored targets. Default: False.

    Returns:
        torch.Tensor: The calculated loss
    """
    # The default value of ignore_index is the same as F.cross_entropy
    ignore_index = -100 if ignore_index is None else ignore_index
    # element-wise losses
    loss = F.cross_entropy(pred,
                           label,
                           weight=class_weight,
                           reduction="none",
                           ignore_index=ignore_index)

    # average loss over non-ignored elements
    # pytorch's official cross_entropy average loss over non-ignored elements
    # refer to https://github.com/pytorch/pytorch/blob/56b43f4fec1f76953f15a627694d4bba34588969/torch/nn/functional.py#L2660  # noqa
    if (avg_factor is None) and avg_non_ignore and reduction == "mean":
        avg_factor = label.numel() - (label == ignore_index).sum().item()

    # apply weights and do the reduction
    if weight is not None:
        weight = weight.float()
    loss = weight_reduce_loss(loss,
                              weight=weight,
                              reduction=reduction,
                              avg_factor=avg_factor)

    return loss


def L1_Loss(pred, label, weight=None, reduction='mean', avg_factor=None):
    loss = F.l1_loss(pred, label, reduction="none")
    # apply weights and do the reduction
    if weight is not None:
        weight = weight.float()
    loss = weight_reduce_loss(loss,
                              weight=weight,
                              reduction=reduction,
                              avg_factor=avg_factor)
    return loss


@contextmanager
def no_grad():
    with torch.no_grad():
        yield


def new_full(input, size, fill_value, dtype=None):
    return torch.Tensor.new_full(input, size, fill_value, dtype=dtype)


def conver_dtype(input, dtype):
    return torch.Tensor.type(input, dtype=dtype)


def detach(input):
    return torch.Tensor.detach(input)


def repeat(input, repeats, axis=None):
    if isinstance(repeats, int):
        return torch.repeat_interleave(input, repeats, dim=axis)
    else:
        return torch.repeat_interleave(input, repeats[0])


def nonzero(input):
    return torch.nonzero(input)


def sort(input, descending=None):
    return torch.Tensor.sort(input, descending=descending)


def freeze_stages(m):
    for param in m.parameters():
        param.requires_grad = False


def move_to_device(model, device=None):
    if torch.cuda.is_available():
        return model.cuda()
    else:
        return model.cpu()


def convert_to_numpy(value):
    """Convert a value to numpy, handle cases of tensor.
    Args:
        value(any): Any type of value.

    Returns:
        np.ndarry type of value

    """
    if isinstance(value, np.ndarray):
        return value
    elif isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    else:
        try:
            return np.array(value)
        except Exception:
            raise TypeError(
                f"Expected type tf.Variable or tf.Tensor, but got type of {type(value)}"
            )


def fill_(tensor, value):
    tensor.fill_(value)


def logsumexp(tensor, axis=None, keep_dims=False):
    return torch.logsumexp(tensor, dim=axis, keepdim=keep_dims)


def item(Tensor):
    return torch.Tensor.item(Tensor)


def tolist(Tensor):
    return Tensor.tolist()


def log2(Tensor):
    return torch.log2(Tensor)


def contiguous(Tensor):
    return torch.Tensor.contiguous(Tensor)


def randperm(num):
    return torch.randperm(num)


def empty_like(Tensor):
    return torch.empty_like(Tensor)


def roi_align(input,
              boxes,
              output_size,
              spatial_scale: float = 1.0,
              sampling_ratio: int = -1,
              aligned: bool = False,
              img_metas=None):
    """
    Performs Region of Interest (RoI) Align operator with average pooling, as described in Mask R-CNN.

    Args:
        input (Tensor[N, C, H, W]): The input tensor, i.e. a batch with ``N`` elements. Each element
            contains ``C`` feature maps of dimensions ``H x W``.
            If the tensor is quantized, we expect a batch size of ``N == 1``.
        boxes (Tensor[K, 5] or List[Tensor[L, 4]]): the box coordinates in (x1, y1, x2, y2)
            format where the regions will be taken from.
            The coordinate must satisfy ``0 <= x1 < x2`` and ``0 <= y1 < y2``.
            If a single Tensor is passed, then the first column should
            contain the index of the corresponding element in the batch, i.e. a number in ``[0, N - 1]``.
            If a list of Tensors is passed, then each Tensor will correspond to the boxes for an element i
            in the batch.
        output_size (int or Tuple[int, int]): the size of the output (in bins or pixels) after the pooling
            is performed, as (height, width).
        spatial_scale (float): a scaling factor that maps the box coordinates to
            the input coordinates. For example, if your boxes are defined on the scale
            of a 224x224 image and your input is a 112x112 feature map (resulting from a 0.5x scaling of
            the original image), you'll want to set this to 0.5. Default: 1.0
        sampling_ratio (int): number of sampling points in the interpolation grid
            used to compute the output value of each pooled output bin. If > 0,
            then exactly ``sampling_ratio x sampling_ratio`` sampling points per bin are used. If
            <= 0, then an adaptive number of grid points are used (computed as
            ``ceil(roi_width / output_width)``, and likewise for height). Default: -1
        aligned (bool): If False, use the legacy implementation.
            If True, pixel shift the box coordinates it by -0.5 for a better alignment with the two
            neighboring pixel indices. This version is used in Detectron2

    Returns:
        Tensor[K, C, output_size[0], output_size[1]]: The pooled RoIs.
    """

    rois = boxes
    output_size = [7, 7]

    return torch.ops.torchvision.roi_align(input, rois, spatial_scale,
                                           output_size[0], output_size[1],
                                           sampling_ratio, aligned)


def get_type(Tensor):
    return Tensor.type()


def count_nonzero(Tensor):
    return torch.count_nonzero(Tensor)