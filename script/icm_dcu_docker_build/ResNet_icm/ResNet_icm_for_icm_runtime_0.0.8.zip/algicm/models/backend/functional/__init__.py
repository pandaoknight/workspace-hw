from algicm import BACKEND

if BACKEND == "tensorflow":
    from .tensorflow_functional import *
elif BACKEND == "torch":
    from .torch_functional import *
else:
    raise NotImplementedError("This backend is not supported")
