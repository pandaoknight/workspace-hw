import inspect
import tensorflow as tf
import tensorflow_addons as tfa
from tensorflow.python.ops import random_ops
from tensorflow.python.ops import stateless_random_ops


_dtypeDict = {
    "DType": tf.DType,
    "float16": tf.float16,
    "float32": tf.float32,
    "float64": tf.float64,
    "int8": tf.int8,
    "int16": tf.int16,
    "int32": tf.int32,
    "int64": tf.int64,
    "uint8": tf.uint8,
    "uint16": tf.uint16,
    "uint32": tf.uint32,
    "uint64": tf.uint64,
    "bool": tf.bool,
    "complex64": tf.complex64,
    "complex128": tf.complex128,
}


DType = tf.DType
float16 = tf.float16
float32 = tf.float32
float64 = tf.float64
int8 = tf.int8
int16 = tf.int16
int32 = tf.int32
int64 = tf.int64
uint8 = tf.uint8
uint16 = tf.uint16
uint32 = tf.uint32
uint64 = tf.uint64
bool = tf.bool
complex64 = tf.complex64
complex128 = tf.complex128
Tensor = (tf.Tensor,tf.Variable)

def padding_format(padding):
    """
    Checks that the padding format correspond format.

    Parameters
    ----------
    padding : str
        Must be one of the following:"same", "SAME", "VALID", "valid"

    Returns
    -------
        str "SAME" or "VALID"
    """

    if padding in ["SAME", "same"]:
        padding = "SAME"
    elif padding in ["VALID", "valid"]:
        padding = "VALID"
    elif padding == None:
        padding = None
    elif isinstance(padding, tuple) or isinstance(padding, int):
        return padding
    else:
        raise Exception("Unsupported padding: " + str(padding))
    return padding


def channel_format(data_format, dim="2d"):
    if dim == "1d":
        if data_format in ["channels_last", "NWC", "NLC"]:
            data_format = "NWC"
        elif data_format in ["channels_first", "NCW", "NCL"]:
            data_format = "NCW"
        elif data_format == None:
            data_format = None
        else:
            raise Exception("Unsupported data format: " + str(data_format))
    elif dim == "2d":
        if data_format in ["channels_last", "NHWC"]:
            data_format = "NHWC"
        elif data_format in ["channels_first", "NCHW"]:
            data_format = "NCHW"
        elif data_format == None:
            data_format = None
        else:
            raise Exception("Unsupported data format: " + str(data_format))
    elif dim == "3d":
        if data_format in ["channels_last", "NDHWC"]:
            data_format = "NDHWC"
        elif data_format in ["channels_first", "NCDHW"]:
            data_format = "NCDHW"
        elif data_format == None:
            data_format = None
        else:
            raise Exception("Unsupported data format: " + str(data_format))
    else:
        raise Exception("dim must be '1d', '2d', '3d'.")
    return data_format


def preprocess_padding(padding, dim="2d", data_format="NHWC"):
    # When explicit padding is used and data_format is "NHWC",
    # this should be in the form [[0, 0], [pad_top, pad_bottom],[pad_left, pad_right], [0, 0]].
    # When explicit padding used and data_format is "NCHW",
    # this should be in the form [[0, 0], [0, 0],[pad_top, pad_bottom], [pad_left, pad_right]].
    check_padding(padding, dim)
    if dim == "1d":
        if data_format == "NWC":
            out_padding = [[0, 0], [padding, padding], [0, 0]]
        else:
            out_padding = [[0, 0], [0, 0], [padding, padding]]
    elif dim == "2d":
        if isinstance(padding, int):
            if data_format == "NHWC":
                out_padding = [[0, 0], [padding, padding], [padding, padding], [0, 0]]
            else:
                out_padding = [[0, 0], [0, 0], [padding, padding], [padding, padding]]
        elif isinstance(padding, tuple):
            if data_format == "NHWC":
                out_padding = [
                    [0, 0],
                    [padding[0], padding[0]],
                    [padding[1], padding[1]],
                    [0, 0],
                ]
            else:
                out_padding = [
                    [0, 0],
                    [0, 0],
                    [padding[0], padding[0]],
                    [padding[1], padding[1]],
                ]
    elif dim == "3d":
        if isinstance(padding, int):
            if data_format == "NDHWC":
                out_padding = [
                    [0, 0],
                    [padding, padding],
                    [padding, padding],
                    [padding, padding],
                    [0, 0],
                ]
            else:
                out_padding = [
                    [0, 0],
                    [0, 0],
                    [padding, padding],
                    [padding, padding],
                    [padding, padding],
                ]
        elif isinstance(padding, tuple):
            if data_format == "NDHWC":
                out_padding = [
                    [0, 0],
                    [padding[0], padding[0]],
                    [padding[1], padding[1]],
                    [padding[2], padding[2]],
                    [0, 0],
                ]
            else:
                out_padding = [
                    [0, 0],
                    [0, 0],
                    [padding[0], padding[0]],
                    [padding[1], padding[1]],
                    [padding[2], padding[2]],
                ]
    else:
        raise RuntimeError("Unsupported input dimensions.")
    return out_padding


def check_padding(padding, dim="2d"):
    if dim == "1d" and isinstance(object, tuple):
        raise RuntimeError(
            "expected padding to be a single integer value or a list of 1 values to match the convolution dimensions."
        )
    if dim == "2d" and isinstance(object, tuple) and len(padding) > 2:
        raise RuntimeError(
            "expected padding to be a single integer value or a list of 2 values to match the convolution dimensions."
        )
    if dim == "3d" and isinstance(object, tuple) and len(padding) > 3:
        raise RuntimeError(
            "expected padding to be a single integer value or a list of 3 values to match the convolution dimensions."
        )


def preprocess_1d_format(data_format, padding):
    """
    Checks that the 1-D dataformat format correspond format.

    Parameters
    ----------
    data_format : str
        Must be one of the following:"channels_last","NWC","NCW","channels_first"
    padding : str
        Must be one of the following:"same","valid","SAME","VALID"

    Returns
    -------
        str "NWC" or "NCW" and "SAME" or "VALID"
    """
    data_format = channel_format(data_format, dim="1d")
    padding = padding_format(padding)
    return data_format, padding


def preprocess_2d_format(data_format, padding):
    """
    Checks that the 2-D dataformat format correspond format.

    Parameters
    ----------
    data_format : str
        Must be one of the following:"channels_last","NHWC","NCHW","channels_first"
    padding : str
        Must be one of the following:"same","valid","SAME","VALID"

    Returns
    -------
        str "NHWC" or "NCHW" and "SAME" or "VALID"
    """

    data_format = channel_format(data_format, dim="2d")
    padding = padding_format(padding)
    return data_format, padding


def preprocess_3d_format(data_format, padding):
    """
    Checks that the 3-D dataformat format correspond format.

    Parameters
    ----------
    data_format : str
        Must be one of the following:"channels_last","NDHWC","NCDHW","channels_first"
    padding : str
        Must be one of the following:"same","valid","SAME","VALID"

    Returns
    -------
        str "NDHWC" or "NCDHW" and "SAME" or "VALID"
    """

    data_format = channel_format(data_format, dim="3d")
    padding = padding_format(padding)
    return data_format, padding


def nchw_to_nhwc(x):
    """
    Channels first to channels last

    Parameters
    ----------
    x : tensor
        channels first tensor data

    Returns
    -------
        channels last tensor data
    """

    if len(x.shape) == 3:
        x = tf.transpose(x, (0, 2, 1))
    elif len(x.shape) == 4:
        x = tf.transpose(x, (0, 2, 3, 1))
    elif len(x.shape) == 5:
        x = tf.transpose(x, (0, 2, 3, 4, 1))
    else:
        raise Exception("Unsupported dimensions")
    return x


def nhwc_to_nchw(x):
    """
    Channles last to channels first

    Parameters
    ----------
    x : tensor
        channels last tensor data

    Returns
    -------
        channels first tensor data
    """

    if len(x.shape) == 3:
        x = tf.transpose(x, (0, 2, 1))
    elif len(x.shape) == 4:
        x = tf.transpose(x, (0, 3, 1, 2))
    elif len(x.shape) == 5:
        x = tf.transpose(x, (0, 4, 1, 2, 3))
    else:
        raise Exception("Unsupported dimensions")
    return x


class _RandomGenerator(object):
    def __init__(self, seed=None):
        super(_RandomGenerator, self).__init__()
        if seed is not None:
            self.seed = [seed, 0]
        else:
            self.seed = None

    def random_normal(self, shape, mean=0.0, stddev=1, dtype=tf.float32):
        if self.seed:
            op = stateless_random_ops.stateless_random_normal
        else:
            op = random_ops.random_normal
        return op(shape=shape, mean=mean, stddev=stddev, dtype=dtype, seed=self.seed)

    def random_uniform(self, shape, minval, maxval, dtype):
        if self.seed:
            op = stateless_random_ops.stateless_random_uniform
        else:
            op = random_ops.random_uniform
        return op(
            shape=shape, minval=minval, maxval=maxval, dtype=dtype, seed=self.seed
        )

    def truncated_normal(self, shape, mean, stddev, dtype):
        if self.seed:
            op = stateless_random_ops.stateless_truncated_normal
        else:
            op = random_ops.truncated_normal
        return op(shape=shape, mean=mean, stddev=stddev, dtype=dtype, seed=self.seed)


def infer_abbr(class_type):
    """Infer abbreviation from the class name.

    When we build a norm layer with `build_norm_layer()`, we want to preserve
    the norm type in variable names, e.g, self.bn1, self.gn. This method will
    infer the abbreviation to map class types to abbreviations.

    Rule 1: If the class has the property "_abbr_", return the property.
    Rule 2: If the parent class is _BatchNorm, GroupNorm, LayerNorm or
    InstanceNorm, the abbreviation of this layer will be "bn", "gn", "ln" and
    "in" respectively.
    Rule 3: If the class name contains "batch", "group", "layer" or "instance",
    the abbreviation of this layer will be "bn", "gn", "ln" and "in"
    respectively.
    Rule 4: Otherwise, the abbreviation falls back to "norm".

    Args:
        class_type (type): The norm layer type.

    Returns:
        str: The inferred abbreviation.
    """
    if not inspect.isclass(class_type):
        raise TypeError(f"class_type must be a type, but got {type(class_type)}")
    if hasattr(class_type, "_abbr_"):
        return class_type._abbr_
    if issubclass(
        class_type, tfa.layers.InstanceNormalization
    ):  # IN is a subclass of BN
        return "in"
    elif issubclass(class_type, tf.keras.layers.BatchNormalization):
        return "bn"
    elif issubclass(class_type, tfa.layers.GroupNormalization):
        return "gn"
    elif issubclass(class_type, tf.keras.layers.LayerNormalization):
        return "ln"
    else:
        class_name = class_type.__name__.lower()
        if "batch" in class_name:
            return "bn"
        elif "group" in class_name:
            return "gn"
        elif "layer" in class_name:
            return "ln"
        elif "instance" in class_name:
            return "in"
        else:
            return "norm_layer"


def check_tensor():
  def func(input_):
          return tf.Variable(input_)

  return func