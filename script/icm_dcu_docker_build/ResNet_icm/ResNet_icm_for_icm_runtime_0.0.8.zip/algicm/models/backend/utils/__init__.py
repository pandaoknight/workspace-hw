from algicm import BACKEND

if BACKEND == "tensorflow":
    from .tensorflow_utils import *
elif BACKEND == "torch":
    from .torch_utils import *
else:
    raise NotImplementedError("This backend is not supported")
