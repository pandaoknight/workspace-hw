from algicm import BACKEND

if BACKEND == "tensorflow":
    from .functional.tensorflow_functional import *
    from .nn.tensorflow_nn import *
    from .utils.tensorflow_utils import *
    from .core.tensorflow import *
elif BACKEND == "torch":
    from .functional.torch_functional import *
    from .nn.torch_nn import *
    from .utils.torch_utils import *
    from .core.pytorch import *
# elif BACKEND == "mindspore":
#     from .mindspore_backend import *
#     from .mindspore_nn import *
#     import mindspore as ms

#     BACKEND_VERSION = ms.__version__
#     # set context
#     import mindspore.context as context
#     import os

#     os.environ["DEVICE_ID"] = "0"
#     context.set_context(mode=context.PYNATIVE_MODE),
#     # context.set_context(mode=context.PYNATIVE_MODE, device_target='CPU'),
#     # enable_task_sink=True, enable_loop_sink=True)
#     # context.set_context(mode=context.PYNATIVE_MODE, device_target='Ascend')
#     sys.stderr.write("Using MindSpore backend.\n")

# elif BACKEND == "paddle":
#     from .paddle_backend import *
#     from .paddle_nn import *
#     import paddle as pd

#     BACKEND_VERSION = pd.__version__
#     sys.stderr.write("Using Paddle backend.\n")

# elif BACKEND == "oneflow":
#     from .oneflow_nn import *
#     from .oneflow_backend import *
#     import oneflow as flow

#     BACKEND_VERSION = flow.__version__

#     sys.stderr.write("Using OneFlow backend.\n")
else:
    raise NotImplementedError("This backend is not supported")
