import logging
import torch
import torch.nn as nn
import numpy as np

from typing import Mapping, Sequence
from algicm.registry.common import MODELS
from algicm.utils import Logger
from algicm.transform.transform import Compose


@MODELS.register_module()
class BaseDataProcessor(nn.Module):
    """Base data pre-processor used for copying data to the target device.

    Subclasses inherit from ``BaseDataPreprocessor`` could override the
    forward method to implement custom data pre-processing, such as
    batch-resize, MixUp, or CutMix.

    Args:
        non_blocking (bool): Whether block current process
            when transferring data to device.
            New in version 0.3.0.

    Note:
        Data dictionary returned by dataloader must be a dict and at least
        contain the ``inputs`` key.
    """

    def __init__(
        self,
        batch_preprocess=[],
        non_blocking=False,
    ):
        super().__init__()
        self.batch_preprocess = Compose(batch_preprocess)
        self._non_blocking = non_blocking
        self._device = torch.device("cpu")
        self.logger = Logger.get_current_instance()

    def cast_data(self, data):
        """Copying data to the target device.

        Args:
            data (dict): Data returned by ``DataLoader``.

        Returns:
            CollatedResult: Inputs and data sample at target device.
        """
        if isinstance(data, Mapping):
            return {key: self.cast_data(data[key]) for key in data}
        elif isinstance(data, (str, bytes)) or data is None:
            return data
        elif isinstance(data, tuple) and hasattr(data, "_fields"):
            # namedtuple
            return type(data)(*(self.cast_data(sample) for sample in data))  # type: ignore  # noqa: E501  # yapf:disable
        elif isinstance(data, Sequence):
            return type(data)(self.cast_data(sample) for sample in data)  # type: ignore  # noqa: E501  # yapf:disable
        elif isinstance(data, torch.Tensor):
            return data.to(self.device, non_blocking=self._non_blocking)
        elif isinstance(data, np.ndarray):
            try:
                data = torch.from_numpy(data)

            except Exception as e:
                self.logger.log_msg(
                    f"try to convert dtype of {data.dtype} ndarry to tensor, but got error {e}",
                    level="ERROR",
                )
            return data.to(self.device, non_blocking=self._non_blocking)
        else:
            return data

    def forward(self, data, training=False):
        """Preprocesses the data into the model input format.

        After the data pre-processing of :meth:`cast_data`, ``forward``
        will stack the input tensor list to a batch tensor at the first
        dimension.

        Args:
            data (dict): Data returned by dataloader
            training (bool): Whether to enable training time augmentation.

        Returns:
            dict or list: Data in the same format as the model input.
        """

        data = self.batch_preprocess(data)
        data = self.cast_data(data)
        return data  # type: ignore

    @property
    def device(self):
        return self._device

    def to(self, *args, **kwargs) -> nn.Module:
        """Overrides this method to set the :attr:`device`

        Returns:
            nn.Module: The model itself.
        """
        device = torch._C._nn._parse_to(*args, **kwargs)[0]
        if device is not None:
            self._device = torch.device(device)
        return super().to(*args, **kwargs)

    def cuda(self, *args, **kwargs) -> nn.Module:
        """Overrides this method to set the :attr:`device`

        Returns:
            nn.Module: The model itself.
        """
        self._device = torch.device(torch.cuda.current_device())
        return super().cuda()

    def cpu(self, *args, **kwargs) -> nn.Module:
        """Overrides this method to set the :attr:`device`

        Returns:
            nn.Module: The model itself.
        """
        self._device = torch.device("cpu")
        return super().cpu()
