# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/9/21
import os.path

import numpy as np
import h5py
import numbers
import pickle
import tensorflow as tf
from collections import OrderedDict


def _recursive_save(data, name, f):
    """
    Args:
        data:  python regular object data need to be store.
               support int, float, str, bytes, dict, list, ndarray
        name: name of the first level of h5 file, need to be modified future
        f:  h5py.File
    Returns: None, all data store in  object 'f'

    """
    if data is None:
        return

    if isinstance(data, dict):
        gf = f.create_group(name)
        gf.attrs["type"] = "OrderedDict" if isinstance(data,
                                                       OrderedDict) else "dict"
        for k, v in data.items():
            _recursive_save(v, k, gf)
    elif isinstance(data, (list, tuple)):
        gf = f.create_group(name)
        gf.attrs["type"] = "list" if isinstance(data, list) else "tuple"
        for i, elem in enumerate(data):
            _recursive_save(elem, str(i), gf)
    elif isinstance(data, (numbers.Number, str, bytes)):
        if "/" in name:
            name_split = name.split("/")

            for index, name_ in enumerate(name_split):
                if index == len(name_split) - 1:
                    continue
                if len(name_split) > 2:
                    if name_ not in f.keys() and len(f.keys()) <= 1:
                        gf = f.create_group(name_)
                        gf.attrs["type"] = "tmp"
                    else:
                        gf = gf.create_group(name_)
                        gf.attrs["type"] = "tmp"
                else:
                    if name_ not in f.keys():
                        gf = f.create_group(name_)
                        gf.attrs["type"] = "tmp"

        number_dset = f.create_dataset(name, data=data)
        number_dset.attrs["type"] = type(data).__name__
    elif isinstance(data, (np.ndarray, tf.Tensor, tf.Variable)):
        if isinstance(data, (tf.Tensor, tf.Variable)):
            data_ = data.numpy()
        else:
            data_ = data
        name = data.name
        if "/" in name:
            name_split = name.split("/")

            for index, name_ in enumerate(name_split):
                if index == len(name_split) - 1:
                    continue
                if len(name_split) > 2:
                    if name_ not in f.keys() and len(f.keys()) <= 1:
                        gf = f.create_group(name_)
                        gf.attrs["type"] = "tmp"
                    else:
                        gf = gf.create_group(name_)
                        gf.attrs["type"] = "tmp"
                else:
                    if name_ not in f.keys():
                        gf = f.create_group(name_)
                        gf.attrs["type"] = "tmp"

        param_dset = f.create_dataset(name, data_.shape, dtype=data_.dtype)
        param_dset.attrs["type"] = type(data_).__name__
        if not data_.shape:
            # scalar
            param_dset[()] = data_
        else:
            param_dset[:] = data_
    else:
        # try to dump with pickle
        try:
            if "/" in name:
                name_split = name.split("/")

                for index, name_ in enumerate(name_split):
                    if index == len(name_split) - 1:
                        continue
                if len(name_split) > 2:
                    if name_ not in f.keys() and len(f.keys()) <= 1:
                        gf = f.create_group(name_)
                        gf.attrs["type"] = "tmp"
                    else:
                        gf = gf.create_group(name_)
                        gf.attrs["type"] = "tmp"
                else:
                    if name_ not in f.keys():
                        gf = f.create_group(name_)
                        gf.attrs["type"] = "tmp"

            pickle_dset = f.create_dataset(name, data=str(pickle.dumps(data)))
            pickle_dset.attrs["type"] = "pickle"
        except Exception as e:
            raise TypeError(
                f"h5 only support type dict, list, tuple, integer, str, bytes, Tensor, Variable "
                f"and hashable object but got type {type(data)}"
                f"with error {e}")


def save_checkpoint(checkpoint, filepath, backend_args):
    """
    Args:
        checkpoint: dict or Orderdict of the data
        filepath: file end with h5
        backend_args: Not used here

    Returns: None

    """
    try:
        # remove first
        if os.path.exists(filepath):
            os.remove(filepath)
        with open(filepath, "wb") as f:
            pickle.dump(checkpoint, f)

        # f = h5py.File(filepath, mode="w")
        # _recursive_save(checkpoint, "model", f)

    except Exception as e:
        raise RuntimeError(f"Some error happens in saving checkpoint, {e}")
    finally:
        f.close()


def _recursive_load(f):
    if isinstance(f, h5py.File) and isinstance(f, h5py.Group):
        v_type = "dict"
    else:
        v_type = f.attrs["type"] if "type" in f.attrs else False

    if not v_type:
        raise ValueError("v_type should be specified in data")

    if isinstance(f, h5py.Group):
        if v_type in ["dict", "OrderedDict"]:
            data = OrderedDict() if v_type == "OrderedDict" else {}
            for dict_k in f.keys():
                dict_v = _recursive_load(f[dict_k])
                data[dict_k] = dict_v
        elif v_type in ["list", "tuple"]:
            data = []
            for dict_k in f.keys():
                dict_v = _recursive_load(f[dict_k])
                if isinstance(dict_v, np.ndarray):
                    dict_ = {}
                    dict_[dict_k] = dict_v
                    data.append(dict_)
                else:
                    data.append(dict_v)
            if v_type == "tuple":
                data = tuple(data)
        elif v_type in ["tmp"]:
            data = OrderedDict() if v_type == "OrderedDict" else {}
            for dict_k in f.keys():
                dict_v = _recursive_load(f[dict_k])
                fname = f.name.split("/")[-1]
                data[fname + "/" + dict_k] = dict_v
        else:
            raise ValueError(
                f"Group only support dict, list, but got type {v_type}")
    elif isinstance(f, h5py.Dataset):
        v_type = f.attrs["type"] if "type" in f.attrs else False
        if not v_type:
            raise ValueError("v_type should be specified in data")

        if v_type in ["int", "float", "bytes", "bool", "float64"]:
            data = f[()]
        elif v_type == "str":
            data = str(f[()])
        elif v_type == "ndarray":
            # scalar of ndarray
            if not f.shape:
                data = f[()]
            else:
                data = f[:]
        elif v_type == "pickle":
            data = pickle.loads(eval(f[()]))
        else:
            raise ValueError(
                f"Dataset only support int, float, bytes, str, ndarray, but got type {v_type}"
            )

    else:
        raise RuntimeError(
            f"Expected type Group or Dataset, but got type {type(f)}")
    return data


def load_checkpoint(filename, map_location="cpu"):
    try:
        with open(filename, "rb") as fp:
            ckpt = pickle.load(fp)

        # f = h5py.File(filename, mode="r")
        # ckpt = _recursive_load(f)["model"]
        return ckpt
    except Exception as e:
        raise RuntimeError(f"Some error happens in loading checkpoint, {e}")
    # finally:
    #     f.close()


def _load_checkpoint_to_model(model,
                              checkpoint,
                              strict=False,
                              revise_keys=None,
                              logger=None):
    if isinstance(checkpoint, dict):
        if "state_dict" in checkpoint:
            state_dict = checkpoint["state_dict"]
        else:
            state_dict = checkpoint

    missing_keys = []
    err_msg = []

    state_dict = state_dict.copy()

    # state_dict = {i.name: i.numpy() for i in state_dict}
    state_dict_name = list(state_dict.keys())
    for key, value in model.all_weights.items():
        if key in state_dict_name:
            if value.shape == state_dict[key].shape:
                value.assign(state_dict[key])
                state_dict.pop(key)
            else:
                continue
        else:
            missing_keys.append(key)

    unexpected_keys = list(state_dict.keys())

    if unexpected_keys:
        err_msg.append("unexpected key in source "
                       f'state_dict: {", ".join(unexpected_keys)}\n')
    if missing_keys:
        err_msg.append(
            f'missing keys in source state_dict: {", ".join(missing_keys)}\n')

    if len(err_msg) > 0:
        err_msg.insert(
            0, "The model and loaded state dict do not match exactly\n")
        err_msg = "\n".join(err_msg)
        if strict:
            raise RuntimeError(err_msg)
        elif logger is not None:
            logger.warning(err_msg)
        else:
            print(err_msg)
    if isinstance(checkpoint, list):
        checkpoint = {i.name: i for i in checkpoint}
    checkpoint_meta = checkpoint.get("meta", {})
    # save the dataset_meta in the model for convenience
    if "dataset_meta" in checkpoint_meta:
        # mmdet 3.x, all keys should be lowercase
        model.dataset_meta = {
            k.lower(): v
            for k, v in checkpoint_meta["dataset_meta"].items()
        }
    else:
        print(
            "dataset_meta or class names are not saved in the 'checkpoint' meta data"
        )
    return model
