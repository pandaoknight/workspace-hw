# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2023/1/4
import warnings
from collections import OrderedDict
import tensorflow as tf


def get_key(dicts, value):
    if isinstance(value, tf.Variable):
        value_ref = value.ref()
    else:
        value_ref = value
    for k, v in dicts.items():
        if isinstance(v, tf.Variable):
            v_ref = v.ref()
        else:
            v_ref = v

        if v_ref == value_ref:
            return k


def get_module_weights(module, attribute, prefix=""):
    # TODO: add assert for modules does not have _modules and _params

    state_dict = OrderedDict()
    assert attribute in ["_trainable_weights", "_non_trainable_weights"]
    nested_modules = module._flatten_modules(include_self=False, recursive=False)
    has_name = hasattr(module, "_modules")
    for submodule in nested_modules:
        if hasattr(module, "_modules"):
            # for submodules
            name = get_key(module._modules, submodule)
        if name is None:
            name = get_key(module.__dict__, submodule)
        if name is None:
            raise RuntimeError(f"Module {submodule} does not have name")
        if prefix == "":
            prefix_name = name
        else:
            prefix_name = prefix + "." + name
        submodule_weights = get_module_weights(submodule, attribute, prefix_name)
        state_dict.update(submodule_weights)

    # for current module weights
    nested_weights = getattr(module, attribute)
    flatten_weights_ref = (
        tf.nest.flatten(module._params_ref) if hasattr(module, "_params_ref") else []
    )

    val_index = 0
    for weight in nested_weights:
        weight_ref = weight.ref()
        name = None
        if weight_ref in flatten_weights_ref:
            name = get_key(module._params_ref, weight_ref)
        if name is None:
            name = get_key(module.__dict__, weight_ref)
        if name is None:
            name = str(val_index)
            val_index += 1
        if prefix == "":
            prefix_name = name
        else:
            prefix_name = prefix + "." + name
        state_dict[prefix_name] = weight

    return state_dict


def _addindent(s_, numSpaces):
    s = s_.split("\n")
    # don't do anything for single-line stuff
    if len(s) == 1:
        return s_
    first = s.pop(0)
    s = [(numSpaces * " ") + line for line in s]
    s = "\n".join(s)
    s = first + "\n" + s
    return s


def is_tensor(x):
    if isinstance(x, (tf.Tensor, tf.Variable)):
        return True
    else:
        return False


def is_trainable(x):
    if hasattr(x, "trainable"):
        return True
    else:
        return False


def get_dict_key(dict, value):
    for k, v in dict.items():
        if isinstance(v, tf.Module) and v == value and type(v) == type(value):
            return k


def recursive_rename_weights(module, prefix=""):
    modules = list(module._flatten_modules(False, False))

    for m in modules:
        name = get_dict_key(module.__dict__, m)
        if name is None:
            raise ValueError(
                f"Could not found value {type(m)} in module {type(module)}"
            )
        recursive_rename_weights(m, prefix + "/" + name)

    # rename varaibles
    for k, v in module.__dict__.items():
        if not isinstance(v, tf.Module) and isinstance(v, (tf.Tensor, tf.Variable)):
            # name = get_dict_key(module.__dict__, v)
            if hasattr(v, "_renamed") and getattr(v, "_renamed"):
                continue

            if len(v.name.split("/")) > 1:
                postfix_name = v.name.split("/")[-1]
            else:
                postfix_name = v.name

            if hasattr(v, "_name"):
                v._name = prefix + "/" + postfix_name
            else:
                v._handle_name = prefix + "/" + postfix_name
            setattr(v, "_renamed", True)


def recursive_set_mode(module, training=True):
    for m in module._flatten(False, is_trainable):
        # for module or layer
        if isinstance(m, tf.Module):
            if hasattr(m, "train") and training:
                m.train()
            elif hasattr(m, "eval") and not training:
                m.eval()
            else:
                recursive_set_mode(m, training)
        # for variables
        elif isinstance(m, (tf.Tensor, tf.Variable)):
            m._trainable = training
        else:
            warnings.warn(f"module or tensor {m} cannot set trainable")


def apply(module, fn):
    for m in module._flatten_modules(recursive=False, include_self=False):
        apply(m, fn)
    fn(module)
    return module
