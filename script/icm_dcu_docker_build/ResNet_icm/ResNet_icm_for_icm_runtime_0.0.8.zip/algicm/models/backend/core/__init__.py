#! /usr/bin/python
# -*- coding: utf-8 -*-

from algicm import BACKEND

if BACKEND == "tensorflow":
    from .tensorflow import (
        BaseModule,
        Sequential,
        ModuleDict,
        ModuleList,
        BaseModel,
        BaseDataProcessor,
        initialize,
        update_init_info,
        constant_init,
        xavier_init,
        normal_init,
        trunc_normal_init,
        uniform_init,
        kaiming_init,
        caffe2_xavier_init,
        bias_init_with_prob,
        ConstantInit,
        XavierInit,
        NormalInit,
        TruncNormalInit,
        UniformInit,
        KaimingInit,
        Caffe2XavierInit,
        PretrainedInit,
        load_checkpoint,
        _load_checkpoint_to_model,
    )
elif BACKEND == "torch":
    from .pytorch import (
        BaseModule,
        Sequential,
        ModuleDict,
        ModuleList,
        BaseModel,
        BaseDataProcessor,
        initialize,
        update_init_info,
        constant_init,
        xavier_init,
        normal_init,
        trunc_normal_init,
        uniform_init,
        kaiming_init,
        caffe2_xavier_init,
        bias_init_with_prob,
        ConstantInit,
        XavierInit,
        NormalInit,
        TruncNormalInit,
        UniformInit,
        KaimingInit,
        Caffe2XavierInit,
        PretrainedInit,
        load_checkpoint,
        _load_checkpoint_to_model,
    )
else:
    raise ("Unsupported backend:", BACKEND)
