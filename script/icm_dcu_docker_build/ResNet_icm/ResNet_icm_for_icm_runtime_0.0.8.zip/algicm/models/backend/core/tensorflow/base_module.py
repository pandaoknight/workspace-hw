#! /usr/bin/python
# -*- coding: utf-8 -*-

import copy
import time
import operator
from logging import FileHandler
from collections.abc import Sequence
from itertools import chain, islice
import tensorflow as tf
from tensorflow.python.keras.engine.base_layer_utils import has_weights
from keras.src import backend
import algicm.models.backend.functional.tensorflow_functional as F
import horovod.tensorflow as hvd
from collections import defaultdict
from collections import OrderedDict, abc as container_abcs
from .util import _addindent, get_module_weights
from .weight_init import initialize, update_init_info
from algicm.utils import Logger
from ..common import (
    tolist,
    construct_graph,
    select_attrs,
    check_parameter,
    get_variable_with_initializer,
    ModuleNode,
)

_global_layer_name_dict = {}
_global_layer_node = []


class BaseModule(tf.keras.layers.Layer):
    """The basic :class:`Module` class represents a single layer of a neural network.
    It should be subclassed when implementing new types of layers.
    Parameters
    ----------
    name : str or None
        A unique layer name. If None, a unique name will be automatically assigned.
    Methods
    ---------
    __init__()
        Initializing the Layer.
    __call__()
        Forwarding the computation.
    all_weights()
        Return a list of Tensor which are all weights of this Layer.
    trainable_weights()
        Return a list of Tensor which are all trainable weights of this Layer.
    nontrainable_weights()
        Return a list of Tensor which are all nontrainable weights of this Layer.
    build()
        Abstract method. Build the Layer. All trainable weights should be defined in this function.
    _get_weights()
        Abstract method.Create weights for training parameters.
    save_weights()
        Input file_path, save model weights into a file of given format.
    load_weights()
        Load model weights from a given file, which should be previously saved by self.save_weights().
    save_standard_weights()
        Input file_path, save model weights into a npz_dict file. These parameters can support multiple backends.
    load_standard_weights()
        Load model weights from a given file, which should be previously saved by self.save_standard_weights().
    forward()
        Abstract method. Forward computation and return computation results.

    """

    def __init__(self, name=None, init_cfg=None, *args, **kwargs):
        super().__init__(name=name)
        self._params_ref = OrderedDict()
        self._modules = OrderedDict()

        self._create_time = int(time.time() * 1e9)
        self._built = False
        self._forward_state = False
        # Layer training state

        # Layer nodes state
        self._nodes_fixed = False
        self._build_graph = False
        # weights init
        self._is_init = False

        self.init_cfg = copy.deepcopy(init_cfg)

    @property
    def is_train(self):
        return self.trainable

    def set_train(self, mode=True):
        if not isinstance(mode, bool):
            raise ValueError("training mode is expected to be boolean")
        self.trainable = mode
        for module in self._flatten_modules(recursive=False,
                                            include_self=False):
            if hasattr(module, "set_train"):
                module.set_train(mode)
            else:
                module.trainable = mode
        return self

    def set_eval(self):
        self.set_train(False)

    def __setattr__(self, name, value):

        if (name == "_self_setattr_tracking"
                or not getattr(self, "_self_setattr_tracking", True)
                # Exclude @property.setters from tracking
                or hasattr(self.__class__, name)):
            try:
                super(tf.__internal__.tracking.AutoTrackable,
                      self).__setattr__(name, value)
            except AttributeError:
                raise AttributeError(
                    ('Can\'t set the attribute "{}", likely because it '
                     "conflicts with an existing read-only @property of the "
                     "object. Please choose a different name.").format(name))
            return

        # Wraps data structures in `Trackable`, unwraps `NoDependency` objects.
        value = tf.__internal__.tracking.sticky_attribute_assignment(
            trackable=self, value=value, name=name)

        reference_counts = self._obj_reference_counts
        reference_counts[value] = reference_counts.get(value, 0) + 1

        # Clean out the old attribute, which clears _layers and
        # _trainable_weights if necessary.
        try:
            self.__delattr__(name)
        except AttributeError:
            pass

        # Append value to self._self_tracked_trackables if relevant
        if getattr(self, "_auto_track_sub_layers", True) and (isinstance(
                value, tf.Module) or has_weights(value)):
            self._maybe_create_attribute("_self_tracked_trackables", [])
            # We need to check object identity to avoid de-duplicating empty
            # container types which compare equal.
            if not any(
                (layer is value for layer in self._self_tracked_trackables)):
                self._self_tracked_trackables.append(value)
                if hasattr(value, "_use_resource_variables"):
                    # Legacy layers (V1 tf.layers) must always use
                    # resource variables.
                    value._use_resource_variables = True
            if isinstance(value, tf.Module):
                self._modules[name] = value

        # Append value to list of trainable / non-trainable weights if relevant
        # TODO(b/125122625): This won't pick up on any variables added to a
        # list/dict after creation.
        val_idx = 0
        nest_values = tf.nest.flatten(value, expand_composites=True)
        for val in nest_values:
            if not isinstance(val, tf.Variable):
                continue

            if len(nest_values) == 1:
                self._params_ref[name] = val.ref()
            else:
                self._params_ref[str(val_idx)] = val.ref()
                val_idx += 1

            # Users may add extra weights/variables simply by assigning them to
            # attributes (invalid for graph networks)
            self._maybe_create_attribute("_trainable_weights", [])
            self._maybe_create_attribute("_non_trainable_weights", [])
            if val.trainable:
                if any(val is w for w in self._trainable_weights):
                    continue
                self._trainable_weights.append(val)
            else:
                if any(val is w for w in self._non_trainable_weights):
                    continue
                self._non_trainable_weights.append(val)

            backend.track_variable(val)

        # TODO(b/180760306) Skip the auto trackable from tf.Module to keep
        # status quo. See the comment at __delattr__.
        super(tf.__internal__.tracking.AutoTrackable,
              self).__setattr__(name, value)

    @property
    def is_init(self):
        return self._is_init

    def init_weights(self):
        """Initialize the weights."""

        is_top_level_module = False
        # check if it is top-level module
        if not hasattr(self, "_params_init_info"):
            # The `_params_init_info` is used to record the initialization
            # information of the parameters
            # the key should be the obj:`nn.Parameter` of model and the value
            # should be a dict containing
            # - init_info (str): The string that describes the initialization.
            # - tmp_mean_value (FloatTensor): The mean of the parameter,
            #       which indicates whether the parameter has been modified.
            # this attribute would be deleted after all parameters
            # is initialized.
            self._params_init_info = defaultdict(dict)
            is_top_level_module = True

            # Initialize the `_params_init_info`,
            # When detecting the `tmp_mean_value` of
            # the corresponding parameter is changed, update related
            # initialization information
            for param in self.trainable_variables:
                self._params_init_info[param.ref()]["init_info"] = (
                    f"The value is the same before and "
                    f"after calling `init_weights` "
                    f"of {self.__class__.__name__} ")
                self._params_init_info[
                    param.ref()]["tmp_mean_value"] = tf.math.reduce_mean(param)

            # pass `params_init_info` to all submodules
            # All submodules share the same `params_init_info`,
            # so it will be updated when parameters are
            # modified at any level of the model.
            for sub_module in self._flatten_modules(recursive=True,
                                                    include_self=True):
                sub_module._params_init_info = self._params_init_info

        logger = Logger.get_current_instance()

        module_name = self.__class__.__name__
        if not self._is_init:
            if self.init_cfg:
                logger.log_msg(
                    f"initialize {module_name} with init_cfg {self.init_cfg}",
                    level="DEBUG",
                )

                init_cfgs = self.init_cfg
                if isinstance(self.init_cfg, dict):
                    init_cfgs = [self.init_cfg]

                # PretrainedInit has higher priority than any other init_cfg.
                # Therefore we initialize `pretrained_cfg` last to overwrite
                # the previous initialized weights.
                # See details in https://github.com/open-mmlab/mmengine/issues/691 # noqa E501
                other_cfgs = []
                pretrained_cfg = []
                for init_cfg in init_cfgs:
                    assert isinstance(init_cfg, dict)
                    if init_cfg["type"] == "Pretrained":
                        pretrained_cfg.append(init_cfg)
                    else:
                        other_cfgs.append(init_cfg)

                initialize(self, other_cfgs)

            for m in self._flatten_modules(recursive=False,
                                           include_self=False):
                if hasattr(m, "init_weights"):
                    m.init_weights()
                    # users may overload the `init_weights`
                    update_init_info(
                        m,
                        init_info=f"Initialized by "
                        f"user-defined `init_weights`"
                        f" in {m.__class__.__name__} ",
                    )
            if self.init_cfg and pretrained_cfg:
                initialize(self, pretrained_cfg)
            self._is_init = True
        else:
            logger.log_msg(
                f"init_weights of {self.__class__.__name__} has "
                f"been called more than once.",
                level="WARNING",
            )

        if is_top_level_module:
            # self._dump_init_info(logger_name)
            self._dump_init_info()

            for sub_module in self._flatten_modules(recursive=True,
                                                    include_self=True):
                del sub_module._params_init_info

    def _dump_init_info(self):
        """Dump the initialization information to a file named
        `initialization.log.json` in workdir.

        Args:
            logger_name (str): The name of logger.
        """
        if hvd.rank() != 0:
            return

        logger = Logger.get_current_instance()
        with_file_handler = False
        # dump the information to the logger file if there is a `FileHandler`
        for handler in logger.handlers:
            if isinstance(handler, FileHandler):
                handler.stream.write(
                    "Name of parameter - Initialization information\n")
                for param in self.trainable_variables:
                    name = param.name
                    handler.stream.write(
                        f"\n{name} - {param.shape}: "
                        f"\n{self._params_init_info[param.ref()]['init_info']} \n"
                    )
                handler.stream.flush()
                with_file_handler = True
        if not with_file_handler:
            for param in self.trainable_variables:
                name = param.name
                logger.log_msg(
                    f"\n{name} - {param.shape}: "
                    f"\n{self._params_init_info[param.ref()]['init_info']} \n ",
                    level="INFO",
                )

    def extend_repr(self):
        """
        Sets the extended representation of the Module.

        To print customized extended information, re-implement this method in your own Layers.

        """

        return ""

    def __repr__(self):
        extra_str = self.extend_repr()
        info_str = self.__class__.__name__ + "("
        if hasattr(self, "_modules"):
            sub_str = "\n"
            if extra_str:
                sub_str += "{}\n".format(self.extend_repr())
            for key, value in self._modules.items():
                sub_str += "({}): {}\n".format(key, repr(value))
            sub_str = sub_str.replace("\n", "\n  ") + ")"
            info_str += sub_str
        else:
            info_str += extra_str + ")"
        return info_str

    def __call__(self, inputs, *args, **kwargs):
        output = self.forward(inputs, *args, **kwargs)
        return output

    def forward(self, *inputs, **kwargs):
        raise Exception(
            "The forward method must be implemented by inherited class")

    def build(self, inputs_shape):
        raise Exception(
            "The build(self, inputs_shape) method must be implemented by inherited class"
        )

    def _get_weights(
        self,
        var_name,
        shape,
        init,
        trainable=True,
        transposed=None,
        order=False,
        **kwargs,
    ):
        """Get trainable variables."""

        weight = get_variable_with_initializer(
            scope_name=self.name,
            var_name=var_name,
            shape=shape,
            init=init,
            trainable=trainable,
            **kwargs,
        )
        self.trainable = trainable
        return weight

    @staticmethod
    def _compute_shape(tensors):
        if isinstance(tensors, list):
            shape_mem = [F.get_tensor_shape(t) for t in tensors]
        else:
            shape_mem = F.get_tensor_shape(tensors)
        return shape_mem

    @property
    def create_time(self):
        return self._create_time

    @property
    def trainable_weights_dict(self):
        """
        Returns all trainable weights.
        Returns a list of all trainable parmeters.

        """
        return get_module_weights(self,
                                  attribute="_trainable_weights",
                                  prefix="")

    @property
    def non_trainable_weights_dict(self):
        """
        Returns all untrainable weights.
        Returns a list of all untrainable weights.

        """

        return get_module_weights(self, "_non_trainable_weights", prefix="")

    @property
    def all_weights(self):
        """
        Returns all weights.
        Returns a list of all weights.

        """
        trainable_weights_dict = self.trainable_weights_dict
        non_trainable_weights_dict = self.non_trainable_weights_dict
        trainable_weights_dict.update(non_trainable_weights_dict)
        return trainable_weights_dict

    def init_build(self, *inputs, **kwargs):
        """
        (1) This method must be called when the Layer has no input in_channels.
        (2) Automatic shape inference when the user does not enter in_channels.
        """

        self.forward(*inputs, **kwargs)

    def set_build_graph(self):
        for layer in self._flatten_modules(recursive=False,
                                           include_self=False):
            if isinstance(layer, tf.keras.layers.Layer) and hasattr(
                    layer, "set_build_graph"):
                layer.set_build_graph()
                layer._build_graph = True

    def build_graph(self, *inputs, **kwargs):
        # Add nodes only when the composition is needed.
        self.set_build_graph()
        self.set_eval()

        outputs = self.forward(*inputs, **kwargs)
        self.inputs = inputs
        self.outputs = outputs
        self._node_by_depth, self._all_layers = construct_graph(
            self.inputs, self.outputs)
        return self._node_by_depth, self._all_layers

    def _add_node(self, input_tensors, output_tensors):
        """Add a ModuleNode for this layer given input_tensors, output_tensors.

        This function should not be called from outside, it should only be called
        in __call__ when building static model.

        Parameters
        ----------
        input_tensors : Tensor or a list of tensors
            Input tensors to this layer.
        output_tensors : Tensor or a list of tensors
            Output tensors to this layer.

        """
        inputs_list = tolist(input_tensors)
        outputs_list = tolist(output_tensors)
        in_nodes = [tensor._info[0] for tensor in inputs_list]
        in_tensor_idxes = [tensor._info[1] for tensor in inputs_list]
        node_index = len(_global_layer_node)

        new_node = ModuleNode(
            self,
            node_index,
            in_nodes,
            inputs_list,
            outputs_list,
            in_tensor_idxes,
            select_attrs(self),
        )
        _global_layer_node.append(new_node)
        for idx, tensor in enumerate(outputs_list):
            tensor._info = (new_node, idx)

    def check_param(self, param, dim="2d"):
        return check_parameter(param, dim)

    def add_module(self, name, module):
        setattr(self, name, module)


class Sequential(BaseModule):
    """
    The class :class:`Sequential` is a linear stack of layers.
    The :class:`Sequential` can be created by passing a list of layer instances.
    The given layer instances will be automatically connected one by one.
    Parameters
    ----------
    layers: list of Layer
        A list of layers.
    name : str or None
        A unique layer name. If None, a unique name will be automatically assigned.
    Methods
    ---------
    __init__()
        Initializing the ModuleList.
    weights()
        A collection of weights of all the layer instances.
    build()
        Build the ModuleList. The layer instances will be connected automatically one by one.
    forward()
        Forward the computation. The computation will go through all layer instances.

    Examples
    ---------
    >>> conv = tlx.layers.Conv2d(3, 2, 3, pad_mode='valid')
    >>> bn = tlx.layers.BatchNorm2d(2)
    >>> seq = tlx.nn.Sequential([conv, bn])
    >>> x = tlx.layers.Input((1, 3, 4, 4))
    >>> seq(x)
    """

    def __init__(self, *args):
        super(Sequential, self).__init__()
        if len(args) == 1 and isinstance(args[0], OrderedDict):
            for key, module in args[0].items():
                self.add_module(key, module)
        else:
            for idx, module in enumerate(args):
                self.add_module(str(idx), module)

    def _get_item_by_idx(self, iterator, idx):
        """Get the idx-th item of the iterator"""
        size = len(self)
        idx = operator.index(idx)
        if not -size <= idx < size:
            raise IndexError("index {} is out of range".format(idx))
        idx %= size
        return next(islice(iterator, idx, None))

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            return self.__class__(OrderedDict(
                list(self._modules.items())[idx]))
        else:
            return self._get_item_by_idx(self._modules.values(), idx)

    def __setitem__(self, idx, module) -> None:
        key: str = self._get_item_by_idx(self._modules.keys(), idx)
        return setattr(self, key, module)

    def __delitem__(self, idx) -> None:
        if isinstance(idx, slice):
            for key in list(self._modules.keys())[idx]:
                delattr(self, key)
        else:
            key = self._get_item_by_idx(self._modules.keys(), idx)
            delattr(self, key)

    def __len__(self) -> int:
        return len(self._modules)

    def __dir__(self):
        keys = super(Sequential, self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return keys

    def __iter__(self):
        return iter(self._modules.values())

    # NB: We can't really type check this function as the type of input
    # may change dynamically (as is tested in
    # TestScript.test_sequential_intermediary_types).  Cannot annotate
    # with Any as TorchScript expects a more precise type
    def forward(self, input):
        for module in self:
            input = module(input)
        return input

    def append(self, module):
        r"""Appends a given module to the end.

        Args:
            module (nn.Module): module to append
        """
        self.add_module(str(len(self)), module)
        return self


class ModuleList(BaseModule):
    """
    Holds submodules in a list.

    ModuleList can be used like a regular Python list, support
    '__getitem__', '__setitem__', '__delitem__', '__len__', '__iter__' and '__iadd__',
    but module it contains are properly registered, and will be visible by all Modules methods.

    Parameters
    ----------
        args : list
            List of subclass of Module.
    Methods
    ---------
    __init__()
        Initializing the ModuleList.
    insert()
        Inserts a given layer before a given index in the list.
    extend()
        Appends layers from a Python iterable to the end of the list.
    append()
        Appends a given layer to the end of the list.

    Examples
    ---------
    >>> from tensorlayerx.nn import Module, ModuleList, Linear
    >>> import tensorlayerx as tlx
    >>> d1 = Linear(out_features=800, act=tlx.ReLU, in_features=784, name='linear1')
    >>> d2 = Linear(out_features=800, act=tlx.ReLU, in_features=800, name='linear2')
    >>> d3 = Linear(out_features=10, act=tlx.ReLU, in_features=800, name='linear3')
    >>> layer_list = ModuleList([d1, d2])
    >>> # Inserts a given d2 before a given index in the list
    >>> layer_list.insert(1, d2)
    >>> layer_list.insert(2, d2)
    >>> # Appends d2 from a Python iterable to the end of the list.
    >>> layer_list.extend([d2])
    >>> # Appends a given d3 to the end of the list.
    >>> layer_list.append(d3)
    """

    def __init__(self, modules=None) -> None:
        super(ModuleList, self).__init__()
        if modules is not None:
            self += modules

    def _get_abs_string_index(self, idx):
        """Get the absolute index for the list of modules"""
        idx = operator.index(idx)
        if not (-len(self) <= idx < len(self)):
            raise IndexError("index {} is out of range".format(idx))
        if idx < 0:
            idx += len(self)
        return str(idx)

    def __getitem__(self, idx: int):
        if isinstance(idx, slice):
            return self.__class__(list(self._modules.values())[idx])
        else:
            return self._modules[self._get_abs_string_index(idx)]

    def __setitem__(self, idx: int, module) -> None:
        idx = self._get_abs_string_index(idx)
        return setattr(self, str(idx), module)

    def __delitem__(self, idx) -> None:
        if isinstance(idx, slice):
            for k in range(len(self._modules))[idx]:
                delattr(self, str(k))
        else:
            delattr(self, self._get_abs_string_index(idx))
        # To preserve numbering, self._modules is being reconstructed with modules after deletion
        str_indices = [str(i) for i in range(len(self._modules))]
        self._modules = OrderedDict(
            list(zip(str_indices, self._modules.values())))

    def __len__(self) -> int:
        return len(self._modules)

    def __iter__(self):
        return iter(self._modules.values())

    def __iadd__(self, modules) -> "ModuleList":
        return self.extend(modules)

    def __add__(self, other) -> "ModuleList":
        combined = ModuleList()
        for i, module in enumerate(chain(self, other)):
            combined.add_module(str(i), module)
        return combined

    def __dir__(self):
        keys = super(ModuleList, self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return keys

    def insert(self, index: int, module) -> None:
        r"""Insert a given module before a given index in the list.

        Args:
            index (int): index to insert.
            module (nn.Module): module to insert
        """
        for i in range(len(self._modules), index, -1):
            self._modules[str(i)] = self._modules[str(i - 1)]
        self._modules[str(index)] = module

    def append(self, module) -> "ModuleList":
        r"""Appends a given module to the end of the list.

        Args:
            module (nn.Module): module to append
        """
        self.add_module(str(len(self)), module)
        return self

    def extend(self, modules) -> "ModuleList":
        r"""Appends modules from a Python iterable to the end of the list.

        Args:
            modules (iterable): iterable of modules to append
        """
        if not isinstance(modules, container_abcs.Iterable):
            raise TypeError("ModuleList.extend should be called with an "
                            "iterable, but got " + type(modules).__name__)
        offset = len(self)
        for i, module in enumerate(modules):
            self.add_module(str(offset + i), module)
        return self


class ModuleDict(BaseModule):
    """
    Holds submodules in a dictionary.

    ModuleDict can be used like a regular Python dictionary, support
    '__getitem__', '__setitem__', '__delitem__', '__len__', '__iter__' and '__contains__',
    but module it contains are properly registered, and will be visible by all Modules methods.

    Parameters
    ----------
        args : dict
            a mapping (dictionary) of (string: module)
            or an iterable of key-value pairs of type (string, module)

    Methods
    ---------
    __init__()
        Initializing the ModuleDict.
    clear()
        Remove all items from the ModuleDict.
    pop()
        Remove key from the ModuleDict and return its module.
    keys()
        Return an iterable of the ModuleDict keys.
    items()
        Return an iterable of the ModuleDict key/value pairs.
    values()
        Return an iterable of the ModuleDict values.
    update()
        Update the ModuleDict with the key-value pairs from a
        mapping or an iterable, overwriting existing keys.

    Examples
    ---------
    >>> from tensorlayerx.nn import Module, ModuleDict, Linear
    >>> import tensorlayerx as tlx
    >>> class MyModule(Module):
    >>>     def __init__(self):
    >>>         super(MyModule, self).__init__()
    >>>         self.dict = ModuleDict({
    >>>                 'linear1':Linear(out_features=800, act=tlx.ReLU, in_features=784, name='linear1'),
    >>>                 'linear2':Linear(out_features=800, act=tlx.ReLU, in_features=800, name='linear2')
    >>>                 })
    >>>     def forward(self, x, linear):
    >>>         x = self.dict[linear](x)
    >>>         return x

    """

    def __init__(self, modules=None) -> None:
        super(ModuleDict, self).__init__()
        if modules is not None:
            self.update(modules)

    def __getitem__(self, key: str):
        return self._modules[key]

    def __setitem__(self, key: str, module) -> None:
        self.add_module(key, module)

    def __delitem__(self, key: str) -> None:
        del self._modules[key]

    def __len__(self) -> int:
        return len(self._modules)

    def __iter__(self):
        return iter(self._modules)

    def __contains__(self, key: str) -> bool:
        return key in self._modules

    def clear(self) -> None:
        """Remove all items from the ModuleDict."""
        self._modules.clear()

    def pop(self, key: str):
        r"""Remove key from the ModuleDict and return its module.

        Args:
            key (string): key to pop from the ModuleDict
        """
        v = self[key]
        del self[key]
        return v

    def keys(self):
        r"""Return an iterable of the ModuleDict keys."""
        return self._modules.keys()

    def items(self):
        r"""Return an iterable of the ModuleDict key/value pairs."""
        return self._modules.items()

    def values(self):
        r"""Return an iterable of the ModuleDict values."""
        return self._modules.values()

    def update(self, modules) -> None:
        r"""Update the :class:`~ModuleDict` with the key-value pairs from a
        mapping or an iterable, overwriting existing keys.

        .. note::
            If :attr:`modules` is an ``OrderedDict``, a :class:`~torch.nn.ModuleDict`, or
            an iterable of key-value pairs, the order of new elements in it is preserved.

        Args:
            modules (iterable): a mapping (dictionary) from string to :class:`~torch.nn.Module`,
                or an iterable of key-value pairs of type (string, :class:`~torch.nn.Module`)
        """
        if not isinstance(modules, container_abcs.Iterable):
            raise TypeError("ModuleDict.update should be called with an "
                            "iterable of key/value pairs, but got " +
                            type(modules).__name__)

        if isinstance(modules,
                      (OrderedDict, ModuleDict, container_abcs.Mapping)):
            for key, module in modules.items():
                self[key] = module
        else:
            # modules here can be a list with two items
            for j, m in enumerate(modules):
                if not isinstance(m, container_abcs.Iterable):
                    raise TypeError("ModuleDict update sequence element "
                                    "#" + str(j) + " should be Iterable; is" +
                                    type(m).__name__)
                if not len(m) == 2:
                    raise ValueError("ModuleDict update sequence element "
                                     "#" + str(j) + " has length " +
                                     str(len(m)) + "; 2 is required")
                # modules can be Mapping (what it's typed at), or a list: [(name1, module1), (name2, module2)]
                # that's too cumbersome to type correctly with overloads, so we add an ignore here
                self[m[0]] = m[1]  # type: ignore[assignment]

    # remove forward alltogether to fallback on Module's _forward_unimplemented
