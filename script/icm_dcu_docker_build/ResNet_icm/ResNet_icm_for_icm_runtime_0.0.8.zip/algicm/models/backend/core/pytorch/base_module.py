#! /usr/bin/python
# -*- coding: utf-8 -*-

import copy
import operator
import torch.nn as nn
from torch.nn.parameter import Parameter
from collections import defaultdict
from logging import FileHandler
from typing import Any, Callable
from itertools import islice
from collections import OrderedDict, abc as container_abcs
from algicm.utils import Logger
from ..common import construct_graph, tolist, ModuleNode, select_attrs, check_parameter
from .weight_init import initialize, update_init_info


_global_layer_name_dict = {}
_global_layer_node = []

class BaseModule(nn.Module):
    def __init__(self, name=None, init_cfg=None, *args, **kwargs):
        super().__init__(*args, **kwargs)

        global _global_layer_name_dict
        if name is None:
            prefix = self.__class__.__name__.lower()

            if _global_layer_name_dict.get(prefix) is not None:
                _global_layer_name_dict[prefix] += 1
                name = prefix + "_" + str(_global_layer_name_dict[prefix])
            else:
                _global_layer_name_dict[prefix] = 0
                name = prefix
            while True:
                if _global_layer_name_dict.get(name) is None:
                    break
                _global_layer_name_dict[prefix] += 1
                name = prefix + "_" + str(_global_layer_name_dict[prefix])
        else:
            if _global_layer_name_dict.get(name) is not None:
                pass
            else:
                _global_layer_name_dict[name] = 0

        self.name = name

        # Layer building state
        self._built = False

        # Layer nodes state
        self._nodes_fixed = False
        self._build_graph = False

        # Layer weight state
        self._all_weights = None
        self._trainable_weights = None
        self._nontrainable_weights = None

        # Layer training state
       

        # layer forward  state
        self._forward_state = False

        # weights check state
        self._check = False

        # weights init
        self._is_init = False

        self.init_cfg = copy.deepcopy(init_cfg)
        
    @property
    def is_train(self):

        return self.training
    
   
    
    @property
    def is_init(self):
        return self._is_init
    
    def init_weights(self):
        """Initialize the weights."""

        is_top_level_module = False
        # check if it is top-level module
        if not hasattr(self, "_params_init_info"):
            # The `_params_init_info` is used to record the initialization
            # information of the parameters
            # the key should be the obj:`nn.Parameter` of model and the value
            # should be a dict containing
            # - init_info (str): The string that describes the initialization.
            # - tmp_mean_value (FloatTensor): The mean of the parameter,
            #       which indicates whether the parameter has been modified.
            # this attribute would be deleted after all parameters
            # is initialized.
            self._params_init_info = defaultdict(dict)
            is_top_level_module = True

            # Initialize the `_params_init_info`,
            # When detecting the `tmp_mean_value` of
            # the corresponding parameter is changed, update related
            # initialization information
            for name, param in self.named_parameters():
                self._params_init_info[param]["init_info"] = (
                    f"The value is the same before and "
                    f"after calling `init_weights` "
                    f"of {self.__class__.__name__} "
                )
                self._params_init_info[param][
                    "tmp_mean_value"
                ] = param.data.mean().cpu()

            # pass `params_init_info` to all submodules
            # All submodules share the same `params_init_info`,
            # so it will be updated when parameters are
            # modified at any level of the model.
            for sub_module in self.modules():
                sub_module._params_init_info = self._params_init_info

        logger = Logger.get_current_instance()

        module_name = self.__class__.__name__
        if not self._is_init:
            if self.init_cfg:
                logger.log_msg(
                    f"initialize {module_name} with init_cfg {self.init_cfg}",
                    level="DEBUG",
                )

                init_cfgs = self.init_cfg
                if isinstance(self.init_cfg, dict):
                    init_cfgs = [self.init_cfg]

                # PretrainedInit has higher priority than any other init_cfg.
                # Therefore we initialize `pretrained_cfg` last to overwrite
                # the previous initialized weights.
                # See details in https://github.com/open-mmlab/mmengine/issues/691 # noqa E501
                other_cfgs = []
                pretrained_cfg = []
                for init_cfg in init_cfgs:
                    assert isinstance(init_cfg, dict)
                    if init_cfg["type"] == "Pretrained":
                        pretrained_cfg.append(init_cfg)
                    else:
                        other_cfgs.append(init_cfg)

                initialize(self, other_cfgs)

            for m in self.children():
                if hasattr(m, "init_weights"):
                    m.init_weights()
                    # users may overload the `init_weights`
                    update_init_info(
                        m,
                        init_info=f"Initialized by "
                        f"user-defined `init_weights`"
                        f" in {m.__class__.__name__} ",
                    )
            if self.init_cfg and pretrained_cfg:
                initialize(self, pretrained_cfg)
            self._is_init = True
        else:
            logger.log_msg(
                f"init_weights of {self.__class__.__name__} has "
                f"been called more than once.",
                level="WARNING",
            )

        if is_top_level_module:
            # self._dump_init_info(logger_name)
            self._dump_init_info()

            for sub_module in self.modules():
                del sub_module._params_init_info

    def _dump_init_info(self):
        """Dump the initialization information to a file named
        `initialization.log.json` in workdir.

        Args:
            logger_name (str): The name of logger.
        """

        logger = Logger.get_current_instance()
        with_file_handler = False
        # dump the information to the logger file if there is a `FileHandler`
        for handler in logger.handlers:
            if isinstance(handler, FileHandler):
                handler.stream.write("Name of parameter - Initialization information\n")
                for name, param in self.named_parameters():
                    handler.stream.write(
                        f"\n{name} - {param.shape}: "
                        f"\n{self._params_init_info[param]['init_info']} \n"
                    )
                handler.stream.flush()
                with_file_handler = True
        if not with_file_handler:
            for name, param in self.named_parameters():
                logger.log_msg(
                    f"\n{name} - {param.shape}: "
                    f"\n{self._params_init_info[param]['init_info']} \n ",
                    level="INFO",
                )

    def set_train(self, mode=True):
        if not isinstance(mode, bool):
            raise ValueError("training mode is expected to be boolean")
        # self.is_train = mode
        # self.trainable = mode
        self.training = mode
        for module in self.children():
            if hasattr(module, "set_train"):
                module.set_train(mode)
            else:
                module.train(mode)
        return self

    def set_eval(self):
        self.set_train(False)

    def build(self, inputs_shape):
        raise Exception(
            "The build(self, inputs_shape) method must be implemented by inherited class"
        )

    def forward(self, *inputs, **kwargs):
        raise Exception("The forward method must be implemented by inherited class")

    def _get_weights(
        self,
        var_name,
        shape,
        init=None,
        trainable=True,
        transposed=None,
        order=False,
        **kwargs,
    ):
        if order:
            w_tmp = Parameter(init(shape, **kwargs), requires_grad=trainable)
            return w_tmp

        if len(shape) == 3:
            shape = shape[::-1]
        if len(shape) == 4:
            if transposed:
                shape = (shape[3], shape[0], shape[1], shape[2])
            else:
                shape = (shape[3], shape[2], shape[0], shape[1])
        if len(shape) == 5:
            shape = (shape[4], shape[3], shape[0], shape[1], shape[2])
        # TODO paramters name should be add
        _param = init(shape=shape, **kwargs)
        param = Parameter(_param, requires_grad=trainable)
        self.var_name = var_name
        return param

    def _call_impl_tlx(self, *input, **kwargs):
        if self._check == False:
            _param_name = []
            for name, param in self.named_parameters(recurse=True):
                if name not in _param_name:
                    _param_name.append(name)
                else:
                    raise Exception(
                        "parameter name [{}] have be been used. "
                        "In training, the name of layer can't be same."
                        "Please check the layers name".format(name)
                    )
            self._check = True

        result = self._call_impl(*input, **kwargs)
        return result

    # TODO RNN enabled after repair
    __call__: Callable[..., Any] = _call_impl_tlx

    def _named_members(self, get_members_fn, prefix="", recurse=True):
        r"""Helper method for yielding various names + members of modules."""
        memo = set()
        modules = self.named_modules(prefix=prefix) if recurse else [(prefix, self)]
        for module_prefix, module in modules:
            members = get_members_fn(module)
            for k, v in members:
                if v is None or v in memo:
                    continue
                memo.add(v)
                name = module_prefix + ("." if module_prefix else "") + k
                # name = module.name + '/' + k
                yield name, v

    @property
    def all_weights(self):
        if self._all_weights is not None and len(self._all_weights) > 0:
            # self._all_weights already extracted, so do nothing
            pass
        else:
            self._all_weights = []
            for name, param in self.named_parameters(recurse=True):
                self._all_weights.append(param)
        return self._all_weights

    @property
    def trainable_weights(self):
        if self._trainable_weights is not None and len(self._trainable_weights) > 0:
            # self._trainable_weights already extracted, so do nothing
            pass
        else:
            self._trainable_weights = []
            for name, param in self.named_parameters(recurse=True):
                if param.requires_grad == True:
                    self._trainable_weights.append(param)
        return self._trainable_weights

    @property
    def nontrainable_weights(self):
        """
        Returns all untrainable weights.
        Returns a list of all untrainable weights.

        """

        if (
            self._nontrainable_weights is not None
            and len(self._nontrainable_weights) > 0
        ):
            # self._nontrainable_weights already extracted, so do nothing
            pass
        else:
            self._nontrainable_weights = []
            for name, param in self.named_parameters(recurse=True):
                if param.requires_grad == False:
                    self._nontrainable_weights.append(param)
        return self._nontrainable_weights

    def init_build(self, *inputs, **kwargs):
        """
        (1) This method must be called when the Layer has no input in_channels.
        (2) Automatic shape inference when the user does not enter inchannels.
        """

        self.forward(*inputs, **kwargs)

    def set_build_graph(self):
        for layer_name, layer in self._modules.items():
            if isinstance(layer, BaseModule):
                if len(layer._modules) > 1:
                    layer.set_build_graph()
                layer._build_graph = True

    def build_graph(self, *inputs, **kwargs):
        # Add nodes only when the composition is needed.
        self.set_build_graph()
        self.set_eval()

        outputs = self.forward(*inputs, **kwargs)
        self.inputs = inputs
        self.outputs = outputs
        self._node_by_depth, self._all_layers = construct_graph(
            self.inputs, self.outputs
        )
        return self._node_by_depth, self._all_layers

    def _add_node(self, input_tensors, output_tensors):
        """Add a ModuleNode for this layer given input_tensors, output_tensors.

        This function should not be called from outside, it should only be called
        in __call__ when building static model.

        Parameters
        ----------
        input_tensors : Tensor or a list of tensors
            Input tensors to this layer.
        output_tensors : Tensor or a list of tensors
            Output tensors to this layer.

        """

        inputs_list = tolist(input_tensors)
        outputs_list = tolist(output_tensors)

        in_nodes = [tensor._info[0] for tensor in inputs_list]
        in_tensor_idxes = [tensor._info[1] for tensor in inputs_list]
        node_index = len(_global_layer_node)

        new_node = ModuleNode(
            self,
            node_index,
            in_nodes,
            inputs_list,
            outputs_list,
            in_tensor_idxes,
            select_attrs(self),
        )
        _global_layer_node.append(new_node)
        for idx, tensor in enumerate(outputs_list):
            tensor._info = (new_node, idx)

    def check_param(self, param, dim="2d"):
        return check_parameter(param, dim)


class Sequential(BaseModule):
    """
    The class :class:`Sequential` is a linear stack of layers.
    The :class:`Sequential` can be created by passing a list of layer instances.
    The given layer instances will be automatically connected one by one.
    Parameters
    ----------
    layers: list of Layer
        A list of layers.
    name : str or None
        A unique layer name. If None, a unique name will be automatically assigned.
    Methods
    ---------
    __init__()
        Initializing the ModuleList.
    weights()
        A collection of weights of all the layer instances.
    build()
        Build the ModuleList. The layer instances will be connected automatically one by one.
    forward()
        Forward the computation. The computation will go through all layer instances.

    Examples
    ---------
    >>> conv = tlx.layers.Conv2d(3, 2, 3, pad_mode='valid')
    >>> bn = tlx.layers.BatchNorm2d(2)
    >>> seq = tlx.nn.Sequential([conv, bn])
    >>> x = tlx.layers.Input((1, 3, 4, 4))
    >>> seq(x)
    """

    def __init__(self, *args):
        super(Sequential, self).__init__()
        self._built = True
        if len(args) == 1:
            layers = args[0]
            if isinstance(layers, list):
                for index, layer in enumerate(layers):
                    self.add_module(str(index), layer)
            elif isinstance(layers, OrderedDict):
                for name, layer in layers.items():
                    self.add_module(name, layer)
            # else:
            #     raise TypeError("Layers must be list or orderedDict")
            else:
                for index, layer in enumerate(args):
                    self.add_module(str(index), layer)
        else:
            for index, layer in enumerate(args):
                self.add_module(str(index), layer)
        self.layer_list = list(self._modules.values())

    def _get_item_by_idx(self, iterator, idx):
        """Get the idx-th item of the iterator"""
        size = len(self)
        idx = operator.index(idx)
        if not -size <= idx < size:
            raise IndexError("index {} is out of range".format(idx))
        idx %= size
        return next(islice(iterator, idx, None))

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            return self.__class__(OrderedDict(list(self._modules.items())[idx]))
        index = _valid_index(len(self), idx)
        return list(self._modules.values())[index]

    def __setitem__(self, index, layer):
        if _valid_module(layer):
            index = _valid_index(len(self), index)
            key = list(self._modules.keys())[index]
            self._modules[key] = layer
            self.layer_list = list(self._modules.values())

    def __delitem__(self, index):
        if isinstance(index, int):
            index = _valid_index(len(self), index)
            key = list(self._modules.keys())[index]
            del self._modules[key]
        elif isinstance(index, slice):
            keys = list(self._modules.keys())[index]
            for key in keys:
                del self._modules[key]
        else:
            raise TypeError("Index {} is not int type or slice type".format(index))
        self.layer_list = list(self._modules.values())

    def __len__(self):
        return len(self._modules)

    def __dir__(self):
        keys = super(Sequential, self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return keys

    def __iter__(self):
        return iter(self._modules.values())

    def append(self, layer):
        if _valid_module(layer):
            self._modules[str(len(self))] = layer
        self.layer_list = list(self._modules.values())
        return self

    def build(self, inputs_shape):
        pass

    def forward(self, input_data):
        for layer in self.layer_list:
            input_data = layer(input_data)
        return input_data


class ModuleList(BaseModule):
    """
    Holds Modules in a list.

    ModuleList can be used like a regular Python list, support
    '__getitem__', '__setitem__', '__delitem__', '__len__', '__iter__' and '__iadd__',
    but module it contains are properly registered, and will be visible by all Modules methods.

    Parameters
    ----------
        args : list
            List of subclass of Module.
    Methods
    ---------
    __init__()
        Initializing the Layer.
    insert()
        Inserts a given layer before a given index in the list.
    extend()
        Appends layers from a Python iterable to the end of the list.
    append()
        Appends a given layer to the end of the list.

    Examples
    ---------
    >>> from tensorlayerx.nn import Module, ModuleList, Linear
    >>> import tensorlayerx as tlx
    >>> d1 = Linear(out_features=800, act=tlx.ReLU, in_features=784, name='linear1')
    >>> d2 = Linear(out_features=800, act=tlx.ReLU, in_features=800, name='linear2')
    >>> d3 = Linear(out_features=10, act=tlx.ReLU, in_features=800, name='linear3')
    >>> layer_list = ModuleList([d1, d2])
    >>> # Inserts a given d2 before a given index in the list
    >>> layer_list.insert(1, d2)
    >>> layer_list.insert(2, d2)
    >>> # Appends d2 from a Python iterable to the end of the list.
    >>> layer_list.extend([d2])
    >>> # Appends a given d3 to the end of the list.
    >>> layer_list.append(d3)
    """

    def __init__(self, modules=None):
        super(ModuleList, self).__init__()
        if modules is not None:
            self.extend(modules)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return self.__class__(list(self._modules.values())[index])
        if isinstance(index, int):
            index = _valid_index(len(self), index)
            return self._modules[str(index)]
        raise TypeError("Index {} is not int type or slice type".format(index))

    def __setitem__(self, index, layer):
        if not isinstance(index, int) and _valid_module(layer):
            raise TypeError("Index {} is not int type".format(index))
        index = _valid_index(len(self), index)
        self._modules[str(index)] = layer

    def __delitem__(self, index):
        if isinstance(index, int):
            index = _valid_index(len(self), index)
            del self._modules[str(index)]
        elif isinstance(index, slice):
            keys = list(self._modules.keys())[index]
            for key in keys:
                del self._modules[key]
        else:
            raise TypeError("Index {} is not int type or slice type".format(index))
        temp_dict = OrderedDict()
        for idx, layer in enumerate(self._modules.values()):
            temp_dict[str(idx)] = layer
        self._modules = temp_dict

    def __len__(self):
        return len(self._modules)

    def __iter__(self):
        return iter(self._modules.values())

    def __iadd__(self, layers):
        self.extend(layers)
        return self

    def insert(self, index, layer):
        """
        Inserts a given layer before a given index in the list.

        """
        idx = _valid_index(len(self), index)
        _valid_module(layer)
        length = len(self)
        while length > idx:
            self._modules[str(length)] = self._modules[str(length - 1)]
            length -= 1
        self._modules[str(idx)] = layer

    def extend(self, layers):
        """
        Appends layers from a Python iterable to the end of the list.

        """

        if not isinstance(layers, list):
            raise TypeError("Modules {} should be list of sublayers".format(layers))
        for layer in layers:
            if _valid_module(layer):
                self._modules[str(len(self))] = layer
        return self

    def append(self, layer):
        """
        Appends a given layer to the end of the list.

        """

        if _valid_module(layer):
            self._modules[str(len(self))] = layer

    def forward(self, *inputs):
        raise NotImplementedError


class ModuleDict(BaseModule):
    def __init__(self, modules=None):
        super(ModuleDict, self).__init__()
        if modules is not None:
            self.update(modules)

    def __getitem__(self, key):

        return self._modules[key]

    def __setitem__(self, key, module):

        self.add_module(key, module)

    def __delitem__(self, key):

        del self._modules[key]

    def __len__(self):

        return len(self._modules)

    def __iter__(self):

        return iter(self._modules)

    def __contains__(self, key):

        return key in self._modules

    def clear(self):

        self._modules.clear()

    def pop(self, key):

        v = self[key]
        del self[key]
        return v

    def keys(self):

        return self._modules.keys()

    def items(self):

        return self._modules.items()

    def values(self):

        return self._modules.values()

    def update(self, modules):
        if not isinstance(modules, container_abcs.Iterable):
            raise TypeError(
                "ModuleDict.update should be called with an "
                "iterable of key/value pairs, but got " + type(modules).__name__
            )

        if isinstance(modules, (OrderedDict, ModuleDict, container_abcs.Mapping)):
            for key, module in modules.items():
                self[key] = module
        else:
            for j, m in enumerate(modules):
                if not isinstance(m, container_abcs.Iterable):
                    raise TypeError(
                        "ModuleDict update sequence element "
                        "#" + str(j) + " should be Iterable; is" + type(m).__name__
                    )
                if not len(m) == 2:
                    raise ValueError(
                        "ModuleDict update sequence element "
                        "#" + str(j) + " has length " + str(len(m)) + "; 2 is required"
                    )
                self[m[0]] = m[1]


def _valid_index(layer_num, index):
    if not isinstance(index, int):
        raise TypeError("Index {} is not int type")
    if not -layer_num <= index < layer_num:
        raise IndexError(
            "Index should be a number in range [{}, {}), but got {}".format(
                -layer_num, layer_num, index
            )
        )
    return index % layer_num


def _valid_module(layer):
    if issubclass(layer.__class__, BaseModule):
        return True
    raise TypeError("Module {} is not subclass of BaseModule".format(layer))
