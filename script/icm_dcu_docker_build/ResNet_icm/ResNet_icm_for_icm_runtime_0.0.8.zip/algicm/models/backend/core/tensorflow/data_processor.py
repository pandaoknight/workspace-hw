import logging
import numpy as np

import tensorflow as tf
from typing import Mapping, Sequence
from algicm.registry.common import MODELS
from algicm.transform.transform import Compose
from algicm.utils import Logger
from algicm.models.backend.core.tensorflow import BaseModule

@MODELS.register_module()
class BaseDataProcessor(BaseModule):
    """Base data pre-processor used for copying data to the target device.

    Subclasses inherit from ``BaseDataPreprocessor`` could override the
    forward method to implement custom data pre-processing, such as
    batch-resize, MixUp, or CutMix.

    Args:
        non_blocking (bool): Whether block current process
            when transferring data to device.
            New in version 0.3.0.

    Note:
        Data dictionary returned by dataloader must be a dict and at least
        contain the ``inputs`` key.
    """

    def __init__(self, batch_preprocess=[], non_blocking=None):
        super().__init__()
        self.batch_preprocess = Compose(batch_preprocess)
        self.logger = Logger.get_current_instance()

    def cast_data(self, data):
        """Copying data to the target device.

        Args:
            data (dict): Data returned by ``DataLoader``.

        Returns:
            CollatedResult: Inputs and data sample at target device.
        """
        if isinstance(data, Mapping):
            return {key: self.cast_data(data[key]) for key in data}
        elif isinstance(data, (str, bytes)) or data is None:
            return data
        elif isinstance(data, tuple) and hasattr(data, "_fields"):
            # namedtuple
            return type(data)(*(self.cast_data(sample) for sample in data))  # type: ignore  # noqa: E501  # yapf:disable
        elif isinstance(data, Sequence):
            return type(data)(self.cast_data(sample) for sample in data)  # type: ignore  # noqa: E501  # yapf:disable
        elif isinstance(data, tf.Tensor):
            return data
        elif isinstance(data, np.ndarray):
            try:
                data = tf.convert_to_tensor(data)
            except Exception as e:
                self.logger.log_msg(
                    f"try to convert dtype of {data.dtype} ndarry to tensor, but got error {e}",
                    level=logging.warning,
                )
            return data
        else:
            return data

    def forward(self, data, training=False):
        """Preprocesses the data into the model input format.

        After the data pre-processing of :meth:`cast_data`, ``forward``
        will stack the input tensor list to a batch tensor at the first
        dimension.

        Args:
            data (dict): Data returned by dataloader
            training (bool): Whether to enable training time augmentation.

        Returns:
            dict or list: Data in the same format as the model input.
        """

        data = self.batch_preprocess(data)

        data = self.cast_data(data)

        return data  # type: ignore
