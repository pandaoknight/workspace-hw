import tensorflow as tf
import os
os.environ['ALGICM_BACKEND'] = 'tensorflow'
from algicm.models.layers.conv import Conv2d
conv = Conv2d(8,32,3, stride=1,groups=2)
input = tf.random.uniform(shape=(8,8,24,24))
print(conv(input).shape)