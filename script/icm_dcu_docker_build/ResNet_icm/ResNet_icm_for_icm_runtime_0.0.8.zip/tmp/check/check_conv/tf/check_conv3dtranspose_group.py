import tensorflow as tf
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
os.environ["ALGICM_BACKEND"] = "tensorflow"
from algicm.models.layers.conv import ConvTranspose3d

input = tf.random.uniform(shape=(1,4,32,32,32))

conv = ConvTranspose3d(4,16,3,padding=6,groups=2,stride=6)

print(conv(input).shape)

