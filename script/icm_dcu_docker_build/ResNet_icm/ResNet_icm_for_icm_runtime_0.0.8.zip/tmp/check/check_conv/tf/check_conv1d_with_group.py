import tensorflow as tf
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["ALGICM_BACKEND"] = "tensorflow"
from algicm.models.layers.conv import Conv1d

conv = Conv1d(2, 32, 3, stride=1, groups=2)
input = tf.random.uniform(shape=(8, 2, 100))
print(conv.weight)
print(conv(input).shape)
print(conv.trainable_weights)
print(1)
