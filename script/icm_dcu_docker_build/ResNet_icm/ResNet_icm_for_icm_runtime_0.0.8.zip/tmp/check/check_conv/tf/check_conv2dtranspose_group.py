import tensorflow as tf
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
os.environ["ALGICM_BACKEND"] = "tensorflow"
from algicm.models.layers.conv import ConvTranspose2d


conv = ConvTranspose2d(4,16,3,padding=6,groups=2,stride=6)
input = tf.random.uniform(shape=(1,4,100,100))
print(conv(input).shape)

