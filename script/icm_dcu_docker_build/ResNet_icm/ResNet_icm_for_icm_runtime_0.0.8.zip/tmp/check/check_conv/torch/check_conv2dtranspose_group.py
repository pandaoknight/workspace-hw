import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.conv import ConvTranspose2d
conv = ConvTranspose2d(4,16,3, stride=6,groups=2,padding=6)
input = torch.rand(1,4,100,100)
print(conv(input).shape)