import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.conv import Conv3d
conv = Conv3d(4,32,3, stride=1,groups=2)
input = torch.rand(8,4,24,24,24)
print(conv(input).shape)