import torch
import os

os.environ["ALGICM_BACKEND"] = "torch"
from algicm.models.layers.conv import Conv1d

conv = Conv1d(2, 32, 3, stride=1)
input = torch.rand(8, 2, 100)
print(conv(input).shape)
