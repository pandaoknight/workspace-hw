import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.conv import ConvTranspose1d
conv = ConvTranspose1d(4,16,3,padding=6,groups=2,stride=6)
input = torch.rand(1,4,100)
print(conv(input).shape)