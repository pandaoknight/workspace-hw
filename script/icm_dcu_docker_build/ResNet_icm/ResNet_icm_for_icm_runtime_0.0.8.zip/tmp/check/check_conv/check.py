import torch
import tensorflow as tf
import numpy as np

# 生成随机的输入张量和卷积核
input_shape = (8, 4, 24, 24) # (batch_size, channel, height, width)
kernel_shape = (32, 2, 3, 3) # (out_channel, in_channel, kernel_height, kernel_width)
input_data = np.random.randn(*input_shape).astype(np.float32)
kernel_data = np.random.randn(*kernel_shape).astype(np.float32)

# 使用 TensorFlow 执行卷积操作

tf_input = tf.constant(input_data)
kernel_data_tf = kernel_data.transpose(2,3,1,0)
tf_kernel = tf.constant(kernel_data_tf)
tf_output = tf.nn.conv2d(tf_input, tf_kernel, strides=[1, 1, 1, 1], padding="SAME",data_format="NCHW")
# tf_result = tf_output()

# 使用 PyTorch 执行卷积操作
pytorch_input = torch.tensor(input_data)
pytorch_kernel = torch.tensor(kernel_data)
pytorch_output = torch.nn.functional.conv2d(pytorch_input, pytorch_kernel, stride=1, padding=1,groups=2)
pytorch_result = pytorch_output.detach().numpy()

# 检查 TensorFlow 和 PyTorch 的卷积结果是否完全匹配
if np.allclose(tf_output, pytorch_result, rtol=1e-03, atol=1e-05):
    print("TensorFlow and PyTorch convolution results match.")
else:
    print("TensorFlow and PyTorch convolution results do not match.")