import torch
import os

os.environ['ALGICM_BACKEND'] = 'torch'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

from algicm.models.losses.iou_loss import IoULoss

x = torch.ones(2,4)
y = torch.ones(2,4,dtype=torch.long)
loss = IoULoss()
print(loss(x,y))