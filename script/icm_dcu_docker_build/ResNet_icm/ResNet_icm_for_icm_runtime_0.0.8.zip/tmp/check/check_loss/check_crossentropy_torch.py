import torch
import os

os.environ['ALGICM_BACKEND'] = 'torch'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
from algicm.models.backend.functional import weight_reduce_loss,no_grad ,split
from algicm.models.losses.cross_entropy import CrossEntropyLoss

x = torch.randn(3,4)
x_1,x_2 = split(x,2,axis=-1)
y = torch.ones(3,dtype=torch.long)
loss = CrossEntropyLoss()
print(loss(x,y))