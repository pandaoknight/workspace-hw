# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: htx
# @Date  : 2022/12/28
import os
from typing import Any

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
# os.environ["ALGICM_BACKEND"] = "torch"
# import torch

os.environ["ALGICM_BACKEND"] = "tensorflow"
import tensorflow as tf

from algicm.models.backend.core import (
    BaseModel,
    BaseDataProcessor,
    BasePostProcessor,
    BaseModule,
    Sequential,
)

from algicm.models.modules.backbone import ResNet
from algicm.models.layers.conv import Conv2d


class MyModel(BaseModel):
    def __init__(self, depth) -> None:
        super().__init__(
            data_postprocessor=BasePostProcessor(),
            data_preprocessor=BaseDataProcessor(),
        )
        self.backbone = ResNet(depth=depth)

    def forward(self, inputs):
        return self.backbone(inputs)


# model = Sequential(Conv2d(3, 3, 3), Conv2d(3, 3, 3))

# class MyModel(BaseModule):
#     def __init__(self, depth) -> None:
#         super().__init__()
#         self.backbone = ResNet(depth=depth)

#     def forward(self, inputs):
#         return self.backbone(inputs)


# a = MyModel()
model = MyModel(depth=18)
model.trainable_weights
# inputs = torch.randn([1, 3, 128, 128])
inputs = tf.ones([1, 3, 128, 128])
out = model(inputs)
print(out)


# # class A:
#     def foo(self):
#         print("Class A")

#     @property
#     def print_l(self):
#         # print("a", self.a)
#         print("Class A property")


# class B(A):
#     def foo(self):
#         print("Class B")


# class C(B):
#     def foo(self):
#         self.a = 2
#         print("Class C")


# class D(C):
#     pass

#     # @property
#     # def print_l(self):
#     #     print("Class A property")


# c = C()
# c.foo()
# c.print_l

# d = D()
# d.print_l

# import tensorflow as tf


# class Mymodel(tf.keras.layers.Layer):
#     def __init__(self, trainable=True, name=None, dtype=None, dynamic=False, **kwargs):
#         super().__init__(trainable, name, dtype, dynamic, **kwargs)
#         self.conv = tf.keras.layers.Conv2D(3, 3)
#         self.a = tf.Variasble(1)

#     def call(self, x):
#         return self.conv(x)


# model = Mymodel()
# model(tf.ones([1, 3, 3, 3]))
# print(1)
