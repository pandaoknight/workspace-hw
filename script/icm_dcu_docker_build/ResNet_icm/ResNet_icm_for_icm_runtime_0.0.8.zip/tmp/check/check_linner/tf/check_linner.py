import tensorflow as tf
import os
os.environ['ALGICM_BACKEND'] = 'tensorflow'
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
from algicm.models.layers.linear import Linear
linner = Linear(in_features=100,out_features=20)
input = tf.random.uniform(shape=(2,100))
print(linner(input).shape)