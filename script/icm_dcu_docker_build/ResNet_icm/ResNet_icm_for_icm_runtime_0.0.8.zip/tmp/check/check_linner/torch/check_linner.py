import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.linear import Linear
linner = Linear(in_features=100,out_features=20)
input = torch.rand(2,100)
print(linner(input).shape)