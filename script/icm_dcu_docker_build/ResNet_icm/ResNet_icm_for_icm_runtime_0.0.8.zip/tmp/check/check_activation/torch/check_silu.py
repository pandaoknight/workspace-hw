import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.activation import SiLU
act = SiLU()
input = torch.rand(8,2,100)
print(act(input).shape)