import tensorflow as tf
import os
os.environ['ALGICM_BACKEND'] = 'tensorflow'
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
from algicm.models.layers.activation import Softmax
act = Softmax()
input = tf.random.uniform(shape=(8,2,100))
print(act(input).shape)