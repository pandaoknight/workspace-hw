import torch
import os

os.environ["ALGICM_BACKEND"] = "torch"
from algicm.models.layers.upsample import DownSampling2d

conv = DownSampling2d(2, antialias=None,method="nearest")
input = torch.rand(1, 1, 32,32)
print(conv(input).shape)
