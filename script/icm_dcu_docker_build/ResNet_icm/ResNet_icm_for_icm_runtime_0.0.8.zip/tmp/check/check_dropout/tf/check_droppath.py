import tensorflow as tf
import os
os.environ['ALGICM_BACKEND'] = 'tensorflow'
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
from algicm.models.layers.dropout import DropPath
drop = DropPath(drop_prob=0.6)
input = tf.random.uniform(shape=(2,100))
print(drop(input).shape)