import tensorflow as tf
import os
os.environ['ALGICM_BACKEND'] = 'tensorflow'
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
from algicm.models.layers.dropout import Dropout
drop = Dropout()
input = tf.random.uniform(shape=(2,100))
print(drop(input).shape)