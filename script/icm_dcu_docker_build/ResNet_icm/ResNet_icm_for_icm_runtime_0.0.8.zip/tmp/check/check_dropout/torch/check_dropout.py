import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.dropout import Dropout
drop = Dropout()
input = torch.rand(2,100)
print(drop(input).shape)