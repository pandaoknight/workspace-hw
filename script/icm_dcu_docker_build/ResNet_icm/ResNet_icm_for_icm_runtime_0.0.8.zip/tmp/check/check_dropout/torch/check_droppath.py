import torch
import os
os.environ['ALGICM_BACKEND'] = 'torch'
from algicm.models.layers.dropout import DropPath
drop = DropPath()
input = torch.rand(2,100)
print(drop(input).shape)