#!/usr/bin/env python
# -*- encoding: utf-8 -*-
#File    :   build_torch_yolov5_model.py
#Time    :   2023/05/09 16:36:46
#Author  :   Tianqi 

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "torch"
from algicm.registry.common import MODELS
loss_cls_weight = 0.5
loss_bbox_weight = 0.05
loss_obj_weight = 1.0

# The scaling factor that controls the depth of the network structure
deepen_factor = 0.33
# The scaling factor that controls the width of the network structure
widen_factor = 0.5
num_classes = 80
num_det_layers = 3
img_scale = (640, 640)
norm_cfg = dict(type="BN2d", momentum=0.03, eps=0.001)
strides = [8, 16, 32]
anchors = [
    [(10, 13), (16, 30), (33, 23)],  # P3/8
    [(30, 61), (62, 45), (59, 119)],  # P4/16
    [(116, 90), (156, 198), (373, 326)],  # P5/32
]

model_test_cfg = dict(
    # The config of multi-label for multi-class prediction.
    multi_label=True,
    # The number of boxes before NMS
    nms_pre=30000,
    score_thr=0.001,  # Threshold to filter out boxes.
    nms=dict(type="nms", iou_threshold=0.65),  # NMS type and threshold
    max_per_img=300,
)  # Max number of detections of each image


model_cfg = dict(
    type="YOLODetector",
    data_preprocessor=dict(type="BaseDataProcessor"),
    data_postprocessor=dict(type="BasePostProcessor"),
    backbone=dict(
        type="YOLOv5CSPDarknet",
        deepen_factor=deepen_factor,
        widen_factor=widen_factor,
        norm_cfg=norm_cfg,
        act_cfg=dict(type="SiLU"),
    ),
    neck=dict(
        type="YOLOv5PAFPN",
        deepen_factor=deepen_factor,
        widen_factor=widen_factor,
        in_channels=[256, 512, 1024],
        out_channels=[256, 512, 1024],
        num_csp_blocks=3,
        norm_cfg=norm_cfg,
        act_cfg=dict(type="SiLU"),
    ),
    head=dict(
        type="YOLOv5Head",
        head_module=dict(
            type="YOLOv5HeadModule",
            num_classes=num_classes,
            in_channels=[256, 512, 1024],
            widen_factor=widen_factor,
            featmap_strides=strides,
            num_base_priors=3,
        ),
        prior_generator=dict(
            type="YOLOAnchorGenerator", base_sizes=anchors, strides=strides
        ),
        # scaled based on number of detection layers
        loss_cls=dict(
            type="CrossEntropyLoss",
            use_sigmoid=True,
            reduction="mean",
            loss_weight=loss_cls_weight * (num_classes / 80 * 3 / num_det_layers),
        ),
        loss_bbox=dict(
            type="IoULoss",
            iou_mode="ciou",
            bbox_format="xywh",
            eps=1e-7,
            reduction="mean",
            loss_weight=loss_bbox_weight * (3 / num_det_layers),
            return_iou=True,
        ),
        loss_obj=dict(
            type="CrossEntropyLoss",
            use_sigmoid=True,
            reduction="mean",
            loss_weight=loss_obj_weight
            * ((img_scale[0] / 640) ** 2 * 3 / num_det_layers),
        ),
        prior_match_thr=4.0,
        obj_level_weights=[4.0, 1.0, 0.4],
    ),
    test_cfg=model_test_cfg,
)


model = MODELS.build(model_cfg)
# back_out = model.backbone(torch.ones([1, 3, 256, 256]).cuda())
# neck_out = model.neck(back_out)
# out = model.head(neck_out)
# # model.head.compute_loss(*out,torch.randn([1,4]),torch.ones([1]),(256,256))
# print(123)
