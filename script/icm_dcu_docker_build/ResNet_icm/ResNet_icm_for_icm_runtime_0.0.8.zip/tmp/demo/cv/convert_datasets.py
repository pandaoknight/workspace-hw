import json

ball_datasets = json.load(
    open("obj_ball_val/Annotations/annotations.json", 'r'))
cat_datasets = json.load(open("cat_dataset/annotations/test.json", 'r'))
cat_datasets_id2_img_name = {
    i["id"]: [i["file_name"], i["height"], i["width"]]
    for i in cat_datasets["images"]
}
cat_data = dict(images=[])
for j in cat_datasets["annotations"]:
    assert isinstance(j["bbox"], list)
    list_ = []
    bboxes = [[int(i) for i in j["bbox"]] + [252]]
    anno_dict = dict(imgCategory=None,
                     caption=None,
                     bboxes=bboxes,
                     segmentations=None,
                     polyPoints=None,
                     keyPoints=None)
    dict_tmp = {}
    dict_tmp["fileName"] = cat_datasets_id2_img_name[j["image_id"]][0]
    dict_tmp["height"] = cat_datasets_id2_img_name[j["image_id"]][2]
    dict_tmp["width"] = cat_datasets_id2_img_name[j["image_id"]][1]
    dict_tmp["dataCaptured"] = None
    dict_tmp["annotations"] = anno_dict
    ball_datasets["images"].append(dict_tmp)

json.dump(cat_data, open("ball_cat_datasets_val.json", "w"))
