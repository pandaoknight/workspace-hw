import torch
import tensorflow as tf
from collections import OrderedDict
import pickle

faster_rcnn_parms = [
    "backbone.layer1.0.downsample.0.weight",
    "backbone.layer2.0.downsample.0.weight",
    "backbone.layer3.0.downsample.0.weight",
    "backbone.layer4.0.downsample.0.weight", "rpn_head.rpn_cls.weight",
    "rpn_head.rpn_reg.weight"
]


def torch2tf(torch_weight_path, tf_model):
    '''
    description: Convert torch weights to tf

    param {torch_weight_path} torch_weight_path

    param {tf_model} tf_model

    return {tf_h5}
    '''
    # try:
    tf_path = torch_weight_path.split('.')[0] + ".h5"
    all_weights = tf_model.all_weights

    torch_weights = torch.load(torch_weight_path)
    unexpected_keys = {}
    if not isinstance(torch_weights, OrderedDict):
        torch_weights = torch_weights["state_dict"]
    state_dict_name = list(torch_weights.keys())
    for weight in all_weights.keys():
        if weight in state_dict_name:
            model_weights = all_weights[weight]
            torch_weight = torch_weights[weight]

            if "bn" not in weight and "bias" not in weight and "conv" in weight or weight in faster_rcnn_parms:
                if model_weights.shape == torch_weight.detach().cpu().numpy(
                ).transpose([2, 3, 1, 0]).shape:
                    model_weights.assign(
                        torch_weight.detach().cpu().numpy().transpose(
                            [2, 3, 1, 0]))
                else:
                    unexpected_keys[
                        weight] = "maybe number of categories is not equal"
                    continue
            else:
                if model_weights.shape == torch_weight.shape:
                    model_weights.assign(torch_weight.detach().cpu().numpy())
                else:
                    unexpected_keys[
                        weight] = "maybe number of categories is not equal"
                    continue
        else:
            raise RuntimeError("The weight name does not match")
    # converted_weights = list(all_weights.values())
    converted_dict = {}
    converted_dict["state_dict"] = all_weights
    with open(tf_path, "wb") as f:
        pickle.dump(converted_dict, f)
    print(unexpected_keys)
    # except Exception as e:
    #     raise RuntimeError(f"Some error happens in convert checkpoint, {e}")
