import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["ALGICM_BACKEND"] = "tensorflow"
import json
from algicm.engine.tensorflow.runner import Runner
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description="ICM algorithms training.")
    parser.add_argument(
        "--config",
        default="demo/image_cls_mnist_train.json",
        help="Hyper parameter config path.",
    )
    args = parser.parse_args()
    return args

if __name__ == "__main__":
        args = parse_args()
        with open(args.config,"r") as f :
                cfg = json.load(f)
        runner = Runner.from_cfg(cfg)
        runner.train()