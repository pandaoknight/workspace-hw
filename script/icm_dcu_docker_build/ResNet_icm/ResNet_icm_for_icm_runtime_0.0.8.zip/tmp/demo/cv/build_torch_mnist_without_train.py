import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "torch"

from algicm.engine.pytorch.runner import Runner


cfg = dict(
    model=dict(
        type="ImageClassifier",
        data_preprocessor=dict(
            type="BaseDataProcessor",
            batch_preprocess=[dict(type="Stack", meta_keys=["img", "label"])],
        ),
        backbone=dict(type="ResNet", depth=18),
        neck=dict(type="GlobalAveragePooling"),
        head=dict(
            type="LinearClsHead",
            in_channels=512,
            num_classes=2,
            loss=dict(
                type="CrossEntropyLoss",
                use_sigmoid=False,
                reduction="mean",
            ),
        ),
    ),
    work_dir="work_dir/test_cifar",
    test_dataloader=dict(
        batch_size=1,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="ClsDataset",
            data_root="V1",
            pipelines=[
                dict(
                    type="WrapData",
                    mapping=dict(img="Image", label="ClassLabel"),
                ),
                dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
                dict(type="Resize", size=[128, 128], meta_keys=["img"]),
                dict(
                    type="Normalize",
                    mean=[123.675, 116.28, 103.53],
                    std=[58.395, 57.12, 57.375],
                    meta_keys=["img"],
                ),
                dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
            ],
        ),
    ),
    test_cfg=dict(
        type="TestLoop",
        evaluator=dict(
            type="Evaluator", metrics=[dict(type="MulticlassAccuracy", num_classes=2)]
        ),
    ),
    experiment_name="test_voc",
    default_hooks=dict(
        checkpoint=dict(type="CheckpointHook", interval=50, by_epoch=False),
        logger=dict(type="LoggerHook", interval=2),
        saver=dict(
            type="OutputSaveHook", formatter=dict(type="ImageClsOutputFormatter")
        ),
    ),
    load_from="work_dir/test_cifar/epoch_3.pth",
    randomness=dict(seed=123),
)

if __name__ == "__main__":
    runner = Runner.from_cfg(cfg)
    runner.test()
