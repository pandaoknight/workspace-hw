import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "torch"
import json
from algicm.engine.pytorch.runner import Runner


cfg = dict(
    model=dict(
        type="ImageClassifier",
        data_preprocessor=dict(
            type="BaseDataProcessor",
            batch_preprocess=[dict(type="Stack", meta_keys=["img", "label"])],
        ),
        backbone=dict(type="ResNet", depth=18),
        neck=dict(type="GlobalAveragePooling"),
        head=dict(
            type="LinearClsHead",
            in_channels=512,
            num_classes=10,
            loss=dict(
                type="CrossEntropyLoss",
                use_sigmoid=False,
                reduction="mean",
            ),
        ),
    ),
    work_dir="work_dir/test_cifar",
    train_dataloader=dict(
        batch_size=16,
        num_workers=2,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="MNIST",
            data_root="/data/sdv1/hetianxiang/icm/data/mnist",
            pipelines=[
                dict(
                    type="WrapData",
                    mapping=dict(img="Image", label="ClassLabel"),
                ),
                dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
                dict(type="Resize", size=[128, 128], meta_keys=["img"]),
                dict(
                    type="RandomFlip",
                    p=0.5,
                    direction="horizontal",
                    main_keys="img",
                ),
                dict(
                    type="Normalize",
                    mean=[123.675, 116.28, 103.53],
                    std=[58.395, 57.12, 57.375],
                    meta_keys=["img"],
                ),
                dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
            ],
        ),
    ),
    val_dataloader=dict(
        batch_size=16,
        num_workers=2,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="MNIST",
            data_root="/data/sdv1/hetianxiang/icm/data/mnist",
            data_type="val",
            pipelines=[
                dict(
                    type="WrapData",
                    mapping=dict(img="Image", label="ClassLabel"),
                ),
                dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
                dict(type="Resize", size=[128, 128], meta_keys=["img"]),
                dict(
                    type="Normalize",
                    mean=[123.675, 116.28, 103.53],
                    std=[58.395, 57.12, 57.375],
                    meta_keys=["img"],
                ),
                dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
            ],
        ),
    ),
    test_dataloader=dict(
        batch_size=16,
        num_workers=2,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="MNIST",
            data_root="/data/sdv1/hetianxiang/icm/data/mnist",
            data_type="test",
            pipelines=[
                dict(
                    type="WrapData",
                    mapping=dict(img="Image", label="ClassLabel"),
                ),
                dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
                dict(type="Resize", size=[128, 128], meta_keys=["img"]),
                dict(
                    type="Normalize",
                    mean=[123.675, 116.28, 103.53],
                    std=[58.395, 57.12, 57.375],
                    meta_keys=["img"],
                ),
                dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
            ],
        ),
    ),
    train_cfg=dict(
        type="EpochBasedTrainLoop", max_epochs=300, val_begin=1, val_interval=1
    ),
    optimizer=dict(type="SGD", lr=0.01, momentum=0.9, weight_decay=0.0001),
    val_cfg=dict(
        type="ValLoop",
        evaluator=dict(
            type="Evaluator", metrics=[dict(type="MulticlassAccuracy", num_classes=10)]
        ),
    ),
    test_cfg=dict(
        type="TestLoop",
        evaluator=dict(
            type="Evaluator", metrics=[dict(type="MulticlassAccuracy", num_classes=10)]
        ),
    ),
    experiment_name="test_voc",
    default_hooks=dict(
        checkpoint=dict(type="CheckpointHook", interval=50, by_epoch=False),
        logger=dict(type="LoggerHook", interval=2),
        saver=dict(
            type="OutputSaveHook", formatter=dict(type="ImageClsOutputFormatter")
        ),
    ),
    load_from="./work_dir/test_cifar/iter_50.pth",
    randomness=dict(seed=123),
)

if __name__ == "__main__":
    with open("demo/image_cls_mnist_train.json","r") as f :
        cfg = json.load(f)
    runner = Runner.from_cfg(cfg)
    runner.train()
