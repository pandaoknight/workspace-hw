from algicm.datasets.cv import COCODatasets
from algicm.datasets import DataLoader
from algicm.models.backend import BaseDataProcessor

pipelines = [
    dict(type="LoadImage"),
    dict(
        type="WrapData",
        mapping=dict(img="Image", bboxes="BoxArray", bbox_label="ClassLabel"),
    ),
    dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
    dict(type="Resize", size=[640, 640], meta_keys=["img", "bboxes"]),
    dict(type="RandomFlip", p=0.5, main_keys="img", meta_keys=["bboxes"]),
    dict(
        type="Normalize",
        mean=[123.675, 116.28, 103.53],
        std=[58.395, 57.12, 57.375],
        meta_keys=["img"],
    ),
    dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
]

dataset = COCODatasets(
    data_root="/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/",
    ann_file="train.json",
    data_prefix=dict(img_path="train"),
    pipelines=pipelines,
    classes=("balloon",),
)

data_processor = BaseDataProcessor(batch_preprocess=[dict(type="Stack")])
dataloader = DataLoader(dataset, 2)
for data in dataloader:
    data1 = data_processor(data)
    print(1)
