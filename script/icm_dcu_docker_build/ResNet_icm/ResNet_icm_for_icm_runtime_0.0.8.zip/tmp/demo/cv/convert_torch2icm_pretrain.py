import torch
import copy
from collections import OrderedDict


def torch2icm(torch_weight_path, icm_model):

    try:

        dict_ = torch.load(torch_weight_path, map_location="cpu")
        if dict_.get("state_dict") is not None:
            dict_ = dict_['state_dict']
        temp_dict = copy.deepcopy(dict_)
        for i, j in temp_dict.items():
            if i.endswith("tracked"):
                del dict_[i]
        if icm_model.state_dict().get("head.priors_base_sizes") is not None:
            dict_["head.priors_base_sizes"] = icm_model.state_dict(
            )["head.priors_base_sizes"]
            dict_["head.grid_offset"] = icm_model.state_dict(
            )["head.grid_offset"]
            dict_["head.prior_inds"] = icm_model.state_dict(
            )["head.prior_inds"]

        dict_model = copy.deepcopy(icm_model.state_dict())
        if dict_model.get("head.priors_base_sizes") is not None:
            dict_model.move_to_end("head.priors_base_sizes")
            dict_model.move_to_end("head.grid_offset")
            dict_model.move_to_end("head.prior_inds")

        for k, v in zip(dict_model.keys(), dict_.keys()):
            dict_model[k] = dict_[v]
        torch.save(dict_model, "pretrain.pth")
    except Exception as e:
        raise RuntimeError(f"Some error happens in convert checkpoint, {e}")
