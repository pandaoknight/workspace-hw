import os

# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"


def test_torch():
    os.environ["ALGICM_BACKEND"] = "torch"
    from algicm.models.layers.conv import Conv1d

    import torch

    layer = Conv1d(3, 3, 3)
    inputs = torch.ones([3, 3, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


def test_tf():
    os.environ["ALGICM_BACKEND"] = "tensorflow"
    from algicm.models.layers.conv import Conv1d
    import tensorflow as tf

    layer = Conv1d(3, 3, 3)
    inputs = tf.ones([3, 3, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


def test_torch_bn1d():
    os.environ["ALGICM_BACKEND"] = "torch"
    from algicm.models.layers.norm import BatchNorm1d

    import torch

    layer = BatchNorm1d(2)
    inputs = torch.ones([1, 2, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


def test_torch_bn1d():
    os.environ["ALGICM_BACKEND"] = "tensorflow"
    from algicm.models.layers.norm import BatchNorm1d

    import tensorflow as tf

    layer = BatchNorm1d(2)
    inputs = tf.ones([1, 2, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


def test_groupnorm():
    os.environ["ALGICM_BACKEND"] = "tensorflow"
    from algicm.models.layers.norm import GroupNorm
    import tensorflow as tf

    layer = GroupNorm(3, 3)
    inputs = tf.ones([3, 3, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


def test_instancenorm():
    os.environ["ALGICM_BACKEND"] = "tensorflow"
    from algicm.models.layers.norm import InstanceNorm1d
    import tensorflow as tf

    layer = InstanceNorm1d(3)
    inputs = tf.ones([3, 3, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


def test_instancenorm_torch():
    os.environ["ALGICM_BACKEND"] = "torch"
    from algicm.models.layers.norm import InstanceNorm1d
    import torch

    layer = InstanceNorm1d(3)
    inputs = torch.ones([3, 3, 3])
    out = layer(inputs)
    print(out, out.shape)
    print(layer)


# test_tf()
# test_torch()
# test_torch_bn1d()
test_instancenorm_torch()
