#!/usr/bin/env python
# -*- encoding: utf-8 -*-
#File    :   build_torch_yolov5_runner.py
#Time    :   2023/05/09 16:36:53
#Author  :   Tianqi

import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "torch"
from algicm.engine.pytorch.runner import Runner

classes = ("balloon", )
CocoMetric = dict(type="COCOMetric", num_classes=1)
loss_cls_weight = 0.5
loss_bbox_weight = 0.05
loss_obj_weight = 1.0

# The scaling factor that controls the depth of the network structure
deepen_factor = 0.33
# The scaling factor that controls the width of the network structure
widen_factor = 0.5
num_classes = 1
num_det_layers = 3
img_scale = (640, 640)
norm_cfg = dict(type="BN2d", momentum=0.03, eps=0.001)
strides = [8, 16, 32]
anchors = [
    [(10, 13), (16, 30), (33, 23)],  # P3/8
    [(30, 61), (62, 45), (59, 119)],  # P4/16
    [(116, 90), (156, 198), (373, 326)],  # P5/32
]

model_test_cfg = dict(
    # The config of multi-label for multi-class prediction.
    multi_label=True,
    # The number of boxes before NMS
    nms_pre=2000,
    score_thr=0.1,  # Threshold to filter out boxes.
    nms=dict(type="nms", iou_threshold=0.3),  # NMS type and threshold
    max_per_img=300,
)  # Max number of detections of each image

val_pipelines = [
    dict(type="LoadImage"),
    dict(
        type="WrapData",
        mapping=dict(img="Image"),
    ),
    dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
    dict(type="Resize", size=[640, 640], meta_keys=["img"]),
    dict(
        type="Normalize",
        mean=[0., 0., 0.],
        std=[255., 255., 255.],
        meta_keys=["img"],
    ),
    dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
]
pipelines = [
    dict(type="LoadImage"),
    dict(
        type="WrapData",
        mapping=dict(img="Image", bboxes="BoxArray", bbox_label="ClassLabel"),
    ),
    dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
    dict(type='Mosaic',
         meta_keys=["bboxes"],
         pre_transform=[
             dict(type="LoadImage"),
             dict(
                 type="WrapData",
                 mapping=dict(img="Image",
                              bboxes="BoxArray",
                              bbox_label="ClassLabel"),
             ),
             dict(type="ConvertDataType", dtype="float32", meta_keys=["img"])
         ]),
    dict(type="Resize", size=[640, 640], meta_keys=["img", "bboxes"]),
    dict(type="RandomFlip",
         p=0.5,
         direction='horizontal',
         main_keys="img",
         meta_keys=["bboxes"]),
    dict(
        type="Normalize",
        mean=[0.0, 0.0, 0.0],
        std=[255.0, 255.0, 255.0],
        meta_keys=["img"],
    ),
    dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
]

cfg = dict(
    model=dict(
        type="YOLODetector",
        data_preprocessor=dict(type="BaseDataProcessor",
                               batch_preprocess=[dict(type="Stack")]),
        backbone=dict(type="YOLOv5CSPDarknet",
                      deepen_factor=deepen_factor,
                      widen_factor=widen_factor,
                      norm_cfg=norm_cfg,
                      act_cfg=dict(type="SiLU"),
                      frozen_stages=4),
        neck=dict(
            type="YOLOv5PAFPN",
            deepen_factor=deepen_factor,
            widen_factor=widen_factor,
            in_channels=[256, 512, 1024],
            out_channels=[256, 512, 1024],
            num_csp_blocks=3,
            norm_cfg=norm_cfg,
            act_cfg=dict(type="SiLU"),
        ),
        head=dict(
            type="YOLOv5Head",
            head_module=dict(
                type="YOLOv5HeadModule",
                num_classes=num_classes,
                in_channels=[256, 512, 1024],
                widen_factor=widen_factor,
                featmap_strides=strides,
                num_base_priors=3,
            ),
            prior_generator=dict(type="YOLOAnchorGenerator",
                                 base_sizes=anchors,
                                 strides=strides),
            # scaled based on number of detection layers
            loss_cls=dict(
                type="CrossEntropyLoss",
                use_sigmoid=True,
                reduction="mean",
                loss_weight=loss_cls_weight,
            ),
            loss_bbox=dict(
                type="IoULoss",
                iou_mode="ciou",
                bbox_format="xywh",
                eps=1e-7,
                reduction="mean",
                loss_weight=loss_bbox_weight,
                return_iou=True,
            ),
            loss_obj=dict(
                type="CrossEntropyLoss",
                use_sigmoid=True,
                reduction="mean",
                loss_weight=loss_obj_weight,
            ),
            prior_match_thr=4.0,
            obj_level_weights=[4.0, 1.0, 0.4],
        ),
        test_cfg=model_test_cfg,
    ),
    work_dir="work_dir/test_yolov5",
    train_dataloader=dict(
        batch_size=16,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=True),
        dataset=dict(
            type="COCODatasets",
            data_root="/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/",
            ann_file="train.json",
            data_prefix=dict(img_path="train"),
            pipelines=pipelines,
            classes=classes),
    ),
    val_dataloader=dict(
        batch_size=1,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="COCODatasets",
            data_root="/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/",
            ann_file="val.json",
            data_prefix=dict(img_path="val"),
            pipelines=val_pipelines,
            classes=("balloon", ),
        )),
    train_cfg=dict(type="EpochBasedTrainLoop",
                   max_epochs=300,
                   val_begin=10,
                   val_interval=1),
    val_cfg=dict(type="ValLoop",
                 evaluator=dict(type="Evaluator", metrics=CocoMetric)),
    optimizer=dict(type="SGD", lr=0.01, momentum=0.9, weight_decay=0.0001),
    # optimizer=dict(type="AdamW",lr=0.01),
    experiment_name="test_voc",
    default_hooks=dict(checkpoint=dict(type="CheckpointHook",
                                       interval=50,
                                       by_epoch=False),
                       logger=dict(type="LoggerHook", interval=2)),
    randomness=dict(seed=123)
    # load_from = "work_dir/test_yolov5/iter_50.pth",
)

if __name__ == "__main__":
    runner = Runner.from_cfg(cfg)
    runner.train()
