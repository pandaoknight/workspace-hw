import argparse
import os 
import json
from algicm.service.controller import run_controller
from algicm.service.server import run_server


def parse_args():
    parser = argparse.ArgumentParser(description="Depoly a model")
    parser.add_argument(
        "--config",
        default="demo/controller.json",
        help="inference config file path",
    )

    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = parse_args()
    with open(args.config) as f:
        config = json.loads(f.read())
    # config = Config.fromfile(args.config)
    # envs = config.get("env")
    os.environ["USE_CONTROLLER"]  = str(config["USE_CONTROLLER"])
    USE_CONTROLLER = (
        True if os.environ.get("USE_CONTROLLER", "false").lower() == "true" else False
    )
    
    if USE_CONTROLLER:
        run_controller(config)
    else:
        run_server(config)
