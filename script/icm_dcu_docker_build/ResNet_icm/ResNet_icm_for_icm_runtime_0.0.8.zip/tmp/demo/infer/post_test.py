
import requests
import json
def start_torch_infer():
     data = {
    "file":"infer_torch.json"
}   
     requests.post("http://127.0.0.1:18082/register",json=data)
def start_tensorflow_infer():
     data = {
    "file":"infer_tensorflow.json"
}      
     requests.post("http://127.0.0.1:18082/register",json=data)
def stop_infer():
     pid = {
    "pid":3744563
}   
     
     requests.post("http://127.0.0.1:18082/unregister",json=pid)

def infer_torch():
     path = "/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/val/6810773040_3d81036d05_k.jpg"
     infer_img = {"img_path":path
            ,"data_meta":[{'classes': ('balloon',)}]}
    #  infer_img = json.dumps(infer_img)
     return requests.post("http://127.0.0.1:28084/infer_torch",json=infer_img)
def infer_tensorflow():
     path = "/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/val/6810773040_3d81036d05_k.jpg"
     infer_img = {"img_path":path
            ,"data_meta":[{'classes': ('balloon',)}]}
    #  infer_img = json.dumps(infer_img)
     return requests.post("http://127.0.0.1:28085/infer_tf",json=infer_img)
if __name__ == "__main__":
     start_tensorflow_infer()
     # out1 = infer_tensorflow()
     # out2 = infer_torch()
     # print(out1.text,out2.text)