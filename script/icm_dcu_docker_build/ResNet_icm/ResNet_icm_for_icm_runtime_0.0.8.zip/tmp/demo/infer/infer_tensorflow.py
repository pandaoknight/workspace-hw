import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "tensorflow"
import tensorflow as tf
import cv2
from collections import OrderedDict
from algicm.registry.common import MODELS
from algicm.datasets.cv.det import COCODatasets
# from algicm.models.pytorch import *
from algicm.transform.transform import Resize 
    # Normalize, ToDataType, MinibatchTransform, Stack, RandomHorizontalFlip,\
    # RandomRotateRightAngle, RandomVerticalFlip, RandomTranspose
from algicm.transform.annotation import Image,BoxArray
import numpy as np
from algicm.transform.transform import Compose
from algicm.models.backend.core.tensorflow.checkpoint import load_checkpoint,_load_checkpoint_to_model
# from demo.convert_weights_torch2tf import torch2tf

def setup_env():
        # init hvd
        

        # set growth memory
        gpus = tf.config.experimental.list_physical_devices("GPU")
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        
setup_env()
loss_cls_weight = 0.5
loss_bbox_weight = 0.05
loss_obj_weight = 1.0

# The scaling factor that controls the depth of the network structure
deepen_factor = 0.33
# The scaling factor that controls the width of the network structure
widen_factor = 0.5
num_classes = 1
num_det_layers = 3
img_scale = (640, 640)
norm_cfg = dict(type="BN2d", momentum=0.03, eps=0.001)
strides = [8, 16, 32]
anchors = [
    [(10, 13), (16, 30), (33, 23)],  # P3/8
    [(30, 61), (62, 45), (59, 119)],  # P4/16
    [(116, 90), (156, 198), (373, 326)],  # P5/32
]

model_test_cfg = dict(
    # The config of multi-label for multi-class prediction.
    multi_label=True,
    # The number of boxes before NMS
    nms_pre=2000,
    score_thr=0.3,  # Threshold to filter out boxes.
    nms=dict(type="nms", iou_threshold=0.3),  # NMS type and threshold
    max_per_img=300,
)  # Max number of detections of each image


model_cfg = dict(
    type="YOLODetector",
    data_preprocessor=dict(type="BaseDataProcessor",
                           batch_preprocess=[dict(type="Stack")]
                          ),
    # data_postprocessor=dict(type="BasePostProcessor"),
    backbone=dict(
        type="YOLOv5CSPDarknet",
        deepen_factor=deepen_factor,
        widen_factor=widen_factor,
        norm_cfg=norm_cfg,
        act_cfg=dict(type="SiLU"),
    ),
    neck=dict(
        type="YOLOv5PAFPN",
        deepen_factor=deepen_factor,
        widen_factor=widen_factor,
        in_channels=[256, 512, 1024],
        out_channels=[256, 512, 1024],
        num_csp_blocks=3,
        norm_cfg=norm_cfg,
        act_cfg=dict(type="SiLU"),
    ),
    head=dict(
        type="YOLOv5Head",
        head_module=dict(
            type="YOLOv5HeadModule",
            num_classes=num_classes,
            in_channels=[256, 512, 1024],
            widen_factor=widen_factor,
            featmap_strides=strides,
            num_base_priors=3,
        ),
        prior_generator=dict(
            type="YOLOAnchorGenerator", base_sizes=anchors, strides=strides
        ),
        # scaled based on number of detection layers
        loss_cls=dict(
            type="CrossEntropyLoss",
            use_sigmoid=True,
            reduction="mean",
            loss_weight=loss_cls_weight ,
        ),
        loss_bbox=dict(
            type="IoULoss",
            iou_mode="ciou",
            bbox_format="xywh",
            eps=1e-7,
            reduction="mean",
            loss_weight=loss_bbox_weight ,
            return_iou=True,
        ),
        loss_obj=dict(
            type="CrossEntropyLoss",
            use_sigmoid=True,
            reduction="mean",
            loss_weight=loss_obj_weight
            ,
        ),
        prior_match_thr=4.0,
        obj_level_weights=[4.0, 1.0, 0.4],
    ),
    test_cfg=model_test_cfg,
)

import copy
pipelines = [
    dict(type="LoadImage"),
    dict(
        type="WrapData",
        mapping=dict(img="Image"),
    ),
    dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
    dict(type="Resize", size=[640, 640], meta_keys=["img"]),
    dict(
        type="Normalize",
        mean=[0., 0., 0.],
        std=[255., 255., 255.],
        meta_keys=["img"],
    ),
    dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
]

list_ = ["head.priors_base_sizes","head.grid_offset","head.prior_inds"]
model = MODELS.build(model_cfg)

# torch2tf("work_dir/test_yolov5/iter_1050.pth",model)
pipeline = Compose(pipelines)
ckpt = load_checkpoint("work_dir/test_yolov5/epoch_20.h5",map_location="cpu")
_load_checkpoint_to_model(model,ckpt,strict=False)
model.set_eval()
path = "/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/val/6810773040_3d81036d05_k.jpg"
root_path = "/data/sdv1/zhoutianqi/mmyolo-main/data/balloon/val"
path_dir = os.listdir(root_path)

num = 0 
for dir in path_dir:
    if dir.endswith(".jpg"):
        path = os.path.join(root_path,dir)
        img = {"img_path":path
            ,"data_meta":[]}
        img_test = pipeline(img)
        img_test_list = []
        img_test_list.append(img_test)
        out = model.test_step(img_test_list)

        
        pred_instances = out[0]["bboxes"]
        img = cv2.imread(path)
        for i in pred_instances:
            i = i.astype(np.int32)
            cv2.rectangle(img,[i[0],i[1]],[i[2],i[3]],color=[255,255,0],thickness=3)
        
        cv2.imwrite(f'infer_tf_out/tf{num}.jpg',img)
        num+=1
