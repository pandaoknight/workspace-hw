#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# File    :   build_torch_yolov5_runner.py
# Time    :   2023/05/09 16:36:53
# Author  :   Tianqi
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["ALGICM_BACKEND"] = "torch"
from algicm.engine.pytorch.runner import Runner
# from algicm.models.structure import Relation_Extraction

cfg = dict(
    model=dict(
        # type="TextClassification",
        type="NER",
        data_preprocessor=dict(
            type="BaseDataProcessor",
            batch_preprocess=[
                dict(type="BertTokenizer", vocab_file="/data/sdv1/ICM_DEMO/icm-merge_tlx-8371b80232d4dc3089b0d5aacf5a22268d0cc27c/demo/nlp/vocab.txt",max_length=128),
                dict(
                    type="Stack",
                    meta_keys=["text","input_ids", "label", "attention_mask", "token_type_ids"],
                ),
            ],
        ),
        backbone=dict(type="Bert", arch="bert-base-uncased", vocab_size=21128,add_pooling_layer=False),
        neck=dict(type="BertNeck", p=0.1,return_hidden_out=True),
        head=dict(
            # type="LinearClsHead",
            type="NERClsHead",
            num_classes=33,
            in_channels=768,
            # loss=dict(type="CrossEntropyLoss", use_sigmoid=False, reduction="mean"),
            loss=dict(type="CRFLoss",   reduction="mean"),
        ),
    ),
    work_dir="work_dir/bert",
    train_dataloader=dict(
        batch_size=32,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=True),
        dataset=dict(
            # type="Text_Dataset",
            type="NER_dataset",
            data_root="/data/sdv1/ICM_DEMO/icm-merge_tlx-8371b80232d4dc3089b0d5aacf5a22268d0cc27c/demo/nlp/data/train.txt",#/data/sdv1/hetianxiang/icm/data/aclImdb/test
            max_length=128,
            # data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/test",
            pipelines=[
                dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
            ],
        ),
    ),

    val_dataloader=dict(
            batch_size=1,
            num_workers=1,
            sampler=dict(type="DefaultSampler", shuffle=False),
            dataset=dict(
                type="NER_dataset",
                data_root="/data/sdv1/ICM_DEMO/icm-merge_tlx-8371b80232d4dc3089b0d5aacf5a22268d0cc27c/demo/nlp/data/val.txt",#/data/sdv1/hetianxiang/icm/data/aclImdb/test
                max_length=128,
                # data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/test",
                pipelines=[
                    dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
                ],
            ),
    ),
    test_dataloader=dict(
        batch_size=1,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="NER_dataset",
            data_root="/data/sdv1/ICM_DEMO/icm-merge_tlx-8371b80232d4dc3089b0d5aacf5a22268d0cc27c/demo/nlp/data/train.txt",
            # /data/sdv1/hetianxiang/icm/data/aclImdb/test
            max_length=128,
            # data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/test",
            pipelines=[
                dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
            ],
        ),
    ),
    train_cfg=dict(
        type="EpochBasedTrainLoop", max_epochs=300, val_begin=1, val_interval=1
    ),
    val_cfg=dict(type="ValLoop", evaluator=dict(type="Evaluator", metrics=[
                {
                    "type": "Nlp_PFR_Metric",

                }]))
                                                ,
test_cfg = dict(type="TestLoop", evaluator=dict(type="Evaluator", metrics=[
    {
        "type": "Nlp_PFR_Metric",

    }]))
,
    # val_cfg=dict(type="ValLoop"),
    optimizer=dict(type="AdamW", lr=0.0001),
    experiment_name="test_bert",
    default_hooks=dict(
        checkpoint=dict(type="CheckpointHook", interval=10, by_epoch=True),
        logger=dict(type="LoggerHook", interval=1),
    ),
    randomness=dict(seed=123),
    load_from="work_dir/bert/epoch_10.pth",
)

if __name__ == "__main__":
    # import json
    # json.dump(cfg,open("icm_test_json/bert_ner/ner_train.json","w"))
    runner = Runner.from_cfg(cfg)
    runner.train()
    # runner.test()
