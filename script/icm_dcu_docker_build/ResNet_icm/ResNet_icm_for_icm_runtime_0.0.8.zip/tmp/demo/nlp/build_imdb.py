from algicm.datasets.nlp.cls.imdb_dataset import IMDBDataset
from algicm.transform.transform.batch import Stack
from algicm.datasets import DataLoader


# pipelines = [
#     dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel")),
#     dict(type="RegularMatchFilter"),
#     dict(type="LowerChars"),
#     dict(type="Truncate"),
#     dict(type="JiebaCut"),
#     dict(type="FilterChar", stop_files="./work_dir/stopword.txt"),
#     dict(type="TokenToId"),
#     dict(type="PadText"),
# ]


ds = IMDBDataset(
    
    data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/test"
    # pipelines=pipelines,
)

dataloader = DataLoader(dataset=ds, batch_size=16)
# out = dataloader.n[0]
for data in dataloader:
    print(data)
stack = Stack(meta_keys=["text"])
