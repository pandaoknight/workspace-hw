#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# File    :   build_torch_yolov5_runner.py
# Time    :   2023/05/09 16:36:53
# Author  :   Tianqi

import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["ALGICM_BACKEND"] = "tensorflow"
from algicm.engine.tensorflow.runner import Runner


cfg = dict(
    model=dict(
        type="TextClassification",
        data_preprocessor=dict(
            type="BaseDataProcessor",
            batch_preprocess=[
                dict(type="BertTokenizer", vocab_file="/data/sdv1/zhoutianqi/icm_tlx/icm/demo/nlp/vocab.txt"),
                dict(type="Stack",meta_keys=["text", "label", "attention_mask", "token_type_ids"]),
            ],
        ),
        backbone=dict(type="Bert", arch="bert-base-chinese", vocab_size=21128),
        neck=dict(type="BertNeck",p=0.1),
        head=dict(type="LinearClsHead", num_classes=2, in_channels=768,
                  loss=dict(
                  type="CrossEntropyLoss",
                  use_sigmoid=False,
                  reduction="mean"))),
    work_dir="work_dir/bert",
    train_dataloader=dict(batch_size=64,
                    num_workers=1,
                    sampler=dict(type="DefaultSampler", shuffle=True),
                    dataset=dict(type="IMDBDataset",
                                 data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/train",
                                 pipelines=[dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))])),
    train_cfg=dict(type="EpochBasedTrainLoop", 
                   max_epochs=300, 
                   val_begin=30, 
                   val_interval=10),
    # val_cfg=dict(type="ValLoop", evaluator=dict(type="Evaluator", metrics=CocoMetric)),
    val_dataloader=dict(
        batch_size=64,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="IMDBDataset",
            data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/test",
            pipelines=[
                dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
            ],
        ),
    ),
    val_cfg=dict(
        type="ValLoop",
        evaluator=dict(
            type="Evaluator", metrics=[dict(type="Accuracy", num_classes=2)]
        ),
    ),
    # optimizer=dict(type="SGD", lr=0.01, momentum=0.9, weight_decay=0.0001),
    optimizer=dict(type="AdamW", lr=0.00001),
    experiment_name="test_bert",
    default_hooks=dict(checkpoint=dict(type="CheckpointHook", interval=1, by_epoch=True),
                       logger=dict(type="LoggerHook", interval=1)),
    randomness=dict(seed=123),
    load_from="work_dir/bert/epoch_6.h5",
)

if __name__ == "__main__":
    runner = Runner.from_cfg(cfg)
    runner.train()



