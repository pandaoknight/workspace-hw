from collections import OrderedDict
import torch

new_dict = OrderedDict()
ckpt = torch.load("/data/sdv1/zhoutianqi/Huggingface_Toturials-main/pre_train_torch.pth")
for i,j in ckpt.items():
    if "output" in i :
        i = i.replace("output","dense_output")
    new_dict["backbone."+i] = j
torch.save(new_dict,"bert_chinese_icm_pretrain.pth")