#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# File    :   build_torch_yolov5_runner.py
# Time    :   2023/05/09 16:36:53
# Author  :   Tianqi
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "torch"
from algicm.engine.pytorch.runner import Runner
# from algicm.models.structure import Relation_Extraction

cfg = dict(
    model=dict(
        type="Relation_Extraction",
        data_preprocessor=dict(
            type="BaseDataProcessor",
            batch_preprocess=[
                dict(type="BertTokenizer", vocab_file="demo/nlp/vocab.txt",task = "relation"),
                dict(
                    type="Stack",
                    meta_keys=["text", "label", "attention_mask", "token_type_ids","sub_obj"],
                ),
            ],
        ),
        backbone=dict(type="Bert", arch="bert-base-uncased", vocab_size=21128),
        neck=dict(type="BertNeck", p=0.1,return_hidden_out = True),
        head=dict(
            type="LinearClsHead",
            num_classes=10,
            in_channels=1536,
            loss=dict(type="CrossEntropyLoss", use_sigmoid=False, reduction="mean"),
        ),
    ),
    work_dir="work_dir/bert",
    train_dataloader=dict(
        batch_size=32,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=True),
        dataset=dict(
            type="Relation_dataset",
            data_root="datasets/data/train.txt",#/data/sdv1/hetianxiang/icm/data/aclImdb/test
            # data_root="/data/sdv1/hetianxiang/icm/data/aclImdb/test",
            pipelines=[
                dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
            ],
            config = "datasets/data/entity_relation_tag.json"
        ),
    ),
    train_cfg=dict(
        type="EpochBasedTrainLoop", max_epochs=300, val_begin=30, val_interval=10
    ),
    # val_cfg=dict(type="ValLoop", evaluator=dict(type="Evaluator", metrics=CocoMetric)),
    optimizer=dict(type="AdamW", lr=0.00001),
    experiment_name="test_bert",
    default_hooks=dict(
        checkpoint=dict(type="CheckpointHook", interval=1, by_epoch=True),
        logger=dict(type="LoggerHook", interval=1),
    ),
    randomness=dict(seed=123),
    load_from="pretrain/bert_chinese_icm_pretrain.pth",
)

if __name__ == "__main__":
    import json
    json.dump(cfg,open("icm_test_json/ber_relation/relation_train.json","w"))
    runner = Runner.from_cfg(cfg)
    runner.train()
