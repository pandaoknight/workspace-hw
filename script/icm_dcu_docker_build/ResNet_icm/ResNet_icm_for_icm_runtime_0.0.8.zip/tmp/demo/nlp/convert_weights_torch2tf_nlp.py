import torch
import tensorflow as tf
from collections import OrderedDict
import pickle


def torch2tf(torch_weight_path, tf_model):
    '''
    description: Convert torch weights to tf

    param {torch_weight_path} torch_weight_path

    param {tf_model} tf_model

    return {tf_h5}
    '''
    try:
        tf_path = torch_weight_path.split('.')[0] + ".h5"
        all_weights = tf_model.all_weights
        tensors_to_transpose = ("dense.weight", "attention.self.query",
                                "attention.self.key", "attention.self.value")
        torch_weights = torch.load(torch_weight_path)
        unexpected_keys = {}
        if not isinstance(torch_weights, OrderedDict):
            torch_weights = torch_weights["state_dict"]
        state_dict_name = list(torch_weights.keys())
        for weight in all_weights.keys():
            if weight in state_dict_name:
                model_weights = all_weights[weight]
                torch_weight = torch_weights[weight]
                if any(x in weight for x in tensors_to_transpose):
                    # torch_weight = torch_weight.T

                    model_weights.assign(torch_weight.detach().cpu().numpy())
                else:
                    model_weights.assign(torch_weight.detach().cpu().numpy())
            else:
                unexpected_keys[
                    weight] = "maybe number of categories is not equal"
                continue

        # converted_weights = list(all_weights.values())
        converted_dict = {}
        converted_dict["state_dict"] = all_weights
        with open(tf_path, "wb") as f:
            pickle.dump(converted_dict, f)
        print(unexpected_keys)
    except Exception as e:
        raise RuntimeError(f"Some error happens in convert checkpoint, {e}")
