#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# File    :   build_torch_yolov5_runner.py
# Time    :   2023/05/09 16:36:53
# Author  :   Tianqi
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "torch"
from algicm.engine.pytorch.runner import Runner
import json

cfg = dict(
    model=dict(
        type="TextClassification",
        data_preprocessor=dict(
            type="BaseDataProcessor",
            batch_preprocess=[
                dict(type="BertTokenizer", vocab_file="demo/nlp/vocab.txt"),
                dict(
                    type="Stack",
                    meta_keys=["text", "label", "attention_mask", "token_type_ids"],
                ),
            ],
        ),
        backbone=dict(type="Bert", arch="bert-base-chinese", vocab_size=21128),
        neck=dict(type="BertNeck", p=0.1),
        head=dict(
            type="LinearClsHead",
            num_classes=2,
            in_channels=768,
            loss=dict(type="CrossEntropyLoss", use_sigmoid=False, reduction="mean"),
        ),
    ),
    work_dir="work_dir/bert",
    train_dataloader=dict(
        batch_size=64,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=True),
        dataset=dict(
            type="Text_Dataset",
            data_root="bert_cls_data/text_cls.json",
            pipelines=[
                dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
            ],
        ),
    ),
    val_dataloader=dict(
        batch_size=64,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset=dict(
            type="Text_Dataset",
            data_root="bert_cls_data/text_cls.json",
            pipelines=[
                dict(type="WrapData", mapping=dict(text="Text", label="ClassLabel"))
            ],
        ),
    ),
    train_cfg=dict(
        type="EpochBasedTrainLoop", max_epochs=300, val_begin=1, val_interval=1
    ),
    # val_cfg=dict(type="ValLoop", evaluator=dict(type="Evaluator", metrics=CocoMetric)),
    val_cfg=dict(
        type="ValLoop",
        evaluator=dict(
            type="Evaluator", metrics=[dict(type="MulticlassAccuracy", num_classes=2)]
        ),
    ),
    # 0.00001
    # 0.0005
    # optimizer=dict(type="SGD", lr=0.01, momentum=0.9, weight_decay=0.0001),
    optimizer=dict(type="AdamW", lr=0.00001),
    experiment_name="test_bert",
    default_hooks=dict(
        checkpoint=dict(type="CheckpointHook", interval=1, by_epoch=True),
        logger=dict(type="LoggerHook", interval=1),
    ),
    randomness=dict(seed=123),
    load_from="pretrain/bert_chinese_icm_pretrain.pth",
)

if __name__ == "__main__":
    # json.dump(cfg,open("demo/bert_cls/text_cls_train.json","w"))
    runner = Runner.from_cfg(cfg)
    runner.train()