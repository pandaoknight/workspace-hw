#!/usr/bin/env python
# -*- encoding: utf-8 -*-
#File    :   build_torch_yolov5_runner.py
#Time    :   2023/05/09 16:36:53
#Author  :   Tianqi 

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["ALGICM_BACKEND"] = "tensorflow"
# os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
from algicm.engine.tensorflow.runner import Runner


CocoMetric = dict(
    type="SegMetric",
    num_classes = 4
)


val_pipelines =[
    dict(type="LoadImage"),
    dict(
        type="WrapData",
        mapping=dict(img="Image", seg_map="Mask"),
    ),
    dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
    dict(type="Resize", size=[640, 640], meta_keys=["img","seg_map"]),
    dict(
        type="Normalize",
        mean=[123.675, 116.28, 103.53],
        std=[58.395, 57.12, 57.375],
        meta_keys=["img"],
    ),
    dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
]
pipelines = [
    dict(type="LoadImage"),
    dict(
        type="WrapData",
        mapping=dict(img="Image", seg_map="Mask"),
    ),
    dict(type="ConvertDataType", dtype="float32", meta_keys=["img"]),
    dict(type="Resize", size=[640, 640], meta_keys=["img", "seg_map"]),
    dict(type="RandomFlip", p=0.5, direction='horizontal', main_keys="img", meta_keys=["seg_map"]),
    dict(
        type="Normalize",
        mean=[123.675, 116.28, 103.53],
        std=[58.395, 57.12, 57.375],
        meta_keys=["img"],
    ),
    dict(type="Transpose", axes=[2, 0, 1], meta_keys=["img"]),
]

norm_cfg = dict(type="BN2d", momentum=0.03, eps=0.001)
cfg = dict(
    model = dict(
    type='EncoderDecoder',
    data_preprocessor=dict(type="BaseDataProcessor",batch_preprocess=[dict(type="Stack",meta_keys=["img", "seg_map"])]),
    backbone=dict(
        type='UNet',
        in_channels=3,
        base_channels=64,
        num_stages=5,
        strides=(1, 1, 1, 1, 1),
        enc_num_convs=(2, 2, 2, 2, 2),
        dec_num_convs=(2, 2, 2, 2),
        downsamples=(True, True, True, True),
        enc_dilations=(1, 1, 1, 1, 1),
        dec_dilations=(1, 1, 1, 1),
        conv_cfg=None,
        norm_cfg=norm_cfg,
        act_cfg=dict(type='ReLU'),
        upsample_cfg=dict(type='InterpConv'),
        norm_eval=False),
    decode_head=dict(
        type='FCNHead',
        in_channels=64,
        in_index=4,
        channels=64,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=4,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(
            type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0)),
    auxiliary_head=dict(
        type='FCNHead',
        in_channels=128,
        in_index=3,
        channels=64,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=4,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(
            type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4)),
    # model training and testing settings
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))
    ,
    work_dir="work_dir/test_unet",
    train_dataloader=dict(
        batch_size=1,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=True),
        dataset = dict(type = "SegDataset",
        data_root="obj_data",
        # ann_file="train.json",
        # data_prefix=dict(img_path="train"),
        pipelines=pipelines,
        # classes=classes
),  

    ),
    val_dataloader=dict(batch_size=1,
        num_workers=1,
        sampler=dict(type="DefaultSampler", shuffle=False),
        dataset = dict(type = "SegDataset",
        data_root="obj_data",
        # ann_file="val.json",
        # data_prefix=dict(img_path="val"),
        pipelines=val_pipelines,
        # classes=("balloon",),
        )),
    train_cfg=dict(type="EpochBasedTrainLoop", max_epochs=300,
                   val_begin = 1,
                   val_interval = 1),
                   
    val_cfg = dict(type="ValLoop",evaluator = dict(type="Evaluator",metrics = CocoMetric)),

    optimizer=dict(type="SGD", lr=0.01, momentum=0.9, weight_decay=0.0001),
    # optimizer=dict(type="AdamW",lr=0.01),
    experiment_name="test_voc",
    default_hooks=dict(
        checkpoint=dict(type="CheckpointHook", interval=50, by_epoch=False),
        logger=dict(type="LoggerHook",interval=2)
    ),
    randomness=dict(seed=123)
    
)

if __name__ == "__main__":
    runner = Runner.from_cfg(cfg)
    runner.train()
